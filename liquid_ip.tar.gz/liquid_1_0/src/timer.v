module timer(clk, enable, reset, count_val, counter_out);
input clk, enable, reset;
input [4:0] count_val;
output counter_out;

reg [28:0] count_clk_cycles;
reg [4:0]  count_seconds;
reg        counter_out;
reg        started;

parameter MAX_COUNT = 29'd49999999;

always @(posedge clk) begin
    if (reset) begin
        count_clk_cycles <= 29'd0;
        count_seconds    <= 4'd0;
        counter_out      <= 1'd0;
        started          <= 1'b0;
    end
    else if (enable && !started) begin
        // Start the timer
        count_seconds    <= count_val;
        count_clk_cycles <= 29'd0;
        counter_out      <= (count_val != 4'd0) ? 1'd1 : 1'd0;
        started          <= 1'b1;
    end
    else if (started) begin
        // Timer is running
        if (count_seconds != 4'd0) begin
            if (count_clk_cycles < MAX_COUNT - 1) begin
                count_clk_cycles <= count_clk_cycles + 29'd1;
                counter_out      <= 1'd1;
            end 
            else begin
                count_clk_cycles <= 29'd0;
                count_seconds    <= count_seconds - 4'd1;
                counter_out      <= (count_seconds != 4'd1) ? 1'd1 : 1'd0;
            end
        end
        else begin
            // Timer finished
            counter_out <= 1'd0;
            started     <= 1'b0;
        end
    end
end

endmodule