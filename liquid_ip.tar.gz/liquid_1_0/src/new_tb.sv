`timescale 1ns / 1ps

module arthur_tb;

// ===============================================
// Testbench Signals
// ===============================================
reg clk;
reg reset;
reg [7:0] relay_incoming;
reg request_receive;
reg [8:0] relay_0_liquid_amount;
reg [8:0] relay_1_liquid_amount;
reg [8:0] relay_2_liquid_amount;
reg [8:0] relay_3_liquid_amount;
reg [8:0] relay_4_liquid_amount;
reg [8:0] relay_5_liquid_amount;
reg [8:0] relay_6_liquid_amount;
reg [8:0] relay_7_liquid_amount;
wire [7:0] relay_enable_out;

// ===============================================
// Clock Generation (50MHz = 20ns period)
// ===============================================
initial begin
    clk = 0;
    forever #10 clk = ~clk;  // 20ns period
end

// ===============================================
// DUT Instantiation
// ===============================================
arthur dut (
    .clk(clk),
    .reset(reset),
    .relay_incoming(relay_incoming),
    .request_receive(request_receive),
    .relay_0_liquid_amount(relay_0_liquid_amount),
    .relay_1_liquid_amount(relay_1_liquid_amount),
    .relay_2_liquid_amount(relay_2_liquid_amount),
    .relay_3_liquid_amount(relay_3_liquid_amount),
    .relay_4_liquid_amount(relay_4_liquid_amount),
    .relay_5_liquid_amount(relay_5_liquid_amount),
    .relay_6_liquid_amount(relay_6_liquid_amount),
    .relay_7_liquid_amount(relay_7_liquid_amount),
    .relay_enable_out(relay_enable_out)
);

// ===============================================
// Test Stimulus
// ===============================================
initial begin
    // Initialize all signals
    reset = 1;
    request_receive = 0;
    relay_incoming = 8'b00000000;
    relay_0_liquid_amount = 9'd0;
    relay_1_liquid_amount = 9'd0;
    relay_2_liquid_amount = 9'd0;
    relay_3_liquid_amount = 9'd0;
    relay_4_liquid_amount = 9'd0;
    relay_5_liquid_amount = 9'd0;
    relay_6_liquid_amount = 9'd0;
    relay_7_liquid_amount = 9'd0;
    
    // Wait for a few cycles
    repeat(3) @(posedge clk);
    
    // Release reset
    @(posedge clk);
    reset = 0;
    $display("=== Reset released at time %t ===", $time);
    
    // Wait a bit
    repeat(5) @(posedge clk);
    
    // ===============================================
    // TEST 1: Request with all zeros (should do nothing)
    // ===============================================
    $display("\n=== TEST 1: Request with zero relays ===");
    @(posedge clk);
    relay_incoming = 8'b00000000;
    request_receive = 1;
    @(posedge clk);
    request_receive = 0;
    
    // Wait and observe
    repeat(10) @(posedge clk);
    
    // ===============================================
    // TEST 2: Request relays 0, 1, 4, 7 with liquid amounts
    // ===============================================
    $display("\n=== TEST 2: Request relays 0,1,4,7 with 56ml each (2.8 seconds) ===");
    @(posedge clk);
    relay_incoming = 8'b10010011;  // Relays 7, 4, 1, 0
    relay_0_liquid_amount = 9'd56;  // 56/20 = 2 seconds (truncated)
    relay_1_liquid_amount = 9'd56;
    relay_4_liquid_amount = 9'd56;
    relay_7_liquid_amount = 9'd56;
    request_receive = 1;
    @(posedge clk);
    request_receive = 0;
    
    $display("Waiting for relays to activate...");
    
    // Wait for timers to run (2 seconds = 2*16 = 32 clock cycles per second)
    // Total should be about 64 cycles
    repeat(100) @(posedge clk);
    
    // ===============================================
    // TEST 3: Different durations for each relay
    // ===============================================
    $display("\n=== TEST 3: Different durations per relay ===");
    @(posedge clk);
    relay_incoming = 8'b11111111;  // All relays
    relay_0_liquid_amount = 9'd20;  // 1 second
    relay_1_liquid_amount = 9'd40;  // 2 seconds
    relay_2_liquid_amount = 9'd60;  // 3 seconds
    relay_3_liquid_amount = 9'd80;  // 4 seconds
    relay_4_liquid_amount = 9'd100; // 5 seconds
    relay_5_liquid_amount = 9'd120; // 6 seconds
    relay_6_liquid_amount = 9'd140; // 7 seconds
    relay_7_liquid_amount = 9'd160; // 8 seconds
    request_receive = 1;
    @(posedge clk);
    request_receive = 0;
    
    $display("Waiting for staggered relay deactivation...");
    
    // Wait long enough to see all relays finish
    repeat(200) @(posedge clk);
    
    // ===============================================
    // TEST 4: New request while previous is still running
    // ===============================================
    $display("\n=== TEST 4: Overlapping requests (should be ignored) ===");
    @(posedge clk);
    relay_incoming = 8'b00001111;  // Relays 0-3
    relay_0_liquid_amount = 9'd100; // 5 seconds
    relay_1_liquid_amount = 9'd100;
    relay_2_liquid_amount = 9'd100;
    relay_3_liquid_amount = 9'd100;
    request_receive = 1;
    @(posedge clk);
    request_receive = 0;
    
    // Wait 2 seconds
    repeat(32) @(posedge clk);
    
    // Try to send another request (should be ignored if still processing)
    $display("Attempting to send new request while processing...");
    @(posedge clk);
    relay_incoming = 8'b11110000;  // Different relays
    relay_4_liquid_amount = 9'd40;
    relay_5_liquid_amount = 9'd40;
    relay_6_liquid_amount = 9'd40;
    relay_7_liquid_amount = 9'd40;
    request_receive = 1;
    @(posedge clk);
    request_receive = 0;
    
    // Wait for completion
    repeat(150) @(posedge clk);
    
    // ===============================================
    // End simulation
    // ===============================================
    $display("\n=== Simulation Complete ===");
    repeat(10) @(posedge clk);
end

// ===============================================
// Monitor relay outputs
// ===============================================
always @(posedge clk) begin
    if (relay_enable_out != 8'b00000000) begin
        $display("Time %t: relay_enable_out = %b", $time, relay_enable_out);
    end
end

// ===============================================
// Monitor state transitions
// ===============================================
always @(posedge clk) begin
    if (dut.current_state != dut.next_state) begin
        $display("Time %t: State transition %d -> %d", $time, dut.current_state, dut.next_state);
    end
end

// ===============================================
// Dump waveforms
// ===============================================
initial begin
    $dumpfile("arthur_tb.vcd");
    $dumpvars(0, arthur_tb);
end

endmodule