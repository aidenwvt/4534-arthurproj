`timescale 1ns / 1ps

module liquid_0_tb;

    // 1. Testbench Signals
    reg S00_AXI_ACLK;
    reg S00_AXI_ARESETN;
    
    // AXI Write Address Channel
    reg  [31:0] S00_AXI_AWADDR;
    reg         S00_AXI_AWVALID;
    wire        S00_AXI_AWREADY;
    
    // AXI Write Data Channel
    reg  [31:0] S00_AXI_WDATA;
    reg  [3:0]  S00_AXI_WSTRB;
    reg         S00_AXI_WVALID;
    wire        S00_AXI_WREADY;
    
    // AXI Write Response Channel
    wire [1:0]  S00_AXI_BRESP;
    wire        S00_AXI_BVALID;
    reg         S00_AXI_BREADY;
    
    // AXI Read Address Channel
    reg  [31:0] S00_AXI_ARADDR;
    reg         S00_AXI_ARVALID;
    wire        S00_AXI_ARREADY;
    
    // AXI Read Data Channel
    wire [31:0] S00_AXI_RDATA;
    wire [1:0]  S00_AXI_RRESP;
    wire        S00_AXI_RVALID;
    reg         S00_AXI_RREADY;
    
    // Your IP's Custom Output Port
    wire [7:0]  liquid_out;


    // 2. Instantiate Your IP (The Device Under Test)
    //    !! Check this module name against your IP's top file !!
    liquid UUT (
        .s00_axi_aclk(S00_AXI_ACLK),
        .s00_axi_aresetn(S00_AXI_ARESETN),
        .s00_axi_awaddr(S00_AXI_AWADDR),
        .s00_axi_awprot(3'b0), // We can tie off PROT signals
        .s00_axi_awvalid(S00_AXI_AWVALID),
        .s00_axi_awready(S00_AXI_AWREADY),
        .s00_axi_wdata(S00_AXI_WDATA),
        .s00_axi_wstrb(S00_AXI_WSTRB),
        .s00_axi_wvalid(S00_AXI_WVALID),
        .s00_axi_wready(S00_AXI_WREADY),
        .s00_axi_bresp(S00_AXI_BRESP),
        .s00_axi_bvalid(S00_AXI_BVALID),
        .s00_axi_bready(S00_AXI_BREADY),
        .s00_axi_araddr(S00_AXI_ARADDR),
        .s00_axi_arprot(3'b0), // We can tie off PROT signals
        .s00_axi_arvalid(S00_AXI_ARVALID),
        .s00_axi_arready(S00_AXI_ARREADY),
        .s00_axi_rdata(S00_AXI_RDATA),
        .s00_axi_rresp(S00_AXI_RRESP),
        .s00_axi_rvalid(S00_AXI_RVALID),
        .s00_axi_rready(S00_AXI_RREADY),
        
        .liquid_out(liquid_out)
    );

    // 3. Generate the Clock (50 MHz = 20ns period)
    initial S00_AXI_ACLK = 0;
    always #10 S00_AXI_ACLK = ~S00_AXI_ACLK;

    // 4. The Test Sequence
    initial begin
        // Initialize all AXI inputs to idle
        S00_AXI_ARESETN <= 0;
        S00_AXI_AWADDR  <= 32'h0;
        S00_AXI_AWVALID <= 0;
        S00_AXI_WDATA   <= 32'h0;
        S00_AXI_WSTRB   <= 4'hF; // Write all 4 bytes
        S00_AXI_WVALID  <= 0;
        S00_AXI_BREADY  <= 0;
        S00_AXI_ARADDR  <= 32'h0;
        S00_AXI_ARVALID <= 0;
        S00_AXI_RREADY  <= 0;

        // --- Apply Reset ---
        #100; // Wait 100ns
        S00_AXI_ARESETN <= 1; // De-assert reset
        @(posedge S00_AXI_ACLK); // Wait for next clock edge
        
        $display("Testbench: Reset is done.");

        // --- TEST 1: AXI WRITE ---
        // (Write '1' to Register 0, offset 0x00, to start the counter)
        $display("Testbench: Writing 0x01 to 0x00...");
        
        // Write Address phase
        S00_AXI_AWADDR  <= 32'h00; // Offset 0x0
        S00_AXI_AWVALID <= 1;
        wait (S00_AXI_AWREADY == 1); // Wait for IP to be ready
        @(posedge S00_AXI_ACLK);
        S00_AXI_AWVALID <= 0;

        // Write Data phase
        S00_AXI_WDATA  <= 32'h00000001; // The value '1'
        S00_AXI_WVALID <= 1;
        wait (S00_AXI_WREADY == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_WVALID <= 0;
        
        // Write Response phase
        S00_AXI_BREADY <= 1;
        wait (S00_AXI_BVALID == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_BREADY <= 0;
        
        $display("Testbench: Write complete.");
        #100; // Wait for the counter to run a bit
        
 // --- TEST 2: AXI WRITE to Reg 2 ---
        $display("Testbench: Writing 123 to 0x08...");
        
        // Write Address phase
        @(posedge S00_AXI_ACLK); 
        S00_AXI_AWADDR  <= 32'h08; // Offset 0x08
        S00_AXI_AWVALID <= 1;
        
        while (S00_AXI_AWREADY == 0) begin
            @(posedge S00_AXI_ACLK);
        end
        
        @(posedge S00_AXI_ACLK);
        S00_AXI_AWVALID <= 0;

        // Write Data phase
        S00_AXI_WDATA  <= 32'd123; // The value '123'
        S00_AXI_WVALID <= 1;

        while (S00_AXI_WREADY == 0) begin
            @(posedge S00_AXI_ACLK);
        end
        
        @(posedge S00_AXI_ACLK);
        S00_AXI_WVALID <= 0;
        
        // Write Response phase
        S00_AXI_BREADY <= 1;
        
        while (S00_AXI_BVALID == 0) begin
            @(posedge S00_AXI_ACLK);
        end
        
        @(posedge S00_AXI_ACLK);
        S00_AXI_BREADY <= 0;
        
        $display("Testbench: Write complete.");
        #100;
        
          // --- TEST 1: AXI WRITE ---
        // (Write '1' to Register 1, offset 0x00, to start the counter)
        $display("Testbench: Writing 0x01 to 0x01...");
        
        // Write Address phase
        S00_AXI_AWADDR  <= 32'h04; // Offset 0x0
        S00_AXI_AWVALID <= 1;
        wait (S00_AXI_AWREADY == 1); // Wait for IP to be ready
        @(posedge S00_AXI_ACLK);
        S00_AXI_AWVALID <= 0;

        // Write Data phase
        S00_AXI_WDATA  <= 32'h00000001; // The value '1'
        S00_AXI_WVALID <= 1;
        wait (S00_AXI_WREADY == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_WVALID <= 0;
        
        // Write Response phase
        S00_AXI_BREADY <= 1;
        wait (S00_AXI_BVALID == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_BREADY <= 0;
        
        $display("Testbench: Write complete.");
        #100; // Wait for the counter to run a bit
        
        
        

        // --- TEST 2: AXI READ ---
        // (Read from Register 10, offset 0x28)
        $display("Testbench: Reading from 0x28 (Reg 10)...");

        // Read Address phase
        S00_AXI_ARADDR  <= 32'h28; // Offset 0x28
        S00_AXI_ARVALID <= 1;
        wait (S00_AXI_ARREADY == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_ARVALID <= 0;
        
        // Read Data phase
        S00_AXI_RREADY <= 1;
        wait (S00_AXI_RVALID == 1);
        @(posedge S00_AXI_ACLK);
        S00_AXI_RREADY <= 0;
        
        $display("Testbench: Read complete. Data was: 0x%h", S00_AXI_RDATA);
        
        // Check if the read data is '1' (which is your counter_running_status)
        if (S00_AXI_RDATA == 32'h1) begin
            $display("Testbench: SUCCESS! Read back '1' as expected.");
        end else begin
            $display("Testbench: FAILED! Read back 0x%h, expected 0x1.", S00_AXI_RDATA);
        end
        
        // --- TEST 3: Stop Counter ---
        // (Write '0' to Register 0)
        // (This is just a repeat of the write task, but with data '0')
        S00_AXI_AWADDR  <= 32'h00;
        S00_AXI_AWVALID <= 1;
        wait (S00_AXI_AWREADY == 1); @(posedge S00_AXI_ACLK); S00_AXI_AWVALID <= 0;
        S00_AXI_WDATA  <= 32'h0;
        S00_AXI_WVALID <= 1;
        wait (S00_AXI_WREADY == 1); @(posedge S00_AXI_ACLK); S00_AXI_WVALID <= 0;
        S00_AXI_BREADY <= 1;
        wait (S00_AXI_BVALID == 1); @(posedge S00_AXI_ACLK); S00_AXI_BREADY <= 0;
        $display("Testbench: Wrote 0x0 to stop counter.");

        #100;
        $display("Testbench: Simulation finished.");
        $finish; // End the simulation
    end
    
endmodule