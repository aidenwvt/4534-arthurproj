module arthur(
    input clk, 
    input reset, 
    input [7:0] relay_incoming, 
    input request_receive, 
    input [8:0] relay_0_liquid_amount, 
    input [8:0] relay_1_liquid_amount, 
    input [8:0] relay_2_liquid_amount, 
    input [8:0] relay_3_liquid_amount, 
    input [8:0] relay_4_liquid_amount, 
    input [8:0] relay_5_liquid_amount, 
    input [8:0] relay_6_liquid_amount, 
    input [8:0] relay_7_liquid_amount, 
        input [8:0] liquid_division_in,   
    output reg [7:0] relay_enable_out
);

// ===============================================
// Parameters
// ===============================================
parameter IDLE = 3'b000, LOAD = 3'b001, WAIT = 3'b010, PROCESS = 3'b011;
//parameter LIQUID_DIVISION = 9'd21;
reg [8:0] liquid_division_reg;


reg [2:0] current_state, next_state;
reg [2:0] out; // out[2] = reset, out[1] = enable_timer, out[0] = load relay register

wire [7:0] relay_register_out;
register #(8) relay_reg(clk, out[2], out[0], relay_incoming, relay_register_out);

wire [8:0] seconds_relay_0 = relay_0_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_1 = relay_1_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_2 = relay_2_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_3 = relay_3_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_4 = relay_4_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_5 = relay_5_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_6 = relay_6_liquid_amount / liquid_division_reg;
wire [8:0] seconds_relay_7 = relay_7_liquid_amount / liquid_division_reg;

wire [4:0] reg_0_out, reg_1_out, reg_2_out, reg_3_out;
wire [4:0] reg_4_out, reg_5_out, reg_6_out, reg_7_out;

wire load_duration_regs = (current_state == LOAD);

register #(5) reg_r0(clk, out[2], load_duration_regs, seconds_relay_0[4:0], reg_0_out);
register #(5) reg_r1(clk, out[2], load_duration_regs, seconds_relay_1[4:0], reg_1_out);
register #(5) reg_r2(clk, out[2], load_duration_regs, seconds_relay_2[4:0], reg_2_out);
register #(5) reg_r3(clk, out[2], load_duration_regs, seconds_relay_3[4:0], reg_3_out);
register #(5) reg_r4(clk, out[2], load_duration_regs, seconds_relay_4[4:0], reg_4_out);
register #(5) reg_r5(clk, out[2], load_duration_regs, seconds_relay_5[4:0], reg_5_out);
register #(5) reg_r6(clk, out[2], load_duration_regs, seconds_relay_6[4:0], reg_6_out);
register #(5) reg_r7(clk, out[2], load_duration_regs, seconds_relay_7[4:0], reg_7_out);





wire load_liquid_division = (current_state == IDLE);

always @(posedge clk or posedge reset) begin
    if (reset)
        liquid_division_reg <= 9'd21;      // default value
    else if (load_liquid_division)
        liquid_division_reg <= liquid_division_in;
end


reg prev_was_load;
always @(posedge clk or posedge reset) begin
    if (reset)
        prev_was_load <= 1'b0;
    else
        prev_was_load <= (current_state == LOAD);
end

wire start_timers = prev_was_load && (current_state == WAIT);
wire [7:0] enable_timer_bus = relay_register_out & {8{start_timers}};

wire relay_0_enable, relay_1_enable, relay_2_enable, relay_3_enable;
wire relay_4_enable, relay_5_enable, relay_6_enable, relay_7_enable;

timer timer_0(clk, enable_timer_bus[0], out[2], reg_0_out, relay_0_enable);
timer timer_1(clk, enable_timer_bus[1], out[2], reg_1_out, relay_1_enable);
timer timer_2(clk, enable_timer_bus[2], out[2], reg_2_out, relay_2_enable);
timer timer_3(clk, enable_timer_bus[3], out[2], reg_3_out, relay_3_enable);
timer timer_4(clk, enable_timer_bus[4], out[2], reg_4_out, relay_4_enable);
timer timer_5(clk, enable_timer_bus[5], out[2], reg_5_out, relay_5_enable);
timer timer_6(clk, enable_timer_bus[6], out[2], reg_6_out, relay_6_enable);
timer timer_7(clk, enable_timer_bus[7], out[2], reg_7_out, relay_7_enable);

wire [7:0] all_relays = {
    relay_7_enable, relay_6_enable, relay_5_enable, relay_4_enable,
    relay_3_enable, relay_2_enable, relay_1_enable, relay_0_enable
};

wire any_relays_enabled = |all_relays;

always @(*) begin
    relay_enable_out = all_relays;
end

always @(posedge clk or posedge reset) begin
    if (reset)
        current_state <= IDLE;
    else
        current_state <= next_state;
end

always @(*) begin
    case(current_state)
        IDLE:    next_state = (request_receive) ? LOAD : IDLE;
        LOAD:    next_state = WAIT;        // Go to WAIT after LOAD
        WAIT:    next_state = PROCESS;     // Give timers 1 cycle to start
        PROCESS: next_state = (any_relays_enabled) ? PROCESS : IDLE;
        default: next_state = IDLE;
    endcase
end

always @(*) begin
    case(current_state)
        IDLE:    out = 3'b100;  // reset
        LOAD:    out = 3'b001;  // load relay register
        WAIT:    out = 3'b000;  // wait for timers to start
        PROCESS: out = 3'b000;  // normal operation
        default: out = 3'bxxx;
    endcase
end

endmodule
