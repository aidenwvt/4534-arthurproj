module register #(parameter WIDTH = 4) (clk, reset, load, reg_input, reg_output);
	input clk, reset, load;
	input  [WIDTH-1:0] reg_input;
	output [WIDTH-1:0] reg_output;
	
	reg [WIDTH-1:0] state;
	
	always@(posedge clk) begin
		if (reset) begin
			state <= {WIDTH{1'b0}};
		end
		else if (load) begin
			state <= reg_input;
		end
	end
	
	assign reg_output = state;
	
endmodule