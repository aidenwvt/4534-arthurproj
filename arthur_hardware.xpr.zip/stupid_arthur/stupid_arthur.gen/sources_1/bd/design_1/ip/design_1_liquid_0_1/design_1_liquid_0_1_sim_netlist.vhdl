-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (lin64) Build 6140274 Wed May 21 22:58:25 MDT 2025
-- Date        : Thu Dec  4 16:43:52 2025
-- Host        : framed running 64-bit Arch Linux
-- Command     : write_vhdl -force -mode funcsim
--               /home/dom/Documents/FPGA_Projects/stupid_arthur/stupid_arthur.gen/sources_1/bd/design_1/ip/design_1_liquid_0_1/design_1_liquid_0_1_sim_netlist.vhdl
-- Design      : design_1_liquid_0_1
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z007sclg400-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_register is
  port (
    prev_was_load_reg : out STD_LOGIC;
    \state_reg[7]_0\ : out STD_LOGIC_VECTOR ( 7 downto 0 );
    prev_was_load_reg_0 : out STD_LOGIC;
    prev_was_load_reg_1 : out STD_LOGIC;
    prev_was_load_reg_2 : out STD_LOGIC;
    prev_was_load_reg_3 : out STD_LOGIC;
    prev_was_load_reg_4 : out STD_LOGIC;
    prev_was_load_reg_5 : out STD_LOGIC;
    prev_was_load_reg_6 : out STD_LOGIC;
    prev_was_load : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \count_clk_cycles_reg[0]\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_1\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_2\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_3\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_4\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_5\ : in STD_LOGIC;
    \count_clk_cycles_reg[0]_6\ : in STD_LOGIC;
    \state_reg[7]_1\ : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_register : entity is "register";
end design_1_liquid_0_1_register;

architecture STRUCTURE of design_1_liquid_0_1_register is
  signal \^state_reg[7]_0\ : STD_LOGIC_VECTOR ( 7 downto 0 );
begin
  \state_reg[7]_0\(7 downto 0) <= \^state_reg[7]_0\(7 downto 0);
counter_out_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(0),
      I3 => \count_clk_cycles_reg[0]\,
      O => prev_was_load_reg
    );
\counter_out_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(1),
      I3 => \count_clk_cycles_reg[0]_0\,
      O => prev_was_load_reg_0
    );
\counter_out_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(2),
      I3 => \count_clk_cycles_reg[0]_1\,
      O => prev_was_load_reg_1
    );
\counter_out_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(3),
      I3 => \count_clk_cycles_reg[0]_2\,
      O => prev_was_load_reg_2
    );
\counter_out_i_4__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(4),
      I3 => \count_clk_cycles_reg[0]_3\,
      O => prev_was_load_reg_3
    );
\counter_out_i_4__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(5),
      I3 => \count_clk_cycles_reg[0]_4\,
      O => prev_was_load_reg_4
    );
\counter_out_i_4__5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(6),
      I3 => \count_clk_cycles_reg[0]_5\,
      O => prev_was_load_reg_5
    );
\counter_out_i_4__6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => prev_was_load,
      I1 => Q(1),
      I2 => \^state_reg[7]_0\(7),
      I3 => \count_clk_cycles_reg[0]_6\,
      O => prev_was_load_reg_6
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(0),
      Q => \^state_reg[7]_0\(0),
      R => Q(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(1),
      Q => \^state_reg[7]_0\(1),
      R => Q(0)
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(2),
      Q => \^state_reg[7]_0\(2),
      R => Q(0)
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(3),
      Q => \^state_reg[7]_0\(3),
      R => Q(0)
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(4),
      Q => \^state_reg[7]_0\(4),
      R => Q(0)
    );
\state_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(5),
      Q => \^state_reg[7]_0\(5),
      R => Q(0)
    );
\state_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(6),
      Q => \^state_reg[7]_0\(6),
      R => Q(0)
    );
\state_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => Q(2),
      D => \state_reg[7]_1\(7),
      Q => \^state_reg[7]_0\(7),
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg2_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg2_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_0__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_0 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_0__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2_n_0\ : STD_LOGIC;
  signal \state[1]_i_3_n_0\ : STD_LOGIC;
  signal \state[1]_i_4_n_0\ : STD_LOGIC;
  signal \state[2]_i_3_n_0\ : STD_LOGIC;
  signal \state[2]_i_4_n_0\ : STD_LOGIC;
  signal \state[2]_i_5_n_0\ : STD_LOGIC;
  signal \state[2]_i_6_n_0\ : STD_LOGIC;
  signal \state[2]_i_7_n_0\ : STD_LOGIC;
  signal \state[2]_i_8_n_0\ : STD_LOGIC;
  signal \state[2]_i_9_n_0\ : STD_LOGIC;
  signal \state[3]_i_10_n_0\ : STD_LOGIC;
  signal \state[3]_i_11_n_0\ : STD_LOGIC;
  signal \state[3]_i_12_n_0\ : STD_LOGIC;
  signal \state[3]_i_13_n_0\ : STD_LOGIC;
  signal \state[3]_i_3_n_0\ : STD_LOGIC;
  signal \state[3]_i_4_n_0\ : STD_LOGIC;
  signal \state[3]_i_5_n_0\ : STD_LOGIC;
  signal \state[3]_i_7_n_0\ : STD_LOGIC;
  signal \state[3]_i_8_n_0\ : STD_LOGIC;
  signal \state[3]_i_9_n_0\ : STD_LOGIC;
  signal \state[4]_i_10_n_0\ : STD_LOGIC;
  signal \state[4]_i_11_n_0\ : STD_LOGIC;
  signal \state[4]_i_12_n_0\ : STD_LOGIC;
  signal \state[4]_i_13_n_0\ : STD_LOGIC;
  signal \state[4]_i_16_n_0\ : STD_LOGIC;
  signal \state[4]_i_17_n_0\ : STD_LOGIC;
  signal \state[4]_i_18_n_0\ : STD_LOGIC;
  signal \state[4]_i_20_n_0\ : STD_LOGIC;
  signal \state[4]_i_21_n_0\ : STD_LOGIC;
  signal \state[4]_i_22_n_0\ : STD_LOGIC;
  signal \state[4]_i_23_n_0\ : STD_LOGIC;
  signal \state[4]_i_24_n_0\ : STD_LOGIC;
  signal \state[4]_i_25_n_0\ : STD_LOGIC;
  signal \state[4]_i_26_n_0\ : STD_LOGIC;
  signal \state[4]_i_27_n_0\ : STD_LOGIC;
  signal \state[4]_i_28_n_0\ : STD_LOGIC;
  signal \state[4]_i_29_n_0\ : STD_LOGIC;
  signal \state[4]_i_30_n_0\ : STD_LOGIC;
  signal \state[4]_i_31_n_0\ : STD_LOGIC;
  signal \state[4]_i_32_n_0\ : STD_LOGIC;
  signal \state[4]_i_33_n_0\ : STD_LOGIC;
  signal \state[4]_i_34_n_0\ : STD_LOGIC;
  signal \state[4]_i_35_n_0\ : STD_LOGIC;
  signal \state[4]_i_36_n_0\ : STD_LOGIC;
  signal \state[4]_i_37_n_0\ : STD_LOGIC;
  signal \state[4]_i_38_n_0\ : STD_LOGIC;
  signal \state[4]_i_39_n_0\ : STD_LOGIC;
  signal \state[4]_i_5_n_0\ : STD_LOGIC;
  signal \state[4]_i_6_n_0\ : STD_LOGIC;
  signal \state[4]_i_7_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_0__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_0__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_14_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
counter_out_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_0__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_0__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_0__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_0__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_0__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2_n_5\,
      DI(2) => \state_reg[2]_i_2_n_6\,
      DI(1) => \state_reg[2]_i_2_n_7\,
      DI(0) => \seconds_relay_0__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg2_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_0__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_0__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_0__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_0__274_carry__0_i_9_n_0\
    );
\seconds_relay_0__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2_n_5\,
      O => \seconds_relay_0__274_carry__0_i_6_n_0\
    );
\seconds_relay_0__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2_n_6\,
      O => \seconds_relay_0__274_carry__0_i_7_n_0\
    );
\seconds_relay_0__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2_n_7\,
      O => \seconds_relay_0__274_carry__0_i_8_n_0\
    );
\seconds_relay_0__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(3),
      I2 => \seconds_relay_0__274_carry_i_6_n_4\,
      O => \seconds_relay_0__274_carry__0_i_9_n_0\
    );
\seconds_relay_0__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1_n_6\,
      O => \state_reg[1]_i_1_0\(1)
    );
\seconds_relay_0__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1_0\(0)
    );
\seconds_relay_0__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_0__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_0__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_0__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_0__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_0(2),
      DI(3) => \seconds_relay_0__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_0__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg2_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_0__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_0__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_0__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_0__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_0__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6_n_5\,
      O => \seconds_relay_0__274_carry_i_10_n_0\
    );
\seconds_relay_0__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6_n_6\,
      O => \seconds_relay_0__274_carry_i_11_n_0\
    );
\seconds_relay_0__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(1),
      O => \seconds_relay_0__274_carry_i_12_n_0\
    );
\seconds_relay_0__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_0__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_0__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_0__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_0__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_0(3),
      DI(3) => \state_reg[3]_i_6_n_5\,
      DI(2) => \state_reg[3]_i_6_n_6\,
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_0__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_0__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_0__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_0__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_0__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_0__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_0__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_0__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(2),
      I2 => \seconds_relay_0__274_carry_i_6_n_5\,
      O => \seconds_relay_0__274_carry_i_7_n_0\
    );
\seconds_relay_0__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(1),
      I2 => \seconds_relay_0__274_carry_i_6_n_6\,
      O => \seconds_relay_0__274_carry_i_8_n_0\
    );
\seconds_relay_0__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(0),
      O => \seconds_relay_0__274_carry_i_9_n_0\
    );
\seconds_relay_0__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_0__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_0__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_0__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_0__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_0__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_0__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => \state_reg[2]_i_1_n_6\,
      O => \state[1]_i_2_n_0\
    );
\state[1]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1_n_7\,
      O => \state[1]_i_3_n_0\
    );
\state[1]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2_n_4\,
      O => \state[1]_i_4_n_0\
    );
\state[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => \state_reg[3]_i_1_n_6\,
      O => \state[2]_i_3_n_0\
    );
\state[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1_n_7\,
      O => \state[2]_i_4_n_0\
    );
\state[2]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2_n_4\,
      O => \state[2]_i_5_n_0\
    );
\state[2]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2_n_5\,
      O => \state[2]_i_6_n_0\
    );
\state[2]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2_n_6\,
      O => \state[2]_i_7_n_0\
    );
\state[2]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2_n_7\,
      O => \state[2]_i_8_n_0\
    );
\state[2]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6_n_4\,
      O => \state[2]_i_9_n_0\
    );
\state[3]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8_n_4\,
      O => \state[3]_i_10_n_0\
    );
\state[3]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8_n_5\,
      O => \state[3]_i_11_n_0\
    );
\state[3]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8_n_6\,
      O => \state[3]_i_12_n_0\
    );
\state[3]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(2),
      O => \state[3]_i_13_n_0\
    );
\state[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => \state_reg[4]_i_1_n_6\,
      O => \state[3]_i_3_n_0\
    );
\state[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1_n_7\,
      O => \state[3]_i_4_n_0\
    );
\state[3]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2_n_4\,
      O => \state[3]_i_5_n_0\
    );
\state[3]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2_n_5\,
      O => \state[3]_i_7_n_0\
    );
\state[3]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2_n_6\,
      O => \state[3]_i_8_n_0\
    );
\state[3]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2_n_7\,
      O => \state[3]_i_9_n_0\
    );
\state[4]_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4_n_5\,
      O => \state[4]_i_10_n_0\
    );
\state[4]_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4_n_6\,
      O => \state[4]_i_11_n_0\
    );
\state[4]_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4_n_7\,
      O => \state[4]_i_12_n_0\
    );
\state[4]_i_13\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9_n_4\,
      O => \state[4]_i_13_n_0\
    );
\state[4]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => \state_reg[4]_i_14_n_6\,
      O => \state[4]_i_16_n_0\
    );
\state[4]_i_17\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14_n_7\,
      O => \state[4]_i_17_n_0\
    );
\state[4]_i_18\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15_n_4\,
      O => \state[4]_i_18_n_0\
    );
\state[4]_i_20\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15_n_5\,
      O => \state[4]_i_20_n_0\
    );
\state[4]_i_21\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15_n_6\,
      O => \state[4]_i_21_n_0\
    );
\state[4]_i_22\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15_n_7\,
      O => \state[4]_i_22_n_0\
    );
\state[4]_i_23\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19_n_4\,
      O => \state[4]_i_23_n_0\
    );
\state[4]_i_24\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9_n_5\,
      O => \state[4]_i_24_n_0\
    );
\state[4]_i_25\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9_n_6\,
      O => \state[4]_i_25_n_0\
    );
\state[4]_i_26\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(3),
      O => \state[4]_i_26_n_0\
    );
\state[4]_i_27\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19_n_5\,
      O => \state[4]_i_27_n_0\
    );
\state[4]_i_28\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19_n_6\,
      O => \state[4]_i_28_n_0\
    );
\state[4]_i_29\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(4),
      O => \state[4]_i_29_n_0\
    );
\state[4]_i_30\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14_1\(0),
      O => \state[4]_i_30_n_0\
    );
\state[4]_i_31\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14_0\(3),
      O => \state[4]_i_31_n_0\
    );
\state[4]_i_32\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14_0\(2),
      O => \state[4]_i_32_n_0\
    );
\state[4]_i_33\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14_0\(1),
      O => \state[4]_i_33_n_0\
    );
\state[4]_i_34\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14_0\(0),
      O => \state[4]_i_34_n_0\
    );
\state[4]_i_35\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35_n_0\
    );
\state[4]_i_36\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36_n_0\
    );
\state[4]_i_37\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37_n_0\
    );
\state[4]_i_38\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38_n_0\
    );
\state[4]_i_39\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_0__8_carry__0_i_6\(5),
      O => \state[4]_i_39_n_0\
    );
\state[4]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => \state_reg[4]_i_3_n_6\,
      O => \state[4]_i_5_n_0\
    );
\state[4]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3_n_7\,
      O => \state[4]_i_6_n_0\
    );
\state[4]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4_n_4\,
      O => \state[4]_i_7_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1_n_2\,
      CO(0) => \state_reg[1]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_0(2),
      DI(1) => \state_reg[2]_i_1_n_7\,
      DI(0) => \state_reg[2]_i_2_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2_n_0\,
      S(1) => \state[1]_i_3_n_0\,
      S(0) => \state[1]_i_4_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_0(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[4]_1\(0)
    );
\state_reg[2]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_0(2),
      CO(1) => \state_reg[2]_i_1_n_2\,
      CO(0) => \state_reg[2]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_0(3),
      DI(1) => \state_reg[3]_i_1_n_7\,
      DI(0) => \state_reg[3]_i_2_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1_n_6\,
      O(0) => \state_reg[2]_i_1_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3_n_0\,
      S(1) => \state[2]_i_4_n_0\,
      S(0) => \state[2]_i_5_n_0\
    );
\state_reg[2]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2_n_0\,
      CO(2) => \state_reg[2]_i_2_n_1\,
      CO(1) => \state_reg[2]_i_2_n_2\,
      CO(0) => \state_reg[2]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2_n_5\,
      DI(2) => \state_reg[3]_i_2_n_6\,
      DI(1) => \state_reg[3]_i_2_n_7\,
      DI(0) => \state_reg[3]_i_6_n_4\,
      O(3) => \state_reg[2]_i_2_n_4\,
      O(2) => \state_reg[2]_i_2_n_5\,
      O(1) => \state_reg[2]_i_2_n_6\,
      O(0) => \state_reg[2]_i_2_n_7\,
      S(3) => \state[2]_i_6_n_0\,
      S(2) => \state[2]_i_7_n_0\,
      S(1) => \state[2]_i_8_n_0\,
      S(0) => \state[2]_i_9_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_0(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[4]_1\(0)
    );
\state_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_0(3),
      CO(1) => \state_reg[3]_i_1_n_2\,
      CO(0) => \state_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_0(4),
      DI(1) => \state_reg[4]_i_1_n_7\,
      DI(0) => \state_reg[4]_i_2_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1_n_6\,
      O(0) => \state_reg[3]_i_1_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3_n_0\,
      S(1) => \state[3]_i_4_n_0\,
      S(0) => \state[3]_i_5_n_0\
    );
\state_reg[3]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6_n_0\,
      CO(3) => \state_reg[3]_i_2_n_0\,
      CO(2) => \state_reg[3]_i_2_n_1\,
      CO(1) => \state_reg[3]_i_2_n_2\,
      CO(0) => \state_reg[3]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2_n_5\,
      DI(2) => \state_reg[4]_i_2_n_6\,
      DI(1) => \state_reg[4]_i_2_n_7\,
      DI(0) => \state_reg[4]_i_8_n_4\,
      O(3) => \state_reg[3]_i_2_n_4\,
      O(2) => \state_reg[3]_i_2_n_5\,
      O(1) => \state_reg[3]_i_2_n_6\,
      O(0) => \state_reg[3]_i_2_n_7\,
      S(3) => \state[3]_i_7_n_0\,
      S(2) => \state[3]_i_8_n_0\,
      S(1) => \state[3]_i_9_n_0\,
      S(0) => \state[3]_i_10_n_0\
    );
\state_reg[3]_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6_n_0\,
      CO(2) => \state_reg[3]_i_6_n_1\,
      CO(1) => \state_reg[3]_i_6_n_2\,
      CO(0) => \state_reg[3]_i_6_n_3\,
      CYINIT => seconds_relay_0(4),
      DI(3) => \state_reg[4]_i_8_n_5\,
      DI(2) => \state_reg[4]_i_8_n_6\,
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6_n_4\,
      O(2) => \state_reg[3]_i_6_n_5\,
      O(1) => \state_reg[3]_i_6_n_6\,
      O(0) => \NLW_state_reg[3]_i_6_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11_n_0\,
      S(2) => \state[3]_i_12_n_0\,
      S(1) => \state[3]_i_13_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_0(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[4]_1\(0)
    );
\state_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_0(4),
      CO(1) => \state_reg[4]_i_1_n_2\,
      CO(0) => \state_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3_n_1\,
      DI(1) => \state_reg[4]_i_3_n_7\,
      DI(0) => \state_reg[4]_i_4_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1_n_6\,
      O(0) => \state_reg[4]_i_1_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5_n_0\,
      S(1) => \state[4]_i_6_n_0\,
      S(0) => \state[4]_i_7_n_0\
    );
\state_reg[4]_i_14\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14_n_1\,
      CO(1) => \state_reg[4]_i_14_n_2\,
      CO(0) => \state_reg[4]_i_14_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14_n_6\,
      O(0) => \state_reg[4]_i_14_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30_n_0\,
      S(1) => \state[4]_i_31_n_0\,
      S(0) => \state[4]_i_32_n_0\
    );
\state_reg[4]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19_n_0\,
      CO(3) => \state_reg[4]_i_15_n_0\,
      CO(2) => \state_reg[4]_i_15_n_1\,
      CO(1) => \state_reg[4]_i_15_n_2\,
      CO(0) => \state_reg[4]_i_15_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15_n_4\,
      O(2) => \state_reg[4]_i_15_n_5\,
      O(1) => \state_reg[4]_i_15_n_6\,
      O(0) => \state_reg[4]_i_15_n_7\,
      S(3) => \state[4]_i_33_n_0\,
      S(2) => \state[4]_i_34_n_0\,
      S(1) => \state[4]_i_35_n_0\,
      S(0) => \state[4]_i_36_n_0\
    );
\state_reg[4]_i_19\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19_n_0\,
      CO(2) => \state_reg[4]_i_19_n_1\,
      CO(1) => \state_reg[4]_i_19_n_2\,
      CO(0) => \state_reg[4]_i_19_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19_n_4\,
      O(2) => \state_reg[4]_i_19_n_5\,
      O(1) => \state_reg[4]_i_19_n_6\,
      O(0) => \NLW_state_reg[4]_i_19_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37_n_0\,
      S(2) => \state[4]_i_38_n_0\,
      S(1) => \state[4]_i_39_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8_n_0\,
      CO(3) => \state_reg[4]_i_2_n_0\,
      CO(2) => \state_reg[4]_i_2_n_1\,
      CO(1) => \state_reg[4]_i_2_n_2\,
      CO(0) => \state_reg[4]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4_n_5\,
      DI(2) => \state_reg[4]_i_4_n_6\,
      DI(1) => \state_reg[4]_i_4_n_7\,
      DI(0) => \state_reg[4]_i_9_n_4\,
      O(3) => \state_reg[4]_i_2_n_4\,
      O(2) => \state_reg[4]_i_2_n_5\,
      O(1) => \state_reg[4]_i_2_n_6\,
      O(0) => \state_reg[4]_i_2_n_7\,
      S(3) => \state[4]_i_10_n_0\,
      S(2) => \state[4]_i_11_n_0\,
      S(1) => \state[4]_i_12_n_0\,
      S(0) => \state[4]_i_13_n_0\
    );
\state_reg[4]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3_n_1\,
      CO(1) => \state_reg[4]_i_3_n_2\,
      CO(0) => \state_reg[4]_i_3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14_n_1\,
      DI(1) => \state_reg[4]_i_14_n_7\,
      DI(0) => \state_reg[4]_i_15_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3_n_6\,
      O(0) => \state_reg[4]_i_3_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16_n_0\,
      S(1) => \state[4]_i_17_n_0\,
      S(0) => \state[4]_i_18_n_0\
    );
\state_reg[4]_i_4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9_n_0\,
      CO(3) => \state_reg[4]_i_4_n_0\,
      CO(2) => \state_reg[4]_i_4_n_1\,
      CO(1) => \state_reg[4]_i_4_n_2\,
      CO(0) => \state_reg[4]_i_4_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15_n_5\,
      DI(2) => \state_reg[4]_i_15_n_6\,
      DI(1) => \state_reg[4]_i_15_n_7\,
      DI(0) => \state_reg[4]_i_19_n_4\,
      O(3) => \state_reg[4]_i_4_n_4\,
      O(2) => \state_reg[4]_i_4_n_5\,
      O(1) => \state_reg[4]_i_4_n_6\,
      O(0) => \state_reg[4]_i_4_n_7\,
      S(3) => \state[4]_i_20_n_0\,
      S(2) => \state[4]_i_21_n_0\,
      S(1) => \state[4]_i_22_n_0\,
      S(0) => \state[4]_i_23_n_0\
    );
\state_reg[4]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8_n_0\,
      CO(2) => \state_reg[4]_i_8_n_1\,
      CO(1) => \state_reg[4]_i_8_n_2\,
      CO(0) => \state_reg[4]_i_8_n_3\,
      CYINIT => \state_reg[4]_i_3_n_1\,
      DI(3) => \state_reg[4]_i_9_n_5\,
      DI(2) => \state_reg[4]_i_9_n_6\,
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8_n_4\,
      O(2) => \state_reg[4]_i_8_n_5\,
      O(1) => \state_reg[4]_i_8_n_6\,
      O(0) => \NLW_state_reg[4]_i_8_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24_n_0\,
      S(2) => \state[4]_i_25_n_0\,
      S(1) => \state[4]_i_26_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9_n_0\,
      CO(2) => \state_reg[4]_i_9_n_1\,
      CO(1) => \state_reg[4]_i_9_n_2\,
      CO(0) => \state_reg[4]_i_9_n_3\,
      CYINIT => \state_reg[4]_i_14_n_1\,
      DI(3) => \state_reg[4]_i_19_n_5\,
      DI(2) => \state_reg[4]_i_19_n_6\,
      DI(1) => \seconds_relay_0__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9_n_4\,
      O(2) => \state_reg[4]_i_9_n_5\,
      O(1) => \state_reg[4]_i_9_n_6\,
      O(0) => \NLW_state_reg[4]_i_9_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27_n_0\,
      S(2) => \state[4]_i_28_n_0\,
      S(1) => \state[4]_i_29_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_0\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg3_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg3_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__0_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_1__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__0_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__0_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[0]_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_0\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_0\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_0\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_1 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_1__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__0_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__0_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__0_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__0_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__0_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__0_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__0_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__0_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__0_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__0_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__0_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__0_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__0_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__0_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__0_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__0_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__0_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__0_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__0_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__0_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__0_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__0_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__0_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_1__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_1__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_1__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_1__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_1__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_1__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_1__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__0_n_5\,
      DI(2) => \state_reg[2]_i_2__0_n_6\,
      DI(1) => \state_reg[2]_i_2__0_n_7\,
      DI(0) => \seconds_relay_1__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg3_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_1__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_1__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_1__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_1__274_carry__0_i_9_n_0\
    );
\seconds_relay_1__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__0_n_5\,
      O => \seconds_relay_1__274_carry__0_i_6_n_0\
    );
\seconds_relay_1__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__0_n_6\,
      O => \seconds_relay_1__274_carry__0_i_7_n_0\
    );
\seconds_relay_1__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__0_n_7\,
      O => \seconds_relay_1__274_carry__0_i_8_n_0\
    );
\seconds_relay_1__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(3),
      I2 => \seconds_relay_1__274_carry_i_6_n_4\,
      O => \seconds_relay_1__274_carry__0_i_9_n_0\
    );
\seconds_relay_1__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__0_n_6\,
      O => \state_reg[1]_i_1__0_0\(1)
    );
\seconds_relay_1__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__0_0\(0)
    );
\seconds_relay_1__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_1__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_1__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_1__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_1__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_1(2),
      DI(3) => \seconds_relay_1__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_1__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg3_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_1__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_1__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_1__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_1__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_1__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__0_n_5\,
      O => \seconds_relay_1__274_carry_i_10_n_0\
    );
\seconds_relay_1__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__0_n_6\,
      O => \seconds_relay_1__274_carry_i_11_n_0\
    );
\seconds_relay_1__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(1),
      O => \seconds_relay_1__274_carry_i_12_n_0\
    );
\seconds_relay_1__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_1__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_1__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_1__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_1__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_1(3),
      DI(3) => \state_reg[3]_i_6__0_n_5\,
      DI(2) => \state_reg[3]_i_6__0_n_6\,
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_1__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_1__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_1__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_1__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_1__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_1__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_1__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_1__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(2),
      I2 => \seconds_relay_1__274_carry_i_6_n_5\,
      O => \seconds_relay_1__274_carry_i_7_n_0\
    );
\seconds_relay_1__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(1),
      I2 => \seconds_relay_1__274_carry_i_6_n_6\,
      O => \seconds_relay_1__274_carry_i_8_n_0\
    );
\seconds_relay_1__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(0),
      O => \seconds_relay_1__274_carry_i_9_n_0\
    );
\seconds_relay_1__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_1__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_1__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_1__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_1__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_1__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_1__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => \state_reg[2]_i_1__0_n_6\,
      O => \state[1]_i_2__0_n_0\
    );
\state[1]_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__0_n_7\,
      O => \state[1]_i_3__0_n_0\
    );
\state[1]_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__0_n_4\,
      O => \state[1]_i_4__0_n_0\
    );
\state[2]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => \state_reg[3]_i_1__0_n_6\,
      O => \state[2]_i_3__0_n_0\
    );
\state[2]_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__0_n_7\,
      O => \state[2]_i_4__0_n_0\
    );
\state[2]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__0_n_4\,
      O => \state[2]_i_5__0_n_0\
    );
\state[2]_i_6__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__0_n_5\,
      O => \state[2]_i_6__0_n_0\
    );
\state[2]_i_7__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__0_n_6\,
      O => \state[2]_i_7__0_n_0\
    );
\state[2]_i_8__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__0_n_7\,
      O => \state[2]_i_8__0_n_0\
    );
\state[2]_i_9__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__0_n_4\,
      O => \state[2]_i_9__0_n_0\
    );
\state[3]_i_10__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__0_n_4\,
      O => \state[3]_i_10__0_n_0\
    );
\state[3]_i_11__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__0_n_5\,
      O => \state[3]_i_11__0_n_0\
    );
\state[3]_i_12__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__0_n_6\,
      O => \state[3]_i_12__0_n_0\
    );
\state[3]_i_13__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(2),
      O => \state[3]_i_13__0_n_0\
    );
\state[3]_i_3__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => \state_reg[4]_i_1__0_n_6\,
      O => \state[3]_i_3__0_n_0\
    );
\state[3]_i_4__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__0_n_7\,
      O => \state[3]_i_4__0_n_0\
    );
\state[3]_i_5__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__0_n_4\,
      O => \state[3]_i_5__0_n_0\
    );
\state[3]_i_7__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__0_n_5\,
      O => \state[3]_i_7__0_n_0\
    );
\state[3]_i_8__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__0_n_6\,
      O => \state[3]_i_8__0_n_0\
    );
\state[3]_i_9__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__0_n_7\,
      O => \state[3]_i_9__0_n_0\
    );
\state[4]_i_10__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__0_n_5\,
      O => \state[4]_i_10__0_n_0\
    );
\state[4]_i_11__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__0_n_6\,
      O => \state[4]_i_11__0_n_0\
    );
\state[4]_i_12__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__0_n_7\,
      O => \state[4]_i_12__0_n_0\
    );
\state[4]_i_13__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__0_n_4\,
      O => \state[4]_i_13__0_n_0\
    );
\state[4]_i_16__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => \state_reg[4]_i_14__0_n_6\,
      O => \state[4]_i_16__0_n_0\
    );
\state[4]_i_17__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__0_n_7\,
      O => \state[4]_i_17__0_n_0\
    );
\state[4]_i_18__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__0_n_4\,
      O => \state[4]_i_18__0_n_0\
    );
\state[4]_i_20__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__0_n_5\,
      O => \state[4]_i_20__0_n_0\
    );
\state[4]_i_21__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__0_n_6\,
      O => \state[4]_i_21__0_n_0\
    );
\state[4]_i_22__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__0_n_7\,
      O => \state[4]_i_22__0_n_0\
    );
\state[4]_i_23__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__0_n_4\,
      O => \state[4]_i_23__0_n_0\
    );
\state[4]_i_24__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__0_n_5\,
      O => \state[4]_i_24__0_n_0\
    );
\state[4]_i_25__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__0_n_6\,
      O => \state[4]_i_25__0_n_0\
    );
\state[4]_i_26__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(3),
      O => \state[4]_i_26__0_n_0\
    );
\state[4]_i_27__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__0_n_5\,
      O => \state[4]_i_27__0_n_0\
    );
\state[4]_i_28__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__0_n_6\,
      O => \state[4]_i_28__0_n_0\
    );
\state[4]_i_29__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__0_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(4),
      O => \state[4]_i_29__0_n_0\
    );
\state[4]_i_30__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__0_1\(0),
      O => \state[4]_i_30__0_n_0\
    );
\state[4]_i_31__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__0_0\(3),
      O => \state[4]_i_31__0_n_0\
    );
\state[4]_i_32__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__0_0\(2),
      O => \state[4]_i_32__0_n_0\
    );
\state[4]_i_33__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__0_0\(1),
      O => \state[4]_i_33__0_n_0\
    );
\state[4]_i_34__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__0_0\(0),
      O => \state[4]_i_34__0_n_0\
    );
\state[4]_i_35__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__0_n_0\
    );
\state[4]_i_36__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__0_n_0\
    );
\state[4]_i_37__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__0_n_0\
    );
\state[4]_i_38__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__0_n_0\
    );
\state[4]_i_39__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_1__8_carry__0_i_6\(5),
      O => \state[4]_i_39__0_n_0\
    );
\state[4]_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => \state_reg[4]_i_3__0_n_6\,
      O => \state[4]_i_5__0_n_0\
    );
\state[4]_i_6__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__0_n_7\,
      O => \state[4]_i_6__0_n_0\
    );
\state[4]_i_7__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__0_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__0_n_4\,
      O => \state[4]_i_7__0_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__0_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__0_n_2\,
      CO(0) => \state_reg[1]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_1(2),
      DI(1) => \state_reg[2]_i_1__0_n_7\,
      DI(0) => \state_reg[2]_i_2__0_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__0_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__0_n_0\,
      S(1) => \state[1]_i_3__0_n_0\,
      S(0) => \state[1]_i_4__0_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_1(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[0]_0\(0)
    );
\state_reg[2]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__0_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__0_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_1(2),
      CO(1) => \state_reg[2]_i_1__0_n_2\,
      CO(0) => \state_reg[2]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_1(3),
      DI(1) => \state_reg[3]_i_1__0_n_7\,
      DI(0) => \state_reg[3]_i_2__0_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__0_n_6\,
      O(0) => \state_reg[2]_i_1__0_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__0_n_0\,
      S(1) => \state[2]_i_4__0_n_0\,
      S(0) => \state[2]_i_5__0_n_0\
    );
\state_reg[2]_i_2__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__0_n_0\,
      CO(2) => \state_reg[2]_i_2__0_n_1\,
      CO(1) => \state_reg[2]_i_2__0_n_2\,
      CO(0) => \state_reg[2]_i_2__0_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__0_n_5\,
      DI(2) => \state_reg[3]_i_2__0_n_6\,
      DI(1) => \state_reg[3]_i_2__0_n_7\,
      DI(0) => \state_reg[3]_i_6__0_n_4\,
      O(3) => \state_reg[2]_i_2__0_n_4\,
      O(2) => \state_reg[2]_i_2__0_n_5\,
      O(1) => \state_reg[2]_i_2__0_n_6\,
      O(0) => \state_reg[2]_i_2__0_n_7\,
      S(3) => \state[2]_i_6__0_n_0\,
      S(2) => \state[2]_i_7__0_n_0\,
      S(1) => \state[2]_i_8__0_n_0\,
      S(0) => \state[2]_i_9__0_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_1(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[0]_0\(0)
    );
\state_reg[3]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__0_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__0_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_1(3),
      CO(1) => \state_reg[3]_i_1__0_n_2\,
      CO(0) => \state_reg[3]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_1(4),
      DI(1) => \state_reg[4]_i_1__0_n_7\,
      DI(0) => \state_reg[4]_i_2__0_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__0_n_6\,
      O(0) => \state_reg[3]_i_1__0_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__0_n_0\,
      S(1) => \state[3]_i_4__0_n_0\,
      S(0) => \state[3]_i_5__0_n_0\
    );
\state_reg[3]_i_2__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__0_n_0\,
      CO(3) => \state_reg[3]_i_2__0_n_0\,
      CO(2) => \state_reg[3]_i_2__0_n_1\,
      CO(1) => \state_reg[3]_i_2__0_n_2\,
      CO(0) => \state_reg[3]_i_2__0_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__0_n_5\,
      DI(2) => \state_reg[4]_i_2__0_n_6\,
      DI(1) => \state_reg[4]_i_2__0_n_7\,
      DI(0) => \state_reg[4]_i_8__0_n_4\,
      O(3) => \state_reg[3]_i_2__0_n_4\,
      O(2) => \state_reg[3]_i_2__0_n_5\,
      O(1) => \state_reg[3]_i_2__0_n_6\,
      O(0) => \state_reg[3]_i_2__0_n_7\,
      S(3) => \state[3]_i_7__0_n_0\,
      S(2) => \state[3]_i_8__0_n_0\,
      S(1) => \state[3]_i_9__0_n_0\,
      S(0) => \state[3]_i_10__0_n_0\
    );
\state_reg[3]_i_6__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__0_n_0\,
      CO(2) => \state_reg[3]_i_6__0_n_1\,
      CO(1) => \state_reg[3]_i_6__0_n_2\,
      CO(0) => \state_reg[3]_i_6__0_n_3\,
      CYINIT => seconds_relay_1(4),
      DI(3) => \state_reg[4]_i_8__0_n_5\,
      DI(2) => \state_reg[4]_i_8__0_n_6\,
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__0_n_4\,
      O(2) => \state_reg[3]_i_6__0_n_5\,
      O(1) => \state_reg[3]_i_6__0_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__0_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__0_n_0\,
      S(2) => \state[3]_i_12__0_n_0\,
      S(1) => \state[3]_i_13__0_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_1(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[0]_0\(0)
    );
\state_reg[4]_i_14__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__0_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__0_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__0_n_1\,
      CO(1) => \state_reg[4]_i_14__0_n_2\,
      CO(0) => \state_reg[4]_i_14__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__0_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__0_n_6\,
      O(0) => \state_reg[4]_i_14__0_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__0_n_0\,
      S(1) => \state[4]_i_31__0_n_0\,
      S(0) => \state[4]_i_32__0_n_0\
    );
\state_reg[4]_i_15__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__0_n_0\,
      CO(3) => \state_reg[4]_i_15__0_n_0\,
      CO(2) => \state_reg[4]_i_15__0_n_1\,
      CO(1) => \state_reg[4]_i_15__0_n_2\,
      CO(0) => \state_reg[4]_i_15__0_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__0_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__0_n_4\,
      O(2) => \state_reg[4]_i_15__0_n_5\,
      O(1) => \state_reg[4]_i_15__0_n_6\,
      O(0) => \state_reg[4]_i_15__0_n_7\,
      S(3) => \state[4]_i_33__0_n_0\,
      S(2) => \state[4]_i_34__0_n_0\,
      S(1) => \state[4]_i_35__0_n_0\,
      S(0) => \state[4]_i_36__0_n_0\
    );
\state_reg[4]_i_19__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__0_n_0\,
      CO(2) => \state_reg[4]_i_19__0_n_1\,
      CO(1) => \state_reg[4]_i_19__0_n_2\,
      CO(0) => \state_reg[4]_i_19__0_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__0_n_4\,
      O(2) => \state_reg[4]_i_19__0_n_5\,
      O(1) => \state_reg[4]_i_19__0_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__0_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__0_n_0\,
      S(2) => \state[4]_i_38__0_n_0\,
      S(1) => \state[4]_i_39__0_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__0_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__0_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_1(4),
      CO(1) => \state_reg[4]_i_1__0_n_2\,
      CO(0) => \state_reg[4]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__0_n_1\,
      DI(1) => \state_reg[4]_i_3__0_n_7\,
      DI(0) => \state_reg[4]_i_4__0_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__0_n_6\,
      O(0) => \state_reg[4]_i_1__0_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__0_n_0\,
      S(1) => \state[4]_i_6__0_n_0\,
      S(0) => \state[4]_i_7__0_n_0\
    );
\state_reg[4]_i_2__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__0_n_0\,
      CO(3) => \state_reg[4]_i_2__0_n_0\,
      CO(2) => \state_reg[4]_i_2__0_n_1\,
      CO(1) => \state_reg[4]_i_2__0_n_2\,
      CO(0) => \state_reg[4]_i_2__0_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__0_n_5\,
      DI(2) => \state_reg[4]_i_4__0_n_6\,
      DI(1) => \state_reg[4]_i_4__0_n_7\,
      DI(0) => \state_reg[4]_i_9__0_n_4\,
      O(3) => \state_reg[4]_i_2__0_n_4\,
      O(2) => \state_reg[4]_i_2__0_n_5\,
      O(1) => \state_reg[4]_i_2__0_n_6\,
      O(0) => \state_reg[4]_i_2__0_n_7\,
      S(3) => \state[4]_i_10__0_n_0\,
      S(2) => \state[4]_i_11__0_n_0\,
      S(1) => \state[4]_i_12__0_n_0\,
      S(0) => \state[4]_i_13__0_n_0\
    );
\state_reg[4]_i_3__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__0_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__0_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__0_n_1\,
      CO(1) => \state_reg[4]_i_3__0_n_2\,
      CO(0) => \state_reg[4]_i_3__0_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__0_n_1\,
      DI(1) => \state_reg[4]_i_14__0_n_7\,
      DI(0) => \state_reg[4]_i_15__0_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__0_n_6\,
      O(0) => \state_reg[4]_i_3__0_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__0_n_0\,
      S(1) => \state[4]_i_17__0_n_0\,
      S(0) => \state[4]_i_18__0_n_0\
    );
\state_reg[4]_i_4__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__0_n_0\,
      CO(3) => \state_reg[4]_i_4__0_n_0\,
      CO(2) => \state_reg[4]_i_4__0_n_1\,
      CO(1) => \state_reg[4]_i_4__0_n_2\,
      CO(0) => \state_reg[4]_i_4__0_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__0_n_5\,
      DI(2) => \state_reg[4]_i_15__0_n_6\,
      DI(1) => \state_reg[4]_i_15__0_n_7\,
      DI(0) => \state_reg[4]_i_19__0_n_4\,
      O(3) => \state_reg[4]_i_4__0_n_4\,
      O(2) => \state_reg[4]_i_4__0_n_5\,
      O(1) => \state_reg[4]_i_4__0_n_6\,
      O(0) => \state_reg[4]_i_4__0_n_7\,
      S(3) => \state[4]_i_20__0_n_0\,
      S(2) => \state[4]_i_21__0_n_0\,
      S(1) => \state[4]_i_22__0_n_0\,
      S(0) => \state[4]_i_23__0_n_0\
    );
\state_reg[4]_i_8__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__0_n_0\,
      CO(2) => \state_reg[4]_i_8__0_n_1\,
      CO(1) => \state_reg[4]_i_8__0_n_2\,
      CO(0) => \state_reg[4]_i_8__0_n_3\,
      CYINIT => \state_reg[4]_i_3__0_n_1\,
      DI(3) => \state_reg[4]_i_9__0_n_5\,
      DI(2) => \state_reg[4]_i_9__0_n_6\,
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__0_n_4\,
      O(2) => \state_reg[4]_i_8__0_n_5\,
      O(1) => \state_reg[4]_i_8__0_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__0_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__0_n_0\,
      S(2) => \state[4]_i_25__0_n_0\,
      S(1) => \state[4]_i_26__0_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__0_n_0\,
      CO(2) => \state_reg[4]_i_9__0_n_1\,
      CO(1) => \state_reg[4]_i_9__0_n_2\,
      CO(0) => \state_reg[4]_i_9__0_n_3\,
      CYINIT => \state_reg[4]_i_14__0_n_1\,
      DI(3) => \state_reg[4]_i_19__0_n_5\,
      DI(2) => \state_reg[4]_i_19__0_n_6\,
      DI(1) => \seconds_relay_1__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__0_n_4\,
      O(2) => \state_reg[4]_i_9__0_n_5\,
      O(1) => \state_reg[4]_i_9__0_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__0_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__0_n_0\,
      S(2) => \state[4]_i_28__0_n_0\,
      S(1) => \state[4]_i_29__0_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_1\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg4_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg4_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__1_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_2__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__1_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__1_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_1\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_1\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_1\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_2 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_2__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__1_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__1_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__1_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__1_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__1_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__1_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__1_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__1_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__1_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__1_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__1_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__1_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__1_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__1_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__1_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__1_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__1_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__1_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__1_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__1_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__1_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__1_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__1_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_2__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_2__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_2__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_2__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_2__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_2__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_2__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__1_n_5\,
      DI(2) => \state_reg[2]_i_2__1_n_6\,
      DI(1) => \state_reg[2]_i_2__1_n_7\,
      DI(0) => \seconds_relay_2__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg4_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_2__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_2__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_2__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_2__274_carry__0_i_9_n_0\
    );
\seconds_relay_2__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__1_n_5\,
      O => \seconds_relay_2__274_carry__0_i_6_n_0\
    );
\seconds_relay_2__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__1_n_6\,
      O => \seconds_relay_2__274_carry__0_i_7_n_0\
    );
\seconds_relay_2__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__1_n_7\,
      O => \seconds_relay_2__274_carry__0_i_8_n_0\
    );
\seconds_relay_2__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(3),
      I2 => \seconds_relay_2__274_carry_i_6_n_4\,
      O => \seconds_relay_2__274_carry__0_i_9_n_0\
    );
\seconds_relay_2__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__1_n_6\,
      O => \state_reg[1]_i_1__1_0\(1)
    );
\seconds_relay_2__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__1_0\(0)
    );
\seconds_relay_2__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_2__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_2__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_2__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_2__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_2(2),
      DI(3) => \seconds_relay_2__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_2__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg4_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_2__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_2__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_2__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_2__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_2__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__1_n_5\,
      O => \seconds_relay_2__274_carry_i_10_n_0\
    );
\seconds_relay_2__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__1_n_6\,
      O => \seconds_relay_2__274_carry_i_11_n_0\
    );
\seconds_relay_2__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(1),
      O => \seconds_relay_2__274_carry_i_12_n_0\
    );
\seconds_relay_2__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_2__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_2__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_2__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_2__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_2(3),
      DI(3) => \state_reg[3]_i_6__1_n_5\,
      DI(2) => \state_reg[3]_i_6__1_n_6\,
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_2__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_2__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_2__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_2__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_2__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_2__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_2__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_2__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(2),
      I2 => \seconds_relay_2__274_carry_i_6_n_5\,
      O => \seconds_relay_2__274_carry_i_7_n_0\
    );
\seconds_relay_2__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(1),
      I2 => \seconds_relay_2__274_carry_i_6_n_6\,
      O => \seconds_relay_2__274_carry_i_8_n_0\
    );
\seconds_relay_2__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(0),
      O => \seconds_relay_2__274_carry_i_9_n_0\
    );
\seconds_relay_2__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_2__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_2__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_2__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_2__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_2__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_2__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => \state_reg[2]_i_1__1_n_6\,
      O => \state[1]_i_2__1_n_0\
    );
\state[1]_i_3__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__1_n_7\,
      O => \state[1]_i_3__1_n_0\
    );
\state[1]_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__1_n_4\,
      O => \state[1]_i_4__1_n_0\
    );
\state[2]_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => \state_reg[3]_i_1__1_n_6\,
      O => \state[2]_i_3__1_n_0\
    );
\state[2]_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__1_n_7\,
      O => \state[2]_i_4__1_n_0\
    );
\state[2]_i_5__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__1_n_4\,
      O => \state[2]_i_5__1_n_0\
    );
\state[2]_i_6__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__1_n_5\,
      O => \state[2]_i_6__1_n_0\
    );
\state[2]_i_7__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__1_n_6\,
      O => \state[2]_i_7__1_n_0\
    );
\state[2]_i_8__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__1_n_7\,
      O => \state[2]_i_8__1_n_0\
    );
\state[2]_i_9__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__1_n_4\,
      O => \state[2]_i_9__1_n_0\
    );
\state[3]_i_10__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__1_n_4\,
      O => \state[3]_i_10__1_n_0\
    );
\state[3]_i_11__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__1_n_5\,
      O => \state[3]_i_11__1_n_0\
    );
\state[3]_i_12__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__1_n_6\,
      O => \state[3]_i_12__1_n_0\
    );
\state[3]_i_13__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(2),
      O => \state[3]_i_13__1_n_0\
    );
\state[3]_i_3__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => \state_reg[4]_i_1__1_n_6\,
      O => \state[3]_i_3__1_n_0\
    );
\state[3]_i_4__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__1_n_7\,
      O => \state[3]_i_4__1_n_0\
    );
\state[3]_i_5__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__1_n_4\,
      O => \state[3]_i_5__1_n_0\
    );
\state[3]_i_7__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__1_n_5\,
      O => \state[3]_i_7__1_n_0\
    );
\state[3]_i_8__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__1_n_6\,
      O => \state[3]_i_8__1_n_0\
    );
\state[3]_i_9__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__1_n_7\,
      O => \state[3]_i_9__1_n_0\
    );
\state[4]_i_10__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__1_n_5\,
      O => \state[4]_i_10__1_n_0\
    );
\state[4]_i_11__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__1_n_6\,
      O => \state[4]_i_11__1_n_0\
    );
\state[4]_i_12__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__1_n_7\,
      O => \state[4]_i_12__1_n_0\
    );
\state[4]_i_13__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__1_n_4\,
      O => \state[4]_i_13__1_n_0\
    );
\state[4]_i_16__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => \state_reg[4]_i_14__1_n_6\,
      O => \state[4]_i_16__1_n_0\
    );
\state[4]_i_17__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__1_n_7\,
      O => \state[4]_i_17__1_n_0\
    );
\state[4]_i_18__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__1_n_4\,
      O => \state[4]_i_18__1_n_0\
    );
\state[4]_i_20__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__1_n_5\,
      O => \state[4]_i_20__1_n_0\
    );
\state[4]_i_21__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__1_n_6\,
      O => \state[4]_i_21__1_n_0\
    );
\state[4]_i_22__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__1_n_7\,
      O => \state[4]_i_22__1_n_0\
    );
\state[4]_i_23__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__1_n_4\,
      O => \state[4]_i_23__1_n_0\
    );
\state[4]_i_24__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__1_n_5\,
      O => \state[4]_i_24__1_n_0\
    );
\state[4]_i_25__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__1_n_6\,
      O => \state[4]_i_25__1_n_0\
    );
\state[4]_i_26__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(3),
      O => \state[4]_i_26__1_n_0\
    );
\state[4]_i_27__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__1_n_5\,
      O => \state[4]_i_27__1_n_0\
    );
\state[4]_i_28__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__1_n_6\,
      O => \state[4]_i_28__1_n_0\
    );
\state[4]_i_29__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__1_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(4),
      O => \state[4]_i_29__1_n_0\
    );
\state[4]_i_30__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__1_1\(0),
      O => \state[4]_i_30__1_n_0\
    );
\state[4]_i_31__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__1_0\(3),
      O => \state[4]_i_31__1_n_0\
    );
\state[4]_i_32__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__1_0\(2),
      O => \state[4]_i_32__1_n_0\
    );
\state[4]_i_33__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__1_0\(1),
      O => \state[4]_i_33__1_n_0\
    );
\state[4]_i_34__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__1_0\(0),
      O => \state[4]_i_34__1_n_0\
    );
\state[4]_i_35__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__1_n_0\
    );
\state[4]_i_36__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__1_n_0\
    );
\state[4]_i_37__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__1_n_0\
    );
\state[4]_i_38__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__1_n_0\
    );
\state[4]_i_39__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_2__8_carry__0_i_6\(5),
      O => \state[4]_i_39__1_n_0\
    );
\state[4]_i_5__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => \state_reg[4]_i_3__1_n_6\,
      O => \state[4]_i_5__1_n_0\
    );
\state[4]_i_6__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__1_n_7\,
      O => \state[4]_i_6__1_n_0\
    );
\state[4]_i_7__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__1_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__1_n_4\,
      O => \state[4]_i_7__1_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__1_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__1_n_2\,
      CO(0) => \state_reg[1]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_2(2),
      DI(1) => \state_reg[2]_i_1__1_n_7\,
      DI(0) => \state_reg[2]_i_2__1_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__1_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__1_n_0\,
      S(1) => \state[1]_i_3__1_n_0\,
      S(0) => \state[1]_i_4__1_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_2(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[4]_1\(0)
    );
\state_reg[2]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__1_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_2(2),
      CO(1) => \state_reg[2]_i_1__1_n_2\,
      CO(0) => \state_reg[2]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_2(3),
      DI(1) => \state_reg[3]_i_1__1_n_7\,
      DI(0) => \state_reg[3]_i_2__1_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__1_n_6\,
      O(0) => \state_reg[2]_i_1__1_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__1_n_0\,
      S(1) => \state[2]_i_4__1_n_0\,
      S(0) => \state[2]_i_5__1_n_0\
    );
\state_reg[2]_i_2__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__1_n_0\,
      CO(2) => \state_reg[2]_i_2__1_n_1\,
      CO(1) => \state_reg[2]_i_2__1_n_2\,
      CO(0) => \state_reg[2]_i_2__1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__1_n_5\,
      DI(2) => \state_reg[3]_i_2__1_n_6\,
      DI(1) => \state_reg[3]_i_2__1_n_7\,
      DI(0) => \state_reg[3]_i_6__1_n_4\,
      O(3) => \state_reg[2]_i_2__1_n_4\,
      O(2) => \state_reg[2]_i_2__1_n_5\,
      O(1) => \state_reg[2]_i_2__1_n_6\,
      O(0) => \state_reg[2]_i_2__1_n_7\,
      S(3) => \state[2]_i_6__1_n_0\,
      S(2) => \state[2]_i_7__1_n_0\,
      S(1) => \state[2]_i_8__1_n_0\,
      S(0) => \state[2]_i_9__1_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_2(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[4]_1\(0)
    );
\state_reg[3]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__1_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_2(3),
      CO(1) => \state_reg[3]_i_1__1_n_2\,
      CO(0) => \state_reg[3]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_2(4),
      DI(1) => \state_reg[4]_i_1__1_n_7\,
      DI(0) => \state_reg[4]_i_2__1_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__1_n_6\,
      O(0) => \state_reg[3]_i_1__1_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__1_n_0\,
      S(1) => \state[3]_i_4__1_n_0\,
      S(0) => \state[3]_i_5__1_n_0\
    );
\state_reg[3]_i_2__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__1_n_0\,
      CO(3) => \state_reg[3]_i_2__1_n_0\,
      CO(2) => \state_reg[3]_i_2__1_n_1\,
      CO(1) => \state_reg[3]_i_2__1_n_2\,
      CO(0) => \state_reg[3]_i_2__1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__1_n_5\,
      DI(2) => \state_reg[4]_i_2__1_n_6\,
      DI(1) => \state_reg[4]_i_2__1_n_7\,
      DI(0) => \state_reg[4]_i_8__1_n_4\,
      O(3) => \state_reg[3]_i_2__1_n_4\,
      O(2) => \state_reg[3]_i_2__1_n_5\,
      O(1) => \state_reg[3]_i_2__1_n_6\,
      O(0) => \state_reg[3]_i_2__1_n_7\,
      S(3) => \state[3]_i_7__1_n_0\,
      S(2) => \state[3]_i_8__1_n_0\,
      S(1) => \state[3]_i_9__1_n_0\,
      S(0) => \state[3]_i_10__1_n_0\
    );
\state_reg[3]_i_6__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__1_n_0\,
      CO(2) => \state_reg[3]_i_6__1_n_1\,
      CO(1) => \state_reg[3]_i_6__1_n_2\,
      CO(0) => \state_reg[3]_i_6__1_n_3\,
      CYINIT => seconds_relay_2(4),
      DI(3) => \state_reg[4]_i_8__1_n_5\,
      DI(2) => \state_reg[4]_i_8__1_n_6\,
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__1_n_4\,
      O(2) => \state_reg[3]_i_6__1_n_5\,
      O(1) => \state_reg[3]_i_6__1_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__1_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__1_n_0\,
      S(2) => \state[3]_i_12__1_n_0\,
      S(1) => \state[3]_i_13__1_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_2(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[4]_1\(0)
    );
\state_reg[4]_i_14__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__1_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__1_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__1_n_1\,
      CO(1) => \state_reg[4]_i_14__1_n_2\,
      CO(0) => \state_reg[4]_i_14__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__1_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__1_n_6\,
      O(0) => \state_reg[4]_i_14__1_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__1_n_0\,
      S(1) => \state[4]_i_31__1_n_0\,
      S(0) => \state[4]_i_32__1_n_0\
    );
\state_reg[4]_i_15__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__1_n_0\,
      CO(3) => \state_reg[4]_i_15__1_n_0\,
      CO(2) => \state_reg[4]_i_15__1_n_1\,
      CO(1) => \state_reg[4]_i_15__1_n_2\,
      CO(0) => \state_reg[4]_i_15__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__1_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__1_n_4\,
      O(2) => \state_reg[4]_i_15__1_n_5\,
      O(1) => \state_reg[4]_i_15__1_n_6\,
      O(0) => \state_reg[4]_i_15__1_n_7\,
      S(3) => \state[4]_i_33__1_n_0\,
      S(2) => \state[4]_i_34__1_n_0\,
      S(1) => \state[4]_i_35__1_n_0\,
      S(0) => \state[4]_i_36__1_n_0\
    );
\state_reg[4]_i_19__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__1_n_0\,
      CO(2) => \state_reg[4]_i_19__1_n_1\,
      CO(1) => \state_reg[4]_i_19__1_n_2\,
      CO(0) => \state_reg[4]_i_19__1_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__1_n_4\,
      O(2) => \state_reg[4]_i_19__1_n_5\,
      O(1) => \state_reg[4]_i_19__1_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__1_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__1_n_0\,
      S(2) => \state[4]_i_38__1_n_0\,
      S(1) => \state[4]_i_39__1_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__1_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__1_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_2(4),
      CO(1) => \state_reg[4]_i_1__1_n_2\,
      CO(0) => \state_reg[4]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__1_n_1\,
      DI(1) => \state_reg[4]_i_3__1_n_7\,
      DI(0) => \state_reg[4]_i_4__1_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__1_n_6\,
      O(0) => \state_reg[4]_i_1__1_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__1_n_0\,
      S(1) => \state[4]_i_6__1_n_0\,
      S(0) => \state[4]_i_7__1_n_0\
    );
\state_reg[4]_i_2__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__1_n_0\,
      CO(3) => \state_reg[4]_i_2__1_n_0\,
      CO(2) => \state_reg[4]_i_2__1_n_1\,
      CO(1) => \state_reg[4]_i_2__1_n_2\,
      CO(0) => \state_reg[4]_i_2__1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__1_n_5\,
      DI(2) => \state_reg[4]_i_4__1_n_6\,
      DI(1) => \state_reg[4]_i_4__1_n_7\,
      DI(0) => \state_reg[4]_i_9__1_n_4\,
      O(3) => \state_reg[4]_i_2__1_n_4\,
      O(2) => \state_reg[4]_i_2__1_n_5\,
      O(1) => \state_reg[4]_i_2__1_n_6\,
      O(0) => \state_reg[4]_i_2__1_n_7\,
      S(3) => \state[4]_i_10__1_n_0\,
      S(2) => \state[4]_i_11__1_n_0\,
      S(1) => \state[4]_i_12__1_n_0\,
      S(0) => \state[4]_i_13__1_n_0\
    );
\state_reg[4]_i_3__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__1_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__1_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__1_n_1\,
      CO(1) => \state_reg[4]_i_3__1_n_2\,
      CO(0) => \state_reg[4]_i_3__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__1_n_1\,
      DI(1) => \state_reg[4]_i_14__1_n_7\,
      DI(0) => \state_reg[4]_i_15__1_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__1_n_6\,
      O(0) => \state_reg[4]_i_3__1_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__1_n_0\,
      S(1) => \state[4]_i_17__1_n_0\,
      S(0) => \state[4]_i_18__1_n_0\
    );
\state_reg[4]_i_4__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__1_n_0\,
      CO(3) => \state_reg[4]_i_4__1_n_0\,
      CO(2) => \state_reg[4]_i_4__1_n_1\,
      CO(1) => \state_reg[4]_i_4__1_n_2\,
      CO(0) => \state_reg[4]_i_4__1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__1_n_5\,
      DI(2) => \state_reg[4]_i_15__1_n_6\,
      DI(1) => \state_reg[4]_i_15__1_n_7\,
      DI(0) => \state_reg[4]_i_19__1_n_4\,
      O(3) => \state_reg[4]_i_4__1_n_4\,
      O(2) => \state_reg[4]_i_4__1_n_5\,
      O(1) => \state_reg[4]_i_4__1_n_6\,
      O(0) => \state_reg[4]_i_4__1_n_7\,
      S(3) => \state[4]_i_20__1_n_0\,
      S(2) => \state[4]_i_21__1_n_0\,
      S(1) => \state[4]_i_22__1_n_0\,
      S(0) => \state[4]_i_23__1_n_0\
    );
\state_reg[4]_i_8__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__1_n_0\,
      CO(2) => \state_reg[4]_i_8__1_n_1\,
      CO(1) => \state_reg[4]_i_8__1_n_2\,
      CO(0) => \state_reg[4]_i_8__1_n_3\,
      CYINIT => \state_reg[4]_i_3__1_n_1\,
      DI(3) => \state_reg[4]_i_9__1_n_5\,
      DI(2) => \state_reg[4]_i_9__1_n_6\,
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__1_n_4\,
      O(2) => \state_reg[4]_i_8__1_n_5\,
      O(1) => \state_reg[4]_i_8__1_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__1_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__1_n_0\,
      S(2) => \state[4]_i_25__1_n_0\,
      S(1) => \state[4]_i_26__1_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__1_n_0\,
      CO(2) => \state_reg[4]_i_9__1_n_1\,
      CO(1) => \state_reg[4]_i_9__1_n_2\,
      CO(0) => \state_reg[4]_i_9__1_n_3\,
      CYINIT => \state_reg[4]_i_14__1_n_1\,
      DI(3) => \state_reg[4]_i_19__1_n_5\,
      DI(2) => \state_reg[4]_i_19__1_n_6\,
      DI(1) => \seconds_relay_2__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__1_n_4\,
      O(2) => \state_reg[4]_i_9__1_n_5\,
      O(1) => \state_reg[4]_i_9__1_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__1_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__1_n_0\,
      S(2) => \state[4]_i_28__1_n_0\,
      S(1) => \state[4]_i_29__1_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_2\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg5_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg5_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__2_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_3__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__2_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__2_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[0]_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_2\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_2\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_2\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_3 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_3__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__2_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__2_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__2_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__2_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__2_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__2_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__2_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__2_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__2_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__2_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__2_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__2_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__2_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__2_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__2_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__2_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__2_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__2_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__2_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__2_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__2_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__2_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__2_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_3__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_3__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_3__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_3__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_3__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_3__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_3__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__2_n_5\,
      DI(2) => \state_reg[2]_i_2__2_n_6\,
      DI(1) => \state_reg[2]_i_2__2_n_7\,
      DI(0) => \seconds_relay_3__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg5_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_3__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_3__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_3__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_3__274_carry__0_i_9_n_0\
    );
\seconds_relay_3__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__2_n_5\,
      O => \seconds_relay_3__274_carry__0_i_6_n_0\
    );
\seconds_relay_3__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__2_n_6\,
      O => \seconds_relay_3__274_carry__0_i_7_n_0\
    );
\seconds_relay_3__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__2_n_7\,
      O => \seconds_relay_3__274_carry__0_i_8_n_0\
    );
\seconds_relay_3__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(3),
      I2 => \seconds_relay_3__274_carry_i_6_n_4\,
      O => \seconds_relay_3__274_carry__0_i_9_n_0\
    );
\seconds_relay_3__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__2_n_6\,
      O => \state_reg[1]_i_1__2_0\(1)
    );
\seconds_relay_3__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__2_0\(0)
    );
\seconds_relay_3__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_3__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_3__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_3__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_3__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_3(2),
      DI(3) => \seconds_relay_3__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_3__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg5_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_3__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_3__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_3__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_3__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_3__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__2_n_5\,
      O => \seconds_relay_3__274_carry_i_10_n_0\
    );
\seconds_relay_3__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__2_n_6\,
      O => \seconds_relay_3__274_carry_i_11_n_0\
    );
\seconds_relay_3__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(1),
      O => \seconds_relay_3__274_carry_i_12_n_0\
    );
\seconds_relay_3__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_3__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_3__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_3__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_3__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_3(3),
      DI(3) => \state_reg[3]_i_6__2_n_5\,
      DI(2) => \state_reg[3]_i_6__2_n_6\,
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_3__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_3__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_3__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_3__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_3__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_3__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_3__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_3__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(2),
      I2 => \seconds_relay_3__274_carry_i_6_n_5\,
      O => \seconds_relay_3__274_carry_i_7_n_0\
    );
\seconds_relay_3__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(1),
      I2 => \seconds_relay_3__274_carry_i_6_n_6\,
      O => \seconds_relay_3__274_carry_i_8_n_0\
    );
\seconds_relay_3__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(0),
      O => \seconds_relay_3__274_carry_i_9_n_0\
    );
\seconds_relay_3__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_3__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_3__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_3__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_3__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_3__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_3__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => \state_reg[2]_i_1__2_n_6\,
      O => \state[1]_i_2__2_n_0\
    );
\state[1]_i_3__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__2_n_7\,
      O => \state[1]_i_3__2_n_0\
    );
\state[1]_i_4__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__2_n_4\,
      O => \state[1]_i_4__2_n_0\
    );
\state[2]_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => \state_reg[3]_i_1__2_n_6\,
      O => \state[2]_i_3__2_n_0\
    );
\state[2]_i_4__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__2_n_7\,
      O => \state[2]_i_4__2_n_0\
    );
\state[2]_i_5__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__2_n_4\,
      O => \state[2]_i_5__2_n_0\
    );
\state[2]_i_6__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__2_n_5\,
      O => \state[2]_i_6__2_n_0\
    );
\state[2]_i_7__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__2_n_6\,
      O => \state[2]_i_7__2_n_0\
    );
\state[2]_i_8__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__2_n_7\,
      O => \state[2]_i_8__2_n_0\
    );
\state[2]_i_9__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__2_n_4\,
      O => \state[2]_i_9__2_n_0\
    );
\state[3]_i_10__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__2_n_4\,
      O => \state[3]_i_10__2_n_0\
    );
\state[3]_i_11__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__2_n_5\,
      O => \state[3]_i_11__2_n_0\
    );
\state[3]_i_12__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__2_n_6\,
      O => \state[3]_i_12__2_n_0\
    );
\state[3]_i_13__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(2),
      O => \state[3]_i_13__2_n_0\
    );
\state[3]_i_3__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => \state_reg[4]_i_1__2_n_6\,
      O => \state[3]_i_3__2_n_0\
    );
\state[3]_i_4__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__2_n_7\,
      O => \state[3]_i_4__2_n_0\
    );
\state[3]_i_5__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__2_n_4\,
      O => \state[3]_i_5__2_n_0\
    );
\state[3]_i_7__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__2_n_5\,
      O => \state[3]_i_7__2_n_0\
    );
\state[3]_i_8__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__2_n_6\,
      O => \state[3]_i_8__2_n_0\
    );
\state[3]_i_9__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__2_n_7\,
      O => \state[3]_i_9__2_n_0\
    );
\state[4]_i_10__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__2_n_5\,
      O => \state[4]_i_10__2_n_0\
    );
\state[4]_i_11__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__2_n_6\,
      O => \state[4]_i_11__2_n_0\
    );
\state[4]_i_12__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__2_n_7\,
      O => \state[4]_i_12__2_n_0\
    );
\state[4]_i_13__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__2_n_4\,
      O => \state[4]_i_13__2_n_0\
    );
\state[4]_i_16__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => \state_reg[4]_i_14__2_n_6\,
      O => \state[4]_i_16__2_n_0\
    );
\state[4]_i_17__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__2_n_7\,
      O => \state[4]_i_17__2_n_0\
    );
\state[4]_i_18__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__2_n_4\,
      O => \state[4]_i_18__2_n_0\
    );
\state[4]_i_20__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__2_n_5\,
      O => \state[4]_i_20__2_n_0\
    );
\state[4]_i_21__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__2_n_6\,
      O => \state[4]_i_21__2_n_0\
    );
\state[4]_i_22__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__2_n_7\,
      O => \state[4]_i_22__2_n_0\
    );
\state[4]_i_23__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__2_n_4\,
      O => \state[4]_i_23__2_n_0\
    );
\state[4]_i_24__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__2_n_5\,
      O => \state[4]_i_24__2_n_0\
    );
\state[4]_i_25__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__2_n_6\,
      O => \state[4]_i_25__2_n_0\
    );
\state[4]_i_26__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(3),
      O => \state[4]_i_26__2_n_0\
    );
\state[4]_i_27__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__2_n_5\,
      O => \state[4]_i_27__2_n_0\
    );
\state[4]_i_28__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__2_n_6\,
      O => \state[4]_i_28__2_n_0\
    );
\state[4]_i_29__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__2_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(4),
      O => \state[4]_i_29__2_n_0\
    );
\state[4]_i_30__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__2_1\(0),
      O => \state[4]_i_30__2_n_0\
    );
\state[4]_i_31__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__2_0\(3),
      O => \state[4]_i_31__2_n_0\
    );
\state[4]_i_32__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__2_0\(2),
      O => \state[4]_i_32__2_n_0\
    );
\state[4]_i_33__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__2_0\(1),
      O => \state[4]_i_33__2_n_0\
    );
\state[4]_i_34__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__2_0\(0),
      O => \state[4]_i_34__2_n_0\
    );
\state[4]_i_35__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__2_n_0\
    );
\state[4]_i_36__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__2_n_0\
    );
\state[4]_i_37__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__2_n_0\
    );
\state[4]_i_38__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__2_n_0\
    );
\state[4]_i_39__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_3__8_carry__0_i_6\(5),
      O => \state[4]_i_39__2_n_0\
    );
\state[4]_i_5__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => \state_reg[4]_i_3__2_n_6\,
      O => \state[4]_i_5__2_n_0\
    );
\state[4]_i_6__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__2_n_7\,
      O => \state[4]_i_6__2_n_0\
    );
\state[4]_i_7__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__2_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__2_n_4\,
      O => \state[4]_i_7__2_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__2_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__2_n_2\,
      CO(0) => \state_reg[1]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_3(2),
      DI(1) => \state_reg[2]_i_1__2_n_7\,
      DI(0) => \state_reg[2]_i_2__2_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__2_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__2_n_0\,
      S(1) => \state[1]_i_3__2_n_0\,
      S(0) => \state[1]_i_4__2_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_3(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[0]_0\(0)
    );
\state_reg[2]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__2_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__2_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_3(2),
      CO(1) => \state_reg[2]_i_1__2_n_2\,
      CO(0) => \state_reg[2]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_3(3),
      DI(1) => \state_reg[3]_i_1__2_n_7\,
      DI(0) => \state_reg[3]_i_2__2_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__2_n_6\,
      O(0) => \state_reg[2]_i_1__2_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__2_n_0\,
      S(1) => \state[2]_i_4__2_n_0\,
      S(0) => \state[2]_i_5__2_n_0\
    );
\state_reg[2]_i_2__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__2_n_0\,
      CO(2) => \state_reg[2]_i_2__2_n_1\,
      CO(1) => \state_reg[2]_i_2__2_n_2\,
      CO(0) => \state_reg[2]_i_2__2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__2_n_5\,
      DI(2) => \state_reg[3]_i_2__2_n_6\,
      DI(1) => \state_reg[3]_i_2__2_n_7\,
      DI(0) => \state_reg[3]_i_6__2_n_4\,
      O(3) => \state_reg[2]_i_2__2_n_4\,
      O(2) => \state_reg[2]_i_2__2_n_5\,
      O(1) => \state_reg[2]_i_2__2_n_6\,
      O(0) => \state_reg[2]_i_2__2_n_7\,
      S(3) => \state[2]_i_6__2_n_0\,
      S(2) => \state[2]_i_7__2_n_0\,
      S(1) => \state[2]_i_8__2_n_0\,
      S(0) => \state[2]_i_9__2_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_3(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[0]_0\(0)
    );
\state_reg[3]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__2_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__2_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_3(3),
      CO(1) => \state_reg[3]_i_1__2_n_2\,
      CO(0) => \state_reg[3]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_3(4),
      DI(1) => \state_reg[4]_i_1__2_n_7\,
      DI(0) => \state_reg[4]_i_2__2_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__2_n_6\,
      O(0) => \state_reg[3]_i_1__2_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__2_n_0\,
      S(1) => \state[3]_i_4__2_n_0\,
      S(0) => \state[3]_i_5__2_n_0\
    );
\state_reg[3]_i_2__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__2_n_0\,
      CO(3) => \state_reg[3]_i_2__2_n_0\,
      CO(2) => \state_reg[3]_i_2__2_n_1\,
      CO(1) => \state_reg[3]_i_2__2_n_2\,
      CO(0) => \state_reg[3]_i_2__2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__2_n_5\,
      DI(2) => \state_reg[4]_i_2__2_n_6\,
      DI(1) => \state_reg[4]_i_2__2_n_7\,
      DI(0) => \state_reg[4]_i_8__2_n_4\,
      O(3) => \state_reg[3]_i_2__2_n_4\,
      O(2) => \state_reg[3]_i_2__2_n_5\,
      O(1) => \state_reg[3]_i_2__2_n_6\,
      O(0) => \state_reg[3]_i_2__2_n_7\,
      S(3) => \state[3]_i_7__2_n_0\,
      S(2) => \state[3]_i_8__2_n_0\,
      S(1) => \state[3]_i_9__2_n_0\,
      S(0) => \state[3]_i_10__2_n_0\
    );
\state_reg[3]_i_6__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__2_n_0\,
      CO(2) => \state_reg[3]_i_6__2_n_1\,
      CO(1) => \state_reg[3]_i_6__2_n_2\,
      CO(0) => \state_reg[3]_i_6__2_n_3\,
      CYINIT => seconds_relay_3(4),
      DI(3) => \state_reg[4]_i_8__2_n_5\,
      DI(2) => \state_reg[4]_i_8__2_n_6\,
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__2_n_4\,
      O(2) => \state_reg[3]_i_6__2_n_5\,
      O(1) => \state_reg[3]_i_6__2_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__2_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__2_n_0\,
      S(2) => \state[3]_i_12__2_n_0\,
      S(1) => \state[3]_i_13__2_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_3(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[0]_0\(0)
    );
\state_reg[4]_i_14__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__2_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__2_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__2_n_1\,
      CO(1) => \state_reg[4]_i_14__2_n_2\,
      CO(0) => \state_reg[4]_i_14__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__2_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__2_n_6\,
      O(0) => \state_reg[4]_i_14__2_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__2_n_0\,
      S(1) => \state[4]_i_31__2_n_0\,
      S(0) => \state[4]_i_32__2_n_0\
    );
\state_reg[4]_i_15__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__2_n_0\,
      CO(3) => \state_reg[4]_i_15__2_n_0\,
      CO(2) => \state_reg[4]_i_15__2_n_1\,
      CO(1) => \state_reg[4]_i_15__2_n_2\,
      CO(0) => \state_reg[4]_i_15__2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__2_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__2_n_4\,
      O(2) => \state_reg[4]_i_15__2_n_5\,
      O(1) => \state_reg[4]_i_15__2_n_6\,
      O(0) => \state_reg[4]_i_15__2_n_7\,
      S(3) => \state[4]_i_33__2_n_0\,
      S(2) => \state[4]_i_34__2_n_0\,
      S(1) => \state[4]_i_35__2_n_0\,
      S(0) => \state[4]_i_36__2_n_0\
    );
\state_reg[4]_i_19__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__2_n_0\,
      CO(2) => \state_reg[4]_i_19__2_n_1\,
      CO(1) => \state_reg[4]_i_19__2_n_2\,
      CO(0) => \state_reg[4]_i_19__2_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__2_n_4\,
      O(2) => \state_reg[4]_i_19__2_n_5\,
      O(1) => \state_reg[4]_i_19__2_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__2_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__2_n_0\,
      S(2) => \state[4]_i_38__2_n_0\,
      S(1) => \state[4]_i_39__2_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__2_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__2_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_3(4),
      CO(1) => \state_reg[4]_i_1__2_n_2\,
      CO(0) => \state_reg[4]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__2_n_1\,
      DI(1) => \state_reg[4]_i_3__2_n_7\,
      DI(0) => \state_reg[4]_i_4__2_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__2_n_6\,
      O(0) => \state_reg[4]_i_1__2_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__2_n_0\,
      S(1) => \state[4]_i_6__2_n_0\,
      S(0) => \state[4]_i_7__2_n_0\
    );
\state_reg[4]_i_2__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__2_n_0\,
      CO(3) => \state_reg[4]_i_2__2_n_0\,
      CO(2) => \state_reg[4]_i_2__2_n_1\,
      CO(1) => \state_reg[4]_i_2__2_n_2\,
      CO(0) => \state_reg[4]_i_2__2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__2_n_5\,
      DI(2) => \state_reg[4]_i_4__2_n_6\,
      DI(1) => \state_reg[4]_i_4__2_n_7\,
      DI(0) => \state_reg[4]_i_9__2_n_4\,
      O(3) => \state_reg[4]_i_2__2_n_4\,
      O(2) => \state_reg[4]_i_2__2_n_5\,
      O(1) => \state_reg[4]_i_2__2_n_6\,
      O(0) => \state_reg[4]_i_2__2_n_7\,
      S(3) => \state[4]_i_10__2_n_0\,
      S(2) => \state[4]_i_11__2_n_0\,
      S(1) => \state[4]_i_12__2_n_0\,
      S(0) => \state[4]_i_13__2_n_0\
    );
\state_reg[4]_i_3__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__2_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__2_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__2_n_1\,
      CO(1) => \state_reg[4]_i_3__2_n_2\,
      CO(0) => \state_reg[4]_i_3__2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__2_n_1\,
      DI(1) => \state_reg[4]_i_14__2_n_7\,
      DI(0) => \state_reg[4]_i_15__2_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__2_n_6\,
      O(0) => \state_reg[4]_i_3__2_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__2_n_0\,
      S(1) => \state[4]_i_17__2_n_0\,
      S(0) => \state[4]_i_18__2_n_0\
    );
\state_reg[4]_i_4__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__2_n_0\,
      CO(3) => \state_reg[4]_i_4__2_n_0\,
      CO(2) => \state_reg[4]_i_4__2_n_1\,
      CO(1) => \state_reg[4]_i_4__2_n_2\,
      CO(0) => \state_reg[4]_i_4__2_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__2_n_5\,
      DI(2) => \state_reg[4]_i_15__2_n_6\,
      DI(1) => \state_reg[4]_i_15__2_n_7\,
      DI(0) => \state_reg[4]_i_19__2_n_4\,
      O(3) => \state_reg[4]_i_4__2_n_4\,
      O(2) => \state_reg[4]_i_4__2_n_5\,
      O(1) => \state_reg[4]_i_4__2_n_6\,
      O(0) => \state_reg[4]_i_4__2_n_7\,
      S(3) => \state[4]_i_20__2_n_0\,
      S(2) => \state[4]_i_21__2_n_0\,
      S(1) => \state[4]_i_22__2_n_0\,
      S(0) => \state[4]_i_23__2_n_0\
    );
\state_reg[4]_i_8__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__2_n_0\,
      CO(2) => \state_reg[4]_i_8__2_n_1\,
      CO(1) => \state_reg[4]_i_8__2_n_2\,
      CO(0) => \state_reg[4]_i_8__2_n_3\,
      CYINIT => \state_reg[4]_i_3__2_n_1\,
      DI(3) => \state_reg[4]_i_9__2_n_5\,
      DI(2) => \state_reg[4]_i_9__2_n_6\,
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__2_n_4\,
      O(2) => \state_reg[4]_i_8__2_n_5\,
      O(1) => \state_reg[4]_i_8__2_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__2_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__2_n_0\,
      S(2) => \state[4]_i_25__2_n_0\,
      S(1) => \state[4]_i_26__2_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__2_n_0\,
      CO(2) => \state_reg[4]_i_9__2_n_1\,
      CO(1) => \state_reg[4]_i_9__2_n_2\,
      CO(0) => \state_reg[4]_i_9__2_n_3\,
      CYINIT => \state_reg[4]_i_14__2_n_1\,
      DI(3) => \state_reg[4]_i_19__2_n_5\,
      DI(2) => \state_reg[4]_i_19__2_n_6\,
      DI(1) => \seconds_relay_3__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__2_n_4\,
      O(2) => \state_reg[4]_i_9__2_n_5\,
      O(1) => \state_reg[4]_i_9__2_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__2_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__2_n_0\,
      S(2) => \state[4]_i_28__2_n_0\,
      S(1) => \state[4]_i_29__2_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_3\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg6_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg6_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__3_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_4__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__3_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__3_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_3\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_3\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_3\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_4 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_4__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__3_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__3_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__3_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__3_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__3_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__3_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__3_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__3_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__3_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__3_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__3_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__3_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__3_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__3_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__3_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__3_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__3_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__3_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__3_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__3_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__3_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__3_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__3_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_4__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_4__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_4__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_4__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_4__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_4__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_4__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__3_n_5\,
      DI(2) => \state_reg[2]_i_2__3_n_6\,
      DI(1) => \state_reg[2]_i_2__3_n_7\,
      DI(0) => \seconds_relay_4__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg6_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_4__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_4__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_4__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_4__274_carry__0_i_9_n_0\
    );
\seconds_relay_4__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__3_n_5\,
      O => \seconds_relay_4__274_carry__0_i_6_n_0\
    );
\seconds_relay_4__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__3_n_6\,
      O => \seconds_relay_4__274_carry__0_i_7_n_0\
    );
\seconds_relay_4__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__3_n_7\,
      O => \seconds_relay_4__274_carry__0_i_8_n_0\
    );
\seconds_relay_4__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(3),
      I2 => \seconds_relay_4__274_carry_i_6_n_4\,
      O => \seconds_relay_4__274_carry__0_i_9_n_0\
    );
\seconds_relay_4__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__3_n_6\,
      O => \state_reg[1]_i_1__3_0\(1)
    );
\seconds_relay_4__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__3_0\(0)
    );
\seconds_relay_4__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_4__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_4__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_4__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_4__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_4(2),
      DI(3) => \seconds_relay_4__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_4__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg6_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_4__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_4__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_4__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_4__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_4__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__3_n_5\,
      O => \seconds_relay_4__274_carry_i_10_n_0\
    );
\seconds_relay_4__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__3_n_6\,
      O => \seconds_relay_4__274_carry_i_11_n_0\
    );
\seconds_relay_4__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(1),
      O => \seconds_relay_4__274_carry_i_12_n_0\
    );
\seconds_relay_4__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_4__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_4__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_4__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_4__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_4(3),
      DI(3) => \state_reg[3]_i_6__3_n_5\,
      DI(2) => \state_reg[3]_i_6__3_n_6\,
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_4__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_4__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_4__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_4__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_4__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_4__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_4__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_4__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(2),
      I2 => \seconds_relay_4__274_carry_i_6_n_5\,
      O => \seconds_relay_4__274_carry_i_7_n_0\
    );
\seconds_relay_4__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(1),
      I2 => \seconds_relay_4__274_carry_i_6_n_6\,
      O => \seconds_relay_4__274_carry_i_8_n_0\
    );
\seconds_relay_4__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(0),
      O => \seconds_relay_4__274_carry_i_9_n_0\
    );
\seconds_relay_4__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_4__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_4__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_4__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_4__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_4__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_4__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => \state_reg[2]_i_1__3_n_6\,
      O => \state[1]_i_2__3_n_0\
    );
\state[1]_i_3__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__3_n_7\,
      O => \state[1]_i_3__3_n_0\
    );
\state[1]_i_4__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__3_n_4\,
      O => \state[1]_i_4__3_n_0\
    );
\state[2]_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => \state_reg[3]_i_1__3_n_6\,
      O => \state[2]_i_3__3_n_0\
    );
\state[2]_i_4__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__3_n_7\,
      O => \state[2]_i_4__3_n_0\
    );
\state[2]_i_5__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__3_n_4\,
      O => \state[2]_i_5__3_n_0\
    );
\state[2]_i_6__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__3_n_5\,
      O => \state[2]_i_6__3_n_0\
    );
\state[2]_i_7__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__3_n_6\,
      O => \state[2]_i_7__3_n_0\
    );
\state[2]_i_8__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__3_n_7\,
      O => \state[2]_i_8__3_n_0\
    );
\state[2]_i_9__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__3_n_4\,
      O => \state[2]_i_9__3_n_0\
    );
\state[3]_i_10__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__3_n_4\,
      O => \state[3]_i_10__3_n_0\
    );
\state[3]_i_11__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__3_n_5\,
      O => \state[3]_i_11__3_n_0\
    );
\state[3]_i_12__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__3_n_6\,
      O => \state[3]_i_12__3_n_0\
    );
\state[3]_i_13__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(2),
      O => \state[3]_i_13__3_n_0\
    );
\state[3]_i_3__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => \state_reg[4]_i_1__3_n_6\,
      O => \state[3]_i_3__3_n_0\
    );
\state[3]_i_4__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__3_n_7\,
      O => \state[3]_i_4__3_n_0\
    );
\state[3]_i_5__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__3_n_4\,
      O => \state[3]_i_5__3_n_0\
    );
\state[3]_i_7__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__3_n_5\,
      O => \state[3]_i_7__3_n_0\
    );
\state[3]_i_8__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__3_n_6\,
      O => \state[3]_i_8__3_n_0\
    );
\state[3]_i_9__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__3_n_7\,
      O => \state[3]_i_9__3_n_0\
    );
\state[4]_i_10__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__3_n_5\,
      O => \state[4]_i_10__3_n_0\
    );
\state[4]_i_11__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__3_n_6\,
      O => \state[4]_i_11__3_n_0\
    );
\state[4]_i_12__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__3_n_7\,
      O => \state[4]_i_12__3_n_0\
    );
\state[4]_i_13__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__3_n_4\,
      O => \state[4]_i_13__3_n_0\
    );
\state[4]_i_16__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => \state_reg[4]_i_14__3_n_6\,
      O => \state[4]_i_16__3_n_0\
    );
\state[4]_i_17__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__3_n_7\,
      O => \state[4]_i_17__3_n_0\
    );
\state[4]_i_18__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__3_n_4\,
      O => \state[4]_i_18__3_n_0\
    );
\state[4]_i_20__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__3_n_5\,
      O => \state[4]_i_20__3_n_0\
    );
\state[4]_i_21__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__3_n_6\,
      O => \state[4]_i_21__3_n_0\
    );
\state[4]_i_22__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__3_n_7\,
      O => \state[4]_i_22__3_n_0\
    );
\state[4]_i_23__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__3_n_4\,
      O => \state[4]_i_23__3_n_0\
    );
\state[4]_i_24__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__3_n_5\,
      O => \state[4]_i_24__3_n_0\
    );
\state[4]_i_25__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__3_n_6\,
      O => \state[4]_i_25__3_n_0\
    );
\state[4]_i_26__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(3),
      O => \state[4]_i_26__3_n_0\
    );
\state[4]_i_27__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__3_n_5\,
      O => \state[4]_i_27__3_n_0\
    );
\state[4]_i_28__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__3_n_6\,
      O => \state[4]_i_28__3_n_0\
    );
\state[4]_i_29__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__3_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(4),
      O => \state[4]_i_29__3_n_0\
    );
\state[4]_i_30__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__3_1\(0),
      O => \state[4]_i_30__3_n_0\
    );
\state[4]_i_31__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__3_0\(3),
      O => \state[4]_i_31__3_n_0\
    );
\state[4]_i_32__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__3_0\(2),
      O => \state[4]_i_32__3_n_0\
    );
\state[4]_i_33__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__3_0\(1),
      O => \state[4]_i_33__3_n_0\
    );
\state[4]_i_34__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__3_0\(0),
      O => \state[4]_i_34__3_n_0\
    );
\state[4]_i_35__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__3_n_0\
    );
\state[4]_i_36__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__3_n_0\
    );
\state[4]_i_37__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__3_n_0\
    );
\state[4]_i_38__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__3_n_0\
    );
\state[4]_i_39__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_4__8_carry__0_i_6\(5),
      O => \state[4]_i_39__3_n_0\
    );
\state[4]_i_5__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => \state_reg[4]_i_3__3_n_6\,
      O => \state[4]_i_5__3_n_0\
    );
\state[4]_i_6__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__3_n_7\,
      O => \state[4]_i_6__3_n_0\
    );
\state[4]_i_7__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__3_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__3_n_4\,
      O => \state[4]_i_7__3_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__3_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__3_n_2\,
      CO(0) => \state_reg[1]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_4(2),
      DI(1) => \state_reg[2]_i_1__3_n_7\,
      DI(0) => \state_reg[2]_i_2__3_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__3_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__3_n_0\,
      S(1) => \state[1]_i_3__3_n_0\,
      S(0) => \state[1]_i_4__3_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_4(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[4]_1\(0)
    );
\state_reg[2]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__3_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__3_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_4(2),
      CO(1) => \state_reg[2]_i_1__3_n_2\,
      CO(0) => \state_reg[2]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_4(3),
      DI(1) => \state_reg[3]_i_1__3_n_7\,
      DI(0) => \state_reg[3]_i_2__3_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__3_n_6\,
      O(0) => \state_reg[2]_i_1__3_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__3_n_0\,
      S(1) => \state[2]_i_4__3_n_0\,
      S(0) => \state[2]_i_5__3_n_0\
    );
\state_reg[2]_i_2__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__3_n_0\,
      CO(2) => \state_reg[2]_i_2__3_n_1\,
      CO(1) => \state_reg[2]_i_2__3_n_2\,
      CO(0) => \state_reg[2]_i_2__3_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__3_n_5\,
      DI(2) => \state_reg[3]_i_2__3_n_6\,
      DI(1) => \state_reg[3]_i_2__3_n_7\,
      DI(0) => \state_reg[3]_i_6__3_n_4\,
      O(3) => \state_reg[2]_i_2__3_n_4\,
      O(2) => \state_reg[2]_i_2__3_n_5\,
      O(1) => \state_reg[2]_i_2__3_n_6\,
      O(0) => \state_reg[2]_i_2__3_n_7\,
      S(3) => \state[2]_i_6__3_n_0\,
      S(2) => \state[2]_i_7__3_n_0\,
      S(1) => \state[2]_i_8__3_n_0\,
      S(0) => \state[2]_i_9__3_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_4(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[4]_1\(0)
    );
\state_reg[3]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__3_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__3_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_4(3),
      CO(1) => \state_reg[3]_i_1__3_n_2\,
      CO(0) => \state_reg[3]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_4(4),
      DI(1) => \state_reg[4]_i_1__3_n_7\,
      DI(0) => \state_reg[4]_i_2__3_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__3_n_6\,
      O(0) => \state_reg[3]_i_1__3_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__3_n_0\,
      S(1) => \state[3]_i_4__3_n_0\,
      S(0) => \state[3]_i_5__3_n_0\
    );
\state_reg[3]_i_2__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__3_n_0\,
      CO(3) => \state_reg[3]_i_2__3_n_0\,
      CO(2) => \state_reg[3]_i_2__3_n_1\,
      CO(1) => \state_reg[3]_i_2__3_n_2\,
      CO(0) => \state_reg[3]_i_2__3_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__3_n_5\,
      DI(2) => \state_reg[4]_i_2__3_n_6\,
      DI(1) => \state_reg[4]_i_2__3_n_7\,
      DI(0) => \state_reg[4]_i_8__3_n_4\,
      O(3) => \state_reg[3]_i_2__3_n_4\,
      O(2) => \state_reg[3]_i_2__3_n_5\,
      O(1) => \state_reg[3]_i_2__3_n_6\,
      O(0) => \state_reg[3]_i_2__3_n_7\,
      S(3) => \state[3]_i_7__3_n_0\,
      S(2) => \state[3]_i_8__3_n_0\,
      S(1) => \state[3]_i_9__3_n_0\,
      S(0) => \state[3]_i_10__3_n_0\
    );
\state_reg[3]_i_6__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__3_n_0\,
      CO(2) => \state_reg[3]_i_6__3_n_1\,
      CO(1) => \state_reg[3]_i_6__3_n_2\,
      CO(0) => \state_reg[3]_i_6__3_n_3\,
      CYINIT => seconds_relay_4(4),
      DI(3) => \state_reg[4]_i_8__3_n_5\,
      DI(2) => \state_reg[4]_i_8__3_n_6\,
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__3_n_4\,
      O(2) => \state_reg[3]_i_6__3_n_5\,
      O(1) => \state_reg[3]_i_6__3_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__3_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__3_n_0\,
      S(2) => \state[3]_i_12__3_n_0\,
      S(1) => \state[3]_i_13__3_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_4(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[4]_1\(0)
    );
\state_reg[4]_i_14__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__3_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__3_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__3_n_1\,
      CO(1) => \state_reg[4]_i_14__3_n_2\,
      CO(0) => \state_reg[4]_i_14__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__3_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__3_n_6\,
      O(0) => \state_reg[4]_i_14__3_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__3_n_0\,
      S(1) => \state[4]_i_31__3_n_0\,
      S(0) => \state[4]_i_32__3_n_0\
    );
\state_reg[4]_i_15__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__3_n_0\,
      CO(3) => \state_reg[4]_i_15__3_n_0\,
      CO(2) => \state_reg[4]_i_15__3_n_1\,
      CO(1) => \state_reg[4]_i_15__3_n_2\,
      CO(0) => \state_reg[4]_i_15__3_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__3_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__3_n_4\,
      O(2) => \state_reg[4]_i_15__3_n_5\,
      O(1) => \state_reg[4]_i_15__3_n_6\,
      O(0) => \state_reg[4]_i_15__3_n_7\,
      S(3) => \state[4]_i_33__3_n_0\,
      S(2) => \state[4]_i_34__3_n_0\,
      S(1) => \state[4]_i_35__3_n_0\,
      S(0) => \state[4]_i_36__3_n_0\
    );
\state_reg[4]_i_19__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__3_n_0\,
      CO(2) => \state_reg[4]_i_19__3_n_1\,
      CO(1) => \state_reg[4]_i_19__3_n_2\,
      CO(0) => \state_reg[4]_i_19__3_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__3_n_4\,
      O(2) => \state_reg[4]_i_19__3_n_5\,
      O(1) => \state_reg[4]_i_19__3_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__3_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__3_n_0\,
      S(2) => \state[4]_i_38__3_n_0\,
      S(1) => \state[4]_i_39__3_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__3_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__3_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_4(4),
      CO(1) => \state_reg[4]_i_1__3_n_2\,
      CO(0) => \state_reg[4]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__3_n_1\,
      DI(1) => \state_reg[4]_i_3__3_n_7\,
      DI(0) => \state_reg[4]_i_4__3_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__3_n_6\,
      O(0) => \state_reg[4]_i_1__3_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__3_n_0\,
      S(1) => \state[4]_i_6__3_n_0\,
      S(0) => \state[4]_i_7__3_n_0\
    );
\state_reg[4]_i_2__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__3_n_0\,
      CO(3) => \state_reg[4]_i_2__3_n_0\,
      CO(2) => \state_reg[4]_i_2__3_n_1\,
      CO(1) => \state_reg[4]_i_2__3_n_2\,
      CO(0) => \state_reg[4]_i_2__3_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__3_n_5\,
      DI(2) => \state_reg[4]_i_4__3_n_6\,
      DI(1) => \state_reg[4]_i_4__3_n_7\,
      DI(0) => \state_reg[4]_i_9__3_n_4\,
      O(3) => \state_reg[4]_i_2__3_n_4\,
      O(2) => \state_reg[4]_i_2__3_n_5\,
      O(1) => \state_reg[4]_i_2__3_n_6\,
      O(0) => \state_reg[4]_i_2__3_n_7\,
      S(3) => \state[4]_i_10__3_n_0\,
      S(2) => \state[4]_i_11__3_n_0\,
      S(1) => \state[4]_i_12__3_n_0\,
      S(0) => \state[4]_i_13__3_n_0\
    );
\state_reg[4]_i_3__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__3_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__3_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__3_n_1\,
      CO(1) => \state_reg[4]_i_3__3_n_2\,
      CO(0) => \state_reg[4]_i_3__3_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__3_n_1\,
      DI(1) => \state_reg[4]_i_14__3_n_7\,
      DI(0) => \state_reg[4]_i_15__3_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__3_n_6\,
      O(0) => \state_reg[4]_i_3__3_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__3_n_0\,
      S(1) => \state[4]_i_17__3_n_0\,
      S(0) => \state[4]_i_18__3_n_0\
    );
\state_reg[4]_i_4__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__3_n_0\,
      CO(3) => \state_reg[4]_i_4__3_n_0\,
      CO(2) => \state_reg[4]_i_4__3_n_1\,
      CO(1) => \state_reg[4]_i_4__3_n_2\,
      CO(0) => \state_reg[4]_i_4__3_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__3_n_5\,
      DI(2) => \state_reg[4]_i_15__3_n_6\,
      DI(1) => \state_reg[4]_i_15__3_n_7\,
      DI(0) => \state_reg[4]_i_19__3_n_4\,
      O(3) => \state_reg[4]_i_4__3_n_4\,
      O(2) => \state_reg[4]_i_4__3_n_5\,
      O(1) => \state_reg[4]_i_4__3_n_6\,
      O(0) => \state_reg[4]_i_4__3_n_7\,
      S(3) => \state[4]_i_20__3_n_0\,
      S(2) => \state[4]_i_21__3_n_0\,
      S(1) => \state[4]_i_22__3_n_0\,
      S(0) => \state[4]_i_23__3_n_0\
    );
\state_reg[4]_i_8__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__3_n_0\,
      CO(2) => \state_reg[4]_i_8__3_n_1\,
      CO(1) => \state_reg[4]_i_8__3_n_2\,
      CO(0) => \state_reg[4]_i_8__3_n_3\,
      CYINIT => \state_reg[4]_i_3__3_n_1\,
      DI(3) => \state_reg[4]_i_9__3_n_5\,
      DI(2) => \state_reg[4]_i_9__3_n_6\,
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__3_n_4\,
      O(2) => \state_reg[4]_i_8__3_n_5\,
      O(1) => \state_reg[4]_i_8__3_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__3_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__3_n_0\,
      S(2) => \state[4]_i_25__3_n_0\,
      S(1) => \state[4]_i_26__3_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__3_n_0\,
      CO(2) => \state_reg[4]_i_9__3_n_1\,
      CO(1) => \state_reg[4]_i_9__3_n_2\,
      CO(0) => \state_reg[4]_i_9__3_n_3\,
      CYINIT => \state_reg[4]_i_14__3_n_1\,
      DI(3) => \state_reg[4]_i_19__3_n_5\,
      DI(2) => \state_reg[4]_i_19__3_n_6\,
      DI(1) => \seconds_relay_4__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__3_n_4\,
      O(2) => \state_reg[4]_i_9__3_n_5\,
      O(1) => \state_reg[4]_i_9__3_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__3_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__3_n_0\,
      S(2) => \state[4]_i_28__3_n_0\,
      S(1) => \state[4]_i_29__3_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_4\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg7_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg7_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__4_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_5__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__4_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__4_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[0]_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_4\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_4\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_4\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_5 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_5__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__4_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__4_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__4_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__4_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__4_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__4_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__4_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__4_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__4_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__4_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__4_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__4_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__4_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__4_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__4_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__4_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__4_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__4_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__4_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__4_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__4_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__4_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__4_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_5__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_5__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_5__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_5__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_5__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_5__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_5__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__4_n_5\,
      DI(2) => \state_reg[2]_i_2__4_n_6\,
      DI(1) => \state_reg[2]_i_2__4_n_7\,
      DI(0) => \seconds_relay_5__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg7_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_5__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_5__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_5__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_5__274_carry__0_i_9_n_0\
    );
\seconds_relay_5__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__4_n_5\,
      O => \seconds_relay_5__274_carry__0_i_6_n_0\
    );
\seconds_relay_5__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__4_n_6\,
      O => \seconds_relay_5__274_carry__0_i_7_n_0\
    );
\seconds_relay_5__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__4_n_7\,
      O => \seconds_relay_5__274_carry__0_i_8_n_0\
    );
\seconds_relay_5__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(3),
      I2 => \seconds_relay_5__274_carry_i_6_n_4\,
      O => \seconds_relay_5__274_carry__0_i_9_n_0\
    );
\seconds_relay_5__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__4_n_6\,
      O => \state_reg[1]_i_1__4_0\(1)
    );
\seconds_relay_5__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__4_0\(0)
    );
\seconds_relay_5__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_5__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_5__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_5__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_5__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_5(2),
      DI(3) => \seconds_relay_5__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_5__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg7_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_5__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_5__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_5__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_5__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_5__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__4_n_5\,
      O => \seconds_relay_5__274_carry_i_10_n_0\
    );
\seconds_relay_5__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__4_n_6\,
      O => \seconds_relay_5__274_carry_i_11_n_0\
    );
\seconds_relay_5__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(1),
      O => \seconds_relay_5__274_carry_i_12_n_0\
    );
\seconds_relay_5__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_5__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_5__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_5__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_5__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_5(3),
      DI(3) => \state_reg[3]_i_6__4_n_5\,
      DI(2) => \state_reg[3]_i_6__4_n_6\,
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_5__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_5__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_5__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_5__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_5__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_5__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_5__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_5__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(2),
      I2 => \seconds_relay_5__274_carry_i_6_n_5\,
      O => \seconds_relay_5__274_carry_i_7_n_0\
    );
\seconds_relay_5__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(1),
      I2 => \seconds_relay_5__274_carry_i_6_n_6\,
      O => \seconds_relay_5__274_carry_i_8_n_0\
    );
\seconds_relay_5__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(0),
      O => \seconds_relay_5__274_carry_i_9_n_0\
    );
\seconds_relay_5__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_5__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_5__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_5__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_5__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_5__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_5__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => \state_reg[2]_i_1__4_n_6\,
      O => \state[1]_i_2__4_n_0\
    );
\state[1]_i_3__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__4_n_7\,
      O => \state[1]_i_3__4_n_0\
    );
\state[1]_i_4__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__4_n_4\,
      O => \state[1]_i_4__4_n_0\
    );
\state[2]_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => \state_reg[3]_i_1__4_n_6\,
      O => \state[2]_i_3__4_n_0\
    );
\state[2]_i_4__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__4_n_7\,
      O => \state[2]_i_4__4_n_0\
    );
\state[2]_i_5__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__4_n_4\,
      O => \state[2]_i_5__4_n_0\
    );
\state[2]_i_6__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__4_n_5\,
      O => \state[2]_i_6__4_n_0\
    );
\state[2]_i_7__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__4_n_6\,
      O => \state[2]_i_7__4_n_0\
    );
\state[2]_i_8__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__4_n_7\,
      O => \state[2]_i_8__4_n_0\
    );
\state[2]_i_9__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__4_n_4\,
      O => \state[2]_i_9__4_n_0\
    );
\state[3]_i_10__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__4_n_4\,
      O => \state[3]_i_10__4_n_0\
    );
\state[3]_i_11__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__4_n_5\,
      O => \state[3]_i_11__4_n_0\
    );
\state[3]_i_12__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__4_n_6\,
      O => \state[3]_i_12__4_n_0\
    );
\state[3]_i_13__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(2),
      O => \state[3]_i_13__4_n_0\
    );
\state[3]_i_3__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => \state_reg[4]_i_1__4_n_6\,
      O => \state[3]_i_3__4_n_0\
    );
\state[3]_i_4__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__4_n_7\,
      O => \state[3]_i_4__4_n_0\
    );
\state[3]_i_5__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__4_n_4\,
      O => \state[3]_i_5__4_n_0\
    );
\state[3]_i_7__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__4_n_5\,
      O => \state[3]_i_7__4_n_0\
    );
\state[3]_i_8__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__4_n_6\,
      O => \state[3]_i_8__4_n_0\
    );
\state[3]_i_9__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__4_n_7\,
      O => \state[3]_i_9__4_n_0\
    );
\state[4]_i_10__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__4_n_5\,
      O => \state[4]_i_10__4_n_0\
    );
\state[4]_i_11__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__4_n_6\,
      O => \state[4]_i_11__4_n_0\
    );
\state[4]_i_12__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__4_n_7\,
      O => \state[4]_i_12__4_n_0\
    );
\state[4]_i_13__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__4_n_4\,
      O => \state[4]_i_13__4_n_0\
    );
\state[4]_i_16__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => \state_reg[4]_i_14__4_n_6\,
      O => \state[4]_i_16__4_n_0\
    );
\state[4]_i_17__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__4_n_7\,
      O => \state[4]_i_17__4_n_0\
    );
\state[4]_i_18__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__4_n_4\,
      O => \state[4]_i_18__4_n_0\
    );
\state[4]_i_20__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__4_n_5\,
      O => \state[4]_i_20__4_n_0\
    );
\state[4]_i_21__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__4_n_6\,
      O => \state[4]_i_21__4_n_0\
    );
\state[4]_i_22__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__4_n_7\,
      O => \state[4]_i_22__4_n_0\
    );
\state[4]_i_23__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__4_n_4\,
      O => \state[4]_i_23__4_n_0\
    );
\state[4]_i_24__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__4_n_5\,
      O => \state[4]_i_24__4_n_0\
    );
\state[4]_i_25__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__4_n_6\,
      O => \state[4]_i_25__4_n_0\
    );
\state[4]_i_26__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(3),
      O => \state[4]_i_26__4_n_0\
    );
\state[4]_i_27__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__4_n_5\,
      O => \state[4]_i_27__4_n_0\
    );
\state[4]_i_28__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__4_n_6\,
      O => \state[4]_i_28__4_n_0\
    );
\state[4]_i_29__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__4_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(4),
      O => \state[4]_i_29__4_n_0\
    );
\state[4]_i_30__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__4_1\(0),
      O => \state[4]_i_30__4_n_0\
    );
\state[4]_i_31__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__4_0\(3),
      O => \state[4]_i_31__4_n_0\
    );
\state[4]_i_32__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__4_0\(2),
      O => \state[4]_i_32__4_n_0\
    );
\state[4]_i_33__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__4_0\(1),
      O => \state[4]_i_33__4_n_0\
    );
\state[4]_i_34__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__4_0\(0),
      O => \state[4]_i_34__4_n_0\
    );
\state[4]_i_35__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__4_n_0\
    );
\state[4]_i_36__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__4_n_0\
    );
\state[4]_i_37__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__4_n_0\
    );
\state[4]_i_38__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__4_n_0\
    );
\state[4]_i_39__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_5__8_carry__0_i_6\(5),
      O => \state[4]_i_39__4_n_0\
    );
\state[4]_i_5__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => \state_reg[4]_i_3__4_n_6\,
      O => \state[4]_i_5__4_n_0\
    );
\state[4]_i_6__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__4_n_7\,
      O => \state[4]_i_6__4_n_0\
    );
\state[4]_i_7__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__4_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__4_n_4\,
      O => \state[4]_i_7__4_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__4_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__4_n_2\,
      CO(0) => \state_reg[1]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_5(2),
      DI(1) => \state_reg[2]_i_1__4_n_7\,
      DI(0) => \state_reg[2]_i_2__4_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__4_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__4_n_0\,
      S(1) => \state[1]_i_3__4_n_0\,
      S(0) => \state[1]_i_4__4_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_5(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[0]_0\(0)
    );
\state_reg[2]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__4_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__4_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_5(2),
      CO(1) => \state_reg[2]_i_1__4_n_2\,
      CO(0) => \state_reg[2]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_5(3),
      DI(1) => \state_reg[3]_i_1__4_n_7\,
      DI(0) => \state_reg[3]_i_2__4_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__4_n_6\,
      O(0) => \state_reg[2]_i_1__4_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__4_n_0\,
      S(1) => \state[2]_i_4__4_n_0\,
      S(0) => \state[2]_i_5__4_n_0\
    );
\state_reg[2]_i_2__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__4_n_0\,
      CO(2) => \state_reg[2]_i_2__4_n_1\,
      CO(1) => \state_reg[2]_i_2__4_n_2\,
      CO(0) => \state_reg[2]_i_2__4_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__4_n_5\,
      DI(2) => \state_reg[3]_i_2__4_n_6\,
      DI(1) => \state_reg[3]_i_2__4_n_7\,
      DI(0) => \state_reg[3]_i_6__4_n_4\,
      O(3) => \state_reg[2]_i_2__4_n_4\,
      O(2) => \state_reg[2]_i_2__4_n_5\,
      O(1) => \state_reg[2]_i_2__4_n_6\,
      O(0) => \state_reg[2]_i_2__4_n_7\,
      S(3) => \state[2]_i_6__4_n_0\,
      S(2) => \state[2]_i_7__4_n_0\,
      S(1) => \state[2]_i_8__4_n_0\,
      S(0) => \state[2]_i_9__4_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_5(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[0]_0\(0)
    );
\state_reg[3]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__4_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__4_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_5(3),
      CO(1) => \state_reg[3]_i_1__4_n_2\,
      CO(0) => \state_reg[3]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_5(4),
      DI(1) => \state_reg[4]_i_1__4_n_7\,
      DI(0) => \state_reg[4]_i_2__4_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__4_n_6\,
      O(0) => \state_reg[3]_i_1__4_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__4_n_0\,
      S(1) => \state[3]_i_4__4_n_0\,
      S(0) => \state[3]_i_5__4_n_0\
    );
\state_reg[3]_i_2__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__4_n_0\,
      CO(3) => \state_reg[3]_i_2__4_n_0\,
      CO(2) => \state_reg[3]_i_2__4_n_1\,
      CO(1) => \state_reg[3]_i_2__4_n_2\,
      CO(0) => \state_reg[3]_i_2__4_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__4_n_5\,
      DI(2) => \state_reg[4]_i_2__4_n_6\,
      DI(1) => \state_reg[4]_i_2__4_n_7\,
      DI(0) => \state_reg[4]_i_8__4_n_4\,
      O(3) => \state_reg[3]_i_2__4_n_4\,
      O(2) => \state_reg[3]_i_2__4_n_5\,
      O(1) => \state_reg[3]_i_2__4_n_6\,
      O(0) => \state_reg[3]_i_2__4_n_7\,
      S(3) => \state[3]_i_7__4_n_0\,
      S(2) => \state[3]_i_8__4_n_0\,
      S(1) => \state[3]_i_9__4_n_0\,
      S(0) => \state[3]_i_10__4_n_0\
    );
\state_reg[3]_i_6__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__4_n_0\,
      CO(2) => \state_reg[3]_i_6__4_n_1\,
      CO(1) => \state_reg[3]_i_6__4_n_2\,
      CO(0) => \state_reg[3]_i_6__4_n_3\,
      CYINIT => seconds_relay_5(4),
      DI(3) => \state_reg[4]_i_8__4_n_5\,
      DI(2) => \state_reg[4]_i_8__4_n_6\,
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__4_n_4\,
      O(2) => \state_reg[3]_i_6__4_n_5\,
      O(1) => \state_reg[3]_i_6__4_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__4_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__4_n_0\,
      S(2) => \state[3]_i_12__4_n_0\,
      S(1) => \state[3]_i_13__4_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_5(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[0]_0\(0)
    );
\state_reg[4]_i_14__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__4_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__4_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__4_n_1\,
      CO(1) => \state_reg[4]_i_14__4_n_2\,
      CO(0) => \state_reg[4]_i_14__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__4_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__4_n_6\,
      O(0) => \state_reg[4]_i_14__4_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__4_n_0\,
      S(1) => \state[4]_i_31__4_n_0\,
      S(0) => \state[4]_i_32__4_n_0\
    );
\state_reg[4]_i_15__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__4_n_0\,
      CO(3) => \state_reg[4]_i_15__4_n_0\,
      CO(2) => \state_reg[4]_i_15__4_n_1\,
      CO(1) => \state_reg[4]_i_15__4_n_2\,
      CO(0) => \state_reg[4]_i_15__4_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__4_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__4_n_4\,
      O(2) => \state_reg[4]_i_15__4_n_5\,
      O(1) => \state_reg[4]_i_15__4_n_6\,
      O(0) => \state_reg[4]_i_15__4_n_7\,
      S(3) => \state[4]_i_33__4_n_0\,
      S(2) => \state[4]_i_34__4_n_0\,
      S(1) => \state[4]_i_35__4_n_0\,
      S(0) => \state[4]_i_36__4_n_0\
    );
\state_reg[4]_i_19__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__4_n_0\,
      CO(2) => \state_reg[4]_i_19__4_n_1\,
      CO(1) => \state_reg[4]_i_19__4_n_2\,
      CO(0) => \state_reg[4]_i_19__4_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__4_n_4\,
      O(2) => \state_reg[4]_i_19__4_n_5\,
      O(1) => \state_reg[4]_i_19__4_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__4_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__4_n_0\,
      S(2) => \state[4]_i_38__4_n_0\,
      S(1) => \state[4]_i_39__4_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__4_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__4_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_5(4),
      CO(1) => \state_reg[4]_i_1__4_n_2\,
      CO(0) => \state_reg[4]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__4_n_1\,
      DI(1) => \state_reg[4]_i_3__4_n_7\,
      DI(0) => \state_reg[4]_i_4__4_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__4_n_6\,
      O(0) => \state_reg[4]_i_1__4_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__4_n_0\,
      S(1) => \state[4]_i_6__4_n_0\,
      S(0) => \state[4]_i_7__4_n_0\
    );
\state_reg[4]_i_2__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__4_n_0\,
      CO(3) => \state_reg[4]_i_2__4_n_0\,
      CO(2) => \state_reg[4]_i_2__4_n_1\,
      CO(1) => \state_reg[4]_i_2__4_n_2\,
      CO(0) => \state_reg[4]_i_2__4_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__4_n_5\,
      DI(2) => \state_reg[4]_i_4__4_n_6\,
      DI(1) => \state_reg[4]_i_4__4_n_7\,
      DI(0) => \state_reg[4]_i_9__4_n_4\,
      O(3) => \state_reg[4]_i_2__4_n_4\,
      O(2) => \state_reg[4]_i_2__4_n_5\,
      O(1) => \state_reg[4]_i_2__4_n_6\,
      O(0) => \state_reg[4]_i_2__4_n_7\,
      S(3) => \state[4]_i_10__4_n_0\,
      S(2) => \state[4]_i_11__4_n_0\,
      S(1) => \state[4]_i_12__4_n_0\,
      S(0) => \state[4]_i_13__4_n_0\
    );
\state_reg[4]_i_3__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__4_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__4_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__4_n_1\,
      CO(1) => \state_reg[4]_i_3__4_n_2\,
      CO(0) => \state_reg[4]_i_3__4_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__4_n_1\,
      DI(1) => \state_reg[4]_i_14__4_n_7\,
      DI(0) => \state_reg[4]_i_15__4_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__4_n_6\,
      O(0) => \state_reg[4]_i_3__4_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__4_n_0\,
      S(1) => \state[4]_i_17__4_n_0\,
      S(0) => \state[4]_i_18__4_n_0\
    );
\state_reg[4]_i_4__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__4_n_0\,
      CO(3) => \state_reg[4]_i_4__4_n_0\,
      CO(2) => \state_reg[4]_i_4__4_n_1\,
      CO(1) => \state_reg[4]_i_4__4_n_2\,
      CO(0) => \state_reg[4]_i_4__4_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__4_n_5\,
      DI(2) => \state_reg[4]_i_15__4_n_6\,
      DI(1) => \state_reg[4]_i_15__4_n_7\,
      DI(0) => \state_reg[4]_i_19__4_n_4\,
      O(3) => \state_reg[4]_i_4__4_n_4\,
      O(2) => \state_reg[4]_i_4__4_n_5\,
      O(1) => \state_reg[4]_i_4__4_n_6\,
      O(0) => \state_reg[4]_i_4__4_n_7\,
      S(3) => \state[4]_i_20__4_n_0\,
      S(2) => \state[4]_i_21__4_n_0\,
      S(1) => \state[4]_i_22__4_n_0\,
      S(0) => \state[4]_i_23__4_n_0\
    );
\state_reg[4]_i_8__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__4_n_0\,
      CO(2) => \state_reg[4]_i_8__4_n_1\,
      CO(1) => \state_reg[4]_i_8__4_n_2\,
      CO(0) => \state_reg[4]_i_8__4_n_3\,
      CYINIT => \state_reg[4]_i_3__4_n_1\,
      DI(3) => \state_reg[4]_i_9__4_n_5\,
      DI(2) => \state_reg[4]_i_9__4_n_6\,
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__4_n_4\,
      O(2) => \state_reg[4]_i_8__4_n_5\,
      O(1) => \state_reg[4]_i_8__4_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__4_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__4_n_0\,
      S(2) => \state[4]_i_25__4_n_0\,
      S(1) => \state[4]_i_26__4_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__4_n_0\,
      CO(2) => \state_reg[4]_i_9__4_n_1\,
      CO(1) => \state_reg[4]_i_9__4_n_2\,
      CO(0) => \state_reg[4]_i_9__4_n_3\,
      CYINIT => \state_reg[4]_i_14__4_n_1\,
      DI(3) => \state_reg[4]_i_19__4_n_5\,
      DI(2) => \state_reg[4]_i_19__4_n_6\,
      DI(1) => \seconds_relay_5__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__4_n_4\,
      O(2) => \state_reg[4]_i_9__4_n_5\,
      O(1) => \state_reg[4]_i_9__4_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__4_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__4_n_0\,
      S(2) => \state[4]_i_28__4_n_0\,
      S(1) => \state[4]_i_29__4_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_5\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg8_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg8_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__5_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_6__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__5_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__5_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_1\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_5\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_5\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_5\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_6 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_6__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__5_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__5_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__5_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__5_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__5_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__5_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__5_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__5_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__5_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__5_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__5_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__5_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__5_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__5_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__5_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__5_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__5_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__5_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__5_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__5_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__5_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__5_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__5_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_6__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_6__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_6__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_6__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_6__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_6__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_6__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__5_n_5\,
      DI(2) => \state_reg[2]_i_2__5_n_6\,
      DI(1) => \state_reg[2]_i_2__5_n_7\,
      DI(0) => \seconds_relay_6__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg8_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_6__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_6__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_6__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_6__274_carry__0_i_9_n_0\
    );
\seconds_relay_6__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__5_n_5\,
      O => \seconds_relay_6__274_carry__0_i_6_n_0\
    );
\seconds_relay_6__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__5_n_6\,
      O => \seconds_relay_6__274_carry__0_i_7_n_0\
    );
\seconds_relay_6__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__5_n_7\,
      O => \seconds_relay_6__274_carry__0_i_8_n_0\
    );
\seconds_relay_6__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(3),
      I2 => \seconds_relay_6__274_carry_i_6_n_4\,
      O => \seconds_relay_6__274_carry__0_i_9_n_0\
    );
\seconds_relay_6__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__5_n_6\,
      O => \state_reg[1]_i_1__5_0\(1)
    );
\seconds_relay_6__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__5_0\(0)
    );
\seconds_relay_6__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_6__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_6__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_6__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_6__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_6(2),
      DI(3) => \seconds_relay_6__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_6__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg8_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_6__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_6__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_6__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_6__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_6__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__5_n_5\,
      O => \seconds_relay_6__274_carry_i_10_n_0\
    );
\seconds_relay_6__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__5_n_6\,
      O => \seconds_relay_6__274_carry_i_11_n_0\
    );
\seconds_relay_6__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(1),
      O => \seconds_relay_6__274_carry_i_12_n_0\
    );
\seconds_relay_6__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_6__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_6__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_6__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_6__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_6(3),
      DI(3) => \state_reg[3]_i_6__5_n_5\,
      DI(2) => \state_reg[3]_i_6__5_n_6\,
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_6__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_6__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_6__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_6__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_6__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_6__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_6__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_6__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(2),
      I2 => \seconds_relay_6__274_carry_i_6_n_5\,
      O => \seconds_relay_6__274_carry_i_7_n_0\
    );
\seconds_relay_6__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(1),
      I2 => \seconds_relay_6__274_carry_i_6_n_6\,
      O => \seconds_relay_6__274_carry_i_8_n_0\
    );
\seconds_relay_6__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(0),
      O => \seconds_relay_6__274_carry_i_9_n_0\
    );
\seconds_relay_6__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_6__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_6__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_6__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_6__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_6__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_6__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => \state_reg[2]_i_1__5_n_6\,
      O => \state[1]_i_2__5_n_0\
    );
\state[1]_i_3__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__5_n_7\,
      O => \state[1]_i_3__5_n_0\
    );
\state[1]_i_4__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__5_n_4\,
      O => \state[1]_i_4__5_n_0\
    );
\state[2]_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => \state_reg[3]_i_1__5_n_6\,
      O => \state[2]_i_3__5_n_0\
    );
\state[2]_i_4__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__5_n_7\,
      O => \state[2]_i_4__5_n_0\
    );
\state[2]_i_5__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__5_n_4\,
      O => \state[2]_i_5__5_n_0\
    );
\state[2]_i_6__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__5_n_5\,
      O => \state[2]_i_6__5_n_0\
    );
\state[2]_i_7__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__5_n_6\,
      O => \state[2]_i_7__5_n_0\
    );
\state[2]_i_8__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__5_n_7\,
      O => \state[2]_i_8__5_n_0\
    );
\state[2]_i_9__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__5_n_4\,
      O => \state[2]_i_9__5_n_0\
    );
\state[3]_i_10__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__5_n_4\,
      O => \state[3]_i_10__5_n_0\
    );
\state[3]_i_11__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__5_n_5\,
      O => \state[3]_i_11__5_n_0\
    );
\state[3]_i_12__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__5_n_6\,
      O => \state[3]_i_12__5_n_0\
    );
\state[3]_i_13__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(2),
      O => \state[3]_i_13__5_n_0\
    );
\state[3]_i_3__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => \state_reg[4]_i_1__5_n_6\,
      O => \state[3]_i_3__5_n_0\
    );
\state[3]_i_4__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__5_n_7\,
      O => \state[3]_i_4__5_n_0\
    );
\state[3]_i_5__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__5_n_4\,
      O => \state[3]_i_5__5_n_0\
    );
\state[3]_i_7__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__5_n_5\,
      O => \state[3]_i_7__5_n_0\
    );
\state[3]_i_8__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__5_n_6\,
      O => \state[3]_i_8__5_n_0\
    );
\state[3]_i_9__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__5_n_7\,
      O => \state[3]_i_9__5_n_0\
    );
\state[4]_i_10__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__5_n_5\,
      O => \state[4]_i_10__5_n_0\
    );
\state[4]_i_11__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__5_n_6\,
      O => \state[4]_i_11__5_n_0\
    );
\state[4]_i_12__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__5_n_7\,
      O => \state[4]_i_12__5_n_0\
    );
\state[4]_i_13__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__5_n_4\,
      O => \state[4]_i_13__5_n_0\
    );
\state[4]_i_16__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => \state_reg[4]_i_14__5_n_6\,
      O => \state[4]_i_16__5_n_0\
    );
\state[4]_i_17__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__5_n_7\,
      O => \state[4]_i_17__5_n_0\
    );
\state[4]_i_18__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__5_n_4\,
      O => \state[4]_i_18__5_n_0\
    );
\state[4]_i_20__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__5_n_5\,
      O => \state[4]_i_20__5_n_0\
    );
\state[4]_i_21__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__5_n_6\,
      O => \state[4]_i_21__5_n_0\
    );
\state[4]_i_22__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__5_n_7\,
      O => \state[4]_i_22__5_n_0\
    );
\state[4]_i_23__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__5_n_4\,
      O => \state[4]_i_23__5_n_0\
    );
\state[4]_i_24__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__5_n_5\,
      O => \state[4]_i_24__5_n_0\
    );
\state[4]_i_25__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__5_n_6\,
      O => \state[4]_i_25__5_n_0\
    );
\state[4]_i_26__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(3),
      O => \state[4]_i_26__5_n_0\
    );
\state[4]_i_27__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__5_n_5\,
      O => \state[4]_i_27__5_n_0\
    );
\state[4]_i_28__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__5_n_6\,
      O => \state[4]_i_28__5_n_0\
    );
\state[4]_i_29__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__5_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(4),
      O => \state[4]_i_29__5_n_0\
    );
\state[4]_i_30__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__5_1\(0),
      O => \state[4]_i_30__5_n_0\
    );
\state[4]_i_31__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__5_0\(3),
      O => \state[4]_i_31__5_n_0\
    );
\state[4]_i_32__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__5_0\(2),
      O => \state[4]_i_32__5_n_0\
    );
\state[4]_i_33__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__5_0\(1),
      O => \state[4]_i_33__5_n_0\
    );
\state[4]_i_34__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__5_0\(0),
      O => \state[4]_i_34__5_n_0\
    );
\state[4]_i_35__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__5_n_0\
    );
\state[4]_i_36__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__5_n_0\
    );
\state[4]_i_37__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__5_n_0\
    );
\state[4]_i_38__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__5_n_0\
    );
\state[4]_i_39__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_6__8_carry__0_i_6\(5),
      O => \state[4]_i_39__5_n_0\
    );
\state[4]_i_5__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => \state_reg[4]_i_3__5_n_6\,
      O => \state[4]_i_5__5_n_0\
    );
\state[4]_i_6__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__5_n_7\,
      O => \state[4]_i_6__5_n_0\
    );
\state[4]_i_7__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__5_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__5_n_4\,
      O => \state[4]_i_7__5_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[4]_1\(0)
    );
\state_reg[1]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__5_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__5_n_2\,
      CO(0) => \state_reg[1]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_6(2),
      DI(1) => \state_reg[2]_i_1__5_n_7\,
      DI(0) => \state_reg[2]_i_2__5_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__5_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__5_n_0\,
      S(1) => \state[1]_i_3__5_n_0\,
      S(0) => \state[1]_i_4__5_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_6(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[4]_1\(0)
    );
\state_reg[2]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__5_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__5_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_6(2),
      CO(1) => \state_reg[2]_i_1__5_n_2\,
      CO(0) => \state_reg[2]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_6(3),
      DI(1) => \state_reg[3]_i_1__5_n_7\,
      DI(0) => \state_reg[3]_i_2__5_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__5_n_6\,
      O(0) => \state_reg[2]_i_1__5_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__5_n_0\,
      S(1) => \state[2]_i_4__5_n_0\,
      S(0) => \state[2]_i_5__5_n_0\
    );
\state_reg[2]_i_2__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__5_n_0\,
      CO(2) => \state_reg[2]_i_2__5_n_1\,
      CO(1) => \state_reg[2]_i_2__5_n_2\,
      CO(0) => \state_reg[2]_i_2__5_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__5_n_5\,
      DI(2) => \state_reg[3]_i_2__5_n_6\,
      DI(1) => \state_reg[3]_i_2__5_n_7\,
      DI(0) => \state_reg[3]_i_6__5_n_4\,
      O(3) => \state_reg[2]_i_2__5_n_4\,
      O(2) => \state_reg[2]_i_2__5_n_5\,
      O(1) => \state_reg[2]_i_2__5_n_6\,
      O(0) => \state_reg[2]_i_2__5_n_7\,
      S(3) => \state[2]_i_6__5_n_0\,
      S(2) => \state[2]_i_7__5_n_0\,
      S(1) => \state[2]_i_8__5_n_0\,
      S(0) => \state[2]_i_9__5_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_6(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[4]_1\(0)
    );
\state_reg[3]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__5_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__5_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_6(3),
      CO(1) => \state_reg[3]_i_1__5_n_2\,
      CO(0) => \state_reg[3]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_6(4),
      DI(1) => \state_reg[4]_i_1__5_n_7\,
      DI(0) => \state_reg[4]_i_2__5_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__5_n_6\,
      O(0) => \state_reg[3]_i_1__5_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__5_n_0\,
      S(1) => \state[3]_i_4__5_n_0\,
      S(0) => \state[3]_i_5__5_n_0\
    );
\state_reg[3]_i_2__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__5_n_0\,
      CO(3) => \state_reg[3]_i_2__5_n_0\,
      CO(2) => \state_reg[3]_i_2__5_n_1\,
      CO(1) => \state_reg[3]_i_2__5_n_2\,
      CO(0) => \state_reg[3]_i_2__5_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__5_n_5\,
      DI(2) => \state_reg[4]_i_2__5_n_6\,
      DI(1) => \state_reg[4]_i_2__5_n_7\,
      DI(0) => \state_reg[4]_i_8__5_n_4\,
      O(3) => \state_reg[3]_i_2__5_n_4\,
      O(2) => \state_reg[3]_i_2__5_n_5\,
      O(1) => \state_reg[3]_i_2__5_n_6\,
      O(0) => \state_reg[3]_i_2__5_n_7\,
      S(3) => \state[3]_i_7__5_n_0\,
      S(2) => \state[3]_i_8__5_n_0\,
      S(1) => \state[3]_i_9__5_n_0\,
      S(0) => \state[3]_i_10__5_n_0\
    );
\state_reg[3]_i_6__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__5_n_0\,
      CO(2) => \state_reg[3]_i_6__5_n_1\,
      CO(1) => \state_reg[3]_i_6__5_n_2\,
      CO(0) => \state_reg[3]_i_6__5_n_3\,
      CYINIT => seconds_relay_6(4),
      DI(3) => \state_reg[4]_i_8__5_n_5\,
      DI(2) => \state_reg[4]_i_8__5_n_6\,
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__5_n_4\,
      O(2) => \state_reg[3]_i_6__5_n_5\,
      O(1) => \state_reg[3]_i_6__5_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__5_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__5_n_0\,
      S(2) => \state[3]_i_12__5_n_0\,
      S(1) => \state[3]_i_13__5_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[4]_1\(1),
      D => seconds_relay_6(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[4]_1\(0)
    );
\state_reg[4]_i_14__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__5_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__5_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__5_n_1\,
      CO(1) => \state_reg[4]_i_14__5_n_2\,
      CO(0) => \state_reg[4]_i_14__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__5_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__5_n_6\,
      O(0) => \state_reg[4]_i_14__5_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__5_n_0\,
      S(1) => \state[4]_i_31__5_n_0\,
      S(0) => \state[4]_i_32__5_n_0\
    );
\state_reg[4]_i_15__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__5_n_0\,
      CO(3) => \state_reg[4]_i_15__5_n_0\,
      CO(2) => \state_reg[4]_i_15__5_n_1\,
      CO(1) => \state_reg[4]_i_15__5_n_2\,
      CO(0) => \state_reg[4]_i_15__5_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__5_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__5_n_4\,
      O(2) => \state_reg[4]_i_15__5_n_5\,
      O(1) => \state_reg[4]_i_15__5_n_6\,
      O(0) => \state_reg[4]_i_15__5_n_7\,
      S(3) => \state[4]_i_33__5_n_0\,
      S(2) => \state[4]_i_34__5_n_0\,
      S(1) => \state[4]_i_35__5_n_0\,
      S(0) => \state[4]_i_36__5_n_0\
    );
\state_reg[4]_i_19__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__5_n_0\,
      CO(2) => \state_reg[4]_i_19__5_n_1\,
      CO(1) => \state_reg[4]_i_19__5_n_2\,
      CO(0) => \state_reg[4]_i_19__5_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__5_n_4\,
      O(2) => \state_reg[4]_i_19__5_n_5\,
      O(1) => \state_reg[4]_i_19__5_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__5_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__5_n_0\,
      S(2) => \state[4]_i_38__5_n_0\,
      S(1) => \state[4]_i_39__5_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__5_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__5_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_6(4),
      CO(1) => \state_reg[4]_i_1__5_n_2\,
      CO(0) => \state_reg[4]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__5_n_1\,
      DI(1) => \state_reg[4]_i_3__5_n_7\,
      DI(0) => \state_reg[4]_i_4__5_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__5_n_6\,
      O(0) => \state_reg[4]_i_1__5_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__5_n_0\,
      S(1) => \state[4]_i_6__5_n_0\,
      S(0) => \state[4]_i_7__5_n_0\
    );
\state_reg[4]_i_2__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__5_n_0\,
      CO(3) => \state_reg[4]_i_2__5_n_0\,
      CO(2) => \state_reg[4]_i_2__5_n_1\,
      CO(1) => \state_reg[4]_i_2__5_n_2\,
      CO(0) => \state_reg[4]_i_2__5_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__5_n_5\,
      DI(2) => \state_reg[4]_i_4__5_n_6\,
      DI(1) => \state_reg[4]_i_4__5_n_7\,
      DI(0) => \state_reg[4]_i_9__5_n_4\,
      O(3) => \state_reg[4]_i_2__5_n_4\,
      O(2) => \state_reg[4]_i_2__5_n_5\,
      O(1) => \state_reg[4]_i_2__5_n_6\,
      O(0) => \state_reg[4]_i_2__5_n_7\,
      S(3) => \state[4]_i_10__5_n_0\,
      S(2) => \state[4]_i_11__5_n_0\,
      S(1) => \state[4]_i_12__5_n_0\,
      S(0) => \state[4]_i_13__5_n_0\
    );
\state_reg[4]_i_3__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__5_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__5_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__5_n_1\,
      CO(1) => \state_reg[4]_i_3__5_n_2\,
      CO(0) => \state_reg[4]_i_3__5_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__5_n_1\,
      DI(1) => \state_reg[4]_i_14__5_n_7\,
      DI(0) => \state_reg[4]_i_15__5_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__5_n_6\,
      O(0) => \state_reg[4]_i_3__5_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__5_n_0\,
      S(1) => \state[4]_i_17__5_n_0\,
      S(0) => \state[4]_i_18__5_n_0\
    );
\state_reg[4]_i_4__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__5_n_0\,
      CO(3) => \state_reg[4]_i_4__5_n_0\,
      CO(2) => \state_reg[4]_i_4__5_n_1\,
      CO(1) => \state_reg[4]_i_4__5_n_2\,
      CO(0) => \state_reg[4]_i_4__5_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__5_n_5\,
      DI(2) => \state_reg[4]_i_15__5_n_6\,
      DI(1) => \state_reg[4]_i_15__5_n_7\,
      DI(0) => \state_reg[4]_i_19__5_n_4\,
      O(3) => \state_reg[4]_i_4__5_n_4\,
      O(2) => \state_reg[4]_i_4__5_n_5\,
      O(1) => \state_reg[4]_i_4__5_n_6\,
      O(0) => \state_reg[4]_i_4__5_n_7\,
      S(3) => \state[4]_i_20__5_n_0\,
      S(2) => \state[4]_i_21__5_n_0\,
      S(1) => \state[4]_i_22__5_n_0\,
      S(0) => \state[4]_i_23__5_n_0\
    );
\state_reg[4]_i_8__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__5_n_0\,
      CO(2) => \state_reg[4]_i_8__5_n_1\,
      CO(1) => \state_reg[4]_i_8__5_n_2\,
      CO(0) => \state_reg[4]_i_8__5_n_3\,
      CYINIT => \state_reg[4]_i_3__5_n_1\,
      DI(3) => \state_reg[4]_i_9__5_n_5\,
      DI(2) => \state_reg[4]_i_9__5_n_6\,
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__5_n_4\,
      O(2) => \state_reg[4]_i_8__5_n_5\,
      O(1) => \state_reg[4]_i_8__5_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__5_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__5_n_0\,
      S(2) => \state[4]_i_25__5_n_0\,
      S(1) => \state[4]_i_26__5_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__5_n_0\,
      CO(2) => \state_reg[4]_i_9__5_n_1\,
      CO(1) => \state_reg[4]_i_9__5_n_2\,
      CO(0) => \state_reg[4]_i_9__5_n_3\,
      CYINIT => \state_reg[4]_i_14__5_n_1\,
      DI(3) => \state_reg[4]_i_19__5_n_5\,
      DI(2) => \state_reg[4]_i_19__5_n_6\,
      DI(1) => \seconds_relay_6__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__5_n_4\,
      O(2) => \state_reg[4]_i_9__5_n_5\,
      O(1) => \state_reg[4]_i_9__5_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__5_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__5_n_0\,
      S(2) => \state[4]_i_28__5_n_0\,
      S(1) => \state[4]_i_29__5_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_liquid_0_1_register__parameterized0_6\ is
  port (
    \liquid_division_reg_reg[7]\ : out STD_LOGIC;
    \liquid_division_reg_reg[3]\ : out STD_LOGIC;
    DI : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[4]_0\ : out STD_LOGIC_VECTOR ( 4 downto 0 );
    \liquid_division_reg_reg[8]\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \slv_reg9_reg[1]\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    \slv_reg9_reg[1]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \liquid_division_reg_reg[8]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 1 downto 0 );
    \state_reg[1]_i_1__6_0\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_7__8_carry__0_i_6\ : in STD_LOGIC_VECTOR ( 6 downto 0 );
    CO : in STD_LOGIC_VECTOR ( 0 to 0 );
    O : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \state_reg[4]_i_14__6_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    D : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[4]_i_14__6_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[0]_0\ : in STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_aclk : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_liquid_0_1_register__parameterized0_6\ : entity is "register";
end \design_1_liquid_0_1_register__parameterized0_6\;

architecture STRUCTURE of \design_1_liquid_0_1_register__parameterized0_6\ is
  signal \^liquid_division_reg_reg[3]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[7]\ : STD_LOGIC;
  signal \^liquid_division_reg_reg[8]\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^liquid_division_reg_reg[8]_0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal seconds_relay_7 : STD_LOGIC_VECTOR ( 4 downto 2 );
  signal \seconds_relay_7__274_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_10_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_11_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_12_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_1_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_1_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_1_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_4\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_5\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_6_n_6\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_9_n_0\ : STD_LOGIC;
  signal \state[1]_i_2__6_n_0\ : STD_LOGIC;
  signal \state[1]_i_3__6_n_0\ : STD_LOGIC;
  signal \state[1]_i_4__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_3__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_4__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_5__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_6__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_7__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_8__6_n_0\ : STD_LOGIC;
  signal \state[2]_i_9__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_10__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_11__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_12__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_13__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_3__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_4__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_5__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_7__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_8__6_n_0\ : STD_LOGIC;
  signal \state[3]_i_9__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_10__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_11__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_12__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_13__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_16__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_17__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_18__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_20__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_21__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_22__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_23__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_24__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_25__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_26__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_27__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_28__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_29__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_30__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_31__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_32__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_33__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_34__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_35__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_36__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_37__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_38__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_39__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_5__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_6__6_n_0\ : STD_LOGIC;
  signal \state[4]_i_7__6_n_0\ : STD_LOGIC;
  signal \state_reg[1]_i_1__6_n_2\ : STD_LOGIC;
  signal \state_reg[1]_i_1__6_n_3\ : STD_LOGIC;
  signal \state_reg[1]_i_1__6_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__6_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_1__6_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_1__6_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_1__6_n_7\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_0\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_1\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_2\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_3\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_4\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_5\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_6\ : STD_LOGIC;
  signal \state_reg[2]_i_2__6_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_1__6_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_1__6_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_1__6_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_1__6_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_6\ : STD_LOGIC;
  signal \state_reg[3]_i_2__6_n_7\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_0\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_1\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_2\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_3\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_4\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_5\ : STD_LOGIC;
  signal \state_reg[3]_i_6__6_n_6\ : STD_LOGIC;
  signal \^state_reg[4]_0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \state_reg[4]_i_14__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_14__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_14__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_14__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_14__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_15__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_19__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_1__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_1__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_1__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_2__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_3__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_3__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_3__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_3__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_3__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_4__6_n_7\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_8__6_n_6\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_0\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_1\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_2\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_3\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_4\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_5\ : STD_LOGIC;
  signal \state_reg[4]_i_9__6_n_6\ : STD_LOGIC;
  signal \NLW_seconds_relay_7__274_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_seconds_relay_7__274_carry_i_6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[1]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[1]_i_1__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[2]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[2]_i_1__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[3]_i_1__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[3]_i_6__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_14__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_14__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_19__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_1__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_3__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_state_reg[4]_i_3__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_state_reg[4]_i_8__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_state_reg[4]_i_9__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  \liquid_division_reg_reg[3]\ <= \^liquid_division_reg_reg[3]\;
  \liquid_division_reg_reg[7]\ <= \^liquid_division_reg_reg[7]\;
  \liquid_division_reg_reg[8]\(0) <= \^liquid_division_reg_reg[8]\(0);
  \liquid_division_reg_reg[8]_0\(0) <= \^liquid_division_reg_reg[8]_0\(0);
  \state_reg[4]_0\(4 downto 0) <= \^state_reg[4]_0\(4 downto 0);
\counter_out_i_2__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^state_reg[4]_0\(2),
      I1 => \^state_reg[4]_0\(0),
      I2 => \^state_reg[4]_0\(1),
      I3 => \^state_reg[4]_0\(3),
      I4 => \^state_reg[4]_0\(4),
      O => \state_reg[2]_0\
    );
\seconds_relay_7__274_carry__0_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__274_carry_i_1_n_0\,
      CO(3) => \seconds_relay_7__274_carry__0_i_1_n_0\,
      CO(2) => \seconds_relay_7__274_carry__0_i_1_n_1\,
      CO(1) => \seconds_relay_7__274_carry__0_i_1_n_2\,
      CO(0) => \seconds_relay_7__274_carry__0_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[2]_i_2__6_n_5\,
      DI(2) => \state_reg[2]_i_2__6_n_6\,
      DI(1) => \state_reg[2]_i_2__6_n_7\,
      DI(0) => \seconds_relay_7__274_carry_i_6_n_4\,
      O(3 downto 0) => \slv_reg9_reg[1]_0\(3 downto 0),
      S(3) => \seconds_relay_7__274_carry__0_i_6_n_0\,
      S(2) => \seconds_relay_7__274_carry__0_i_7_n_0\,
      S(1) => \seconds_relay_7__274_carry__0_i_8_n_0\,
      S(0) => \seconds_relay_7__274_carry__0_i_9_n_0\
    );
\seconds_relay_7__274_carry__0_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(6),
      I2 => \state_reg[2]_i_2__6_n_5\,
      O => \seconds_relay_7__274_carry__0_i_6_n_0\
    );
\seconds_relay_7__274_carry__0_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(5),
      I2 => \state_reg[2]_i_2__6_n_6\,
      O => \seconds_relay_7__274_carry__0_i_7_n_0\
    );
\seconds_relay_7__274_carry__0_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(4),
      I2 => \state_reg[2]_i_2__6_n_7\,
      O => \seconds_relay_7__274_carry__0_i_8_n_0\
    );
\seconds_relay_7__274_carry__0_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(3),
      I2 => \seconds_relay_7__274_carry_i_6_n_4\,
      O => \seconds_relay_7__274_carry__0_i_9_n_0\
    );
\seconds_relay_7__274_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => \state_reg[1]_i_1__6_n_6\,
      O => \state_reg[1]_i_1__6_0\(1)
    );
\seconds_relay_7__274_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \^liquid_division_reg_reg[8]\(0),
      I1 => Q(8),
      I2 => \^liquid_division_reg_reg[8]_0\(0),
      O => \state_reg[1]_i_1__6_0\(0)
    );
\seconds_relay_7__274_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_7__274_carry_i_1_n_0\,
      CO(2) => \seconds_relay_7__274_carry_i_1_n_1\,
      CO(1) => \seconds_relay_7__274_carry_i_1_n_2\,
      CO(0) => \seconds_relay_7__274_carry_i_1_n_3\,
      CYINIT => seconds_relay_7(2),
      DI(3) => \seconds_relay_7__274_carry_i_6_n_5\,
      DI(2) => \seconds_relay_7__274_carry_i_6_n_6\,
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(0),
      DI(0) => '0',
      O(3 downto 1) => \slv_reg9_reg[1]\(2 downto 0),
      O(0) => \NLW_seconds_relay_7__274_carry_i_1_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_7__274_carry_i_7_n_0\,
      S(2) => \seconds_relay_7__274_carry_i_8_n_0\,
      S(1) => \seconds_relay_7__274_carry_i_9_n_0\,
      S(0) => '1'
    );
\seconds_relay_7__274_carry_i_10\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(2),
      I2 => \state_reg[3]_i_6__6_n_5\,
      O => \seconds_relay_7__274_carry_i_10_n_0\
    );
\seconds_relay_7__274_carry_i_11\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(1),
      I2 => \state_reg[3]_i_6__6_n_6\,
      O => \seconds_relay_7__274_carry_i_11_n_0\
    );
\seconds_relay_7__274_carry_i_12\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(1),
      O => \seconds_relay_7__274_carry_i_12_n_0\
    );
\seconds_relay_7__274_carry_i_6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_7__274_carry_i_6_n_0\,
      CO(2) => \seconds_relay_7__274_carry_i_6_n_1\,
      CO(1) => \seconds_relay_7__274_carry_i_6_n_2\,
      CO(0) => \seconds_relay_7__274_carry_i_6_n_3\,
      CYINIT => seconds_relay_7(3),
      DI(3) => \state_reg[3]_i_6__6_n_5\,
      DI(2) => \state_reg[3]_i_6__6_n_6\,
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(1),
      DI(0) => '0',
      O(3) => \seconds_relay_7__274_carry_i_6_n_4\,
      O(2) => \seconds_relay_7__274_carry_i_6_n_5\,
      O(1) => \seconds_relay_7__274_carry_i_6_n_6\,
      O(0) => \NLW_seconds_relay_7__274_carry_i_6_O_UNCONNECTED\(0),
      S(3) => \seconds_relay_7__274_carry_i_10_n_0\,
      S(2) => \seconds_relay_7__274_carry_i_11_n_0\,
      S(1) => \seconds_relay_7__274_carry_i_12_n_0\,
      S(0) => '1'
    );
\seconds_relay_7__274_carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(2),
      I2 => \seconds_relay_7__274_carry_i_6_n_5\,
      O => \seconds_relay_7__274_carry_i_7_n_0\
    );
\seconds_relay_7__274_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(1),
      I2 => \seconds_relay_7__274_carry_i_6_n_6\,
      O => \seconds_relay_7__274_carry_i_8_n_0\
    );
\seconds_relay_7__274_carry_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(0),
      O => \seconds_relay_7__274_carry_i_9_n_0\
    );
\seconds_relay_7__8_carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => DI(1)
    );
\seconds_relay_7__8_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => Q(8),
      I1 => \^liquid_division_reg_reg[7]\,
      O => DI(0)
    );
\seconds_relay_7__8_carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555575"
    )
        port map (
      I0 => Q(8),
      I1 => Q(6),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(5),
      I4 => Q(7),
      O => S(1)
    );
\seconds_relay_7__8_carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"99999799"
    )
        port map (
      I0 => Q(8),
      I1 => Q(7),
      I2 => Q(5),
      I3 => \^liquid_division_reg_reg[3]\,
      I4 => Q(6),
      O => S(0)
    );
\seconds_relay_7__8_carry_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => Q(7),
      I1 => Q(5),
      I2 => \^liquid_division_reg_reg[3]\,
      I3 => Q(6),
      I4 => Q(8),
      O => \^liquid_division_reg_reg[7]\
    );
\seconds_relay_7__8_carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001011"
    )
        port map (
      I0 => Q(3),
      I1 => Q(1),
      I2 => \seconds_relay_7__8_carry__0_i_6\(6),
      I3 => Q(0),
      I4 => Q(2),
      I5 => Q(4),
      O => \^liquid_division_reg_reg[3]\
    );
\state[1]_i_2__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => \state_reg[2]_i_1__6_n_6\,
      O => \state[1]_i_2__6_n_0\
    );
\state[1]_i_3__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(8),
      I2 => \state_reg[2]_i_1__6_n_7\,
      O => \state[1]_i_3__6_n_0\
    );
\state[1]_i_4__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(2),
      I1 => Q(7),
      I2 => \state_reg[2]_i_2__6_n_4\,
      O => \state[1]_i_4__6_n_0\
    );
\state[2]_i_3__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => \state_reg[3]_i_1__6_n_6\,
      O => \state[2]_i_3__6_n_0\
    );
\state[2]_i_4__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(8),
      I2 => \state_reg[3]_i_1__6_n_7\,
      O => \state[2]_i_4__6_n_0\
    );
\state[2]_i_5__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(7),
      I2 => \state_reg[3]_i_2__6_n_4\,
      O => \state[2]_i_5__6_n_0\
    );
\state[2]_i_6__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(6),
      I2 => \state_reg[3]_i_2__6_n_5\,
      O => \state[2]_i_6__6_n_0\
    );
\state[2]_i_7__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(5),
      I2 => \state_reg[3]_i_2__6_n_6\,
      O => \state[2]_i_7__6_n_0\
    );
\state[2]_i_8__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(4),
      I2 => \state_reg[3]_i_2__6_n_7\,
      O => \state[2]_i_8__6_n_0\
    );
\state[2]_i_9__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(3),
      I1 => Q(3),
      I2 => \state_reg[3]_i_6__6_n_4\,
      O => \state[2]_i_9__6_n_0\
    );
\state[3]_i_10__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(3),
      I2 => \state_reg[4]_i_8__6_n_4\,
      O => \state[3]_i_10__6_n_0\
    );
\state[3]_i_11__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(2),
      I2 => \state_reg[4]_i_8__6_n_5\,
      O => \state[3]_i_11__6_n_0\
    );
\state[3]_i_12__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(1),
      I2 => \state_reg[4]_i_8__6_n_6\,
      O => \state[3]_i_12__6_n_0\
    );
\state[3]_i_13__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(2),
      O => \state[3]_i_13__6_n_0\
    );
\state[3]_i_3__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => \state_reg[4]_i_1__6_n_6\,
      O => \state[3]_i_3__6_n_0\
    );
\state[3]_i_4__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(8),
      I2 => \state_reg[4]_i_1__6_n_7\,
      O => \state[3]_i_4__6_n_0\
    );
\state[3]_i_5__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(7),
      I2 => \state_reg[4]_i_2__6_n_4\,
      O => \state[3]_i_5__6_n_0\
    );
\state[3]_i_7__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(6),
      I2 => \state_reg[4]_i_2__6_n_5\,
      O => \state[3]_i_7__6_n_0\
    );
\state[3]_i_8__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(5),
      I2 => \state_reg[4]_i_2__6_n_6\,
      O => \state[3]_i_8__6_n_0\
    );
\state[3]_i_9__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(4),
      I1 => Q(4),
      I2 => \state_reg[4]_i_2__6_n_7\,
      O => \state[3]_i_9__6_n_0\
    );
\state[4]_i_10__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_4__6_n_5\,
      O => \state[4]_i_10__6_n_0\
    );
\state[4]_i_11__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_4__6_n_6\,
      O => \state[4]_i_11__6_n_0\
    );
\state[4]_i_12__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_4__6_n_7\,
      O => \state[4]_i_12__6_n_0\
    );
\state[4]_i_13__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_9__6_n_4\,
      O => \state[4]_i_13__6_n_0\
    );
\state[4]_i_16__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => \state_reg[4]_i_14__6_n_6\,
      O => \state[4]_i_16__6_n_0\
    );
\state[4]_i_17__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__6_n_7\,
      O => \state[4]_i_17__6_n_0\
    );
\state[4]_i_18__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_15__6_n_4\,
      O => \state[4]_i_18__6_n_0\
    );
\state[4]_i_20__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(6),
      I2 => \state_reg[4]_i_15__6_n_5\,
      O => \state[4]_i_20__6_n_0\
    );
\state[4]_i_21__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(5),
      I2 => \state_reg[4]_i_15__6_n_6\,
      O => \state[4]_i_21__6_n_0\
    );
\state[4]_i_22__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(4),
      I2 => \state_reg[4]_i_15__6_n_7\,
      O => \state[4]_i_22__6_n_0\
    );
\state[4]_i_23__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(3),
      I2 => \state_reg[4]_i_19__6_n_4\,
      O => \state[4]_i_23__6_n_0\
    );
\state[4]_i_24__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_9__6_n_5\,
      O => \state[4]_i_24__6_n_0\
    );
\state[4]_i_25__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_9__6_n_6\,
      O => \state[4]_i_25__6_n_0\
    );
\state[4]_i_26__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(3),
      O => \state[4]_i_26__6_n_0\
    );
\state[4]_i_27__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(2),
      I2 => \state_reg[4]_i_19__6_n_5\,
      O => \state[4]_i_27__6_n_0\
    );
\state[4]_i_28__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(1),
      I2 => \state_reg[4]_i_19__6_n_6\,
      O => \state[4]_i_28__6_n_0\
    );
\state[4]_i_29__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_14__6_n_1\,
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(4),
      O => \state[4]_i_29__6_n_0\
    );
\state[4]_i_30__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => CO(0),
      I1 => \state_reg[4]_i_14__6_1\(0),
      O => \state[4]_i_30__6_n_0\
    );
\state[4]_i_31__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(8),
      I2 => \state_reg[4]_i_14__6_0\(3),
      O => \state[4]_i_31__6_n_0\
    );
\state[4]_i_32__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(7),
      I2 => \state_reg[4]_i_14__6_0\(2),
      O => \state[4]_i_32__6_n_0\
    );
\state[4]_i_33__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(6),
      I2 => \state_reg[4]_i_14__6_0\(1),
      O => \state[4]_i_33__6_n_0\
    );
\state[4]_i_34__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(5),
      I2 => \state_reg[4]_i_14__6_0\(0),
      O => \state[4]_i_34__6_n_0\
    );
\state[4]_i_35__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(4),
      I2 => O(3),
      O => \state[4]_i_35__6_n_0\
    );
\state[4]_i_36__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(3),
      I2 => O(2),
      O => \state[4]_i_36__6_n_0\
    );
\state[4]_i_37__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(2),
      I2 => O(1),
      O => \state[4]_i_37__6_n_0\
    );
\state[4]_i_38__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(1),
      I2 => O(0),
      O => \state[4]_i_38__6_n_0\
    );
\state[4]_i_39__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => CO(0),
      I1 => Q(0),
      I2 => \seconds_relay_7__8_carry__0_i_6\(5),
      O => \state[4]_i_39__6_n_0\
    );
\state[4]_i_5__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => \state_reg[4]_i_3__6_n_6\,
      O => \state[4]_i_5__6_n_0\
    );
\state[4]_i_6__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(8),
      I2 => \state_reg[4]_i_3__6_n_7\,
      O => \state[4]_i_6__6_n_0\
    );
\state[4]_i_7__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => \state_reg[4]_i_3__6_n_1\,
      I1 => Q(7),
      I2 => \state_reg[4]_i_4__6_n_4\,
      O => \state[4]_i_7__6_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => D(0),
      Q => \^state_reg[4]_0\(0),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => \^liquid_division_reg_reg[8]\(0),
      Q => \^state_reg[4]_0\(1),
      R => \state_reg[0]_0\(0)
    );
\state_reg[1]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__274_carry__0_i_1_n_0\,
      CO(3) => \NLW_state_reg[1]_i_1__6_CO_UNCONNECTED\(3),
      CO(2) => \^liquid_division_reg_reg[8]\(0),
      CO(1) => \state_reg[1]_i_1__6_n_2\,
      CO(0) => \state_reg[1]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_7(2),
      DI(1) => \state_reg[2]_i_1__6_n_7\,
      DI(0) => \state_reg[2]_i_2__6_n_4\,
      O(3 downto 2) => \NLW_state_reg[1]_i_1__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[1]_i_1__6_n_6\,
      O(0) => \^liquid_division_reg_reg[8]_0\(0),
      S(3) => '0',
      S(2) => \state[1]_i_2__6_n_0\,
      S(1) => \state[1]_i_3__6_n_0\,
      S(0) => \state[1]_i_4__6_n_0\
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_7(2),
      Q => \^state_reg[4]_0\(2),
      R => \state_reg[0]_0\(0)
    );
\state_reg[2]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[2]_i_2__6_n_0\,
      CO(3) => \NLW_state_reg[2]_i_1__6_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_7(2),
      CO(1) => \state_reg[2]_i_1__6_n_2\,
      CO(0) => \state_reg[2]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_7(3),
      DI(1) => \state_reg[3]_i_1__6_n_7\,
      DI(0) => \state_reg[3]_i_2__6_n_4\,
      O(3 downto 2) => \NLW_state_reg[2]_i_1__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[2]_i_1__6_n_6\,
      O(0) => \state_reg[2]_i_1__6_n_7\,
      S(3) => '0',
      S(2) => \state[2]_i_3__6_n_0\,
      S(1) => \state[2]_i_4__6_n_0\,
      S(0) => \state[2]_i_5__6_n_0\
    );
\state_reg[2]_i_2__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__274_carry_i_6_n_0\,
      CO(3) => \state_reg[2]_i_2__6_n_0\,
      CO(2) => \state_reg[2]_i_2__6_n_1\,
      CO(1) => \state_reg[2]_i_2__6_n_2\,
      CO(0) => \state_reg[2]_i_2__6_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[3]_i_2__6_n_5\,
      DI(2) => \state_reg[3]_i_2__6_n_6\,
      DI(1) => \state_reg[3]_i_2__6_n_7\,
      DI(0) => \state_reg[3]_i_6__6_n_4\,
      O(3) => \state_reg[2]_i_2__6_n_4\,
      O(2) => \state_reg[2]_i_2__6_n_5\,
      O(1) => \state_reg[2]_i_2__6_n_6\,
      O(0) => \state_reg[2]_i_2__6_n_7\,
      S(3) => \state[2]_i_6__6_n_0\,
      S(2) => \state[2]_i_7__6_n_0\,
      S(1) => \state[2]_i_8__6_n_0\,
      S(0) => \state[2]_i_9__6_n_0\
    );
\state_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_7(3),
      Q => \^state_reg[4]_0\(3),
      R => \state_reg[0]_0\(0)
    );
\state_reg[3]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_2__6_n_0\,
      CO(3) => \NLW_state_reg[3]_i_1__6_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_7(3),
      CO(1) => \state_reg[3]_i_1__6_n_2\,
      CO(0) => \state_reg[3]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => seconds_relay_7(4),
      DI(1) => \state_reg[4]_i_1__6_n_7\,
      DI(0) => \state_reg[4]_i_2__6_n_4\,
      O(3 downto 2) => \NLW_state_reg[3]_i_1__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[3]_i_1__6_n_6\,
      O(0) => \state_reg[3]_i_1__6_n_7\,
      S(3) => '0',
      S(2) => \state[3]_i_3__6_n_0\,
      S(1) => \state[3]_i_4__6_n_0\,
      S(0) => \state[3]_i_5__6_n_0\
    );
\state_reg[3]_i_2__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[3]_i_6__6_n_0\,
      CO(3) => \state_reg[3]_i_2__6_n_0\,
      CO(2) => \state_reg[3]_i_2__6_n_1\,
      CO(1) => \state_reg[3]_i_2__6_n_2\,
      CO(0) => \state_reg[3]_i_2__6_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_2__6_n_5\,
      DI(2) => \state_reg[4]_i_2__6_n_6\,
      DI(1) => \state_reg[4]_i_2__6_n_7\,
      DI(0) => \state_reg[4]_i_8__6_n_4\,
      O(3) => \state_reg[3]_i_2__6_n_4\,
      O(2) => \state_reg[3]_i_2__6_n_5\,
      O(1) => \state_reg[3]_i_2__6_n_6\,
      O(0) => \state_reg[3]_i_2__6_n_7\,
      S(3) => \state[3]_i_7__6_n_0\,
      S(2) => \state[3]_i_8__6_n_0\,
      S(1) => \state[3]_i_9__6_n_0\,
      S(0) => \state[3]_i_10__6_n_0\
    );
\state_reg[3]_i_6__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[3]_i_6__6_n_0\,
      CO(2) => \state_reg[3]_i_6__6_n_1\,
      CO(1) => \state_reg[3]_i_6__6_n_2\,
      CO(0) => \state_reg[3]_i_6__6_n_3\,
      CYINIT => seconds_relay_7(4),
      DI(3) => \state_reg[4]_i_8__6_n_5\,
      DI(2) => \state_reg[4]_i_8__6_n_6\,
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(2),
      DI(0) => '0',
      O(3) => \state_reg[3]_i_6__6_n_4\,
      O(2) => \state_reg[3]_i_6__6_n_5\,
      O(1) => \state_reg[3]_i_6__6_n_6\,
      O(0) => \NLW_state_reg[3]_i_6__6_O_UNCONNECTED\(0),
      S(3) => \state[3]_i_11__6_n_0\,
      S(2) => \state[3]_i_12__6_n_0\,
      S(1) => \state[3]_i_13__6_n_0\,
      S(0) => '1'
    );
\state_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \state_reg[0]_0\(1),
      D => seconds_relay_7(4),
      Q => \^state_reg[4]_0\(4),
      R => \state_reg[0]_0\(0)
    );
\state_reg[4]_i_14__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_15__6_n_0\,
      CO(3) => \NLW_state_reg[4]_i_14__6_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_14__6_n_1\,
      CO(1) => \state_reg[4]_i_14__6_n_2\,
      CO(0) => \state_reg[4]_i_14__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => CO(0),
      DI(1 downto 0) => \state_reg[4]_i_14__6_0\(3 downto 2),
      O(3 downto 2) => \NLW_state_reg[4]_i_14__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_14__6_n_6\,
      O(0) => \state_reg[4]_i_14__6_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_30__6_n_0\,
      S(1) => \state[4]_i_31__6_n_0\,
      S(0) => \state[4]_i_32__6_n_0\
    );
\state_reg[4]_i_15__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_19__6_n_0\,
      CO(3) => \state_reg[4]_i_15__6_n_0\,
      CO(2) => \state_reg[4]_i_15__6_n_1\,
      CO(1) => \state_reg[4]_i_15__6_n_2\,
      CO(0) => \state_reg[4]_i_15__6_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => \state_reg[4]_i_14__6_0\(1 downto 0),
      DI(1 downto 0) => O(3 downto 2),
      O(3) => \state_reg[4]_i_15__6_n_4\,
      O(2) => \state_reg[4]_i_15__6_n_5\,
      O(1) => \state_reg[4]_i_15__6_n_6\,
      O(0) => \state_reg[4]_i_15__6_n_7\,
      S(3) => \state[4]_i_33__6_n_0\,
      S(2) => \state[4]_i_34__6_n_0\,
      S(1) => \state[4]_i_35__6_n_0\,
      S(0) => \state[4]_i_36__6_n_0\
    );
\state_reg[4]_i_19__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_19__6_n_0\,
      CO(2) => \state_reg[4]_i_19__6_n_1\,
      CO(1) => \state_reg[4]_i_19__6_n_2\,
      CO(0) => \state_reg[4]_i_19__6_n_3\,
      CYINIT => CO(0),
      DI(3 downto 2) => O(1 downto 0),
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(5),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_19__6_n_4\,
      O(2) => \state_reg[4]_i_19__6_n_5\,
      O(1) => \state_reg[4]_i_19__6_n_6\,
      O(0) => \NLW_state_reg[4]_i_19__6_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_37__6_n_0\,
      S(2) => \state[4]_i_38__6_n_0\,
      S(1) => \state[4]_i_39__6_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_2__6_n_0\,
      CO(3) => \NLW_state_reg[4]_i_1__6_CO_UNCONNECTED\(3),
      CO(2) => seconds_relay_7(4),
      CO(1) => \state_reg[4]_i_1__6_n_2\,
      CO(0) => \state_reg[4]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_3__6_n_1\,
      DI(1) => \state_reg[4]_i_3__6_n_7\,
      DI(0) => \state_reg[4]_i_4__6_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_1__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_1__6_n_6\,
      O(0) => \state_reg[4]_i_1__6_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_5__6_n_0\,
      S(1) => \state[4]_i_6__6_n_0\,
      S(0) => \state[4]_i_7__6_n_0\
    );
\state_reg[4]_i_2__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_8__6_n_0\,
      CO(3) => \state_reg[4]_i_2__6_n_0\,
      CO(2) => \state_reg[4]_i_2__6_n_1\,
      CO(1) => \state_reg[4]_i_2__6_n_2\,
      CO(0) => \state_reg[4]_i_2__6_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_4__6_n_5\,
      DI(2) => \state_reg[4]_i_4__6_n_6\,
      DI(1) => \state_reg[4]_i_4__6_n_7\,
      DI(0) => \state_reg[4]_i_9__6_n_4\,
      O(3) => \state_reg[4]_i_2__6_n_4\,
      O(2) => \state_reg[4]_i_2__6_n_5\,
      O(1) => \state_reg[4]_i_2__6_n_6\,
      O(0) => \state_reg[4]_i_2__6_n_7\,
      S(3) => \state[4]_i_10__6_n_0\,
      S(2) => \state[4]_i_11__6_n_0\,
      S(1) => \state[4]_i_12__6_n_0\,
      S(0) => \state[4]_i_13__6_n_0\
    );
\state_reg[4]_i_3__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_4__6_n_0\,
      CO(3) => \NLW_state_reg[4]_i_3__6_CO_UNCONNECTED\(3),
      CO(2) => \state_reg[4]_i_3__6_n_1\,
      CO(1) => \state_reg[4]_i_3__6_n_2\,
      CO(0) => \state_reg[4]_i_3__6_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \state_reg[4]_i_14__6_n_1\,
      DI(1) => \state_reg[4]_i_14__6_n_7\,
      DI(0) => \state_reg[4]_i_15__6_n_4\,
      O(3 downto 2) => \NLW_state_reg[4]_i_3__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \state_reg[4]_i_3__6_n_6\,
      O(0) => \state_reg[4]_i_3__6_n_7\,
      S(3) => '0',
      S(2) => \state[4]_i_16__6_n_0\,
      S(1) => \state[4]_i_17__6_n_0\,
      S(0) => \state[4]_i_18__6_n_0\
    );
\state_reg[4]_i_4__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \state_reg[4]_i_9__6_n_0\,
      CO(3) => \state_reg[4]_i_4__6_n_0\,
      CO(2) => \state_reg[4]_i_4__6_n_1\,
      CO(1) => \state_reg[4]_i_4__6_n_2\,
      CO(0) => \state_reg[4]_i_4__6_n_3\,
      CYINIT => '0',
      DI(3) => \state_reg[4]_i_15__6_n_5\,
      DI(2) => \state_reg[4]_i_15__6_n_6\,
      DI(1) => \state_reg[4]_i_15__6_n_7\,
      DI(0) => \state_reg[4]_i_19__6_n_4\,
      O(3) => \state_reg[4]_i_4__6_n_4\,
      O(2) => \state_reg[4]_i_4__6_n_5\,
      O(1) => \state_reg[4]_i_4__6_n_6\,
      O(0) => \state_reg[4]_i_4__6_n_7\,
      S(3) => \state[4]_i_20__6_n_0\,
      S(2) => \state[4]_i_21__6_n_0\,
      S(1) => \state[4]_i_22__6_n_0\,
      S(0) => \state[4]_i_23__6_n_0\
    );
\state_reg[4]_i_8__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_8__6_n_0\,
      CO(2) => \state_reg[4]_i_8__6_n_1\,
      CO(1) => \state_reg[4]_i_8__6_n_2\,
      CO(0) => \state_reg[4]_i_8__6_n_3\,
      CYINIT => \state_reg[4]_i_3__6_n_1\,
      DI(3) => \state_reg[4]_i_9__6_n_5\,
      DI(2) => \state_reg[4]_i_9__6_n_6\,
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(3),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_8__6_n_4\,
      O(2) => \state_reg[4]_i_8__6_n_5\,
      O(1) => \state_reg[4]_i_8__6_n_6\,
      O(0) => \NLW_state_reg[4]_i_8__6_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_24__6_n_0\,
      S(2) => \state[4]_i_25__6_n_0\,
      S(1) => \state[4]_i_26__6_n_0\,
      S(0) => '1'
    );
\state_reg[4]_i_9__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \state_reg[4]_i_9__6_n_0\,
      CO(2) => \state_reg[4]_i_9__6_n_1\,
      CO(1) => \state_reg[4]_i_9__6_n_2\,
      CO(0) => \state_reg[4]_i_9__6_n_3\,
      CYINIT => \state_reg[4]_i_14__6_n_1\,
      DI(3) => \state_reg[4]_i_19__6_n_5\,
      DI(2) => \state_reg[4]_i_19__6_n_6\,
      DI(1) => \seconds_relay_7__8_carry__0_i_6\(4),
      DI(0) => '0',
      O(3) => \state_reg[4]_i_9__6_n_4\,
      O(2) => \state_reg[4]_i_9__6_n_5\,
      O(1) => \state_reg[4]_i_9__6_n_6\,
      O(0) => \NLW_state_reg[4]_i_9__6_O_UNCONNECTED\(0),
      S(3) => \state[4]_i_27__6_n_0\,
      S(2) => \state[4]_i_28__6_n_0\,
      S(1) => \state[4]_i_29__6_n_0\,
      S(0) => '1'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer : entity is "timer";
end design_1_liquid_0_1_timer;

architecture STRUCTURE of design_1_liquid_0_1_timer is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal counter_out_i_10_n_0 : STD_LOGIC;
  signal \counter_out_i_5__6_n_0\ : STD_LOGIC;
  signal counter_out_i_6_n_0 : STD_LOGIC;
  signal counter_out_i_7_n_0 : STD_LOGIC;
  signal counter_out_i_8_n_0 : STD_LOGIC;
  signal counter_out_i_9_n_0 : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \counter_out_i_5__6\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \started_i_2__6\ : label is "soft_lutpair1";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2_n_0\
    );
\count_clk_cycles[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => counter_out_i_6_n_0,
      I2 => counter_out_i_7_n_0,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4_n_0\
    );
\count_clk_cycles[0]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[0]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[20]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[24]_i_1_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[24]_i_1_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_clk_cycles_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1_n_0\
    );
\count_seconds[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => p_0_in(0)
    );
\count_seconds[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => p_0_in(1)
    );
\count_seconds[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => p_0_in(2)
    );
\count_seconds[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => p_0_in(3)
    );
\count_seconds[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3_n_0\,
      I4 => count_seconds_reg(4),
      O => p_0_in(4)
    );
\count_seconds[4]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => p_0_in(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => p_0_in(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => p_0_in(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => p_0_in(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => p_0_in(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
counter_out_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => counter_out_i_10_n_0
    );
counter_out_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__6_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => counter_out_i_6_n_0,
      I4 => counter_out_i_7_n_0,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out
    );
\counter_out_i_5__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__6_n_0\
    );
counter_out_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => counter_out_i_8_n_0,
      I2 => counter_out_i_9_n_0,
      I3 => counter_out_i_10_n_0,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => counter_out_i_6_n_0
    );
counter_out_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => counter_out_i_7_n_0
    );
counter_out_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => counter_out_i_8_n_0
    );
counter_out_i_9: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => counter_out_i_9_n_0
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_10 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_14 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_10 : entity is "timer";
end design_1_liquid_0_1_timer_10;

architecture STRUCTURE of design_1_liquid_0_1_timer_10 is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__3_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__3_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__3_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__3_n_0\ : STD_LOGIC;
  signal \p_0_in__3\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__3\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__3\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__3\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__3\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \counter_out_i_5__2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \started_i_2__2\ : label is "soft_lutpair10";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__3_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles[0]_i_2__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__3_n_0\
    );
\count_clk_cycles[0]_i_4__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__3_n_0\,
      I2 => \counter_out_i_7__3_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__3_n_0\
    );
\count_clk_cycles[0]_i_5__3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__3_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__3_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[0]_i_3__3\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__3_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__3_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__3_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__3_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__3_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__3_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__3_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__3_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__3_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__3_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[12]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__3_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__3_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__3_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__3_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__3_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__3_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__3_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__3_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__3_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[16]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__3_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__3_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__3_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__3_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__3_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__3_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__3_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__3_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__3_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__3_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[20]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__3_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__3_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__3_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__3_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__3_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__3_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__3_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__3_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__3_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[24]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__3_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__3_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__3_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__3_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__3_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__3_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[4]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__3_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__3_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__3_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__3_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__3_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__3_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__3_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__3_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__3_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__3_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_clk_cycles_reg[8]_i_1__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__3_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__3_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__3_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__3_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__3_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__3_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__3_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__3_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__3_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__3_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__3_n_0\
    );
\count_seconds[0]_i_1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__3\(0)
    );
\count_seconds[1]_i_1__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__3\(1)
    );
\count_seconds[2]_i_1__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__3\(2)
    );
\count_seconds[3]_i_1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__3\(3)
    );
\count_seconds[4]_i_1__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__3_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__3_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__3\(4)
    );
\count_seconds[4]_i_3__3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__3_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__3\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__3\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__3\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__3\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__3\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__3_n_0\
    );
\counter_out_i_3__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__2_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__3_n_0\,
      I4 => \counter_out_i_7__3_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_14
    );
\counter_out_i_5__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__2_n_0\
    );
\counter_out_i_6__3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__3_n_0\,
      I2 => \counter_out_i_9__3_n_0\,
      I3 => \counter_out_i_10__3_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__3_n_0\
    );
\counter_out_i_7__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__3_n_0\
    );
\counter_out_i_8__3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__3_n_0\
    );
\counter_out_i_9__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__3_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_11 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_16 : out STD_LOGIC;
    counter_out_reg_0 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_1 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 );
    \FSM_onehot_current_state[1]_i_2\ : in STD_LOGIC_VECTOR ( 2 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_11 : entity is "timer";
end design_1_liquid_0_1_timer_11;

architecture STRUCTURE of design_1_liquid_0_1_timer_11 is
  signal \^d\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__4_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__4_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__4_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__4_n_0\ : STD_LOGIC;
  signal \p_0_in__4\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__4\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__4\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__4\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__4\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \counter_out_i_5__1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \started_i_2__1\ : label is "soft_lutpair12";
begin
  D(0) <= \^d\(0);
  started_reg_0 <= \^started_reg_0\;
\FSM_onehot_current_state[1]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^d\(0),
      I1 => \FSM_onehot_current_state[1]_i_2\(0),
      I2 => \FSM_onehot_current_state[1]_i_2\(2),
      I3 => \FSM_onehot_current_state[1]_i_2\(1),
      O => counter_out_reg_0
    );
\count_clk_cycles[0]_i_1__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__4_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles[0]_i_2__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__4_n_0\
    );
\count_clk_cycles[0]_i_4__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__4_n_0\,
      I2 => \counter_out_i_7__4_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__4_n_0\
    );
\count_clk_cycles[0]_i_5__4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__4_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__4_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[0]_i_3__4\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__4_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__4_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__4_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__4_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__4_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__4_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__4_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__4_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__4_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__4_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[12]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__4_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__4_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__4_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__4_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__4_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__4_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__4_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__4_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__4_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[16]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__4_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__4_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__4_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__4_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__4_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__4_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__4_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__4_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__4_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__4_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[20]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__4_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__4_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__4_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__4_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__4_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__4_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__4_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__4_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__4_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[24]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__4_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__4_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__4_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__4_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__4_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__4_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[4]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__4_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__4_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__4_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__4_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__4_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__4_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__4_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__4_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__4_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__4_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_clk_cycles_reg[8]_i_1__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__4_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__4_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__4_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__4_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__4_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__4_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__4_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__4_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__4_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__4_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__4_n_0\
    );
\count_seconds[0]_i_1__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__4\(0)
    );
\count_seconds[1]_i_1__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__4\(1)
    );
\count_seconds[2]_i_1__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__4\(2)
    );
\count_seconds[3]_i_1__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__4\(3)
    );
\count_seconds[4]_i_1__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__4_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__4_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__4\(4)
    );
\count_seconds[4]_i_3__4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__4_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__4\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__4\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__4\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__4\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__4\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__4_n_0\
    );
\counter_out_i_3__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__1_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__4_n_0\,
      I4 => \counter_out_i_7__4_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_16
    );
\counter_out_i_5__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__1_n_0\
    );
\counter_out_i_6__4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__4_n_0\,
      I2 => \counter_out_i_9__4_n_0\,
      I3 => \counter_out_i_10__4_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__4_n_0\
    );
\counter_out_i_7__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__4_n_0\
    );
\counter_out_i_8__4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__4_n_0\
    );
\counter_out_i_9__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__4_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_1,
      Q => \^d\(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_12 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_18 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_12 : entity is "timer";
end design_1_liquid_0_1_timer_12;

architecture STRUCTURE of design_1_liquid_0_1_timer_12 is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__5_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__5_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__5_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__5_n_0\ : STD_LOGIC;
  signal \p_0_in__5\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__5\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__5\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__5\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__5\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \counter_out_i_5__0\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \started_i_2__0\ : label is "soft_lutpair14";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__5_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles[0]_i_2__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__5_n_0\
    );
\count_clk_cycles[0]_i_4__5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__5_n_0\,
      I2 => \counter_out_i_7__5_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__5_n_0\
    );
\count_clk_cycles[0]_i_5__5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__5_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__5_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[0]_i_3__5\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__5_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__5_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__5_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__5_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__5_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__5_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__5_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__5_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__5_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__5_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[12]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__5_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__5_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__5_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__5_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__5_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__5_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__5_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__5_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__5_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[16]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__5_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__5_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__5_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__5_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__5_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__5_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__5_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__5_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__5_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__5_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[20]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__5_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__5_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__5_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__5_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__5_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__5_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__5_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__5_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__5_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[24]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__5_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__5_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__5_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__5_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__5_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__5_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[4]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__5_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__5_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__5_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__5_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__5_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__5_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__5_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__5_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__5_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__5_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_clk_cycles_reg[8]_i_1__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__5_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__5_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__5_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__5_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__5_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__5_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__5_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__5_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__5_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__5_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__5_n_0\
    );
\count_seconds[0]_i_1__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__5\(0)
    );
\count_seconds[1]_i_1__5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__5\(1)
    );
\count_seconds[2]_i_1__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__5\(2)
    );
\count_seconds[3]_i_1__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__5\(3)
    );
\count_seconds[4]_i_1__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__5_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__5_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__5\(4)
    );
\count_seconds[4]_i_3__5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__5_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__5\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__5\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__5\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__5\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__5\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__5_n_0\
    );
\counter_out_i_3__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__0_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__5_n_0\,
      I4 => \counter_out_i_7__5_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_18
    );
\counter_out_i_5__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__0_n_0\
    );
\counter_out_i_6__5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__5_n_0\,
      I2 => \counter_out_i_9__5_n_0\,
      I3 => \counter_out_i_10__5_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__5_n_0\
    );
\counter_out_i_7__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__5_n_0\
    );
\counter_out_i_8__5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__5_n_0\
    );
\counter_out_i_9__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__5_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_13 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_20 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_13 : entity is "timer";
end design_1_liquid_0_1_timer_13;

architecture STRUCTURE of design_1_liquid_0_1_timer_13 is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__6_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__6_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__6_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__6_n_0\ : STD_LOGIC;
  signal counter_out_i_5_n_0 : STD_LOGIC;
  signal \counter_out_i_6__6_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__6_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__6_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__6_n_0\ : STD_LOGIC;
  signal \p_0_in__6\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__6\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__6\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__6\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__6\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of counter_out_i_5 : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of started_i_2 : label is "soft_lutpair16";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__6_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles[0]_i_2__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__6_n_0\
    );
\count_clk_cycles[0]_i_4__6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__6_n_0\,
      I2 => \counter_out_i_7__6_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__6_n_0\
    );
\count_clk_cycles[0]_i_5__6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__6_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__6_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[0]_i_3__6\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__6_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__6_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__6_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__6_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__6_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__6_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__6_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__6_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__6_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__6_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[12]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__6_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__6_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__6_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__6_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__6_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__6_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__6_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__6_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__6_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[16]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__6_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__6_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__6_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__6_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__6_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__6_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__6_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__6_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__6_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__6_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[20]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__6_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__6_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__6_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__6_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__6_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__6_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__6_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__6_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__6_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[24]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__6_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__6_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__6_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__6_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__6_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__6_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[4]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__6_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__6_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__6_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__6_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__6_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__6_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__6_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__6_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__6_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__6_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_clk_cycles_reg[8]_i_1__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__6_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__6_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__6_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__6_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__6_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__6_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__6_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__6_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__6_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__6_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__6_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__6_n_0\
    );
\count_seconds[0]_i_1__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__6\(0)
    );
\count_seconds[1]_i_1__6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__6\(1)
    );
\count_seconds[2]_i_1__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__6\(2)
    );
\count_seconds[3]_i_1__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__6\(3)
    );
\count_seconds[4]_i_1__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__6_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__6_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__6\(4)
    );
\count_seconds[4]_i_3__6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__6_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__6\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__6\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__6\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__6\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__6\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__6_n_0\
    );
\counter_out_i_3__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => counter_out_i_5_n_0,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__6_n_0\,
      I4 => \counter_out_i_7__6_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_20
    );
counter_out_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => counter_out_i_5_n_0
    );
\counter_out_i_6__6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__6_n_0\,
      I2 => \counter_out_i_9__6_n_0\,
      I3 => \counter_out_i_10__6_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__6_n_0\
    );
\counter_out_i_7__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__6_n_0\
    );
\counter_out_i_8__6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__6_n_0\
    );
\counter_out_i_9__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__6_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
started_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_7 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_8 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_7 : entity is "timer";
end design_1_liquid_0_1_timer_7;

architecture STRUCTURE of design_1_liquid_0_1_timer_7 is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__0_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__0_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__0_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__0_n_0\ : STD_LOGIC;
  signal \p_0_in__0\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__0\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__0\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \counter_out_i_5__5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \started_i_2__5\ : label is "soft_lutpair3";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__0_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles[0]_i_2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__0_n_0\
    );
\count_clk_cycles[0]_i_4__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__0_n_0\,
      I2 => \counter_out_i_7__0_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__0_n_0\
    );
\count_clk_cycles[0]_i_5__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__0_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__0_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[0]_i_3__0\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__0_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__0_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__0_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__0_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__0_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__0_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__0_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__0_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__0_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__0_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[12]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__0_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__0_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__0_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__0_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__0_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__0_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__0_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__0_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__0_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[16]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__0_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__0_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__0_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__0_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__0_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__0_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__0_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__0_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__0_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__0_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[20]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__0_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__0_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__0_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__0_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__0_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__0_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__0_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__0_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__0_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[24]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__0_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__0_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__0_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__0_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__0_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__0_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[4]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__0_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__0_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__0_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__0_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__0_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__0_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__0_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__0_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__0_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__0_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_clk_cycles_reg[8]_i_1__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__0_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__0_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__0_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__0_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__0_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__0_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__0_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__0_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__0_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__0_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__0_n_0\
    );
\count_seconds[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__0\(0)
    );
\count_seconds[1]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__0\(1)
    );
\count_seconds[2]_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__0\(2)
    );
\count_seconds[3]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__0\(3)
    );
\count_seconds[4]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__0_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__0_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__0\(4)
    );
\count_seconds[4]_i_3__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__0_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__0\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__0\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__0\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__0\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__0\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__0_n_0\
    );
\counter_out_i_3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__5_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__0_n_0\,
      I4 => \counter_out_i_7__0_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_8
    );
\counter_out_i_5__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__5_n_0\
    );
\counter_out_i_6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__0_n_0\,
      I2 => \counter_out_i_9__0_n_0\,
      I3 => \counter_out_i_10__0_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__0_n_0\
    );
\counter_out_i_7__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__0_n_0\
    );
\counter_out_i_8__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__0_n_0\
    );
\counter_out_i_9__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__0_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_8 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_10 : out STD_LOGIC;
    \FSM_onehot_current_state_reg[2]\ : out STD_LOGIC_VECTOR ( 1 downto 0 );
    Q : in STD_LOGIC_VECTOR ( 2 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 );
    p_2_in : in STD_LOGIC_VECTOR ( 0 to 0 );
    \FSM_onehot_current_state_reg[1]\ : in STD_LOGIC_VECTOR ( 2 downto 0 );
    \FSM_onehot_current_state_reg[1]_0\ : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_8 : entity is "timer";
end design_1_liquid_0_1_timer_8;

architecture STRUCTURE of design_1_liquid_0_1_timer_8 is
  signal \^d\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \any_relays_enabled__6\ : STD_LOGIC;
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__1_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__1_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__1_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__1_n_0\ : STD_LOGIC;
  signal \p_0_in__1\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_current_state[0]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \FSM_onehot_current_state[1]_i_1\ : label is "soft_lutpair6";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__1\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__1\ : label is 11;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \counter_out_i_5__4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \started_i_2__4\ : label is "soft_lutpair5";
begin
  D(0) <= \^d\(0);
  started_reg_0 <= \^started_reg_0\;
\FSM_onehot_current_state[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4F44"
    )
        port map (
      I0 => p_2_in(0),
      I1 => Q(0),
      I2 => \any_relays_enabled__6\,
      I3 => Q(1),
      O => \FSM_onehot_current_state_reg[2]\(0)
    );
\FSM_onehot_current_state[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => Q(2),
      I1 => \any_relays_enabled__6\,
      I2 => Q(1),
      O => \FSM_onehot_current_state_reg[2]\(1)
    );
\FSM_onehot_current_state[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^d\(0),
      I1 => \FSM_onehot_current_state_reg[1]\(2),
      I2 => \FSM_onehot_current_state_reg[1]\(0),
      I3 => \FSM_onehot_current_state_reg[1]\(1),
      I4 => \FSM_onehot_current_state_reg[1]_0\,
      O => \any_relays_enabled__6\
    );
\count_clk_cycles[0]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__1_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles[0]_i_2__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__1_n_0\
    );
\count_clk_cycles[0]_i_4__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__1_n_0\,
      I2 => \counter_out_i_7__1_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__1_n_0\
    );
\count_clk_cycles[0]_i_5__1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__1_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__1_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[0]_i_3__1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__1_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__1_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__1_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__1_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__1_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__1_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__1_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__1_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__1_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__1_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[12]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__1_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__1_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__1_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__1_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__1_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__1_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__1_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__1_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[16]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__1_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__1_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__1_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__1_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__1_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__1_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__1_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__1_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__1_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[20]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__1_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__1_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__1_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__1_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__1_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__1_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__1_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__1_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[24]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__1_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__1_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__1_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__1_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__1_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[4]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__1_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__1_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__1_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__1_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__1_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__1_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__1_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__1_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__1_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_clk_cycles_reg[8]_i_1__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__1_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__1_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__1_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__1_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__1_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__1_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__1_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__1_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__1_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__1_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__1_n_0\
    );
\count_seconds[0]_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(2),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__1\(0)
    );
\count_seconds[1]_i_1__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__1\(1)
    );
\count_seconds[2]_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__1\(2)
    );
\count_seconds[3]_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__1\(3)
    );
\count_seconds[4]_i_1__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(2),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__1_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__1_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__1\(4)
    );
\count_seconds[4]_i_3__1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__1_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__1\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__1\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__1\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__1\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__1\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__1_n_0\
    );
\counter_out_i_3__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__4_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__1_n_0\,
      I4 => \counter_out_i_7__1_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_10
    );
\counter_out_i_5__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__4_n_0\
    );
\counter_out_i_6__1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__1_n_0\,
      I2 => \counter_out_i_9__1_n_0\,
      I3 => \counter_out_i_10__1_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__1_n_0\
    );
\counter_out_i_7__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__1_n_0\
    );
\counter_out_i_8__1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__1_n_0\
    );
\counter_out_i_9__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__1_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => \^d\(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(2),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_timer_9 is
  port (
    D : out STD_LOGIC_VECTOR ( 0 to 0 );
    started_reg_0 : out STD_LOGIC;
    counter_out0_out_12 : out STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 1 downto 0 );
    counter_out_reg_0 : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    \count_clk_cycles_reg[0]_0\ : in STD_LOGIC;
    started_reg_1 : in STD_LOGIC_VECTOR ( 0 to 0 );
    prev_was_load : in STD_LOGIC;
    \count_seconds_reg[4]_0\ : in STD_LOGIC_VECTOR ( 4 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_timer_9 : entity is "timer";
end design_1_liquid_0_1_timer_9;

architecture STRUCTURE of design_1_liquid_0_1_timer_9 is
  signal \count_clk_cycles0__2\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_2__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_4__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles[0]_i_5__2_n_0\ : STD_LOGIC;
  signal count_clk_cycles_reg : STD_LOGIC_VECTOR ( 25 downto 1 );
  signal \count_clk_cycles_reg[0]_i_3__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[0]_i_3__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[12]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[16]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[20]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[24]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[4]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_0\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_1\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_2\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_3\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_4\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_5\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_6\ : STD_LOGIC;
  signal \count_clk_cycles_reg[8]_i_1__2_n_7\ : STD_LOGIC;
  signal \count_clk_cycles_reg_n_0_[0]\ : STD_LOGIC;
  signal count_seconds : STD_LOGIC;
  signal \count_seconds[4]_i_3__2_n_0\ : STD_LOGIC;
  signal count_seconds_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \counter_out_i_10__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_5__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_6__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_7__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_8__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_9__2_n_0\ : STD_LOGIC;
  signal \p_0_in__2\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal started_i_1_n_0 : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \NLW_count_clk_cycles_reg[24]_i_1__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_count_clk_cycles_reg[24]_i_1__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[0]_i_3__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[12]_i_1__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[16]_i_1__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[20]_i_1__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[24]_i_1__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[4]_i_1__2\ : label is 11;
  attribute ADDER_THRESHOLD of \count_clk_cycles_reg[8]_i_1__2\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \count_seconds[2]_i_1__2\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \count_seconds[4]_i_3__2\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \counter_out_i_5__3\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \started_i_2__3\ : label is "soft_lutpair8";
begin
  started_reg_0 <= \^started_reg_0\;
\count_clk_cycles[0]_i_1__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFAEAA"
    )
        port map (
      I0 => Q(0),
      I1 => \^started_reg_0\,
      I2 => \count_clk_cycles[0]_i_4__2_n_0\,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles_reg[0]_0\,
      O => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles[0]_i_2__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => \^started_reg_0\,
      I1 => count_seconds_reg(4),
      I2 => count_seconds_reg(3),
      I3 => count_seconds_reg(1),
      I4 => count_seconds_reg(0),
      I5 => count_seconds_reg(2),
      O => \count_clk_cycles[0]_i_2__2_n_0\
    );
\count_clk_cycles[0]_i_4__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"45FF"
    )
        port map (
      I0 => count_clk_cycles_reg(24),
      I1 => \counter_out_i_6__2_n_0\,
      I2 => \counter_out_i_7__2_n_0\,
      I3 => count_clk_cycles_reg(25),
      O => \count_clk_cycles[0]_i_4__2_n_0\
    );
\count_clk_cycles[0]_i_5__2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \count_clk_cycles_reg_n_0_[0]\,
      O => \count_clk_cycles[0]_i_5__2_n_0\
    );
\count_clk_cycles_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__2_n_7\,
      Q => \count_clk_cycles_reg_n_0_[0]\,
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[0]_i_3__2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \count_clk_cycles_reg[0]_i_3__2_n_0\,
      CO(2) => \count_clk_cycles_reg[0]_i_3__2_n_1\,
      CO(1) => \count_clk_cycles_reg[0]_i_3__2_n_2\,
      CO(0) => \count_clk_cycles_reg[0]_i_3__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \count_clk_cycles_reg[0]_i_3__2_n_4\,
      O(2) => \count_clk_cycles_reg[0]_i_3__2_n_5\,
      O(1) => \count_clk_cycles_reg[0]_i_3__2_n_6\,
      O(0) => \count_clk_cycles_reg[0]_i_3__2_n_7\,
      S(3 downto 1) => count_clk_cycles_reg(3 downto 1),
      S(0) => \count_clk_cycles[0]_i_5__2_n_0\
    );
\count_clk_cycles_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__2_n_5\,
      Q => count_clk_cycles_reg(10),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__2_n_4\,
      Q => count_clk_cycles_reg(11),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(12),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[12]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[8]_i_1__2_n_0\,
      CO(3) => \count_clk_cycles_reg[12]_i_1__2_n_0\,
      CO(2) => \count_clk_cycles_reg[12]_i_1__2_n_1\,
      CO(1) => \count_clk_cycles_reg[12]_i_1__2_n_2\,
      CO(0) => \count_clk_cycles_reg[12]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[12]_i_1__2_n_4\,
      O(2) => \count_clk_cycles_reg[12]_i_1__2_n_5\,
      O(1) => \count_clk_cycles_reg[12]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[12]_i_1__2_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(15 downto 12)
    );
\count_clk_cycles_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(13),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__2_n_5\,
      Q => count_clk_cycles_reg(14),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[12]_i_1__2_n_4\,
      Q => count_clk_cycles_reg(15),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(16),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[16]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[12]_i_1__2_n_0\,
      CO(3) => \count_clk_cycles_reg[16]_i_1__2_n_0\,
      CO(2) => \count_clk_cycles_reg[16]_i_1__2_n_1\,
      CO(1) => \count_clk_cycles_reg[16]_i_1__2_n_2\,
      CO(0) => \count_clk_cycles_reg[16]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[16]_i_1__2_n_4\,
      O(2) => \count_clk_cycles_reg[16]_i_1__2_n_5\,
      O(1) => \count_clk_cycles_reg[16]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[16]_i_1__2_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(19 downto 16)
    );
\count_clk_cycles_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(17),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__2_n_5\,
      Q => count_clk_cycles_reg(18),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[16]_i_1__2_n_4\,
      Q => count_clk_cycles_reg(19),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__2_n_6\,
      Q => count_clk_cycles_reg(1),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(20),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[20]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[16]_i_1__2_n_0\,
      CO(3) => \count_clk_cycles_reg[20]_i_1__2_n_0\,
      CO(2) => \count_clk_cycles_reg[20]_i_1__2_n_1\,
      CO(1) => \count_clk_cycles_reg[20]_i_1__2_n_2\,
      CO(0) => \count_clk_cycles_reg[20]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[20]_i_1__2_n_4\,
      O(2) => \count_clk_cycles_reg[20]_i_1__2_n_5\,
      O(1) => \count_clk_cycles_reg[20]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[20]_i_1__2_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(23 downto 20)
    );
\count_clk_cycles_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(21),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__2_n_5\,
      Q => count_clk_cycles_reg(22),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[20]_i_1__2_n_4\,
      Q => count_clk_cycles_reg(23),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(24),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[24]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[20]_i_1__2_n_0\,
      CO(3 downto 1) => \NLW_count_clk_cycles_reg[24]_i_1__2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \count_clk_cycles_reg[24]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_count_clk_cycles_reg[24]_i_1__2_O_UNCONNECTED\(3 downto 2),
      O(1) => \count_clk_cycles_reg[24]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[24]_i_1__2_n_7\,
      S(3 downto 2) => B"00",
      S(1 downto 0) => count_clk_cycles_reg(25 downto 24)
    );
\count_clk_cycles_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[24]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(25),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__2_n_5\,
      Q => count_clk_cycles_reg(2),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[0]_i_3__2_n_4\,
      Q => count_clk_cycles_reg(3),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(4),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[4]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[0]_i_3__2_n_0\,
      CO(3) => \count_clk_cycles_reg[4]_i_1__2_n_0\,
      CO(2) => \count_clk_cycles_reg[4]_i_1__2_n_1\,
      CO(1) => \count_clk_cycles_reg[4]_i_1__2_n_2\,
      CO(0) => \count_clk_cycles_reg[4]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[4]_i_1__2_n_4\,
      O(2) => \count_clk_cycles_reg[4]_i_1__2_n_5\,
      O(1) => \count_clk_cycles_reg[4]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[4]_i_1__2_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(7 downto 4)
    );
\count_clk_cycles_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(5),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__2_n_5\,
      Q => count_clk_cycles_reg(6),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[4]_i_1__2_n_4\,
      Q => count_clk_cycles_reg(7),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__2_n_7\,
      Q => count_clk_cycles_reg(8),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_clk_cycles_reg[8]_i_1__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \count_clk_cycles_reg[4]_i_1__2_n_0\,
      CO(3) => \count_clk_cycles_reg[8]_i_1__2_n_0\,
      CO(2) => \count_clk_cycles_reg[8]_i_1__2_n_1\,
      CO(1) => \count_clk_cycles_reg[8]_i_1__2_n_2\,
      CO(0) => \count_clk_cycles_reg[8]_i_1__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \count_clk_cycles_reg[8]_i_1__2_n_4\,
      O(2) => \count_clk_cycles_reg[8]_i_1__2_n_5\,
      O(1) => \count_clk_cycles_reg[8]_i_1__2_n_6\,
      O(0) => \count_clk_cycles_reg[8]_i_1__2_n_7\,
      S(3 downto 0) => count_clk_cycles_reg(11 downto 8)
    );
\count_clk_cycles_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \count_clk_cycles[0]_i_2__2_n_0\,
      D => \count_clk_cycles_reg[8]_i_1__2_n_6\,
      Q => count_clk_cycles_reg(9),
      R => \count_clk_cycles[0]_i_1__2_n_0\
    );
\count_seconds[0]_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00008000FFFFBFFF"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(0),
      I1 => prev_was_load,
      I2 => Q(1),
      I3 => started_reg_1(0),
      I4 => \^started_reg_0\,
      I5 => count_seconds_reg(0),
      O => \p_0_in__2\(0)
    );
\count_seconds[1]_i_1__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B88B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(1),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(0),
      I3 => count_seconds_reg(1),
      O => \p_0_in__2\(1)
    );
\count_seconds[2]_i_1__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBB8888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(2),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      O => \p_0_in__2\(2)
    );
\count_seconds[3]_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBBBB88888888B"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(3),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(0),
      I4 => count_seconds_reg(2),
      I5 => count_seconds_reg(3),
      O => \p_0_in__2\(3)
    );
\count_seconds[4]_i_1__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0080808080"
    )
        port map (
      I0 => started_reg_1(0),
      I1 => Q(1),
      I2 => prev_was_load,
      I3 => \count_clk_cycles0__2\,
      I4 => \count_clk_cycles[0]_i_4__2_n_0\,
      I5 => \^started_reg_0\,
      O => count_seconds
    );
\count_seconds[4]_i_2__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BB8B88"
    )
        port map (
      I0 => \count_seconds_reg[4]_0\(4),
      I1 => \count_clk_cycles_reg[0]_0\,
      I2 => count_seconds_reg(3),
      I3 => \count_seconds[4]_i_3__2_n_0\,
      I4 => count_seconds_reg(4),
      O => \p_0_in__2\(4)
    );
\count_seconds[4]_i_3__2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => count_seconds_reg(1),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(2),
      O => \count_seconds[4]_i_3__2_n_0\
    );
\count_seconds_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__2\(0),
      Q => count_seconds_reg(0),
      R => Q(0)
    );
\count_seconds_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__2\(1),
      Q => count_seconds_reg(1),
      R => Q(0)
    );
\count_seconds_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__2\(2),
      Q => count_seconds_reg(2),
      R => Q(0)
    );
\count_seconds_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__2\(3),
      Q => count_seconds_reg(3),
      R => Q(0)
    );
\count_seconds_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => count_seconds,
      D => \p_0_in__2\(4),
      Q => count_seconds_reg(4),
      R => Q(0)
    );
\counter_out_i_10__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => count_clk_cycles_reg(2),
      I1 => count_clk_cycles_reg(1),
      I2 => count_clk_cycles_reg(5),
      I3 => count_clk_cycles_reg(6),
      I4 => count_clk_cycles_reg(3),
      I5 => count_clk_cycles_reg(4),
      O => \counter_out_i_10__2_n_0\
    );
\counter_out_i_3__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A888A8AAAAAAAAA"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \counter_out_i_5__3_n_0\,
      I2 => count_clk_cycles_reg(24),
      I3 => \counter_out_i_6__2_n_0\,
      I4 => \counter_out_i_7__2_n_0\,
      I5 => count_clk_cycles_reg(25),
      O => counter_out0_out_12
    );
\counter_out_i_5__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFB"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \counter_out_i_5__3_n_0\
    );
\counter_out_i_6__2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000005555777F"
    )
        port map (
      I0 => count_clk_cycles_reg(17),
      I1 => \counter_out_i_8__2_n_0\,
      I2 => \counter_out_i_9__2_n_0\,
      I3 => \counter_out_i_10__2_n_0\,
      I4 => count_clk_cycles_reg(16),
      I5 => count_clk_cycles_reg(18),
      O => \counter_out_i_6__2_n_0\
    );
\counter_out_i_7__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => count_clk_cycles_reg(19),
      I1 => count_clk_cycles_reg(22),
      I2 => count_clk_cycles_reg(23),
      I3 => count_clk_cycles_reg(20),
      I4 => count_clk_cycles_reg(21),
      O => \counter_out_i_7__2_n_0\
    );
\counter_out_i_8__2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => count_clk_cycles_reg(13),
      I1 => count_clk_cycles_reg(12),
      I2 => count_clk_cycles_reg(15),
      I3 => count_clk_cycles_reg(14),
      O => \counter_out_i_8__2_n_0\
    );
\counter_out_i_9__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_clk_cycles_reg(7),
      I1 => count_clk_cycles_reg(10),
      I2 => count_clk_cycles_reg(11),
      I3 => count_clk_cycles_reg(8),
      I4 => count_clk_cycles_reg(9),
      O => \counter_out_i_9__2_n_0\
    );
counter_out_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => counter_out_reg_0,
      Q => D(0),
      R => Q(0)
    );
started_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8888888"
    )
        port map (
      I0 => \count_clk_cycles0__2\,
      I1 => \^started_reg_0\,
      I2 => started_reg_1(0),
      I3 => Q(1),
      I4 => prev_was_load,
      O => started_i_1_n_0
    );
\started_i_2__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => count_seconds_reg(2),
      I1 => count_seconds_reg(0),
      I2 => count_seconds_reg(1),
      I3 => count_seconds_reg(3),
      I4 => count_seconds_reg(4),
      O => \count_clk_cycles0__2\
    );
started_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => started_i_1_n_0,
      Q => \^started_reg_0\,
      R => Q(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_arthur is
  port (
    SR : out STD_LOGIC_VECTOR ( 0 to 0 );
    D : out STD_LOGIC_VECTOR ( 7 downto 0 );
    started_reg : out STD_LOGIC;
    prev_was_load_reg_0 : out STD_LOGIC;
    counter_out0_out : out STD_LOGIC;
    started_reg_0 : out STD_LOGIC;
    prev_was_load_reg_1 : out STD_LOGIC;
    counter_out0_out_8 : out STD_LOGIC;
    started_reg_1 : out STD_LOGIC;
    prev_was_load_reg_2 : out STD_LOGIC;
    counter_out0_out_10 : out STD_LOGIC;
    started_reg_2 : out STD_LOGIC;
    prev_was_load_reg_3 : out STD_LOGIC;
    counter_out0_out_12 : out STD_LOGIC;
    started_reg_3 : out STD_LOGIC;
    prev_was_load_reg_4 : out STD_LOGIC;
    counter_out0_out_14 : out STD_LOGIC;
    started_reg_4 : out STD_LOGIC;
    prev_was_load_reg_5 : out STD_LOGIC;
    counter_out0_out_16 : out STD_LOGIC;
    started_reg_5 : out STD_LOGIC;
    prev_was_load_reg_6 : out STD_LOGIC;
    counter_out0_out_18 : out STD_LOGIC;
    started_reg_6 : out STD_LOGIC;
    prev_was_load_reg_7 : out STD_LOGIC;
    counter_out0_out_20 : out STD_LOGIC;
    \state_reg[2]\ : out STD_LOGIC;
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[2]_1\ : out STD_LOGIC;
    \state_reg[2]_2\ : out STD_LOGIC;
    \state_reg[2]_3\ : out STD_LOGIC;
    \state_reg[2]_4\ : out STD_LOGIC;
    \state_reg[2]_5\ : out STD_LOGIC;
    \state_reg[2]_6\ : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    counter_out_reg : in STD_LOGIC;
    counter_out_reg_0 : in STD_LOGIC;
    counter_out_reg_1 : in STD_LOGIC;
    counter_out_reg_2 : in STD_LOGIC;
    counter_out_reg_3 : in STD_LOGIC;
    counter_out_reg_4 : in STD_LOGIC;
    counter_out_reg_5 : in STD_LOGIC;
    counter_out_reg_6 : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_1__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_2__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_3__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_4__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_5__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_6__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    \seconds_relay_7__8_carry__0_i_7_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 );
    s00_axi_aresetn : in STD_LOGIC;
    p_2_in : in STD_LOGIC_VECTOR ( 0 to 0 );
    \state_reg[7]\ : in STD_LOGIC_VECTOR ( 7 downto 0 );
    \liquid_division_reg_reg[8]_0\ : in STD_LOGIC_VECTOR ( 8 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_arthur : entity is "arthur";
end design_1_liquid_0_1_arthur;

architecture STRUCTURE of design_1_liquid_0_1_arthur is
  signal \^d\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \FSM_onehot_current_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_current_state_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_current_state_reg_n_0_[3]\ : STD_LOGIC;
  signal \^sr\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal liquid_division_reg : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal load_liquid_division : STD_LOGIC;
  signal p_0_in_0 : STD_LOGIC;
  signal prev_was_load : STD_LOGIC;
  signal \^prev_was_load_reg_0\ : STD_LOGIC;
  signal \^prev_was_load_reg_1\ : STD_LOGIC;
  signal \^prev_was_load_reg_2\ : STD_LOGIC;
  signal \^prev_was_load_reg_3\ : STD_LOGIC;
  signal \^prev_was_load_reg_4\ : STD_LOGIC;
  signal \^prev_was_load_reg_5\ : STD_LOGIC;
  signal \^prev_was_load_reg_6\ : STD_LOGIC;
  signal \^prev_was_load_reg_7\ : STD_LOGIC;
  signal reg_r0_n_0 : STD_LOGIC;
  signal reg_r0_n_1 : STD_LOGIC;
  signal reg_r0_n_11 : STD_LOGIC;
  signal reg_r0_n_12 : STD_LOGIC;
  signal reg_r0_n_13 : STD_LOGIC;
  signal reg_r0_n_14 : STD_LOGIC;
  signal reg_r0_n_15 : STD_LOGIC;
  signal reg_r0_n_16 : STD_LOGIC;
  signal reg_r0_n_17 : STD_LOGIC;
  signal reg_r0_n_18 : STD_LOGIC;
  signal reg_r0_n_19 : STD_LOGIC;
  signal reg_r0_n_2 : STD_LOGIC;
  signal reg_r0_n_20 : STD_LOGIC;
  signal reg_r0_n_21 : STD_LOGIC;
  signal reg_r0_n_22 : STD_LOGIC;
  signal reg_r0_n_3 : STD_LOGIC;
  signal reg_r0_n_5 : STD_LOGIC;
  signal reg_r0_n_6 : STD_LOGIC;
  signal reg_r0_n_7 : STD_LOGIC;
  signal reg_r0_n_8 : STD_LOGIC;
  signal reg_r0_n_9 : STD_LOGIC;
  signal reg_r1_n_0 : STD_LOGIC;
  signal reg_r1_n_1 : STD_LOGIC;
  signal reg_r1_n_11 : STD_LOGIC;
  signal reg_r1_n_12 : STD_LOGIC;
  signal reg_r1_n_13 : STD_LOGIC;
  signal reg_r1_n_14 : STD_LOGIC;
  signal reg_r1_n_15 : STD_LOGIC;
  signal reg_r1_n_16 : STD_LOGIC;
  signal reg_r1_n_17 : STD_LOGIC;
  signal reg_r1_n_18 : STD_LOGIC;
  signal reg_r1_n_19 : STD_LOGIC;
  signal reg_r1_n_2 : STD_LOGIC;
  signal reg_r1_n_20 : STD_LOGIC;
  signal reg_r1_n_21 : STD_LOGIC;
  signal reg_r1_n_22 : STD_LOGIC;
  signal reg_r1_n_3 : STD_LOGIC;
  signal reg_r1_n_5 : STD_LOGIC;
  signal reg_r1_n_6 : STD_LOGIC;
  signal reg_r1_n_7 : STD_LOGIC;
  signal reg_r1_n_8 : STD_LOGIC;
  signal reg_r1_n_9 : STD_LOGIC;
  signal reg_r2_n_0 : STD_LOGIC;
  signal reg_r2_n_1 : STD_LOGIC;
  signal reg_r2_n_11 : STD_LOGIC;
  signal reg_r2_n_12 : STD_LOGIC;
  signal reg_r2_n_13 : STD_LOGIC;
  signal reg_r2_n_14 : STD_LOGIC;
  signal reg_r2_n_15 : STD_LOGIC;
  signal reg_r2_n_16 : STD_LOGIC;
  signal reg_r2_n_17 : STD_LOGIC;
  signal reg_r2_n_18 : STD_LOGIC;
  signal reg_r2_n_19 : STD_LOGIC;
  signal reg_r2_n_2 : STD_LOGIC;
  signal reg_r2_n_20 : STD_LOGIC;
  signal reg_r2_n_21 : STD_LOGIC;
  signal reg_r2_n_22 : STD_LOGIC;
  signal reg_r2_n_3 : STD_LOGIC;
  signal reg_r2_n_5 : STD_LOGIC;
  signal reg_r2_n_6 : STD_LOGIC;
  signal reg_r2_n_7 : STD_LOGIC;
  signal reg_r2_n_8 : STD_LOGIC;
  signal reg_r2_n_9 : STD_LOGIC;
  signal reg_r3_n_0 : STD_LOGIC;
  signal reg_r3_n_1 : STD_LOGIC;
  signal reg_r3_n_11 : STD_LOGIC;
  signal reg_r3_n_12 : STD_LOGIC;
  signal reg_r3_n_13 : STD_LOGIC;
  signal reg_r3_n_14 : STD_LOGIC;
  signal reg_r3_n_15 : STD_LOGIC;
  signal reg_r3_n_16 : STD_LOGIC;
  signal reg_r3_n_17 : STD_LOGIC;
  signal reg_r3_n_18 : STD_LOGIC;
  signal reg_r3_n_19 : STD_LOGIC;
  signal reg_r3_n_2 : STD_LOGIC;
  signal reg_r3_n_20 : STD_LOGIC;
  signal reg_r3_n_21 : STD_LOGIC;
  signal reg_r3_n_22 : STD_LOGIC;
  signal reg_r3_n_3 : STD_LOGIC;
  signal reg_r3_n_5 : STD_LOGIC;
  signal reg_r3_n_6 : STD_LOGIC;
  signal reg_r3_n_7 : STD_LOGIC;
  signal reg_r3_n_8 : STD_LOGIC;
  signal reg_r3_n_9 : STD_LOGIC;
  signal reg_r4_n_0 : STD_LOGIC;
  signal reg_r4_n_1 : STD_LOGIC;
  signal reg_r4_n_11 : STD_LOGIC;
  signal reg_r4_n_12 : STD_LOGIC;
  signal reg_r4_n_13 : STD_LOGIC;
  signal reg_r4_n_14 : STD_LOGIC;
  signal reg_r4_n_15 : STD_LOGIC;
  signal reg_r4_n_16 : STD_LOGIC;
  signal reg_r4_n_17 : STD_LOGIC;
  signal reg_r4_n_18 : STD_LOGIC;
  signal reg_r4_n_19 : STD_LOGIC;
  signal reg_r4_n_2 : STD_LOGIC;
  signal reg_r4_n_20 : STD_LOGIC;
  signal reg_r4_n_21 : STD_LOGIC;
  signal reg_r4_n_22 : STD_LOGIC;
  signal reg_r4_n_3 : STD_LOGIC;
  signal reg_r4_n_5 : STD_LOGIC;
  signal reg_r4_n_6 : STD_LOGIC;
  signal reg_r4_n_7 : STD_LOGIC;
  signal reg_r4_n_8 : STD_LOGIC;
  signal reg_r4_n_9 : STD_LOGIC;
  signal reg_r5_n_0 : STD_LOGIC;
  signal reg_r5_n_1 : STD_LOGIC;
  signal reg_r5_n_11 : STD_LOGIC;
  signal reg_r5_n_12 : STD_LOGIC;
  signal reg_r5_n_13 : STD_LOGIC;
  signal reg_r5_n_14 : STD_LOGIC;
  signal reg_r5_n_15 : STD_LOGIC;
  signal reg_r5_n_16 : STD_LOGIC;
  signal reg_r5_n_17 : STD_LOGIC;
  signal reg_r5_n_18 : STD_LOGIC;
  signal reg_r5_n_19 : STD_LOGIC;
  signal reg_r5_n_2 : STD_LOGIC;
  signal reg_r5_n_20 : STD_LOGIC;
  signal reg_r5_n_21 : STD_LOGIC;
  signal reg_r5_n_22 : STD_LOGIC;
  signal reg_r5_n_3 : STD_LOGIC;
  signal reg_r5_n_5 : STD_LOGIC;
  signal reg_r5_n_6 : STD_LOGIC;
  signal reg_r5_n_7 : STD_LOGIC;
  signal reg_r5_n_8 : STD_LOGIC;
  signal reg_r5_n_9 : STD_LOGIC;
  signal reg_r6_n_0 : STD_LOGIC;
  signal reg_r6_n_1 : STD_LOGIC;
  signal reg_r6_n_11 : STD_LOGIC;
  signal reg_r6_n_12 : STD_LOGIC;
  signal reg_r6_n_13 : STD_LOGIC;
  signal reg_r6_n_14 : STD_LOGIC;
  signal reg_r6_n_15 : STD_LOGIC;
  signal reg_r6_n_16 : STD_LOGIC;
  signal reg_r6_n_17 : STD_LOGIC;
  signal reg_r6_n_18 : STD_LOGIC;
  signal reg_r6_n_19 : STD_LOGIC;
  signal reg_r6_n_2 : STD_LOGIC;
  signal reg_r6_n_20 : STD_LOGIC;
  signal reg_r6_n_21 : STD_LOGIC;
  signal reg_r6_n_22 : STD_LOGIC;
  signal reg_r6_n_3 : STD_LOGIC;
  signal reg_r6_n_5 : STD_LOGIC;
  signal reg_r6_n_6 : STD_LOGIC;
  signal reg_r6_n_7 : STD_LOGIC;
  signal reg_r6_n_8 : STD_LOGIC;
  signal reg_r6_n_9 : STD_LOGIC;
  signal reg_r7_n_0 : STD_LOGIC;
  signal reg_r7_n_1 : STD_LOGIC;
  signal reg_r7_n_11 : STD_LOGIC;
  signal reg_r7_n_12 : STD_LOGIC;
  signal reg_r7_n_13 : STD_LOGIC;
  signal reg_r7_n_14 : STD_LOGIC;
  signal reg_r7_n_15 : STD_LOGIC;
  signal reg_r7_n_16 : STD_LOGIC;
  signal reg_r7_n_17 : STD_LOGIC;
  signal reg_r7_n_18 : STD_LOGIC;
  signal reg_r7_n_19 : STD_LOGIC;
  signal reg_r7_n_2 : STD_LOGIC;
  signal reg_r7_n_20 : STD_LOGIC;
  signal reg_r7_n_21 : STD_LOGIC;
  signal reg_r7_n_22 : STD_LOGIC;
  signal reg_r7_n_3 : STD_LOGIC;
  signal reg_r7_n_5 : STD_LOGIC;
  signal reg_r7_n_6 : STD_LOGIC;
  signal reg_r7_n_7 : STD_LOGIC;
  signal reg_r7_n_8 : STD_LOGIC;
  signal reg_r7_n_9 : STD_LOGIC;
  signal relay_register_out : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal seconds_relay_0 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_0__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_0__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_1 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_1__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_1__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_2 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_2__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_2__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_3 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_3__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_3__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_4 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_4__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_4__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_5 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_5__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_5__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_6 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_6__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_6__8_carry_n_7\ : STD_LOGIC;
  signal seconds_relay_7 : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \seconds_relay_7__274_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__274_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_i_9_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_4\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_5\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_6\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__0_n_7\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__1_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__1_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry__1_n_7\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_2_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_3_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_4_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_5_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_6_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_7_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_i_8_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_0\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_1\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_2\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_3\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_4\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_5\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_6\ : STD_LOGIC;
  signal \seconds_relay_7__8_carry_n_7\ : STD_LOGIC;
  signal \^started_reg\ : STD_LOGIC;
  signal \^started_reg_0\ : STD_LOGIC;
  signal \^started_reg_1\ : STD_LOGIC;
  signal \^started_reg_2\ : STD_LOGIC;
  signal \^started_reg_3\ : STD_LOGIC;
  signal \^started_reg_4\ : STD_LOGIC;
  signal \^started_reg_5\ : STD_LOGIC;
  signal \^started_reg_6\ : STD_LOGIC;
  signal timer_2_n_3 : STD_LOGIC;
  signal timer_2_n_4 : STD_LOGIC;
  signal timer_5_n_3 : STD_LOGIC;
  signal \NLW_seconds_relay_0__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_0__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_0__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_0__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_0__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_0__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_1__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_1__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_1__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_1__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_1__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_1__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_2__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_2__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_2__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_2__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_2__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_2__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_3__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_3__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_3__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_3__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_3__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_3__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_4__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_4__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_4__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_4__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_4__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_4__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_5__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_5__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_5__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_5__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_5__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_5__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_6__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_6__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_6__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_6__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_6__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_6__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_seconds_relay_7__274_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_7__274_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_7__274_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_7__274_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_seconds_relay_7__8_carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_seconds_relay_7__8_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_current_state_reg[0]\ : label is "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010";
  attribute FSM_ENCODED_STATES of \FSM_onehot_current_state_reg[1]\ : label is "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010";
  attribute FSM_ENCODED_STATES of \FSM_onehot_current_state_reg[2]\ : label is "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010";
  attribute FSM_ENCODED_STATES of \FSM_onehot_current_state_reg[3]\ : label is "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010";
begin
  D(7 downto 0) <= \^d\(7 downto 0);
  SR(0) <= \^sr\(0);
  prev_was_load_reg_0 <= \^prev_was_load_reg_0\;
  prev_was_load_reg_1 <= \^prev_was_load_reg_1\;
  prev_was_load_reg_2 <= \^prev_was_load_reg_2\;
  prev_was_load_reg_3 <= \^prev_was_load_reg_3\;
  prev_was_load_reg_4 <= \^prev_was_load_reg_4\;
  prev_was_load_reg_5 <= \^prev_was_load_reg_5\;
  prev_was_load_reg_6 <= \^prev_was_load_reg_6\;
  prev_was_load_reg_7 <= \^prev_was_load_reg_7\;
  started_reg <= \^started_reg\;
  started_reg_0 <= \^started_reg_0\;
  started_reg_1 <= \^started_reg_1\;
  started_reg_2 <= \^started_reg_2\;
  started_reg_3 <= \^started_reg_3\;
  started_reg_4 <= \^started_reg_4\;
  started_reg_5 <= \^started_reg_5\;
  started_reg_6 <= \^started_reg_6\;
\FSM_onehot_current_state[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => load_liquid_division,
      I1 => p_2_in(0),
      O => \FSM_onehot_current_state[3]_i_1_n_0\
    );
\FSM_onehot_current_state_reg[0]\: unisim.vcomponents.FDPE
    generic map(
      INIT => '1'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => timer_2_n_4,
      PRE => \^sr\(0),
      Q => load_liquid_division
    );
\FSM_onehot_current_state_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      CLR => \^sr\(0),
      D => timer_2_n_3,
      Q => \FSM_onehot_current_state_reg_n_0_[1]\
    );
\FSM_onehot_current_state_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      CLR => \^sr\(0),
      D => \FSM_onehot_current_state_reg_n_0_[3]\,
      Q => p_0_in_0
    );
\FSM_onehot_current_state_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      CLR => \^sr\(0),
      D => \FSM_onehot_current_state[3]_i_1_n_0\,
      Q => \FSM_onehot_current_state_reg_n_0_[3]\
    );
axi_awready_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s00_axi_aresetn,
      O => \^sr\(0)
    );
\liquid_division_reg_reg[0]\: unisim.vcomponents.FDPE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      D => \liquid_division_reg_reg[8]_0\(0),
      PRE => \^sr\(0),
      Q => liquid_division_reg(0)
    );
\liquid_division_reg_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(1),
      Q => liquid_division_reg(1)
    );
\liquid_division_reg_reg[2]\: unisim.vcomponents.FDPE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      D => \liquid_division_reg_reg[8]_0\(2),
      PRE => \^sr\(0),
      Q => liquid_division_reg(2)
    );
\liquid_division_reg_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(3),
      Q => liquid_division_reg(3)
    );
\liquid_division_reg_reg[4]\: unisim.vcomponents.FDPE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      D => \liquid_division_reg_reg[8]_0\(4),
      PRE => \^sr\(0),
      Q => liquid_division_reg(4)
    );
\liquid_division_reg_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(5),
      Q => liquid_division_reg(5)
    );
\liquid_division_reg_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(6),
      Q => liquid_division_reg(6)
    );
\liquid_division_reg_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(7),
      Q => liquid_division_reg(7)
    );
\liquid_division_reg_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => load_liquid_division,
      CLR => \^sr\(0),
      D => \liquid_division_reg_reg[8]_0\(8),
      Q => liquid_division_reg(8)
    );
prev_was_load_reg: unisim.vcomponents.FDCE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      CLR => \^sr\(0),
      D => \FSM_onehot_current_state_reg_n_0_[3]\,
      Q => prev_was_load
    );
reg_r0: entity work.\design_1_liquid_0_1_register__parameterized0\
     port map (
      CO(0) => \seconds_relay_0__8_carry__1_n_2\,
      D(0) => seconds_relay_0(0),
      DI(1) => reg_r0_n_2,
      DI(0) => reg_r0_n_3,
      O(3) => \seconds_relay_0__8_carry_n_4\,
      O(2) => \seconds_relay_0__8_carry_n_5\,
      O(1) => \seconds_relay_0__8_carry_n_6\,
      O(0) => \seconds_relay_0__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r0_n_19,
      S(0) => reg_r0_n_20,
      \liquid_division_reg_reg[3]\ => reg_r0_n_1,
      \liquid_division_reg_reg[7]\ => reg_r0_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_0(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r0_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_0__8_carry__0_i_6\(6) => Q(8),
      \seconds_relay_0__8_carry__0_i_6\(5 downto 0) => Q(6 downto 1),
      \slv_reg2_reg[1]\(2) => reg_r0_n_11,
      \slv_reg2_reg[1]\(1) => reg_r0_n_12,
      \slv_reg2_reg[1]\(0) => reg_r0_n_13,
      \slv_reg2_reg[1]_0\(3) => reg_r0_n_14,
      \slv_reg2_reg[1]_0\(2) => reg_r0_n_15,
      \slv_reg2_reg[1]_0\(1) => reg_r0_n_16,
      \slv_reg2_reg[1]_0\(0) => reg_r0_n_17,
      \state_reg[1]_i_1_0\(1) => reg_r0_n_21,
      \state_reg[1]_i_1_0\(0) => reg_r0_n_22,
      \state_reg[2]_0\ => \state_reg[2]\,
      \state_reg[4]_0\(4) => reg_r0_n_5,
      \state_reg[4]_0\(3) => reg_r0_n_6,
      \state_reg[4]_0\(2) => reg_r0_n_7,
      \state_reg[4]_0\(1) => reg_r0_n_8,
      \state_reg[4]_0\(0) => reg_r0_n_9,
      \state_reg[4]_1\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[4]_1\(0) => load_liquid_division,
      \state_reg[4]_i_14_0\(3) => \seconds_relay_0__8_carry__0_n_4\,
      \state_reg[4]_i_14_0\(2) => \seconds_relay_0__8_carry__0_n_5\,
      \state_reg[4]_i_14_0\(1) => \seconds_relay_0__8_carry__0_n_6\,
      \state_reg[4]_i_14_0\(0) => \seconds_relay_0__8_carry__0_n_7\,
      \state_reg[4]_i_14_1\(0) => \seconds_relay_0__8_carry__1_n_7\
    );
reg_r1: entity work.\design_1_liquid_0_1_register__parameterized0_0\
     port map (
      CO(0) => \seconds_relay_1__8_carry__1_n_2\,
      D(0) => seconds_relay_1(0),
      DI(1) => reg_r1_n_2,
      DI(0) => reg_r1_n_3,
      O(3) => \seconds_relay_1__8_carry_n_4\,
      O(2) => \seconds_relay_1__8_carry_n_5\,
      O(1) => \seconds_relay_1__8_carry_n_6\,
      O(0) => \seconds_relay_1__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r1_n_19,
      S(0) => reg_r1_n_20,
      \liquid_division_reg_reg[3]\ => reg_r1_n_1,
      \liquid_division_reg_reg[7]\ => reg_r1_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_1(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r1_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_1__8_carry__0_i_6\(6) => \seconds_relay_1__8_carry__0_i_7_0\(8),
      \seconds_relay_1__8_carry__0_i_6\(5 downto 0) => \seconds_relay_1__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg3_reg[1]\(2) => reg_r1_n_11,
      \slv_reg3_reg[1]\(1) => reg_r1_n_12,
      \slv_reg3_reg[1]\(0) => reg_r1_n_13,
      \slv_reg3_reg[1]_0\(3) => reg_r1_n_14,
      \slv_reg3_reg[1]_0\(2) => reg_r1_n_15,
      \slv_reg3_reg[1]_0\(1) => reg_r1_n_16,
      \slv_reg3_reg[1]_0\(0) => reg_r1_n_17,
      \state_reg[0]_0\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[0]_0\(0) => load_liquid_division,
      \state_reg[1]_i_1__0_0\(1) => reg_r1_n_21,
      \state_reg[1]_i_1__0_0\(0) => reg_r1_n_22,
      \state_reg[2]_0\ => \state_reg[2]_0\,
      \state_reg[4]_0\(4) => reg_r1_n_5,
      \state_reg[4]_0\(3) => reg_r1_n_6,
      \state_reg[4]_0\(2) => reg_r1_n_7,
      \state_reg[4]_0\(1) => reg_r1_n_8,
      \state_reg[4]_0\(0) => reg_r1_n_9,
      \state_reg[4]_i_14__0_0\(3) => \seconds_relay_1__8_carry__0_n_4\,
      \state_reg[4]_i_14__0_0\(2) => \seconds_relay_1__8_carry__0_n_5\,
      \state_reg[4]_i_14__0_0\(1) => \seconds_relay_1__8_carry__0_n_6\,
      \state_reg[4]_i_14__0_0\(0) => \seconds_relay_1__8_carry__0_n_7\,
      \state_reg[4]_i_14__0_1\(0) => \seconds_relay_1__8_carry__1_n_7\
    );
reg_r2: entity work.\design_1_liquid_0_1_register__parameterized0_1\
     port map (
      CO(0) => \seconds_relay_2__8_carry__1_n_2\,
      D(0) => seconds_relay_2(0),
      DI(1) => reg_r2_n_2,
      DI(0) => reg_r2_n_3,
      O(3) => \seconds_relay_2__8_carry_n_4\,
      O(2) => \seconds_relay_2__8_carry_n_5\,
      O(1) => \seconds_relay_2__8_carry_n_6\,
      O(0) => \seconds_relay_2__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r2_n_19,
      S(0) => reg_r2_n_20,
      \liquid_division_reg_reg[3]\ => reg_r2_n_1,
      \liquid_division_reg_reg[7]\ => reg_r2_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_2(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r2_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_2__8_carry__0_i_6\(6) => \seconds_relay_2__8_carry__0_i_7_0\(8),
      \seconds_relay_2__8_carry__0_i_6\(5 downto 0) => \seconds_relay_2__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg4_reg[1]\(2) => reg_r2_n_11,
      \slv_reg4_reg[1]\(1) => reg_r2_n_12,
      \slv_reg4_reg[1]\(0) => reg_r2_n_13,
      \slv_reg4_reg[1]_0\(3) => reg_r2_n_14,
      \slv_reg4_reg[1]_0\(2) => reg_r2_n_15,
      \slv_reg4_reg[1]_0\(1) => reg_r2_n_16,
      \slv_reg4_reg[1]_0\(0) => reg_r2_n_17,
      \state_reg[1]_i_1__1_0\(1) => reg_r2_n_21,
      \state_reg[1]_i_1__1_0\(0) => reg_r2_n_22,
      \state_reg[2]_0\ => \state_reg[2]_1\,
      \state_reg[4]_0\(4) => reg_r2_n_5,
      \state_reg[4]_0\(3) => reg_r2_n_6,
      \state_reg[4]_0\(2) => reg_r2_n_7,
      \state_reg[4]_0\(1) => reg_r2_n_8,
      \state_reg[4]_0\(0) => reg_r2_n_9,
      \state_reg[4]_1\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[4]_1\(0) => load_liquid_division,
      \state_reg[4]_i_14__1_0\(3) => \seconds_relay_2__8_carry__0_n_4\,
      \state_reg[4]_i_14__1_0\(2) => \seconds_relay_2__8_carry__0_n_5\,
      \state_reg[4]_i_14__1_0\(1) => \seconds_relay_2__8_carry__0_n_6\,
      \state_reg[4]_i_14__1_0\(0) => \seconds_relay_2__8_carry__0_n_7\,
      \state_reg[4]_i_14__1_1\(0) => \seconds_relay_2__8_carry__1_n_7\
    );
reg_r3: entity work.\design_1_liquid_0_1_register__parameterized0_2\
     port map (
      CO(0) => \seconds_relay_3__8_carry__1_n_2\,
      D(0) => seconds_relay_3(0),
      DI(1) => reg_r3_n_2,
      DI(0) => reg_r3_n_3,
      O(3) => \seconds_relay_3__8_carry_n_4\,
      O(2) => \seconds_relay_3__8_carry_n_5\,
      O(1) => \seconds_relay_3__8_carry_n_6\,
      O(0) => \seconds_relay_3__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r3_n_19,
      S(0) => reg_r3_n_20,
      \liquid_division_reg_reg[3]\ => reg_r3_n_1,
      \liquid_division_reg_reg[7]\ => reg_r3_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_3(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r3_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_3__8_carry__0_i_6\(6) => \seconds_relay_3__8_carry__0_i_7_0\(8),
      \seconds_relay_3__8_carry__0_i_6\(5 downto 0) => \seconds_relay_3__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg5_reg[1]\(2) => reg_r3_n_11,
      \slv_reg5_reg[1]\(1) => reg_r3_n_12,
      \slv_reg5_reg[1]\(0) => reg_r3_n_13,
      \slv_reg5_reg[1]_0\(3) => reg_r3_n_14,
      \slv_reg5_reg[1]_0\(2) => reg_r3_n_15,
      \slv_reg5_reg[1]_0\(1) => reg_r3_n_16,
      \slv_reg5_reg[1]_0\(0) => reg_r3_n_17,
      \state_reg[0]_0\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[0]_0\(0) => load_liquid_division,
      \state_reg[1]_i_1__2_0\(1) => reg_r3_n_21,
      \state_reg[1]_i_1__2_0\(0) => reg_r3_n_22,
      \state_reg[2]_0\ => \state_reg[2]_2\,
      \state_reg[4]_0\(4) => reg_r3_n_5,
      \state_reg[4]_0\(3) => reg_r3_n_6,
      \state_reg[4]_0\(2) => reg_r3_n_7,
      \state_reg[4]_0\(1) => reg_r3_n_8,
      \state_reg[4]_0\(0) => reg_r3_n_9,
      \state_reg[4]_i_14__2_0\(3) => \seconds_relay_3__8_carry__0_n_4\,
      \state_reg[4]_i_14__2_0\(2) => \seconds_relay_3__8_carry__0_n_5\,
      \state_reg[4]_i_14__2_0\(1) => \seconds_relay_3__8_carry__0_n_6\,
      \state_reg[4]_i_14__2_0\(0) => \seconds_relay_3__8_carry__0_n_7\,
      \state_reg[4]_i_14__2_1\(0) => \seconds_relay_3__8_carry__1_n_7\
    );
reg_r4: entity work.\design_1_liquid_0_1_register__parameterized0_3\
     port map (
      CO(0) => \seconds_relay_4__8_carry__1_n_2\,
      D(0) => seconds_relay_4(0),
      DI(1) => reg_r4_n_2,
      DI(0) => reg_r4_n_3,
      O(3) => \seconds_relay_4__8_carry_n_4\,
      O(2) => \seconds_relay_4__8_carry_n_5\,
      O(1) => \seconds_relay_4__8_carry_n_6\,
      O(0) => \seconds_relay_4__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r4_n_19,
      S(0) => reg_r4_n_20,
      \liquid_division_reg_reg[3]\ => reg_r4_n_1,
      \liquid_division_reg_reg[7]\ => reg_r4_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_4(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r4_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_4__8_carry__0_i_6\(6) => \seconds_relay_4__8_carry__0_i_7_0\(8),
      \seconds_relay_4__8_carry__0_i_6\(5 downto 0) => \seconds_relay_4__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg6_reg[1]\(2) => reg_r4_n_11,
      \slv_reg6_reg[1]\(1) => reg_r4_n_12,
      \slv_reg6_reg[1]\(0) => reg_r4_n_13,
      \slv_reg6_reg[1]_0\(3) => reg_r4_n_14,
      \slv_reg6_reg[1]_0\(2) => reg_r4_n_15,
      \slv_reg6_reg[1]_0\(1) => reg_r4_n_16,
      \slv_reg6_reg[1]_0\(0) => reg_r4_n_17,
      \state_reg[1]_i_1__3_0\(1) => reg_r4_n_21,
      \state_reg[1]_i_1__3_0\(0) => reg_r4_n_22,
      \state_reg[2]_0\ => \state_reg[2]_3\,
      \state_reg[4]_0\(4) => reg_r4_n_5,
      \state_reg[4]_0\(3) => reg_r4_n_6,
      \state_reg[4]_0\(2) => reg_r4_n_7,
      \state_reg[4]_0\(1) => reg_r4_n_8,
      \state_reg[4]_0\(0) => reg_r4_n_9,
      \state_reg[4]_1\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[4]_1\(0) => load_liquid_division,
      \state_reg[4]_i_14__3_0\(3) => \seconds_relay_4__8_carry__0_n_4\,
      \state_reg[4]_i_14__3_0\(2) => \seconds_relay_4__8_carry__0_n_5\,
      \state_reg[4]_i_14__3_0\(1) => \seconds_relay_4__8_carry__0_n_6\,
      \state_reg[4]_i_14__3_0\(0) => \seconds_relay_4__8_carry__0_n_7\,
      \state_reg[4]_i_14__3_1\(0) => \seconds_relay_4__8_carry__1_n_7\
    );
reg_r5: entity work.\design_1_liquid_0_1_register__parameterized0_4\
     port map (
      CO(0) => \seconds_relay_5__8_carry__1_n_2\,
      D(0) => seconds_relay_5(0),
      DI(1) => reg_r5_n_2,
      DI(0) => reg_r5_n_3,
      O(3) => \seconds_relay_5__8_carry_n_4\,
      O(2) => \seconds_relay_5__8_carry_n_5\,
      O(1) => \seconds_relay_5__8_carry_n_6\,
      O(0) => \seconds_relay_5__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r5_n_19,
      S(0) => reg_r5_n_20,
      \liquid_division_reg_reg[3]\ => reg_r5_n_1,
      \liquid_division_reg_reg[7]\ => reg_r5_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_5(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r5_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_5__8_carry__0_i_6\(6) => \seconds_relay_5__8_carry__0_i_7_0\(8),
      \seconds_relay_5__8_carry__0_i_6\(5 downto 0) => \seconds_relay_5__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg7_reg[1]\(2) => reg_r5_n_11,
      \slv_reg7_reg[1]\(1) => reg_r5_n_12,
      \slv_reg7_reg[1]\(0) => reg_r5_n_13,
      \slv_reg7_reg[1]_0\(3) => reg_r5_n_14,
      \slv_reg7_reg[1]_0\(2) => reg_r5_n_15,
      \slv_reg7_reg[1]_0\(1) => reg_r5_n_16,
      \slv_reg7_reg[1]_0\(0) => reg_r5_n_17,
      \state_reg[0]_0\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[0]_0\(0) => load_liquid_division,
      \state_reg[1]_i_1__4_0\(1) => reg_r5_n_21,
      \state_reg[1]_i_1__4_0\(0) => reg_r5_n_22,
      \state_reg[2]_0\ => \state_reg[2]_4\,
      \state_reg[4]_0\(4) => reg_r5_n_5,
      \state_reg[4]_0\(3) => reg_r5_n_6,
      \state_reg[4]_0\(2) => reg_r5_n_7,
      \state_reg[4]_0\(1) => reg_r5_n_8,
      \state_reg[4]_0\(0) => reg_r5_n_9,
      \state_reg[4]_i_14__4_0\(3) => \seconds_relay_5__8_carry__0_n_4\,
      \state_reg[4]_i_14__4_0\(2) => \seconds_relay_5__8_carry__0_n_5\,
      \state_reg[4]_i_14__4_0\(1) => \seconds_relay_5__8_carry__0_n_6\,
      \state_reg[4]_i_14__4_0\(0) => \seconds_relay_5__8_carry__0_n_7\,
      \state_reg[4]_i_14__4_1\(0) => \seconds_relay_5__8_carry__1_n_7\
    );
reg_r6: entity work.\design_1_liquid_0_1_register__parameterized0_5\
     port map (
      CO(0) => \seconds_relay_6__8_carry__1_n_2\,
      D(0) => seconds_relay_6(0),
      DI(1) => reg_r6_n_2,
      DI(0) => reg_r6_n_3,
      O(3) => \seconds_relay_6__8_carry_n_4\,
      O(2) => \seconds_relay_6__8_carry_n_5\,
      O(1) => \seconds_relay_6__8_carry_n_6\,
      O(0) => \seconds_relay_6__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r6_n_19,
      S(0) => reg_r6_n_20,
      \liquid_division_reg_reg[3]\ => reg_r6_n_1,
      \liquid_division_reg_reg[7]\ => reg_r6_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_6(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r6_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_6__8_carry__0_i_6\(6) => \seconds_relay_6__8_carry__0_i_7_0\(8),
      \seconds_relay_6__8_carry__0_i_6\(5 downto 0) => \seconds_relay_6__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg8_reg[1]\(2) => reg_r6_n_11,
      \slv_reg8_reg[1]\(1) => reg_r6_n_12,
      \slv_reg8_reg[1]\(0) => reg_r6_n_13,
      \slv_reg8_reg[1]_0\(3) => reg_r6_n_14,
      \slv_reg8_reg[1]_0\(2) => reg_r6_n_15,
      \slv_reg8_reg[1]_0\(1) => reg_r6_n_16,
      \slv_reg8_reg[1]_0\(0) => reg_r6_n_17,
      \state_reg[1]_i_1__5_0\(1) => reg_r6_n_21,
      \state_reg[1]_i_1__5_0\(0) => reg_r6_n_22,
      \state_reg[2]_0\ => \state_reg[2]_5\,
      \state_reg[4]_0\(4) => reg_r6_n_5,
      \state_reg[4]_0\(3) => reg_r6_n_6,
      \state_reg[4]_0\(2) => reg_r6_n_7,
      \state_reg[4]_0\(1) => reg_r6_n_8,
      \state_reg[4]_0\(0) => reg_r6_n_9,
      \state_reg[4]_1\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[4]_1\(0) => load_liquid_division,
      \state_reg[4]_i_14__5_0\(3) => \seconds_relay_6__8_carry__0_n_4\,
      \state_reg[4]_i_14__5_0\(2) => \seconds_relay_6__8_carry__0_n_5\,
      \state_reg[4]_i_14__5_0\(1) => \seconds_relay_6__8_carry__0_n_6\,
      \state_reg[4]_i_14__5_0\(0) => \seconds_relay_6__8_carry__0_n_7\,
      \state_reg[4]_i_14__5_1\(0) => \seconds_relay_6__8_carry__1_n_7\
    );
reg_r7: entity work.\design_1_liquid_0_1_register__parameterized0_6\
     port map (
      CO(0) => \seconds_relay_7__8_carry__1_n_2\,
      D(0) => seconds_relay_7(0),
      DI(1) => reg_r7_n_2,
      DI(0) => reg_r7_n_3,
      O(3) => \seconds_relay_7__8_carry_n_4\,
      O(2) => \seconds_relay_7__8_carry_n_5\,
      O(1) => \seconds_relay_7__8_carry_n_6\,
      O(0) => \seconds_relay_7__8_carry_n_7\,
      Q(8 downto 0) => liquid_division_reg(8 downto 0),
      S(1) => reg_r7_n_19,
      S(0) => reg_r7_n_20,
      \liquid_division_reg_reg[3]\ => reg_r7_n_1,
      \liquid_division_reg_reg[7]\ => reg_r7_n_0,
      \liquid_division_reg_reg[8]\(0) => seconds_relay_7(1),
      \liquid_division_reg_reg[8]_0\(0) => reg_r7_n_18,
      s00_axi_aclk => s00_axi_aclk,
      \seconds_relay_7__8_carry__0_i_6\(6) => \seconds_relay_7__8_carry__0_i_7_0\(8),
      \seconds_relay_7__8_carry__0_i_6\(5 downto 0) => \seconds_relay_7__8_carry__0_i_7_0\(6 downto 1),
      \slv_reg9_reg[1]\(2) => reg_r7_n_11,
      \slv_reg9_reg[1]\(1) => reg_r7_n_12,
      \slv_reg9_reg[1]\(0) => reg_r7_n_13,
      \slv_reg9_reg[1]_0\(3) => reg_r7_n_14,
      \slv_reg9_reg[1]_0\(2) => reg_r7_n_15,
      \slv_reg9_reg[1]_0\(1) => reg_r7_n_16,
      \slv_reg9_reg[1]_0\(0) => reg_r7_n_17,
      \state_reg[0]_0\(1) => \FSM_onehot_current_state_reg_n_0_[3]\,
      \state_reg[0]_0\(0) => load_liquid_division,
      \state_reg[1]_i_1__6_0\(1) => reg_r7_n_21,
      \state_reg[1]_i_1__6_0\(0) => reg_r7_n_22,
      \state_reg[2]_0\ => \state_reg[2]_6\,
      \state_reg[4]_0\(4) => reg_r7_n_5,
      \state_reg[4]_0\(3) => reg_r7_n_6,
      \state_reg[4]_0\(2) => reg_r7_n_7,
      \state_reg[4]_0\(1) => reg_r7_n_8,
      \state_reg[4]_0\(0) => reg_r7_n_9,
      \state_reg[4]_i_14__6_0\(3) => \seconds_relay_7__8_carry__0_n_4\,
      \state_reg[4]_i_14__6_0\(2) => \seconds_relay_7__8_carry__0_n_5\,
      \state_reg[4]_i_14__6_0\(1) => \seconds_relay_7__8_carry__0_n_6\,
      \state_reg[4]_i_14__6_0\(0) => \seconds_relay_7__8_carry__0_n_7\,
      \state_reg[4]_i_14__6_1\(0) => \seconds_relay_7__8_carry__1_n_7\
    );
relay_reg: entity work.design_1_liquid_0_1_register
     port map (
      Q(2) => \FSM_onehot_current_state_reg_n_0_[3]\,
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]\ => \^started_reg\,
      \count_clk_cycles_reg[0]_0\ => \^started_reg_0\,
      \count_clk_cycles_reg[0]_1\ => \^started_reg_1\,
      \count_clk_cycles_reg[0]_2\ => \^started_reg_2\,
      \count_clk_cycles_reg[0]_3\ => \^started_reg_3\,
      \count_clk_cycles_reg[0]_4\ => \^started_reg_4\,
      \count_clk_cycles_reg[0]_5\ => \^started_reg_5\,
      \count_clk_cycles_reg[0]_6\ => \^started_reg_6\,
      prev_was_load => prev_was_load,
      prev_was_load_reg => \^prev_was_load_reg_0\,
      prev_was_load_reg_0 => \^prev_was_load_reg_1\,
      prev_was_load_reg_1 => \^prev_was_load_reg_2\,
      prev_was_load_reg_2 => \^prev_was_load_reg_3\,
      prev_was_load_reg_3 => \^prev_was_load_reg_4\,
      prev_was_load_reg_4 => \^prev_was_load_reg_5\,
      prev_was_load_reg_5 => \^prev_was_load_reg_6\,
      prev_was_load_reg_6 => \^prev_was_load_reg_7\,
      s00_axi_aclk => s00_axi_aclk,
      \state_reg[7]_0\(7 downto 0) => relay_register_out(7 downto 0),
      \state_reg[7]_1\(7 downto 0) => \state_reg[7]\(7 downto 0)
    );
\seconds_relay_0__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_0__274_carry_n_0\,
      CO(2) => \seconds_relay_0__274_carry_n_1\,
      CO(1) => \seconds_relay_0__274_carry_n_2\,
      CO(0) => \seconds_relay_0__274_carry_n_3\,
      CYINIT => seconds_relay_0(1),
      DI(3) => reg_r0_n_11,
      DI(2) => reg_r0_n_12,
      DI(1) => reg_r0_n_13,
      DI(0) => Q(0),
      O(3 downto 0) => \NLW_seconds_relay_0__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_0__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_0__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_0__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_0__274_carry_i_5_n_0\
    );
\seconds_relay_0__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__274_carry_n_0\,
      CO(3) => \seconds_relay_0__274_carry__0_n_0\,
      CO(2) => \seconds_relay_0__274_carry__0_n_1\,
      CO(1) => \seconds_relay_0__274_carry__0_n_2\,
      CO(0) => \seconds_relay_0__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r0_n_14,
      DI(2) => reg_r0_n_15,
      DI(1) => reg_r0_n_16,
      DI(0) => reg_r0_n_17,
      O(3 downto 0) => \NLW_seconds_relay_0__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_0__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_0__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_0__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_0__274_carry__0_i_5_n_0\
    );
\seconds_relay_0__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r0_n_14,
      O => \seconds_relay_0__274_carry__0_i_2_n_0\
    );
\seconds_relay_0__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r0_n_15,
      O => \seconds_relay_0__274_carry__0_i_3_n_0\
    );
\seconds_relay_0__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r0_n_16,
      O => \seconds_relay_0__274_carry__0_i_4_n_0\
    );
\seconds_relay_0__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r0_n_17,
      O => \seconds_relay_0__274_carry__0_i_5_n_0\
    );
\seconds_relay_0__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_0__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_0(0),
      CO(0) => \seconds_relay_0__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_0(1),
      DI(0) => reg_r0_n_18,
      O(3 downto 0) => \NLW_seconds_relay_0__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r0_n_21,
      S(0) => reg_r0_n_22
    );
\seconds_relay_0__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r0_n_11,
      O => \seconds_relay_0__274_carry_i_2_n_0\
    );
\seconds_relay_0__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r0_n_12,
      O => \seconds_relay_0__274_carry_i_3_n_0\
    );
\seconds_relay_0__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r0_n_13,
      O => \seconds_relay_0__274_carry_i_4_n_0\
    );
\seconds_relay_0__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_0(1),
      I1 => liquid_division_reg(0),
      I2 => Q(0),
      O => \seconds_relay_0__274_carry_i_5_n_0\
    );
\seconds_relay_0__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_0__8_carry_n_0\,
      CO(2) => \seconds_relay_0__8_carry_n_1\,
      CO(1) => \seconds_relay_0__8_carry_n_2\,
      CO(0) => \seconds_relay_0__8_carry_n_3\,
      CYINIT => reg_r0_n_0,
      DI(3) => \seconds_relay_0__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_0__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_0__8_carry_i_4_n_0\,
      DI(0) => Q(7),
      O(3) => \seconds_relay_0__8_carry_n_4\,
      O(2) => \seconds_relay_0__8_carry_n_5\,
      O(1) => \seconds_relay_0__8_carry_n_6\,
      O(0) => \seconds_relay_0__8_carry_n_7\,
      S(3) => \seconds_relay_0__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_0__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_0__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_0__8_carry_i_8_n_0\
    );
\seconds_relay_0__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__8_carry_n_0\,
      CO(3) => \seconds_relay_0__8_carry__0_n_0\,
      CO(2) => \seconds_relay_0__8_carry__0_n_1\,
      CO(1) => \seconds_relay_0__8_carry__0_n_2\,
      CO(0) => \seconds_relay_0__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_0__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_0__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_0__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_0__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_0__8_carry__0_n_4\,
      O(2) => \seconds_relay_0__8_carry__0_n_5\,
      O(1) => \seconds_relay_0__8_carry__0_n_6\,
      O(0) => \seconds_relay_0__8_carry__0_n_7\,
      S(3) => \seconds_relay_0__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_0__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_0__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_0__8_carry__0_i_8_n_0\
    );
\seconds_relay_0__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry__0_i_1_n_0\
    );
\seconds_relay_0__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry__0_i_2_n_0\
    );
\seconds_relay_0__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry__0_i_3_n_0\
    );
\seconds_relay_0__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry__0_i_4_n_0\
    );
\seconds_relay_0__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r0_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_0__8_carry__0_i_5_n_0\
    );
\seconds_relay_0__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r0_n_1,
      O => \seconds_relay_0__8_carry__0_i_6_n_0\
    );
\seconds_relay_0__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_0__8_carry__0_i_9_n_0\,
      O => \seconds_relay_0__8_carry__0_i_7_n_0\
    );
\seconds_relay_0__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_0__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => Q(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_0__8_carry__0_i_8_n_0\
    );
\seconds_relay_0__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => Q(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_0__8_carry__0_i_9_n_0\
    );
\seconds_relay_0__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_0__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_0__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_0__8_carry__1_n_2\,
      CO(0) => \seconds_relay_0__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r0_n_2,
      DI(0) => reg_r0_n_3,
      O(3 downto 1) => \NLW_seconds_relay_0__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_0__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r0_n_19,
      S(0) => reg_r0_n_20
    );
\seconds_relay_0__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry_i_2_n_0\
    );
\seconds_relay_0__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry_i_3_n_0\
    );
\seconds_relay_0__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r0_n_0,
      O => \seconds_relay_0__8_carry_i_4_n_0\
    );
\seconds_relay_0__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r0_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => Q(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_0__8_carry_i_5_n_0\
    );
\seconds_relay_0__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r0_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => Q(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_0__8_carry_i_6_n_0\
    );
\seconds_relay_0__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r0_n_0,
      I1 => liquid_division_reg(1),
      I2 => Q(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_0__8_carry_i_7_n_0\
    );
\seconds_relay_0__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r0_n_0,
      I1 => liquid_division_reg(0),
      I2 => Q(7),
      O => \seconds_relay_0__8_carry_i_8_n_0\
    );
\seconds_relay_1__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_1__274_carry_n_0\,
      CO(2) => \seconds_relay_1__274_carry_n_1\,
      CO(1) => \seconds_relay_1__274_carry_n_2\,
      CO(0) => \seconds_relay_1__274_carry_n_3\,
      CYINIT => seconds_relay_1(1),
      DI(3) => reg_r1_n_11,
      DI(2) => reg_r1_n_12,
      DI(1) => reg_r1_n_13,
      DI(0) => \seconds_relay_1__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_1__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_1__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_1__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_1__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_1__274_carry_i_5_n_0\
    );
\seconds_relay_1__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__274_carry_n_0\,
      CO(3) => \seconds_relay_1__274_carry__0_n_0\,
      CO(2) => \seconds_relay_1__274_carry__0_n_1\,
      CO(1) => \seconds_relay_1__274_carry__0_n_2\,
      CO(0) => \seconds_relay_1__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r1_n_14,
      DI(2) => reg_r1_n_15,
      DI(1) => reg_r1_n_16,
      DI(0) => reg_r1_n_17,
      O(3 downto 0) => \NLW_seconds_relay_1__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_1__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_1__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_1__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_1__274_carry__0_i_5_n_0\
    );
\seconds_relay_1__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r1_n_14,
      O => \seconds_relay_1__274_carry__0_i_2_n_0\
    );
\seconds_relay_1__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r1_n_15,
      O => \seconds_relay_1__274_carry__0_i_3_n_0\
    );
\seconds_relay_1__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r1_n_16,
      O => \seconds_relay_1__274_carry__0_i_4_n_0\
    );
\seconds_relay_1__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r1_n_17,
      O => \seconds_relay_1__274_carry__0_i_5_n_0\
    );
\seconds_relay_1__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_1__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_1(0),
      CO(0) => \seconds_relay_1__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_1(1),
      DI(0) => reg_r1_n_18,
      O(3 downto 0) => \NLW_seconds_relay_1__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r1_n_21,
      S(0) => reg_r1_n_22
    );
\seconds_relay_1__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r1_n_11,
      O => \seconds_relay_1__274_carry_i_2_n_0\
    );
\seconds_relay_1__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r1_n_12,
      O => \seconds_relay_1__274_carry_i_3_n_0\
    );
\seconds_relay_1__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r1_n_13,
      O => \seconds_relay_1__274_carry_i_4_n_0\
    );
\seconds_relay_1__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_1(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_1__8_carry__0_i_7_0\(0),
      O => \seconds_relay_1__274_carry_i_5_n_0\
    );
\seconds_relay_1__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_1__8_carry_n_0\,
      CO(2) => \seconds_relay_1__8_carry_n_1\,
      CO(1) => \seconds_relay_1__8_carry_n_2\,
      CO(0) => \seconds_relay_1__8_carry_n_3\,
      CYINIT => reg_r1_n_0,
      DI(3) => \seconds_relay_1__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_1__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_1__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_1__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_1__8_carry_n_4\,
      O(2) => \seconds_relay_1__8_carry_n_5\,
      O(1) => \seconds_relay_1__8_carry_n_6\,
      O(0) => \seconds_relay_1__8_carry_n_7\,
      S(3) => \seconds_relay_1__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_1__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_1__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_1__8_carry_i_8_n_0\
    );
\seconds_relay_1__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__8_carry_n_0\,
      CO(3) => \seconds_relay_1__8_carry__0_n_0\,
      CO(2) => \seconds_relay_1__8_carry__0_n_1\,
      CO(1) => \seconds_relay_1__8_carry__0_n_2\,
      CO(0) => \seconds_relay_1__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_1__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_1__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_1__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_1__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_1__8_carry__0_n_4\,
      O(2) => \seconds_relay_1__8_carry__0_n_5\,
      O(1) => \seconds_relay_1__8_carry__0_n_6\,
      O(0) => \seconds_relay_1__8_carry__0_n_7\,
      S(3) => \seconds_relay_1__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_1__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_1__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_1__8_carry__0_i_8_n_0\
    );
\seconds_relay_1__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry__0_i_1_n_0\
    );
\seconds_relay_1__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry__0_i_2_n_0\
    );
\seconds_relay_1__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry__0_i_3_n_0\
    );
\seconds_relay_1__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry__0_i_4_n_0\
    );
\seconds_relay_1__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r1_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_1__8_carry__0_i_5_n_0\
    );
\seconds_relay_1__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r1_n_1,
      O => \seconds_relay_1__8_carry__0_i_6_n_0\
    );
\seconds_relay_1__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_1__8_carry__0_i_9_n_0\,
      O => \seconds_relay_1__8_carry__0_i_7_n_0\
    );
\seconds_relay_1__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_1__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_1__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_1__8_carry__0_i_8_n_0\
    );
\seconds_relay_1__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_1__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_1__8_carry__0_i_9_n_0\
    );
\seconds_relay_1__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_1__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_1__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_1__8_carry__1_n_2\,
      CO(0) => \seconds_relay_1__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r1_n_2,
      DI(0) => reg_r1_n_3,
      O(3 downto 1) => \NLW_seconds_relay_1__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_1__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r1_n_19,
      S(0) => reg_r1_n_20
    );
\seconds_relay_1__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry_i_2_n_0\
    );
\seconds_relay_1__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry_i_3_n_0\
    );
\seconds_relay_1__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r1_n_0,
      O => \seconds_relay_1__8_carry_i_4_n_0\
    );
\seconds_relay_1__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r1_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_1__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_1__8_carry_i_5_n_0\
    );
\seconds_relay_1__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r1_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_1__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_1__8_carry_i_6_n_0\
    );
\seconds_relay_1__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r1_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_1__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_1__8_carry_i_7_n_0\
    );
\seconds_relay_1__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r1_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_1__8_carry__0_i_7_0\(7),
      O => \seconds_relay_1__8_carry_i_8_n_0\
    );
\seconds_relay_2__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_2__274_carry_n_0\,
      CO(2) => \seconds_relay_2__274_carry_n_1\,
      CO(1) => \seconds_relay_2__274_carry_n_2\,
      CO(0) => \seconds_relay_2__274_carry_n_3\,
      CYINIT => seconds_relay_2(1),
      DI(3) => reg_r2_n_11,
      DI(2) => reg_r2_n_12,
      DI(1) => reg_r2_n_13,
      DI(0) => \seconds_relay_2__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_2__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_2__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_2__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_2__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_2__274_carry_i_5_n_0\
    );
\seconds_relay_2__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__274_carry_n_0\,
      CO(3) => \seconds_relay_2__274_carry__0_n_0\,
      CO(2) => \seconds_relay_2__274_carry__0_n_1\,
      CO(1) => \seconds_relay_2__274_carry__0_n_2\,
      CO(0) => \seconds_relay_2__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r2_n_14,
      DI(2) => reg_r2_n_15,
      DI(1) => reg_r2_n_16,
      DI(0) => reg_r2_n_17,
      O(3 downto 0) => \NLW_seconds_relay_2__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_2__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_2__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_2__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_2__274_carry__0_i_5_n_0\
    );
\seconds_relay_2__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r2_n_14,
      O => \seconds_relay_2__274_carry__0_i_2_n_0\
    );
\seconds_relay_2__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r2_n_15,
      O => \seconds_relay_2__274_carry__0_i_3_n_0\
    );
\seconds_relay_2__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r2_n_16,
      O => \seconds_relay_2__274_carry__0_i_4_n_0\
    );
\seconds_relay_2__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r2_n_17,
      O => \seconds_relay_2__274_carry__0_i_5_n_0\
    );
\seconds_relay_2__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_2__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_2(0),
      CO(0) => \seconds_relay_2__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_2(1),
      DI(0) => reg_r2_n_18,
      O(3 downto 0) => \NLW_seconds_relay_2__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r2_n_21,
      S(0) => reg_r2_n_22
    );
\seconds_relay_2__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r2_n_11,
      O => \seconds_relay_2__274_carry_i_2_n_0\
    );
\seconds_relay_2__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r2_n_12,
      O => \seconds_relay_2__274_carry_i_3_n_0\
    );
\seconds_relay_2__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r2_n_13,
      O => \seconds_relay_2__274_carry_i_4_n_0\
    );
\seconds_relay_2__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_2(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_2__8_carry__0_i_7_0\(0),
      O => \seconds_relay_2__274_carry_i_5_n_0\
    );
\seconds_relay_2__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_2__8_carry_n_0\,
      CO(2) => \seconds_relay_2__8_carry_n_1\,
      CO(1) => \seconds_relay_2__8_carry_n_2\,
      CO(0) => \seconds_relay_2__8_carry_n_3\,
      CYINIT => reg_r2_n_0,
      DI(3) => \seconds_relay_2__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_2__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_2__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_2__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_2__8_carry_n_4\,
      O(2) => \seconds_relay_2__8_carry_n_5\,
      O(1) => \seconds_relay_2__8_carry_n_6\,
      O(0) => \seconds_relay_2__8_carry_n_7\,
      S(3) => \seconds_relay_2__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_2__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_2__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_2__8_carry_i_8_n_0\
    );
\seconds_relay_2__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__8_carry_n_0\,
      CO(3) => \seconds_relay_2__8_carry__0_n_0\,
      CO(2) => \seconds_relay_2__8_carry__0_n_1\,
      CO(1) => \seconds_relay_2__8_carry__0_n_2\,
      CO(0) => \seconds_relay_2__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_2__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_2__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_2__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_2__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_2__8_carry__0_n_4\,
      O(2) => \seconds_relay_2__8_carry__0_n_5\,
      O(1) => \seconds_relay_2__8_carry__0_n_6\,
      O(0) => \seconds_relay_2__8_carry__0_n_7\,
      S(3) => \seconds_relay_2__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_2__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_2__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_2__8_carry__0_i_8_n_0\
    );
\seconds_relay_2__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry__0_i_1_n_0\
    );
\seconds_relay_2__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry__0_i_2_n_0\
    );
\seconds_relay_2__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry__0_i_3_n_0\
    );
\seconds_relay_2__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry__0_i_4_n_0\
    );
\seconds_relay_2__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r2_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_2__8_carry__0_i_5_n_0\
    );
\seconds_relay_2__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r2_n_1,
      O => \seconds_relay_2__8_carry__0_i_6_n_0\
    );
\seconds_relay_2__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_2__8_carry__0_i_9_n_0\,
      O => \seconds_relay_2__8_carry__0_i_7_n_0\
    );
\seconds_relay_2__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_2__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_2__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_2__8_carry__0_i_8_n_0\
    );
\seconds_relay_2__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_2__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_2__8_carry__0_i_9_n_0\
    );
\seconds_relay_2__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_2__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_2__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_2__8_carry__1_n_2\,
      CO(0) => \seconds_relay_2__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r2_n_2,
      DI(0) => reg_r2_n_3,
      O(3 downto 1) => \NLW_seconds_relay_2__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_2__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r2_n_19,
      S(0) => reg_r2_n_20
    );
\seconds_relay_2__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry_i_2_n_0\
    );
\seconds_relay_2__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry_i_3_n_0\
    );
\seconds_relay_2__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r2_n_0,
      O => \seconds_relay_2__8_carry_i_4_n_0\
    );
\seconds_relay_2__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r2_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_2__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_2__8_carry_i_5_n_0\
    );
\seconds_relay_2__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r2_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_2__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_2__8_carry_i_6_n_0\
    );
\seconds_relay_2__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r2_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_2__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_2__8_carry_i_7_n_0\
    );
\seconds_relay_2__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r2_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_2__8_carry__0_i_7_0\(7),
      O => \seconds_relay_2__8_carry_i_8_n_0\
    );
\seconds_relay_3__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_3__274_carry_n_0\,
      CO(2) => \seconds_relay_3__274_carry_n_1\,
      CO(1) => \seconds_relay_3__274_carry_n_2\,
      CO(0) => \seconds_relay_3__274_carry_n_3\,
      CYINIT => seconds_relay_3(1),
      DI(3) => reg_r3_n_11,
      DI(2) => reg_r3_n_12,
      DI(1) => reg_r3_n_13,
      DI(0) => \seconds_relay_3__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_3__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_3__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_3__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_3__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_3__274_carry_i_5_n_0\
    );
\seconds_relay_3__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__274_carry_n_0\,
      CO(3) => \seconds_relay_3__274_carry__0_n_0\,
      CO(2) => \seconds_relay_3__274_carry__0_n_1\,
      CO(1) => \seconds_relay_3__274_carry__0_n_2\,
      CO(0) => \seconds_relay_3__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r3_n_14,
      DI(2) => reg_r3_n_15,
      DI(1) => reg_r3_n_16,
      DI(0) => reg_r3_n_17,
      O(3 downto 0) => \NLW_seconds_relay_3__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_3__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_3__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_3__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_3__274_carry__0_i_5_n_0\
    );
\seconds_relay_3__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r3_n_14,
      O => \seconds_relay_3__274_carry__0_i_2_n_0\
    );
\seconds_relay_3__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r3_n_15,
      O => \seconds_relay_3__274_carry__0_i_3_n_0\
    );
\seconds_relay_3__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r3_n_16,
      O => \seconds_relay_3__274_carry__0_i_4_n_0\
    );
\seconds_relay_3__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r3_n_17,
      O => \seconds_relay_3__274_carry__0_i_5_n_0\
    );
\seconds_relay_3__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_3__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_3(0),
      CO(0) => \seconds_relay_3__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_3(1),
      DI(0) => reg_r3_n_18,
      O(3 downto 0) => \NLW_seconds_relay_3__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r3_n_21,
      S(0) => reg_r3_n_22
    );
\seconds_relay_3__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r3_n_11,
      O => \seconds_relay_3__274_carry_i_2_n_0\
    );
\seconds_relay_3__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r3_n_12,
      O => \seconds_relay_3__274_carry_i_3_n_0\
    );
\seconds_relay_3__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r3_n_13,
      O => \seconds_relay_3__274_carry_i_4_n_0\
    );
\seconds_relay_3__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_3(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_3__8_carry__0_i_7_0\(0),
      O => \seconds_relay_3__274_carry_i_5_n_0\
    );
\seconds_relay_3__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_3__8_carry_n_0\,
      CO(2) => \seconds_relay_3__8_carry_n_1\,
      CO(1) => \seconds_relay_3__8_carry_n_2\,
      CO(0) => \seconds_relay_3__8_carry_n_3\,
      CYINIT => reg_r3_n_0,
      DI(3) => \seconds_relay_3__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_3__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_3__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_3__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_3__8_carry_n_4\,
      O(2) => \seconds_relay_3__8_carry_n_5\,
      O(1) => \seconds_relay_3__8_carry_n_6\,
      O(0) => \seconds_relay_3__8_carry_n_7\,
      S(3) => \seconds_relay_3__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_3__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_3__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_3__8_carry_i_8_n_0\
    );
\seconds_relay_3__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__8_carry_n_0\,
      CO(3) => \seconds_relay_3__8_carry__0_n_0\,
      CO(2) => \seconds_relay_3__8_carry__0_n_1\,
      CO(1) => \seconds_relay_3__8_carry__0_n_2\,
      CO(0) => \seconds_relay_3__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_3__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_3__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_3__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_3__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_3__8_carry__0_n_4\,
      O(2) => \seconds_relay_3__8_carry__0_n_5\,
      O(1) => \seconds_relay_3__8_carry__0_n_6\,
      O(0) => \seconds_relay_3__8_carry__0_n_7\,
      S(3) => \seconds_relay_3__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_3__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_3__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_3__8_carry__0_i_8_n_0\
    );
\seconds_relay_3__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry__0_i_1_n_0\
    );
\seconds_relay_3__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry__0_i_2_n_0\
    );
\seconds_relay_3__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry__0_i_3_n_0\
    );
\seconds_relay_3__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry__0_i_4_n_0\
    );
\seconds_relay_3__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r3_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_3__8_carry__0_i_5_n_0\
    );
\seconds_relay_3__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r3_n_1,
      O => \seconds_relay_3__8_carry__0_i_6_n_0\
    );
\seconds_relay_3__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_3__8_carry__0_i_9_n_0\,
      O => \seconds_relay_3__8_carry__0_i_7_n_0\
    );
\seconds_relay_3__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_3__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_3__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_3__8_carry__0_i_8_n_0\
    );
\seconds_relay_3__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_3__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_3__8_carry__0_i_9_n_0\
    );
\seconds_relay_3__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_3__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_3__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_3__8_carry__1_n_2\,
      CO(0) => \seconds_relay_3__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r3_n_2,
      DI(0) => reg_r3_n_3,
      O(3 downto 1) => \NLW_seconds_relay_3__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_3__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r3_n_19,
      S(0) => reg_r3_n_20
    );
\seconds_relay_3__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry_i_2_n_0\
    );
\seconds_relay_3__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry_i_3_n_0\
    );
\seconds_relay_3__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r3_n_0,
      O => \seconds_relay_3__8_carry_i_4_n_0\
    );
\seconds_relay_3__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r3_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_3__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_3__8_carry_i_5_n_0\
    );
\seconds_relay_3__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r3_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_3__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_3__8_carry_i_6_n_0\
    );
\seconds_relay_3__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r3_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_3__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_3__8_carry_i_7_n_0\
    );
\seconds_relay_3__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r3_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_3__8_carry__0_i_7_0\(7),
      O => \seconds_relay_3__8_carry_i_8_n_0\
    );
\seconds_relay_4__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_4__274_carry_n_0\,
      CO(2) => \seconds_relay_4__274_carry_n_1\,
      CO(1) => \seconds_relay_4__274_carry_n_2\,
      CO(0) => \seconds_relay_4__274_carry_n_3\,
      CYINIT => seconds_relay_4(1),
      DI(3) => reg_r4_n_11,
      DI(2) => reg_r4_n_12,
      DI(1) => reg_r4_n_13,
      DI(0) => \seconds_relay_4__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_4__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_4__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_4__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_4__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_4__274_carry_i_5_n_0\
    );
\seconds_relay_4__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__274_carry_n_0\,
      CO(3) => \seconds_relay_4__274_carry__0_n_0\,
      CO(2) => \seconds_relay_4__274_carry__0_n_1\,
      CO(1) => \seconds_relay_4__274_carry__0_n_2\,
      CO(0) => \seconds_relay_4__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r4_n_14,
      DI(2) => reg_r4_n_15,
      DI(1) => reg_r4_n_16,
      DI(0) => reg_r4_n_17,
      O(3 downto 0) => \NLW_seconds_relay_4__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_4__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_4__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_4__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_4__274_carry__0_i_5_n_0\
    );
\seconds_relay_4__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r4_n_14,
      O => \seconds_relay_4__274_carry__0_i_2_n_0\
    );
\seconds_relay_4__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r4_n_15,
      O => \seconds_relay_4__274_carry__0_i_3_n_0\
    );
\seconds_relay_4__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r4_n_16,
      O => \seconds_relay_4__274_carry__0_i_4_n_0\
    );
\seconds_relay_4__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r4_n_17,
      O => \seconds_relay_4__274_carry__0_i_5_n_0\
    );
\seconds_relay_4__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_4__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_4(0),
      CO(0) => \seconds_relay_4__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_4(1),
      DI(0) => reg_r4_n_18,
      O(3 downto 0) => \NLW_seconds_relay_4__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r4_n_21,
      S(0) => reg_r4_n_22
    );
\seconds_relay_4__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r4_n_11,
      O => \seconds_relay_4__274_carry_i_2_n_0\
    );
\seconds_relay_4__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r4_n_12,
      O => \seconds_relay_4__274_carry_i_3_n_0\
    );
\seconds_relay_4__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r4_n_13,
      O => \seconds_relay_4__274_carry_i_4_n_0\
    );
\seconds_relay_4__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_4(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_4__8_carry__0_i_7_0\(0),
      O => \seconds_relay_4__274_carry_i_5_n_0\
    );
\seconds_relay_4__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_4__8_carry_n_0\,
      CO(2) => \seconds_relay_4__8_carry_n_1\,
      CO(1) => \seconds_relay_4__8_carry_n_2\,
      CO(0) => \seconds_relay_4__8_carry_n_3\,
      CYINIT => reg_r4_n_0,
      DI(3) => \seconds_relay_4__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_4__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_4__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_4__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_4__8_carry_n_4\,
      O(2) => \seconds_relay_4__8_carry_n_5\,
      O(1) => \seconds_relay_4__8_carry_n_6\,
      O(0) => \seconds_relay_4__8_carry_n_7\,
      S(3) => \seconds_relay_4__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_4__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_4__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_4__8_carry_i_8_n_0\
    );
\seconds_relay_4__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__8_carry_n_0\,
      CO(3) => \seconds_relay_4__8_carry__0_n_0\,
      CO(2) => \seconds_relay_4__8_carry__0_n_1\,
      CO(1) => \seconds_relay_4__8_carry__0_n_2\,
      CO(0) => \seconds_relay_4__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_4__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_4__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_4__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_4__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_4__8_carry__0_n_4\,
      O(2) => \seconds_relay_4__8_carry__0_n_5\,
      O(1) => \seconds_relay_4__8_carry__0_n_6\,
      O(0) => \seconds_relay_4__8_carry__0_n_7\,
      S(3) => \seconds_relay_4__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_4__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_4__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_4__8_carry__0_i_8_n_0\
    );
\seconds_relay_4__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry__0_i_1_n_0\
    );
\seconds_relay_4__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry__0_i_2_n_0\
    );
\seconds_relay_4__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry__0_i_3_n_0\
    );
\seconds_relay_4__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry__0_i_4_n_0\
    );
\seconds_relay_4__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r4_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_4__8_carry__0_i_5_n_0\
    );
\seconds_relay_4__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r4_n_1,
      O => \seconds_relay_4__8_carry__0_i_6_n_0\
    );
\seconds_relay_4__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_4__8_carry__0_i_9_n_0\,
      O => \seconds_relay_4__8_carry__0_i_7_n_0\
    );
\seconds_relay_4__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_4__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_4__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_4__8_carry__0_i_8_n_0\
    );
\seconds_relay_4__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_4__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_4__8_carry__0_i_9_n_0\
    );
\seconds_relay_4__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_4__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_4__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_4__8_carry__1_n_2\,
      CO(0) => \seconds_relay_4__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r4_n_2,
      DI(0) => reg_r4_n_3,
      O(3 downto 1) => \NLW_seconds_relay_4__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_4__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r4_n_19,
      S(0) => reg_r4_n_20
    );
\seconds_relay_4__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry_i_2_n_0\
    );
\seconds_relay_4__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry_i_3_n_0\
    );
\seconds_relay_4__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r4_n_0,
      O => \seconds_relay_4__8_carry_i_4_n_0\
    );
\seconds_relay_4__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r4_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_4__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_4__8_carry_i_5_n_0\
    );
\seconds_relay_4__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r4_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_4__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_4__8_carry_i_6_n_0\
    );
\seconds_relay_4__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r4_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_4__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_4__8_carry_i_7_n_0\
    );
\seconds_relay_4__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r4_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_4__8_carry__0_i_7_0\(7),
      O => \seconds_relay_4__8_carry_i_8_n_0\
    );
\seconds_relay_5__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_5__274_carry_n_0\,
      CO(2) => \seconds_relay_5__274_carry_n_1\,
      CO(1) => \seconds_relay_5__274_carry_n_2\,
      CO(0) => \seconds_relay_5__274_carry_n_3\,
      CYINIT => seconds_relay_5(1),
      DI(3) => reg_r5_n_11,
      DI(2) => reg_r5_n_12,
      DI(1) => reg_r5_n_13,
      DI(0) => \seconds_relay_5__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_5__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_5__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_5__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_5__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_5__274_carry_i_5_n_0\
    );
\seconds_relay_5__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__274_carry_n_0\,
      CO(3) => \seconds_relay_5__274_carry__0_n_0\,
      CO(2) => \seconds_relay_5__274_carry__0_n_1\,
      CO(1) => \seconds_relay_5__274_carry__0_n_2\,
      CO(0) => \seconds_relay_5__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r5_n_14,
      DI(2) => reg_r5_n_15,
      DI(1) => reg_r5_n_16,
      DI(0) => reg_r5_n_17,
      O(3 downto 0) => \NLW_seconds_relay_5__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_5__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_5__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_5__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_5__274_carry__0_i_5_n_0\
    );
\seconds_relay_5__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r5_n_14,
      O => \seconds_relay_5__274_carry__0_i_2_n_0\
    );
\seconds_relay_5__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r5_n_15,
      O => \seconds_relay_5__274_carry__0_i_3_n_0\
    );
\seconds_relay_5__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r5_n_16,
      O => \seconds_relay_5__274_carry__0_i_4_n_0\
    );
\seconds_relay_5__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r5_n_17,
      O => \seconds_relay_5__274_carry__0_i_5_n_0\
    );
\seconds_relay_5__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_5__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_5(0),
      CO(0) => \seconds_relay_5__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_5(1),
      DI(0) => reg_r5_n_18,
      O(3 downto 0) => \NLW_seconds_relay_5__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r5_n_21,
      S(0) => reg_r5_n_22
    );
\seconds_relay_5__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r5_n_11,
      O => \seconds_relay_5__274_carry_i_2_n_0\
    );
\seconds_relay_5__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r5_n_12,
      O => \seconds_relay_5__274_carry_i_3_n_0\
    );
\seconds_relay_5__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r5_n_13,
      O => \seconds_relay_5__274_carry_i_4_n_0\
    );
\seconds_relay_5__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_5(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_5__8_carry__0_i_7_0\(0),
      O => \seconds_relay_5__274_carry_i_5_n_0\
    );
\seconds_relay_5__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_5__8_carry_n_0\,
      CO(2) => \seconds_relay_5__8_carry_n_1\,
      CO(1) => \seconds_relay_5__8_carry_n_2\,
      CO(0) => \seconds_relay_5__8_carry_n_3\,
      CYINIT => reg_r5_n_0,
      DI(3) => \seconds_relay_5__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_5__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_5__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_5__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_5__8_carry_n_4\,
      O(2) => \seconds_relay_5__8_carry_n_5\,
      O(1) => \seconds_relay_5__8_carry_n_6\,
      O(0) => \seconds_relay_5__8_carry_n_7\,
      S(3) => \seconds_relay_5__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_5__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_5__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_5__8_carry_i_8_n_0\
    );
\seconds_relay_5__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__8_carry_n_0\,
      CO(3) => \seconds_relay_5__8_carry__0_n_0\,
      CO(2) => \seconds_relay_5__8_carry__0_n_1\,
      CO(1) => \seconds_relay_5__8_carry__0_n_2\,
      CO(0) => \seconds_relay_5__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_5__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_5__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_5__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_5__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_5__8_carry__0_n_4\,
      O(2) => \seconds_relay_5__8_carry__0_n_5\,
      O(1) => \seconds_relay_5__8_carry__0_n_6\,
      O(0) => \seconds_relay_5__8_carry__0_n_7\,
      S(3) => \seconds_relay_5__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_5__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_5__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_5__8_carry__0_i_8_n_0\
    );
\seconds_relay_5__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry__0_i_1_n_0\
    );
\seconds_relay_5__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry__0_i_2_n_0\
    );
\seconds_relay_5__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry__0_i_3_n_0\
    );
\seconds_relay_5__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry__0_i_4_n_0\
    );
\seconds_relay_5__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r5_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_5__8_carry__0_i_5_n_0\
    );
\seconds_relay_5__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r5_n_1,
      O => \seconds_relay_5__8_carry__0_i_6_n_0\
    );
\seconds_relay_5__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_5__8_carry__0_i_9_n_0\,
      O => \seconds_relay_5__8_carry__0_i_7_n_0\
    );
\seconds_relay_5__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_5__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_5__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_5__8_carry__0_i_8_n_0\
    );
\seconds_relay_5__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_5__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_5__8_carry__0_i_9_n_0\
    );
\seconds_relay_5__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_5__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_5__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_5__8_carry__1_n_2\,
      CO(0) => \seconds_relay_5__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r5_n_2,
      DI(0) => reg_r5_n_3,
      O(3 downto 1) => \NLW_seconds_relay_5__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_5__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r5_n_19,
      S(0) => reg_r5_n_20
    );
\seconds_relay_5__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry_i_2_n_0\
    );
\seconds_relay_5__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry_i_3_n_0\
    );
\seconds_relay_5__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r5_n_0,
      O => \seconds_relay_5__8_carry_i_4_n_0\
    );
\seconds_relay_5__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r5_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_5__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_5__8_carry_i_5_n_0\
    );
\seconds_relay_5__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r5_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_5__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_5__8_carry_i_6_n_0\
    );
\seconds_relay_5__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r5_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_5__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_5__8_carry_i_7_n_0\
    );
\seconds_relay_5__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r5_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_5__8_carry__0_i_7_0\(7),
      O => \seconds_relay_5__8_carry_i_8_n_0\
    );
\seconds_relay_6__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_6__274_carry_n_0\,
      CO(2) => \seconds_relay_6__274_carry_n_1\,
      CO(1) => \seconds_relay_6__274_carry_n_2\,
      CO(0) => \seconds_relay_6__274_carry_n_3\,
      CYINIT => seconds_relay_6(1),
      DI(3) => reg_r6_n_11,
      DI(2) => reg_r6_n_12,
      DI(1) => reg_r6_n_13,
      DI(0) => \seconds_relay_6__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_6__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_6__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_6__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_6__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_6__274_carry_i_5_n_0\
    );
\seconds_relay_6__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__274_carry_n_0\,
      CO(3) => \seconds_relay_6__274_carry__0_n_0\,
      CO(2) => \seconds_relay_6__274_carry__0_n_1\,
      CO(1) => \seconds_relay_6__274_carry__0_n_2\,
      CO(0) => \seconds_relay_6__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r6_n_14,
      DI(2) => reg_r6_n_15,
      DI(1) => reg_r6_n_16,
      DI(0) => reg_r6_n_17,
      O(3 downto 0) => \NLW_seconds_relay_6__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_6__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_6__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_6__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_6__274_carry__0_i_5_n_0\
    );
\seconds_relay_6__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r6_n_14,
      O => \seconds_relay_6__274_carry__0_i_2_n_0\
    );
\seconds_relay_6__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r6_n_15,
      O => \seconds_relay_6__274_carry__0_i_3_n_0\
    );
\seconds_relay_6__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r6_n_16,
      O => \seconds_relay_6__274_carry__0_i_4_n_0\
    );
\seconds_relay_6__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r6_n_17,
      O => \seconds_relay_6__274_carry__0_i_5_n_0\
    );
\seconds_relay_6__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_6__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_6(0),
      CO(0) => \seconds_relay_6__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_6(1),
      DI(0) => reg_r6_n_18,
      O(3 downto 0) => \NLW_seconds_relay_6__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r6_n_21,
      S(0) => reg_r6_n_22
    );
\seconds_relay_6__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r6_n_11,
      O => \seconds_relay_6__274_carry_i_2_n_0\
    );
\seconds_relay_6__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r6_n_12,
      O => \seconds_relay_6__274_carry_i_3_n_0\
    );
\seconds_relay_6__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r6_n_13,
      O => \seconds_relay_6__274_carry_i_4_n_0\
    );
\seconds_relay_6__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_6(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_6__8_carry__0_i_7_0\(0),
      O => \seconds_relay_6__274_carry_i_5_n_0\
    );
\seconds_relay_6__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_6__8_carry_n_0\,
      CO(2) => \seconds_relay_6__8_carry_n_1\,
      CO(1) => \seconds_relay_6__8_carry_n_2\,
      CO(0) => \seconds_relay_6__8_carry_n_3\,
      CYINIT => reg_r6_n_0,
      DI(3) => \seconds_relay_6__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_6__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_6__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_6__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_6__8_carry_n_4\,
      O(2) => \seconds_relay_6__8_carry_n_5\,
      O(1) => \seconds_relay_6__8_carry_n_6\,
      O(0) => \seconds_relay_6__8_carry_n_7\,
      S(3) => \seconds_relay_6__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_6__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_6__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_6__8_carry_i_8_n_0\
    );
\seconds_relay_6__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__8_carry_n_0\,
      CO(3) => \seconds_relay_6__8_carry__0_n_0\,
      CO(2) => \seconds_relay_6__8_carry__0_n_1\,
      CO(1) => \seconds_relay_6__8_carry__0_n_2\,
      CO(0) => \seconds_relay_6__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_6__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_6__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_6__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_6__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_6__8_carry__0_n_4\,
      O(2) => \seconds_relay_6__8_carry__0_n_5\,
      O(1) => \seconds_relay_6__8_carry__0_n_6\,
      O(0) => \seconds_relay_6__8_carry__0_n_7\,
      S(3) => \seconds_relay_6__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_6__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_6__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_6__8_carry__0_i_8_n_0\
    );
\seconds_relay_6__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry__0_i_1_n_0\
    );
\seconds_relay_6__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry__0_i_2_n_0\
    );
\seconds_relay_6__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry__0_i_3_n_0\
    );
\seconds_relay_6__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry__0_i_4_n_0\
    );
\seconds_relay_6__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r6_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_6__8_carry__0_i_5_n_0\
    );
\seconds_relay_6__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r6_n_1,
      O => \seconds_relay_6__8_carry__0_i_6_n_0\
    );
\seconds_relay_6__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_6__8_carry__0_i_9_n_0\,
      O => \seconds_relay_6__8_carry__0_i_7_n_0\
    );
\seconds_relay_6__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_6__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_6__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_6__8_carry__0_i_8_n_0\
    );
\seconds_relay_6__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_6__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_6__8_carry__0_i_9_n_0\
    );
\seconds_relay_6__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_6__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_6__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_6__8_carry__1_n_2\,
      CO(0) => \seconds_relay_6__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r6_n_2,
      DI(0) => reg_r6_n_3,
      O(3 downto 1) => \NLW_seconds_relay_6__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_6__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r6_n_19,
      S(0) => reg_r6_n_20
    );
\seconds_relay_6__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry_i_2_n_0\
    );
\seconds_relay_6__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry_i_3_n_0\
    );
\seconds_relay_6__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r6_n_0,
      O => \seconds_relay_6__8_carry_i_4_n_0\
    );
\seconds_relay_6__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r6_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_6__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_6__8_carry_i_5_n_0\
    );
\seconds_relay_6__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r6_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_6__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_6__8_carry_i_6_n_0\
    );
\seconds_relay_6__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r6_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_6__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_6__8_carry_i_7_n_0\
    );
\seconds_relay_6__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r6_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_6__8_carry__0_i_7_0\(7),
      O => \seconds_relay_6__8_carry_i_8_n_0\
    );
\seconds_relay_7__274_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_7__274_carry_n_0\,
      CO(2) => \seconds_relay_7__274_carry_n_1\,
      CO(1) => \seconds_relay_7__274_carry_n_2\,
      CO(0) => \seconds_relay_7__274_carry_n_3\,
      CYINIT => seconds_relay_7(1),
      DI(3) => reg_r7_n_11,
      DI(2) => reg_r7_n_12,
      DI(1) => reg_r7_n_13,
      DI(0) => \seconds_relay_7__8_carry__0_i_7_0\(0),
      O(3 downto 0) => \NLW_seconds_relay_7__274_carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_7__274_carry_i_2_n_0\,
      S(2) => \seconds_relay_7__274_carry_i_3_n_0\,
      S(1) => \seconds_relay_7__274_carry_i_4_n_0\,
      S(0) => \seconds_relay_7__274_carry_i_5_n_0\
    );
\seconds_relay_7__274_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__274_carry_n_0\,
      CO(3) => \seconds_relay_7__274_carry__0_n_0\,
      CO(2) => \seconds_relay_7__274_carry__0_n_1\,
      CO(1) => \seconds_relay_7__274_carry__0_n_2\,
      CO(0) => \seconds_relay_7__274_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => reg_r7_n_14,
      DI(2) => reg_r7_n_15,
      DI(1) => reg_r7_n_16,
      DI(0) => reg_r7_n_17,
      O(3 downto 0) => \NLW_seconds_relay_7__274_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \seconds_relay_7__274_carry__0_i_2_n_0\,
      S(2) => \seconds_relay_7__274_carry__0_i_3_n_0\,
      S(1) => \seconds_relay_7__274_carry__0_i_4_n_0\,
      S(0) => \seconds_relay_7__274_carry__0_i_5_n_0\
    );
\seconds_relay_7__274_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(7),
      I2 => reg_r7_n_14,
      O => \seconds_relay_7__274_carry__0_i_2_n_0\
    );
\seconds_relay_7__274_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(6),
      I2 => reg_r7_n_15,
      O => \seconds_relay_7__274_carry__0_i_3_n_0\
    );
\seconds_relay_7__274_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(5),
      I2 => reg_r7_n_16,
      O => \seconds_relay_7__274_carry__0_i_4_n_0\
    );
\seconds_relay_7__274_carry__0_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(4),
      I2 => reg_r7_n_17,
      O => \seconds_relay_7__274_carry__0_i_5_n_0\
    );
\seconds_relay_7__274_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__274_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_7__274_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => seconds_relay_7(0),
      CO(0) => \seconds_relay_7__274_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => seconds_relay_7(1),
      DI(0) => reg_r7_n_18,
      O(3 downto 0) => \NLW_seconds_relay_7__274_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => reg_r7_n_21,
      S(0) => reg_r7_n_22
    );
\seconds_relay_7__274_carry_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(3),
      I2 => reg_r7_n_11,
      O => \seconds_relay_7__274_carry_i_2_n_0\
    );
\seconds_relay_7__274_carry_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(2),
      I2 => reg_r7_n_12,
      O => \seconds_relay_7__274_carry_i_3_n_0\
    );
\seconds_relay_7__274_carry_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(1),
      I2 => reg_r7_n_13,
      O => \seconds_relay_7__274_carry_i_4_n_0\
    );
\seconds_relay_7__274_carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => seconds_relay_7(1),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_7__8_carry__0_i_7_0\(0),
      O => \seconds_relay_7__274_carry_i_5_n_0\
    );
\seconds_relay_7__8_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \seconds_relay_7__8_carry_n_0\,
      CO(2) => \seconds_relay_7__8_carry_n_1\,
      CO(1) => \seconds_relay_7__8_carry_n_2\,
      CO(0) => \seconds_relay_7__8_carry_n_3\,
      CYINIT => reg_r7_n_0,
      DI(3) => \seconds_relay_7__8_carry_i_2_n_0\,
      DI(2) => \seconds_relay_7__8_carry_i_3_n_0\,
      DI(1) => \seconds_relay_7__8_carry_i_4_n_0\,
      DI(0) => \seconds_relay_7__8_carry__0_i_7_0\(7),
      O(3) => \seconds_relay_7__8_carry_n_4\,
      O(2) => \seconds_relay_7__8_carry_n_5\,
      O(1) => \seconds_relay_7__8_carry_n_6\,
      O(0) => \seconds_relay_7__8_carry_n_7\,
      S(3) => \seconds_relay_7__8_carry_i_5_n_0\,
      S(2) => \seconds_relay_7__8_carry_i_6_n_0\,
      S(1) => \seconds_relay_7__8_carry_i_7_n_0\,
      S(0) => \seconds_relay_7__8_carry_i_8_n_0\
    );
\seconds_relay_7__8_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__8_carry_n_0\,
      CO(3) => \seconds_relay_7__8_carry__0_n_0\,
      CO(2) => \seconds_relay_7__8_carry__0_n_1\,
      CO(1) => \seconds_relay_7__8_carry__0_n_2\,
      CO(0) => \seconds_relay_7__8_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \seconds_relay_7__8_carry__0_i_1_n_0\,
      DI(2) => \seconds_relay_7__8_carry__0_i_2_n_0\,
      DI(1) => \seconds_relay_7__8_carry__0_i_3_n_0\,
      DI(0) => \seconds_relay_7__8_carry__0_i_4_n_0\,
      O(3) => \seconds_relay_7__8_carry__0_n_4\,
      O(2) => \seconds_relay_7__8_carry__0_n_5\,
      O(1) => \seconds_relay_7__8_carry__0_n_6\,
      O(0) => \seconds_relay_7__8_carry__0_n_7\,
      S(3) => \seconds_relay_7__8_carry__0_i_5_n_0\,
      S(2) => \seconds_relay_7__8_carry__0_i_6_n_0\,
      S(1) => \seconds_relay_7__8_carry__0_i_7_n_0\,
      S(0) => \seconds_relay_7__8_carry__0_i_8_n_0\
    );
\seconds_relay_7__8_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry__0_i_1_n_0\
    );
\seconds_relay_7__8_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(6),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry__0_i_2_n_0\
    );
\seconds_relay_7__8_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(5),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry__0_i_3_n_0\
    );
\seconds_relay_7__8_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(4),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry__0_i_4_n_0\
    );
\seconds_relay_7__8_carry__0_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A55BA5"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(8),
      I2 => liquid_division_reg(6),
      I3 => reg_r7_n_1,
      I4 => liquid_division_reg(5),
      O => \seconds_relay_7__8_carry__0_i_5_n_0\
    );
\seconds_relay_7__8_carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"33CDCC33"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(6),
      I2 => liquid_division_reg(8),
      I3 => liquid_division_reg(5),
      I4 => reg_r7_n_1,
      O => \seconds_relay_7__8_carry__0_i_6_n_0\
    );
\seconds_relay_7__8_carry__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333CCCDCCCC3333"
    )
        port map (
      I0 => liquid_division_reg(7),
      I1 => liquid_division_reg(5),
      I2 => liquid_division_reg(6),
      I3 => liquid_division_reg(8),
      I4 => liquid_division_reg(4),
      I5 => \seconds_relay_7__8_carry__0_i_9_n_0\,
      O => \seconds_relay_7__8_carry__0_i_7_n_0\
    );
\seconds_relay_7__8_carry__0_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"9999999996999696"
    )
        port map (
      I0 => \seconds_relay_7__8_carry__0_i_4_n_0\,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_7__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      I5 => liquid_division_reg(2),
      O => \seconds_relay_7__8_carry__0_i_8_n_0\
    );
\seconds_relay_7__8_carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000051"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_7__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(1),
      I4 => liquid_division_reg(3),
      O => \seconds_relay_7__8_carry__0_i_9_n_0\
    );
\seconds_relay_7__8_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \seconds_relay_7__8_carry__0_n_0\,
      CO(3 downto 2) => \NLW_seconds_relay_7__8_carry__1_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \seconds_relay_7__8_carry__1_n_2\,
      CO(0) => \seconds_relay_7__8_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => reg_r7_n_2,
      DI(0) => reg_r7_n_3,
      O(3 downto 1) => \NLW_seconds_relay_7__8_carry__1_O_UNCONNECTED\(3 downto 1),
      O(0) => \seconds_relay_7__8_carry__1_n_7\,
      S(3 downto 2) => B"00",
      S(1) => reg_r7_n_19,
      S(0) => reg_r7_n_20
    );
\seconds_relay_7__8_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(3),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry_i_2_n_0\
    );
\seconds_relay_7__8_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(2),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry_i_3_n_0\
    );
\seconds_relay_7__8_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => liquid_division_reg(1),
      I1 => reg_r7_n_0,
      O => \seconds_relay_7__8_carry_i_4_n_0\
    );
\seconds_relay_7__8_carry_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969696996966996"
    )
        port map (
      I0 => reg_r7_n_0,
      I1 => liquid_division_reg(3),
      I2 => liquid_division_reg(2),
      I3 => liquid_division_reg(0),
      I4 => \seconds_relay_7__8_carry__0_i_7_0\(8),
      I5 => liquid_division_reg(1),
      O => \seconds_relay_7__8_carry_i_5_n_0\
    );
\seconds_relay_7__8_carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"96699696"
    )
        port map (
      I0 => reg_r7_n_0,
      I1 => liquid_division_reg(2),
      I2 => liquid_division_reg(1),
      I3 => \seconds_relay_7__8_carry__0_i_7_0\(8),
      I4 => liquid_division_reg(0),
      O => \seconds_relay_7__8_carry_i_6_n_0\
    );
\seconds_relay_7__8_carry_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => reg_r7_n_0,
      I1 => liquid_division_reg(1),
      I2 => \seconds_relay_7__8_carry__0_i_7_0\(8),
      I3 => liquid_division_reg(0),
      O => \seconds_relay_7__8_carry_i_7_n_0\
    );
\seconds_relay_7__8_carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => reg_r7_n_0,
      I1 => liquid_division_reg(0),
      I2 => \seconds_relay_7__8_carry__0_i_7_0\(7),
      O => \seconds_relay_7__8_carry_i_8_n_0\
    );
timer_0: entity work.design_1_liquid_0_1_timer
     port map (
      D(0) => \^d\(0),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_0\,
      \count_seconds_reg[4]_0\(4) => reg_r0_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r0_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r0_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r0_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r0_n_9,
      counter_out0_out => counter_out0_out,
      counter_out_reg_0 => counter_out_reg,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg\,
      started_reg_1(0) => relay_register_out(0)
    );
timer_1: entity work.design_1_liquid_0_1_timer_7
     port map (
      D(0) => \^d\(1),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_1\,
      \count_seconds_reg[4]_0\(4) => reg_r1_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r1_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r1_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r1_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r1_n_9,
      counter_out0_out_8 => counter_out0_out_8,
      counter_out_reg_0 => counter_out_reg_0,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_0\,
      started_reg_1(0) => relay_register_out(1)
    );
timer_2: entity work.design_1_liquid_0_1_timer_8
     port map (
      D(0) => \^d\(2),
      \FSM_onehot_current_state_reg[1]\(2) => \^d\(3),
      \FSM_onehot_current_state_reg[1]\(1 downto 0) => \^d\(1 downto 0),
      \FSM_onehot_current_state_reg[1]_0\ => timer_5_n_3,
      \FSM_onehot_current_state_reg[2]\(1) => timer_2_n_3,
      \FSM_onehot_current_state_reg[2]\(0) => timer_2_n_4,
      Q(2) => p_0_in_0,
      Q(1) => \FSM_onehot_current_state_reg_n_0_[1]\,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_2\,
      \count_seconds_reg[4]_0\(4) => reg_r2_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r2_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r2_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r2_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r2_n_9,
      counter_out0_out_10 => counter_out0_out_10,
      counter_out_reg_0 => counter_out_reg_1,
      p_2_in(0) => p_2_in(0),
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_1\,
      started_reg_1(0) => relay_register_out(2)
    );
timer_3: entity work.design_1_liquid_0_1_timer_9
     port map (
      D(0) => \^d\(3),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_3\,
      \count_seconds_reg[4]_0\(4) => reg_r3_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r3_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r3_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r3_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r3_n_9,
      counter_out0_out_12 => counter_out0_out_12,
      counter_out_reg_0 => counter_out_reg_2,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_2\,
      started_reg_1(0) => relay_register_out(3)
    );
timer_4: entity work.design_1_liquid_0_1_timer_10
     port map (
      D(0) => \^d\(4),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_4\,
      \count_seconds_reg[4]_0\(4) => reg_r4_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r4_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r4_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r4_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r4_n_9,
      counter_out0_out_14 => counter_out0_out_14,
      counter_out_reg_0 => counter_out_reg_3,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_3\,
      started_reg_1(0) => relay_register_out(4)
    );
timer_5: entity work.design_1_liquid_0_1_timer_11
     port map (
      D(0) => \^d\(5),
      \FSM_onehot_current_state[1]_i_2\(2 downto 1) => \^d\(7 downto 6),
      \FSM_onehot_current_state[1]_i_2\(0) => \^d\(4),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_5\,
      \count_seconds_reg[4]_0\(4) => reg_r5_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r5_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r5_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r5_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r5_n_9,
      counter_out0_out_16 => counter_out0_out_16,
      counter_out_reg_0 => timer_5_n_3,
      counter_out_reg_1 => counter_out_reg_4,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_4\,
      started_reg_1(0) => relay_register_out(5)
    );
timer_6: entity work.design_1_liquid_0_1_timer_12
     port map (
      D(0) => \^d\(6),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_6\,
      \count_seconds_reg[4]_0\(4) => reg_r6_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r6_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r6_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r6_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r6_n_9,
      counter_out0_out_18 => counter_out0_out_18,
      counter_out_reg_0 => counter_out_reg_5,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_5\,
      started_reg_1(0) => relay_register_out(6)
    );
timer_7: entity work.design_1_liquid_0_1_timer_13
     port map (
      D(0) => \^d\(7),
      Q(1) => p_0_in_0,
      Q(0) => load_liquid_division,
      \count_clk_cycles_reg[0]_0\ => \^prev_was_load_reg_7\,
      \count_seconds_reg[4]_0\(4) => reg_r7_n_5,
      \count_seconds_reg[4]_0\(3) => reg_r7_n_6,
      \count_seconds_reg[4]_0\(2) => reg_r7_n_7,
      \count_seconds_reg[4]_0\(1) => reg_r7_n_8,
      \count_seconds_reg[4]_0\(0) => reg_r7_n_9,
      counter_out0_out_20 => counter_out0_out_20,
      counter_out_reg_0 => counter_out_reg_6,
      prev_was_load => prev_was_load,
      s00_axi_aclk => s00_axi_aclk,
      started_reg_0 => \^started_reg_6\,
      started_reg_1(0) => relay_register_out(7)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI is
  port (
    D : out STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    axi_awready_reg_0 : out STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    axi_rvalid_reg_0 : out STD_LOGIC;
    axi_arready_reg_0 : out STD_LOGIC;
    started : out STD_LOGIC;
    started_0 : out STD_LOGIC;
    started_1 : out STD_LOGIC;
    started_2 : out STD_LOGIC;
    started_3 : out STD_LOGIC;
    started_4 : out STD_LOGIC;
    started_5 : out STD_LOGIC;
    started_6 : out STD_LOGIC;
    state_write : out STD_LOGIC_VECTOR ( 1 downto 0 );
    state_read : out STD_LOGIC_VECTOR ( 1 downto 0 );
    count_clk_cycles1 : out STD_LOGIC;
    counter_out0_out : out STD_LOGIC;
    count_clk_cycles1_7 : out STD_LOGIC;
    counter_out0_out_8 : out STD_LOGIC;
    count_clk_cycles1_9 : out STD_LOGIC;
    counter_out0_out_10 : out STD_LOGIC;
    count_clk_cycles1_11 : out STD_LOGIC;
    counter_out0_out_12 : out STD_LOGIC;
    count_clk_cycles1_13 : out STD_LOGIC;
    counter_out0_out_14 : out STD_LOGIC;
    count_clk_cycles1_15 : out STD_LOGIC;
    counter_out0_out_16 : out STD_LOGIC;
    count_clk_cycles1_17 : out STD_LOGIC;
    counter_out0_out_18 : out STD_LOGIC;
    count_clk_cycles1_19 : out STD_LOGIC;
    counter_out0_out_20 : out STD_LOGIC;
    \axi_awready0__0\ : out STD_LOGIC;
    \state_reg[2]\ : out STD_LOGIC;
    \state_reg[2]_0\ : out STD_LOGIC;
    \state_reg[2]_1\ : out STD_LOGIC;
    \state_reg[2]_2\ : out STD_LOGIC;
    \state_reg[2]_3\ : out STD_LOGIC;
    \state_reg[2]_4\ : out STD_LOGIC;
    \state_reg[2]_5\ : out STD_LOGIC;
    \state_reg[2]_6\ : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    counter_out_reg : in STD_LOGIC;
    counter_out_reg_0 : in STD_LOGIC;
    counter_out_reg_1 : in STD_LOGIC;
    counter_out_reg_2 : in STD_LOGIC;
    counter_out_reg_3 : in STD_LOGIC;
    counter_out_reg_4 : in STD_LOGIC;
    counter_out_reg_5 : in STD_LOGIC;
    counter_out_reg_6 : in STD_LOGIC;
    axi_bvalid_reg_0 : in STD_LOGIC;
    axi_awready_reg_1 : in STD_LOGIC;
    axi_wready_reg_0 : in STD_LOGIC;
    axi_rvalid_reg_1 : in STD_LOGIC;
    axi_arready_reg_1 : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_rready : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI : entity is "liquid_slave_lite_v1_0_S00_AXI";
end design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI;

architecture STRUCTURE of design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI is
  signal \^d\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \FSM_sequential_state_read[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_read[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_write[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_write[1]_i_1_n_0\ : STD_LOGIC;
  signal arthur_liquid_n_0 : STD_LOGIC;
  signal \axi_araddr[5]_i_1_n_0\ : STD_LOGIC;
  signal \^axi_arready_reg_0\ : STD_LOGIC;
  signal axi_awaddr : STD_LOGIC;
  signal \axi_awaddr_reg_n_0_[2]\ : STD_LOGIC;
  signal \axi_awaddr_reg_n_0_[3]\ : STD_LOGIC;
  signal \axi_awaddr_reg_n_0_[4]\ : STD_LOGIC;
  signal \axi_awaddr_reg_n_0_[5]\ : STD_LOGIC;
  signal \^axi_awready_reg_0\ : STD_LOGIC;
  signal \^axi_rvalid_reg_0\ : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 31 downto 7 );
  signal p_2_in : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \s00_axi_rdata[0]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[0]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[0]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[10]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[10]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[10]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[11]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[11]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[11]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[12]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[12]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[12]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[13]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[13]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[13]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[14]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[14]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[14]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[15]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[15]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[15]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[16]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[16]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[16]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[17]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[17]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[17]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[18]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[18]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[18]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[19]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[19]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[19]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[1]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[1]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[1]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[20]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[20]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[20]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[21]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[21]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[21]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[22]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[22]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[22]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[23]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[23]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[23]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[24]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[24]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[24]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[25]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[25]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[25]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[26]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[26]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[26]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[27]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[27]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[27]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[28]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[28]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[28]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[29]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[29]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[29]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[2]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[2]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[2]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[30]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[30]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[30]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[31]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[31]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[31]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[3]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[3]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[3]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[4]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[4]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[4]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[5]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[5]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[6]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[6]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[7]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[7]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[8]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[8]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[8]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[9]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[9]_INST_0_i_2_n_0\ : STD_LOGIC;
  signal \s00_axi_rdata[9]_INST_0_i_3_n_0\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal slv_reg0 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \slv_reg0[31]_i_2_n_0\ : STD_LOGIC;
  signal \slv_reg0[31]_i_3_n_0\ : STD_LOGIC;
  signal \slv_reg0[31]_i_4_n_0\ : STD_LOGIC;
  signal \slv_reg0[31]_i_5_n_0\ : STD_LOGIC;
  signal \slv_reg0__0\ : STD_LOGIC_VECTOR ( 31 downto 8 );
  signal slv_reg10 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg10[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg10[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg10[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg10[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg10__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg11 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \slv_reg1[0]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg1[0]_i_2_n_0\ : STD_LOGIC;
  signal \slv_reg1[0]_i_3_n_0\ : STD_LOGIC;
  signal \slv_reg1[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg1[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg1[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg1[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[10]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[11]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[12]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[13]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[14]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[15]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[16]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[17]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[18]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[19]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[1]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[20]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[21]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[22]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[23]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[24]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[25]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[26]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[27]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[28]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[29]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[2]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[30]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[31]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[3]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[4]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[5]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[6]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[7]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[8]\ : STD_LOGIC;
  signal \slv_reg1_reg_n_0_[9]\ : STD_LOGIC;
  signal slv_reg2 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg2[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg2[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg2[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg2[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg2__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg3 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg3[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg3[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg3[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg3[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg3__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg4 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg4[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg5 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg5[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg6 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg6[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[31]_i_2_n_0\ : STD_LOGIC;
  signal \slv_reg6[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg7 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg7[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg8 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg8[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal slv_reg9 : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \slv_reg9[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[7]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9__0\ : STD_LOGIC_VECTOR ( 31 downto 9 );
  signal \^state_read\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \^state_write\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_read_reg[0]\ : label is "Idle:00,Rdata:10,Raddr:01";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_read_reg[1]\ : label is "Idle:00,Rdata:10,Raddr:01";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state_write[0]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \FSM_sequential_state_write[1]_i_1\ : label is "soft_lutpair17";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_write_reg[0]\ : label is "Idle:00,Wdata:10,Waddr:01";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_write_reg[1]\ : label is "Idle:00,Wdata:10,Waddr:01";
  attribute SOFT_HLUTNM of axi_bvalid_i_2 : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \slv_reg1[0]_i_3\ : label is "soft_lutpair18";
begin
  D(7 downto 0) <= \^d\(7 downto 0);
  axi_arready_reg_0 <= \^axi_arready_reg_0\;
  axi_awready_reg_0 <= \^axi_awready_reg_0\;
  axi_rvalid_reg_0 <= \^axi_rvalid_reg_0\;
  state_read(1 downto 0) <= \^state_read\(1 downto 0);
  state_write(1 downto 0) <= \^state_write\(1 downto 0);
\FSM_sequential_state_read[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF0007777FFFF"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^axi_arready_reg_0\,
      I2 => s00_axi_rready,
      I3 => \^axi_rvalid_reg_0\,
      I4 => \^state_read\(0),
      I5 => \^state_read\(1),
      O => \FSM_sequential_state_read[0]_i_1_n_0\
    );
\FSM_sequential_state_read[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF0FFF88880000"
    )
        port map (
      I0 => \^axi_arready_reg_0\,
      I1 => s00_axi_arvalid,
      I2 => s00_axi_rready,
      I3 => \^axi_rvalid_reg_0\,
      I4 => \^state_read\(0),
      I5 => \^state_read\(1),
      O => \FSM_sequential_state_read[1]_i_1_n_0\
    );
\FSM_sequential_state_read_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_sequential_state_read[0]_i_1_n_0\,
      Q => \^state_read\(0),
      R => arthur_liquid_n_0
    );
\FSM_sequential_state_read_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_sequential_state_read[1]_i_1_n_0\,
      Q => \^state_read\(1),
      R => arthur_liquid_n_0
    );
\FSM_sequential_state_write[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF0F7FF"
    )
        port map (
      I0 => \^axi_awready_reg_0\,
      I1 => s00_axi_awvalid,
      I2 => s00_axi_wvalid,
      I3 => \^state_write\(0),
      I4 => \^state_write\(1),
      O => \FSM_sequential_state_write[0]_i_1_n_0\
    );
\FSM_sequential_state_write[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF0F0800"
    )
        port map (
      I0 => s00_axi_awvalid,
      I1 => \^axi_awready_reg_0\,
      I2 => s00_axi_wvalid,
      I3 => \^state_write\(0),
      I4 => \^state_write\(1),
      O => \FSM_sequential_state_write[1]_i_1_n_0\
    );
\FSM_sequential_state_write_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_sequential_state_write[0]_i_1_n_0\,
      Q => \^state_write\(0),
      R => arthur_liquid_n_0
    );
\FSM_sequential_state_write_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_sequential_state_write[1]_i_1_n_0\,
      Q => \^state_write\(1),
      R => arthur_liquid_n_0
    );
arthur_liquid: entity work.design_1_liquid_0_1_arthur
     port map (
      D(7 downto 0) => \^d\(7 downto 0),
      Q(8 downto 0) => slv_reg2(8 downto 0),
      SR(0) => arthur_liquid_n_0,
      counter_out0_out => counter_out0_out,
      counter_out0_out_10 => counter_out0_out_10,
      counter_out0_out_12 => counter_out0_out_12,
      counter_out0_out_14 => counter_out0_out_14,
      counter_out0_out_16 => counter_out0_out_16,
      counter_out0_out_18 => counter_out0_out_18,
      counter_out0_out_20 => counter_out0_out_20,
      counter_out0_out_8 => counter_out0_out_8,
      counter_out_reg => counter_out_reg,
      counter_out_reg_0 => counter_out_reg_0,
      counter_out_reg_1 => counter_out_reg_1,
      counter_out_reg_2 => counter_out_reg_2,
      counter_out_reg_3 => counter_out_reg_3,
      counter_out_reg_4 => counter_out_reg_4,
      counter_out_reg_5 => counter_out_reg_5,
      counter_out_reg_6 => counter_out_reg_6,
      \liquid_division_reg_reg[8]_0\(8 downto 0) => slv_reg10(8 downto 0),
      p_2_in(0) => p_2_in(0),
      prev_was_load_reg_0 => count_clk_cycles1,
      prev_was_load_reg_1 => count_clk_cycles1_7,
      prev_was_load_reg_2 => count_clk_cycles1_9,
      prev_was_load_reg_3 => count_clk_cycles1_11,
      prev_was_load_reg_4 => count_clk_cycles1_13,
      prev_was_load_reg_5 => count_clk_cycles1_15,
      prev_was_load_reg_6 => count_clk_cycles1_17,
      prev_was_load_reg_7 => count_clk_cycles1_19,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_aresetn => s00_axi_aresetn,
      \seconds_relay_1__8_carry__0_i_7_0\(8 downto 0) => slv_reg3(8 downto 0),
      \seconds_relay_2__8_carry__0_i_7_0\(8 downto 0) => slv_reg4(8 downto 0),
      \seconds_relay_3__8_carry__0_i_7_0\(8 downto 0) => slv_reg5(8 downto 0),
      \seconds_relay_4__8_carry__0_i_7_0\(8 downto 0) => slv_reg6(8 downto 0),
      \seconds_relay_5__8_carry__0_i_7_0\(8 downto 0) => slv_reg7(8 downto 0),
      \seconds_relay_6__8_carry__0_i_7_0\(8 downto 0) => slv_reg8(8 downto 0),
      \seconds_relay_7__8_carry__0_i_7_0\(8 downto 0) => slv_reg9(8 downto 0),
      started_reg => started,
      started_reg_0 => started_0,
      started_reg_1 => started_1,
      started_reg_2 => started_2,
      started_reg_3 => started_3,
      started_reg_4 => started_4,
      started_reg_5 => started_5,
      started_reg_6 => started_6,
      \state_reg[2]\ => \state_reg[2]\,
      \state_reg[2]_0\ => \state_reg[2]_0\,
      \state_reg[2]_1\ => \state_reg[2]_1\,
      \state_reg[2]_2\ => \state_reg[2]_2\,
      \state_reg[2]_3\ => \state_reg[2]_3\,
      \state_reg[2]_4\ => \state_reg[2]_4\,
      \state_reg[2]_5\ => \state_reg[2]_5\,
      \state_reg[2]_6\ => \state_reg[2]_6\,
      \state_reg[7]\(7 downto 0) => slv_reg0(7 downto 0)
    );
\axi_araddr[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00008000"
    )
        port map (
      I0 => s00_axi_aresetn,
      I1 => \^axi_arready_reg_0\,
      I2 => s00_axi_arvalid,
      I3 => \^state_read\(0),
      I4 => \^state_read\(1),
      O => \axi_araddr[5]_i_1_n_0\
    );
\axi_araddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \axi_araddr[5]_i_1_n_0\,
      D => s00_axi_araddr(0),
      Q => sel0(0),
      R => '0'
    );
\axi_araddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \axi_araddr[5]_i_1_n_0\,
      D => s00_axi_araddr(1),
      Q => sel0(1),
      R => '0'
    );
\axi_araddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \axi_araddr[5]_i_1_n_0\,
      D => s00_axi_araddr(2),
      Q => sel0(2),
      R => '0'
    );
\axi_araddr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \axi_araddr[5]_i_1_n_0\,
      D => s00_axi_araddr(3),
      Q => sel0(3),
      R => '0'
    );
axi_arready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_arready_reg_1,
      Q => \^axi_arready_reg_0\,
      R => arthur_liquid_n_0
    );
\axi_awaddr[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \^state_write\(1),
      I1 => \^state_write\(0),
      I2 => s00_axi_awvalid,
      I3 => \^axi_awready_reg_0\,
      O => axi_awaddr
    );
\axi_awaddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awaddr,
      D => s00_axi_awaddr(0),
      Q => \axi_awaddr_reg_n_0_[2]\,
      R => arthur_liquid_n_0
    );
\axi_awaddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awaddr,
      D => s00_axi_awaddr(1),
      Q => \axi_awaddr_reg_n_0_[3]\,
      R => arthur_liquid_n_0
    );
\axi_awaddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awaddr,
      D => s00_axi_awaddr(2),
      Q => \axi_awaddr_reg_n_0_[4]\,
      R => arthur_liquid_n_0
    );
\axi_awaddr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awaddr,
      D => s00_axi_awaddr(3),
      Q => \axi_awaddr_reg_n_0_[5]\,
      R => arthur_liquid_n_0
    );
axi_awready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_awready_reg_1,
      Q => \^axi_awready_reg_0\,
      R => arthur_liquid_n_0
    );
axi_bvalid_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s00_axi_awvalid,
      I1 => \^axi_awready_reg_0\,
      O => \axi_awready0__0\
    );
axi_bvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_bvalid_reg_0,
      Q => s00_axi_bvalid,
      R => arthur_liquid_n_0
    );
axi_rvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_rvalid_reg_1,
      Q => \^axi_rvalid_reg_0\,
      R => arthur_liquid_n_0
    );
axi_wready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_wready_reg_0,
      Q => s00_axi_wready,
      R => arthur_liquid_n_0
    );
\s00_axi_rdata[0]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[0]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[0]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[0]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(0)
    );
\s00_axi_rdata[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(0),
      I1 => slv_reg10(0),
      I2 => sel0(1),
      I3 => slv_reg9(0),
      I4 => sel0(0),
      I5 => slv_reg8(0),
      O => \s00_axi_rdata[0]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(0),
      I1 => slv_reg6(0),
      I2 => sel0(1),
      I3 => slv_reg5(0),
      I4 => sel0(0),
      I5 => slv_reg4(0),
      O => \s00_axi_rdata[0]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(0),
      I1 => slv_reg2(0),
      I2 => sel0(1),
      I3 => p_2_in(0),
      I4 => sel0(0),
      I5 => slv_reg0(0),
      O => \s00_axi_rdata[0]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[10]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[10]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[10]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[10]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(10)
    );
\s00_axi_rdata[10]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(10),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(10),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(10),
      I5 => sel0(2),
      O => \s00_axi_rdata[10]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[10]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(10),
      I1 => \slv_reg6__0\(10),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(10),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(10),
      O => \s00_axi_rdata[10]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[10]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(10),
      I1 => \slv_reg2__0\(10),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[10]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(10),
      O => \s00_axi_rdata[10]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[11]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[11]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[11]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[11]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(11)
    );
\s00_axi_rdata[11]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(11),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(11),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(11),
      I5 => sel0(2),
      O => \s00_axi_rdata[11]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[11]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(11),
      I1 => \slv_reg6__0\(11),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(11),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(11),
      O => \s00_axi_rdata[11]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[11]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(11),
      I1 => \slv_reg2__0\(11),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[11]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(11),
      O => \s00_axi_rdata[11]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[12]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[12]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[12]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[12]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(12)
    );
\s00_axi_rdata[12]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(12),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(12),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(12),
      I5 => sel0(2),
      O => \s00_axi_rdata[12]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[12]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(12),
      I1 => \slv_reg6__0\(12),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(12),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(12),
      O => \s00_axi_rdata[12]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[12]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(12),
      I1 => \slv_reg2__0\(12),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[12]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(12),
      O => \s00_axi_rdata[12]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[13]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[13]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[13]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[13]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(13)
    );
\s00_axi_rdata[13]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(13),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(13),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(13),
      I5 => sel0(2),
      O => \s00_axi_rdata[13]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[13]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(13),
      I1 => \slv_reg6__0\(13),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(13),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(13),
      O => \s00_axi_rdata[13]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[13]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(13),
      I1 => \slv_reg2__0\(13),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[13]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(13),
      O => \s00_axi_rdata[13]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[14]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[14]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[14]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[14]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(14)
    );
\s00_axi_rdata[14]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(14),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(14),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(14),
      I5 => sel0(2),
      O => \s00_axi_rdata[14]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[14]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(14),
      I1 => \slv_reg6__0\(14),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(14),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(14),
      O => \s00_axi_rdata[14]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[14]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(14),
      I1 => \slv_reg2__0\(14),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[14]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(14),
      O => \s00_axi_rdata[14]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[15]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[15]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[15]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[15]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(15)
    );
\s00_axi_rdata[15]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(15),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(15),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(15),
      I5 => sel0(2),
      O => \s00_axi_rdata[15]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[15]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(15),
      I1 => \slv_reg6__0\(15),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(15),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(15),
      O => \s00_axi_rdata[15]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[15]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(15),
      I1 => \slv_reg2__0\(15),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[15]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(15),
      O => \s00_axi_rdata[15]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[16]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[16]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[16]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[16]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(16)
    );
\s00_axi_rdata[16]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(16),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(16),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(16),
      I5 => sel0(2),
      O => \s00_axi_rdata[16]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[16]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(16),
      I1 => \slv_reg6__0\(16),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(16),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(16),
      O => \s00_axi_rdata[16]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[16]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(16),
      I1 => \slv_reg2__0\(16),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[16]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(16),
      O => \s00_axi_rdata[16]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[17]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[17]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[17]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[17]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(17)
    );
\s00_axi_rdata[17]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(17),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(17),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(17),
      I5 => sel0(2),
      O => \s00_axi_rdata[17]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[17]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(17),
      I1 => \slv_reg6__0\(17),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(17),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(17),
      O => \s00_axi_rdata[17]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[17]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(17),
      I1 => \slv_reg2__0\(17),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[17]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(17),
      O => \s00_axi_rdata[17]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[18]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[18]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[18]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[18]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(18)
    );
\s00_axi_rdata[18]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(18),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(18),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(18),
      I5 => sel0(2),
      O => \s00_axi_rdata[18]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[18]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(18),
      I1 => \slv_reg6__0\(18),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(18),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(18),
      O => \s00_axi_rdata[18]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[18]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(18),
      I1 => \slv_reg2__0\(18),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[18]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(18),
      O => \s00_axi_rdata[18]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[19]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[19]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[19]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[19]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(19)
    );
\s00_axi_rdata[19]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(19),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(19),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(19),
      I5 => sel0(2),
      O => \s00_axi_rdata[19]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[19]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(19),
      I1 => \slv_reg6__0\(19),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(19),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(19),
      O => \s00_axi_rdata[19]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[19]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(19),
      I1 => \slv_reg2__0\(19),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[19]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(19),
      O => \s00_axi_rdata[19]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[1]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[1]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[1]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[1]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(1)
    );
\s00_axi_rdata[1]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(1),
      I1 => slv_reg10(1),
      I2 => sel0(1),
      I3 => slv_reg9(1),
      I4 => sel0(0),
      I5 => slv_reg8(1),
      O => \s00_axi_rdata[1]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[1]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(1),
      I1 => slv_reg6(1),
      I2 => sel0(1),
      I3 => slv_reg5(1),
      I4 => sel0(0),
      I5 => slv_reg4(1),
      O => \s00_axi_rdata[1]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[1]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(1),
      I1 => slv_reg2(1),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[1]\,
      I4 => sel0(0),
      I5 => slv_reg0(1),
      O => \s00_axi_rdata[1]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[20]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[20]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[20]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[20]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(20)
    );
\s00_axi_rdata[20]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(20),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(20),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(20),
      I5 => sel0(2),
      O => \s00_axi_rdata[20]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[20]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(20),
      I1 => \slv_reg6__0\(20),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(20),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(20),
      O => \s00_axi_rdata[20]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[20]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(20),
      I1 => \slv_reg2__0\(20),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[20]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(20),
      O => \s00_axi_rdata[20]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[21]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[21]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[21]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[21]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(21)
    );
\s00_axi_rdata[21]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(21),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(21),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(21),
      I5 => sel0(2),
      O => \s00_axi_rdata[21]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[21]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(21),
      I1 => \slv_reg6__0\(21),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(21),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(21),
      O => \s00_axi_rdata[21]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[21]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(21),
      I1 => \slv_reg2__0\(21),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[21]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(21),
      O => \s00_axi_rdata[21]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[22]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[22]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[22]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[22]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(22)
    );
\s00_axi_rdata[22]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(22),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(22),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(22),
      I5 => sel0(2),
      O => \s00_axi_rdata[22]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[22]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(22),
      I1 => \slv_reg6__0\(22),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(22),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(22),
      O => \s00_axi_rdata[22]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[22]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(22),
      I1 => \slv_reg2__0\(22),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[22]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(22),
      O => \s00_axi_rdata[22]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[23]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[23]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[23]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[23]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(23)
    );
\s00_axi_rdata[23]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(23),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(23),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(23),
      I5 => sel0(2),
      O => \s00_axi_rdata[23]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[23]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(23),
      I1 => \slv_reg6__0\(23),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(23),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(23),
      O => \s00_axi_rdata[23]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[23]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(23),
      I1 => \slv_reg2__0\(23),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[23]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(23),
      O => \s00_axi_rdata[23]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[24]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[24]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[24]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[24]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(24)
    );
\s00_axi_rdata[24]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(24),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(24),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(24),
      I5 => sel0(2),
      O => \s00_axi_rdata[24]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[24]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(24),
      I1 => \slv_reg6__0\(24),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(24),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(24),
      O => \s00_axi_rdata[24]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[24]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(24),
      I1 => \slv_reg2__0\(24),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[24]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(24),
      O => \s00_axi_rdata[24]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[25]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[25]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[25]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[25]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(25)
    );
\s00_axi_rdata[25]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(25),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(25),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(25),
      I5 => sel0(2),
      O => \s00_axi_rdata[25]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[25]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(25),
      I1 => \slv_reg6__0\(25),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(25),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(25),
      O => \s00_axi_rdata[25]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[25]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(25),
      I1 => \slv_reg2__0\(25),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[25]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(25),
      O => \s00_axi_rdata[25]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[26]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[26]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[26]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[26]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(26)
    );
\s00_axi_rdata[26]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(26),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(26),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(26),
      I5 => sel0(2),
      O => \s00_axi_rdata[26]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[26]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(26),
      I1 => \slv_reg6__0\(26),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(26),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(26),
      O => \s00_axi_rdata[26]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[26]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(26),
      I1 => \slv_reg2__0\(26),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[26]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(26),
      O => \s00_axi_rdata[26]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[27]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[27]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[27]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[27]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(27)
    );
\s00_axi_rdata[27]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(27),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(27),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(27),
      I5 => sel0(2),
      O => \s00_axi_rdata[27]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[27]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(27),
      I1 => \slv_reg6__0\(27),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(27),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(27),
      O => \s00_axi_rdata[27]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[27]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(27),
      I1 => \slv_reg2__0\(27),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[27]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(27),
      O => \s00_axi_rdata[27]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[28]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[28]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[28]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[28]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(28)
    );
\s00_axi_rdata[28]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(28),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(28),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(28),
      I5 => sel0(2),
      O => \s00_axi_rdata[28]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[28]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(28),
      I1 => \slv_reg6__0\(28),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(28),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(28),
      O => \s00_axi_rdata[28]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[28]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(28),
      I1 => \slv_reg2__0\(28),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[28]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(28),
      O => \s00_axi_rdata[28]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[29]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[29]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[29]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[29]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(29)
    );
\s00_axi_rdata[29]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(29),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(29),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(29),
      I5 => sel0(2),
      O => \s00_axi_rdata[29]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[29]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(29),
      I1 => \slv_reg6__0\(29),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(29),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(29),
      O => \s00_axi_rdata[29]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[29]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(29),
      I1 => \slv_reg2__0\(29),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[29]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(29),
      O => \s00_axi_rdata[29]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[2]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[2]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[2]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[2]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(2)
    );
\s00_axi_rdata[2]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(2),
      I1 => slv_reg10(2),
      I2 => sel0(1),
      I3 => slv_reg9(2),
      I4 => sel0(0),
      I5 => slv_reg8(2),
      O => \s00_axi_rdata[2]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[2]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(2),
      I1 => slv_reg6(2),
      I2 => sel0(1),
      I3 => slv_reg5(2),
      I4 => sel0(0),
      I5 => slv_reg4(2),
      O => \s00_axi_rdata[2]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[2]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(2),
      I1 => slv_reg2(2),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[2]\,
      I4 => sel0(0),
      I5 => slv_reg0(2),
      O => \s00_axi_rdata[2]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[30]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[30]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[30]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[30]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(30)
    );
\s00_axi_rdata[30]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(30),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(30),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(30),
      I5 => sel0(2),
      O => \s00_axi_rdata[30]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[30]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(30),
      I1 => \slv_reg6__0\(30),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(30),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(30),
      O => \s00_axi_rdata[30]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[30]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(30),
      I1 => \slv_reg2__0\(30),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[30]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(30),
      O => \s00_axi_rdata[30]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[31]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[31]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[31]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[31]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(31)
    );
\s00_axi_rdata[31]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(31),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(31),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(31),
      I5 => sel0(2),
      O => \s00_axi_rdata[31]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[31]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(31),
      I1 => \slv_reg6__0\(31),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(31),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(31),
      O => \s00_axi_rdata[31]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[31]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(31),
      I1 => \slv_reg2__0\(31),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[31]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(31),
      O => \s00_axi_rdata[31]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[3]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[3]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[3]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[3]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(3)
    );
\s00_axi_rdata[3]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(3),
      I1 => slv_reg10(3),
      I2 => sel0(1),
      I3 => slv_reg9(3),
      I4 => sel0(0),
      I5 => slv_reg8(3),
      O => \s00_axi_rdata[3]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[3]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(3),
      I1 => slv_reg6(3),
      I2 => sel0(1),
      I3 => slv_reg5(3),
      I4 => sel0(0),
      I5 => slv_reg4(3),
      O => \s00_axi_rdata[3]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[3]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(3),
      I1 => slv_reg2(3),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[3]\,
      I4 => sel0(0),
      I5 => slv_reg0(3),
      O => \s00_axi_rdata[3]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[4]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[4]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[4]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[4]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(4)
    );
\s00_axi_rdata[4]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(4),
      I1 => slv_reg10(4),
      I2 => sel0(1),
      I3 => slv_reg9(4),
      I4 => sel0(0),
      I5 => slv_reg8(4),
      O => \s00_axi_rdata[4]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[4]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(4),
      I1 => slv_reg6(4),
      I2 => sel0(1),
      I3 => slv_reg5(4),
      I4 => sel0(0),
      I5 => slv_reg4(4),
      O => \s00_axi_rdata[4]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[4]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(4),
      I1 => slv_reg2(4),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[4]\,
      I4 => sel0(0),
      I5 => slv_reg0(4),
      O => \s00_axi_rdata[4]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[5]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[5]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[5]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[5]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(5)
    );
\s00_axi_rdata[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(5),
      I1 => slv_reg10(5),
      I2 => sel0(1),
      I3 => slv_reg9(5),
      I4 => sel0(0),
      I5 => slv_reg8(5),
      O => \s00_axi_rdata[5]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[5]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(5),
      I1 => slv_reg6(5),
      I2 => sel0(1),
      I3 => slv_reg5(5),
      I4 => sel0(0),
      I5 => slv_reg4(5),
      O => \s00_axi_rdata[5]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[5]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(5),
      I1 => slv_reg2(5),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[5]\,
      I4 => sel0(0),
      I5 => slv_reg0(5),
      O => \s00_axi_rdata[5]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[6]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[6]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[6]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[6]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(6)
    );
\s00_axi_rdata[6]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(6),
      I1 => slv_reg10(6),
      I2 => sel0(1),
      I3 => slv_reg9(6),
      I4 => sel0(0),
      I5 => slv_reg8(6),
      O => \s00_axi_rdata[6]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[6]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(6),
      I1 => slv_reg6(6),
      I2 => sel0(1),
      I3 => slv_reg5(6),
      I4 => sel0(0),
      I5 => slv_reg4(6),
      O => \s00_axi_rdata[6]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[6]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(6),
      I1 => slv_reg2(6),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[6]\,
      I4 => sel0(0),
      I5 => slv_reg0(6),
      O => \s00_axi_rdata[6]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[7]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \s00_axi_rdata[7]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[7]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[7]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(7)
    );
\s00_axi_rdata[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(7),
      I1 => slv_reg10(7),
      I2 => sel0(1),
      I3 => slv_reg9(7),
      I4 => sel0(0),
      I5 => slv_reg8(7),
      O => \s00_axi_rdata[7]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[7]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(7),
      I1 => slv_reg6(7),
      I2 => sel0(1),
      I3 => slv_reg5(7),
      I4 => sel0(0),
      I5 => slv_reg4(7),
      O => \s00_axi_rdata[7]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[7]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(7),
      I1 => slv_reg2(7),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[7]\,
      I4 => sel0(0),
      I5 => slv_reg0(7),
      O => \s00_axi_rdata[7]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[8]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[8]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[8]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[8]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(8)
    );
\s00_axi_rdata[8]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => slv_reg8(8),
      I1 => sel0(0),
      I2 => slv_reg9(8),
      I3 => sel0(1),
      I4 => slv_reg10(8),
      I5 => sel0(2),
      O => \s00_axi_rdata[8]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[8]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(8),
      I1 => slv_reg6(8),
      I2 => sel0(1),
      I3 => slv_reg5(8),
      I4 => sel0(0),
      I5 => slv_reg4(8),
      O => \s00_axi_rdata[8]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[8]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg3(8),
      I1 => slv_reg2(8),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[8]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(8),
      O => \s00_axi_rdata[8]_INST_0_i_3_n_0\
    );
\s00_axi_rdata[9]_INST_0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \s00_axi_rdata[9]_INST_0_i_1_n_0\,
      I1 => sel0(3),
      I2 => \s00_axi_rdata[9]_INST_0_i_2_n_0\,
      I3 => sel0(2),
      I4 => \s00_axi_rdata[9]_INST_0_i_3_n_0\,
      O => s00_axi_rdata(9)
    );
\s00_axi_rdata[9]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033E200E2"
    )
        port map (
      I0 => \slv_reg8__0\(9),
      I1 => sel0(0),
      I2 => \slv_reg9__0\(9),
      I3 => sel0(1),
      I4 => \slv_reg10__0\(9),
      I5 => sel0(2),
      O => \s00_axi_rdata[9]_INST_0_i_1_n_0\
    );
\s00_axi_rdata[9]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg7__0\(9),
      I1 => \slv_reg6__0\(9),
      I2 => sel0(1),
      I3 => \slv_reg5__0\(9),
      I4 => sel0(0),
      I5 => \slv_reg4__0\(9),
      O => \s00_axi_rdata[9]_INST_0_i_2_n_0\
    );
\s00_axi_rdata[9]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \slv_reg3__0\(9),
      I1 => \slv_reg2__0\(9),
      I2 => sel0(1),
      I3 => \slv_reg1_reg_n_0_[9]\,
      I4 => sel0(0),
      I5 => \slv_reg0__0\(9),
      O => \s00_axi_rdata[9]_INST_0_i_3_n_0\
    );
\slv_reg0[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_2_n_0\,
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(1),
      O => p_1_in(15)
    );
\slv_reg0[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_2_n_0\,
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(2),
      O => p_1_in(23)
    );
\slv_reg0[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_2_n_0\,
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(3),
      O => p_1_in(31)
    );
\slv_reg0[31]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s00_axi_awaddr(0),
      I1 => s00_axi_awvalid,
      I2 => \axi_awaddr_reg_n_0_[2]\,
      O => \slv_reg0[31]_i_2_n_0\
    );
\slv_reg0[31]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s00_axi_awaddr(3),
      I1 => s00_axi_awvalid,
      I2 => \axi_awaddr_reg_n_0_[5]\,
      O => \slv_reg0[31]_i_3_n_0\
    );
\slv_reg0[31]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s00_axi_awaddr(1),
      I1 => s00_axi_awvalid,
      I2 => \axi_awaddr_reg_n_0_[3]\,
      O => \slv_reg0[31]_i_4_n_0\
    );
\slv_reg0[31]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s00_axi_awaddr(2),
      I1 => s00_axi_awvalid,
      I2 => \axi_awaddr_reg_n_0_[4]\,
      O => \slv_reg0[31]_i_5_n_0\
    );
\slv_reg0[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_2_n_0\,
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(0),
      O => p_1_in(7)
    );
\slv_reg0_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(0),
      Q => slv_reg0(0),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(10),
      Q => \slv_reg0__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(11),
      Q => \slv_reg0__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(12),
      Q => \slv_reg0__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(13),
      Q => \slv_reg0__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(14),
      Q => \slv_reg0__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(15),
      Q => \slv_reg0__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(16),
      Q => \slv_reg0__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(17),
      Q => \slv_reg0__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(18),
      Q => \slv_reg0__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(19),
      Q => \slv_reg0__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(1),
      Q => slv_reg0(1),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(20),
      Q => \slv_reg0__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(21),
      Q => \slv_reg0__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(22),
      Q => \slv_reg0__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(23),
      Q => \slv_reg0__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(24),
      Q => \slv_reg0__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(25),
      Q => \slv_reg0__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(26),
      Q => \slv_reg0__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(27),
      Q => \slv_reg0__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(28),
      Q => \slv_reg0__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(29),
      Q => \slv_reg0__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(2),
      Q => slv_reg0(2),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(30),
      Q => \slv_reg0__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(31),
      Q => \slv_reg0__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(3),
      Q => slv_reg0(3),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(4),
      Q => slv_reg0(4),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(5),
      Q => slv_reg0(5),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(6),
      Q => slv_reg0(6),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(7),
      D => s00_axi_wdata(7),
      Q => slv_reg0(7),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(8),
      Q => \slv_reg0__0\(8),
      R => arthur_liquid_n_0
    );
\slv_reg0_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(9),
      Q => \slv_reg0__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg10[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => s00_axi_wstrb(1),
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg10[15]_i_1_n_0\
    );
\slv_reg10[23]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => s00_axi_wstrb(2),
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg10[23]_i_1_n_0\
    );
\slv_reg10[31]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => s00_axi_wstrb(3),
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg10[31]_i_1_n_0\
    );
\slv_reg10[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => s00_axi_wstrb(0),
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg10[7]_i_1_n_0\
    );
\slv_reg10_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg10(0),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg10__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg10__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg10__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg10__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg10__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg10__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg10__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg10__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg10__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg10__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg10(1),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg10__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg10__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg10__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg10__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg10__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg10__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg10__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg10__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg10__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg10__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg10(2),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg10__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg10__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg10(3),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg10(4),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg10(5),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg10(6),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg10(7),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg10(8),
      R => arthur_liquid_n_0
    );
\slv_reg10_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg10[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg10__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(0),
      Q => slv_reg11(0),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(1),
      Q => slv_reg11(1),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(2),
      Q => slv_reg11(2),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(3),
      Q => slv_reg11(3),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(4),
      Q => slv_reg11(4),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(5),
      Q => slv_reg11(5),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(6),
      Q => slv_reg11(6),
      R => arthur_liquid_n_0
    );
\slv_reg11_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \^d\(7),
      Q => slv_reg11(7),
      R => arthur_liquid_n_0
    );
\slv_reg1[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000080000"
    )
        port map (
      I0 => s00_axi_wdata(0),
      I1 => \slv_reg0[31]_i_2_n_0\,
      I2 => \slv_reg1[0]_i_2_n_0\,
      I3 => \slv_reg1[0]_i_3_n_0\,
      I4 => s00_axi_wvalid,
      I5 => p_2_in(0),
      O => \slv_reg1[0]_i_1_n_0\
    );
\slv_reg1[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \axi_awaddr_reg_n_0_[4]\,
      I1 => s00_axi_awaddr(2),
      I2 => \axi_awaddr_reg_n_0_[3]\,
      I3 => s00_axi_awvalid,
      I4 => s00_axi_awaddr(1),
      O => \slv_reg1[0]_i_2_n_0\
    );
\slv_reg1[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E2FF"
    )
        port map (
      I0 => \axi_awaddr_reg_n_0_[5]\,
      I1 => s00_axi_awvalid,
      I2 => s00_axi_awaddr(3),
      I3 => s00_axi_wstrb(0),
      O => \slv_reg1[0]_i_3_n_0\
    );
\slv_reg1[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_2_n_0\,
      O => \slv_reg1[15]_i_1_n_0\
    );
\slv_reg1[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_2_n_0\,
      O => \slv_reg1[23]_i_1_n_0\
    );
\slv_reg1[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_2_n_0\,
      O => \slv_reg1[31]_i_1_n_0\
    );
\slv_reg1[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_2_n_0\,
      O => \slv_reg1[7]_i_1_n_0\
    );
\slv_reg1_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg1[0]_i_1_n_0\,
      Q => p_2_in(0),
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg1_reg_n_0_[10]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg1_reg_n_0_[11]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg1_reg_n_0_[12]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg1_reg_n_0_[13]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg1_reg_n_0_[14]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg1_reg_n_0_[15]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg1_reg_n_0_[16]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg1_reg_n_0_[17]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg1_reg_n_0_[18]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg1_reg_n_0_[19]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => \slv_reg1_reg_n_0_[1]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg1_reg_n_0_[20]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg1_reg_n_0_[21]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg1_reg_n_0_[22]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg1_reg_n_0_[23]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg1_reg_n_0_[24]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg1_reg_n_0_[25]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg1_reg_n_0_[26]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg1_reg_n_0_[27]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg1_reg_n_0_[28]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg1_reg_n_0_[29]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => \slv_reg1_reg_n_0_[2]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg1_reg_n_0_[30]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg1_reg_n_0_[31]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => \slv_reg1_reg_n_0_[3]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => \slv_reg1_reg_n_0_[4]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => \slv_reg1_reg_n_0_[5]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => \slv_reg1_reg_n_0_[6]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => \slv_reg1_reg_n_0_[7]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => \slv_reg1_reg_n_0_[8]\,
      R => arthur_liquid_n_0
    );
\slv_reg1_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg1[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg1_reg_n_0_[9]\,
      R => arthur_liquid_n_0
    );
\slv_reg2[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_4_n_0\,
      O => \slv_reg2[15]_i_1_n_0\
    );
\slv_reg2[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_4_n_0\,
      O => \slv_reg2[23]_i_1_n_0\
    );
\slv_reg2[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_4_n_0\,
      O => \slv_reg2[31]_i_1_n_0\
    );
\slv_reg2[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_4_n_0\,
      O => \slv_reg2[7]_i_1_n_0\
    );
\slv_reg2_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg2(0),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg2__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg2__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg2__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg2__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg2__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg2__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg2__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg2__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg2__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg2__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg2(1),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg2__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg2__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg2__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg2__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg2__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg2__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg2__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg2__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg2__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg2__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg2(2),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg2__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg2__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg2(3),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg2(4),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg2(5),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg2(6),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg2(7),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg2(8),
      R => arthur_liquid_n_0
    );
\slv_reg2_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg2[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg2__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg3[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg3[15]_i_1_n_0\
    );
\slv_reg3[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg3[23]_i_1_n_0\
    );
\slv_reg3[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg3[31]_i_1_n_0\
    );
\slv_reg3[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg3[7]_i_1_n_0\
    );
\slv_reg3_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg3(0),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg3__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg3__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg3__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg3__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg3__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg3__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg3__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg3__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg3__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg3__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg3(1),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg3__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg3__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg3__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg3__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg3__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg3__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg3__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg3__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg3__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg3__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg3(2),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg3__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg3__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg3(3),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg3(4),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg3(5),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg3(6),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg3(7),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg3(8),
      R => arthur_liquid_n_0
    );
\slv_reg3_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg3[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg3__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg4[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_2_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg4[15]_i_1_n_0\
    );
\slv_reg4[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_2_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg4[23]_i_1_n_0\
    );
\slv_reg4[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_2_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg4[31]_i_1_n_0\
    );
\slv_reg4[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_3_n_0\,
      I3 => \slv_reg0[31]_i_4_n_0\,
      I4 => \slv_reg0[31]_i_2_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg4[7]_i_1_n_0\
    );
\slv_reg4_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg4(0),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg4__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg4__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg4__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg4__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg4__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg4__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg4__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg4__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg4__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg4__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg4(1),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg4__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg4__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg4__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg4__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg4__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg4__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg4__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg4__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg4__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg4__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg4(2),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg4__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg4__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg4(3),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg4(4),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg4(5),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg4(6),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg4(7),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg4(8),
      R => arthur_liquid_n_0
    );
\slv_reg4_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg4__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg5[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_5_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg5[15]_i_1_n_0\
    );
\slv_reg5[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_5_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg5[23]_i_1_n_0\
    );
\slv_reg5[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_5_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg5[31]_i_1_n_0\
    );
\slv_reg5[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => \slv_reg0[31]_i_5_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg5[7]_i_1_n_0\
    );
\slv_reg5_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg5(0),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg5__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg5__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg5__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg5__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg5__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg5__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg5__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg5__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg5__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg5__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg5(1),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg5__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg5__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg5__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg5__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg5__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg5__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg5__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg5__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg5__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg5__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg5(2),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg5__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg5__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg5(3),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg5(4),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg5(5),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg5(6),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg5(7),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg5(8),
      R => arthur_liquid_n_0
    );
\slv_reg5_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg5__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg6[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(1),
      I2 => \slv_reg0[31]_i_5_n_0\,
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg6[15]_i_1_n_0\
    );
\slv_reg6[23]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(2),
      I2 => \slv_reg0[31]_i_5_n_0\,
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg6[23]_i_1_n_0\
    );
\slv_reg6[31]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(3),
      I2 => \slv_reg0[31]_i_5_n_0\,
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg6[31]_i_1_n_0\
    );
\slv_reg6[31]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CCAFFFAF"
    )
        port map (
      I0 => \axi_awaddr_reg_n_0_[2]\,
      I1 => s00_axi_awaddr(0),
      I2 => \axi_awaddr_reg_n_0_[3]\,
      I3 => s00_axi_awvalid,
      I4 => s00_axi_awaddr(1),
      O => \slv_reg6[31]_i_2_n_0\
    );
\slv_reg6[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => s00_axi_wstrb(0),
      I2 => \slv_reg0[31]_i_5_n_0\,
      I3 => \slv_reg6[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg6[7]_i_1_n_0\
    );
\slv_reg6_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg6(0),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg6__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg6__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg6__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg6__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg6__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg6__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg6__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg6__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg6__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg6__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg6(1),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg6__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg6__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg6__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg6__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg6__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg6__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg6__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg6__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg6__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg6__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg6(2),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg6__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg6__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg6(3),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg6(4),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg6(5),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg6(6),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg6(7),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg6(8),
      R => arthur_liquid_n_0
    );
\slv_reg6_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg6__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg7[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_5_n_0\,
      I2 => s00_axi_wstrb(1),
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg7[15]_i_1_n_0\
    );
\slv_reg7[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_5_n_0\,
      I2 => s00_axi_wstrb(2),
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg7[23]_i_1_n_0\
    );
\slv_reg7[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_5_n_0\,
      I2 => s00_axi_wstrb(3),
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg7[31]_i_1_n_0\
    );
\slv_reg7[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_5_n_0\,
      I2 => s00_axi_wstrb(0),
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_3_n_0\,
      O => \slv_reg7[7]_i_1_n_0\
    );
\slv_reg7_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg7(0),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg7__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg7__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg7__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg7__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg7__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg7__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg7__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg7__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg7__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg7__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg7(1),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg7__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg7__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg7__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg7__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg7__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg7__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg7__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg7__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg7__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg7__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg7(2),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg7__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg7__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg7(3),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg7(4),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg7(5),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg7(6),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg7(7),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg7(8),
      R => arthur_liquid_n_0
    );
\slv_reg7_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg7__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg8[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_4_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(1),
      O => \slv_reg8[15]_i_1_n_0\
    );
\slv_reg8[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_4_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(2),
      O => \slv_reg8[23]_i_1_n_0\
    );
\slv_reg8[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_4_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(3),
      O => \slv_reg8[31]_i_1_n_0\
    );
\slv_reg8[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_4_n_0\,
      I3 => \slv_reg0[31]_i_2_n_0\,
      I4 => \slv_reg0[31]_i_5_n_0\,
      I5 => s00_axi_wstrb(0),
      O => \slv_reg8[7]_i_1_n_0\
    );
\slv_reg8_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg8(0),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg8__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg8__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg8__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg8__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg8__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg8__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg8__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg8__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg8__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg8__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg8(1),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg8__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg8__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg8__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg8__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg8__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg8__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg8__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg8__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg8__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg8__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg8(2),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg8__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg8__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg8(3),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg8(4),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg8(5),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg8(6),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg8(7),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg8(8),
      R => arthur_liquid_n_0
    );
\slv_reg8_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg8__0\(9),
      R => arthur_liquid_n_0
    );
\slv_reg9[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => s00_axi_wstrb(1),
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg9[15]_i_1_n_0\
    );
\slv_reg9[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => s00_axi_wstrb(2),
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg9[23]_i_1_n_0\
    );
\slv_reg9[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => s00_axi_wstrb(3),
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg9[31]_i_1_n_0\
    );
\slv_reg9[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => s00_axi_wvalid,
      I1 => \slv_reg0[31]_i_3_n_0\,
      I2 => \slv_reg0[31]_i_2_n_0\,
      I3 => s00_axi_wstrb(0),
      I4 => \slv_reg0[31]_i_4_n_0\,
      I5 => \slv_reg0[31]_i_5_n_0\,
      O => \slv_reg9[7]_i_1_n_0\
    );
\slv_reg9_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg9(0),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => \slv_reg9__0\(10),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => \slv_reg9__0\(11),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => \slv_reg9__0\(12),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => \slv_reg9__0\(13),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => \slv_reg9__0\(14),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => \slv_reg9__0\(15),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => \slv_reg9__0\(16),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => \slv_reg9__0\(17),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => \slv_reg9__0\(18),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => \slv_reg9__0\(19),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg9(1),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => \slv_reg9__0\(20),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => \slv_reg9__0\(21),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => \slv_reg9__0\(22),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => \slv_reg9__0\(23),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => \slv_reg9__0\(24),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => \slv_reg9__0\(25),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => \slv_reg9__0\(26),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => \slv_reg9__0\(27),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => \slv_reg9__0\(28),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => \slv_reg9__0\(29),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg9(2),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => \slv_reg9__0\(30),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => \slv_reg9__0\(31),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg9(3),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg9(4),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg9(5),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg9(6),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg9(7),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg9(8),
      R => arthur_liquid_n_0
    );
\slv_reg9_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => \slv_reg9__0\(9),
      R => arthur_liquid_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1_liquid is
  port (
    axi_awready_reg : out STD_LOGIC;
    axi_arready_reg : out STD_LOGIC;
    axi_rvalid_reg : out STD_LOGIC;
    D : out STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_rready : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_bready : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_liquid_0_1_liquid : entity is "liquid";
end design_1_liquid_0_1_liquid;

architecture STRUCTURE of design_1_liquid_0_1_liquid is
  signal \^d\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \arthur_liquid/timer_0/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_0/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_0/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_1/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_1/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_1/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_2/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_2/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_2/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_3/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_3/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_3/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_4/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_4/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_4/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_5/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_5/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_5/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_6/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_6/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_6/started\ : STD_LOGIC;
  signal \arthur_liquid/timer_7/count_clk_cycles1\ : STD_LOGIC;
  signal \arthur_liquid/timer_7/counter_out0_out\ : STD_LOGIC;
  signal \arthur_liquid/timer_7/started\ : STD_LOGIC;
  signal axi_arready_i_1_n_0 : STD_LOGIC;
  signal \^axi_arready_reg\ : STD_LOGIC;
  signal \axi_awready0__0\ : STD_LOGIC;
  signal axi_awready_i_2_n_0 : STD_LOGIC;
  signal \^axi_awready_reg\ : STD_LOGIC;
  signal axi_bvalid_i_1_n_0 : STD_LOGIC;
  signal axi_rvalid_i_1_n_0 : STD_LOGIC;
  signal \^axi_rvalid_reg\ : STD_LOGIC;
  signal axi_wready_i_1_n_0 : STD_LOGIC;
  signal \counter_out_i_1__0_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__1_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__2_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__3_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__4_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__5_n_0\ : STD_LOGIC;
  signal \counter_out_i_1__6_n_0\ : STD_LOGIC;
  signal counter_out_i_1_n_0 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_42 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_43 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_44 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_45 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_46 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_47 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_48 : STD_LOGIC;
  signal liquid_slave_lite_v1_0_S00_AXI_inst_n_49 : STD_LOGIC;
  signal \^s00_axi_bvalid\ : STD_LOGIC;
  signal \^s00_axi_wready\ : STD_LOGIC;
  signal state_read : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal state_write : STD_LOGIC_VECTOR ( 1 downto 0 );
begin
  D(7 downto 0) <= \^d\(7 downto 0);
  axi_arready_reg <= \^axi_arready_reg\;
  axi_awready_reg <= \^axi_awready_reg\;
  axi_rvalid_reg <= \^axi_rvalid_reg\;
  s00_axi_bvalid <= \^s00_axi_bvalid\;
  s00_axi_wready <= \^s00_axi_wready\;
axi_arready_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C4C4C4C4FFCFCFCF"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^axi_arready_reg\,
      I2 => state_read(1),
      I3 => s00_axi_rready,
      I4 => \^axi_rvalid_reg\,
      I5 => state_read(0),
      O => axi_arready_i_1_n_0
    );
axi_awready_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CCC4FFCF"
    )
        port map (
      I0 => s00_axi_awvalid,
      I1 => \^axi_awready_reg\,
      I2 => state_write(1),
      I3 => s00_axi_wvalid,
      I4 => state_write(0),
      O => axi_awready_i_2_n_0
    );
axi_bvalid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFF3838C3FF0000"
    )
        port map (
      I0 => \axi_awready0__0\,
      I1 => state_write(0),
      I2 => state_write(1),
      I3 => s00_axi_bready,
      I4 => \^s00_axi_bvalid\,
      I5 => s00_axi_wvalid,
      O => axi_bvalid_i_1_n_0
    );
axi_rvalid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FFFFFF00800080"
    )
        port map (
      I0 => \^axi_arready_reg\,
      I1 => s00_axi_arvalid,
      I2 => state_read(0),
      I3 => state_read(1),
      I4 => s00_axi_rready,
      I5 => \^axi_rvalid_reg\,
      O => axi_rvalid_i_1_n_0
    );
axi_wready_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"F1"
    )
        port map (
      I0 => state_write(1),
      I1 => state_write(0),
      I2 => \^s00_axi_wready\,
      O => axi_wready_i_1_n_0
    );
counter_out_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_42,
      I1 => \arthur_liquid/timer_0/counter_out0_out\,
      I2 => \arthur_liquid/timer_0/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_0/started\,
      I4 => \^d\(0),
      O => counter_out_i_1_n_0
    );
\counter_out_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_43,
      I1 => \arthur_liquid/timer_1/counter_out0_out\,
      I2 => \arthur_liquid/timer_1/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_1/started\,
      I4 => \^d\(1),
      O => \counter_out_i_1__0_n_0\
    );
\counter_out_i_1__1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_44,
      I1 => \arthur_liquid/timer_2/counter_out0_out\,
      I2 => \arthur_liquid/timer_2/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_2/started\,
      I4 => \^d\(2),
      O => \counter_out_i_1__1_n_0\
    );
\counter_out_i_1__2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_45,
      I1 => \arthur_liquid/timer_3/counter_out0_out\,
      I2 => \arthur_liquid/timer_3/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_3/started\,
      I4 => \^d\(3),
      O => \counter_out_i_1__2_n_0\
    );
\counter_out_i_1__3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_46,
      I1 => \arthur_liquid/timer_4/counter_out0_out\,
      I2 => \arthur_liquid/timer_4/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_4/started\,
      I4 => \^d\(4),
      O => \counter_out_i_1__3_n_0\
    );
\counter_out_i_1__4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_47,
      I1 => \arthur_liquid/timer_5/counter_out0_out\,
      I2 => \arthur_liquid/timer_5/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_5/started\,
      I4 => \^d\(5),
      O => \counter_out_i_1__4_n_0\
    );
\counter_out_i_1__5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_48,
      I1 => \arthur_liquid/timer_6/counter_out0_out\,
      I2 => \arthur_liquid/timer_6/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_6/started\,
      I4 => \^d\(6),
      O => \counter_out_i_1__5_n_0\
    );
\counter_out_i_1__6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"ACAFACA0"
    )
        port map (
      I0 => liquid_slave_lite_v1_0_S00_AXI_inst_n_49,
      I1 => \arthur_liquid/timer_7/counter_out0_out\,
      I2 => \arthur_liquid/timer_7/count_clk_cycles1\,
      I3 => \arthur_liquid/timer_7/started\,
      I4 => \^d\(7),
      O => \counter_out_i_1__6_n_0\
    );
liquid_slave_lite_v1_0_S00_AXI_inst: entity work.design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI
     port map (
      D(7 downto 0) => \^d\(7 downto 0),
      axi_arready_reg_0 => \^axi_arready_reg\,
      axi_arready_reg_1 => axi_arready_i_1_n_0,
      \axi_awready0__0\ => \axi_awready0__0\,
      axi_awready_reg_0 => \^axi_awready_reg\,
      axi_awready_reg_1 => axi_awready_i_2_n_0,
      axi_bvalid_reg_0 => axi_bvalid_i_1_n_0,
      axi_rvalid_reg_0 => \^axi_rvalid_reg\,
      axi_rvalid_reg_1 => axi_rvalid_i_1_n_0,
      axi_wready_reg_0 => axi_wready_i_1_n_0,
      count_clk_cycles1 => \arthur_liquid/timer_0/count_clk_cycles1\,
      count_clk_cycles1_11 => \arthur_liquid/timer_3/count_clk_cycles1\,
      count_clk_cycles1_13 => \arthur_liquid/timer_4/count_clk_cycles1\,
      count_clk_cycles1_15 => \arthur_liquid/timer_5/count_clk_cycles1\,
      count_clk_cycles1_17 => \arthur_liquid/timer_6/count_clk_cycles1\,
      count_clk_cycles1_19 => \arthur_liquid/timer_7/count_clk_cycles1\,
      count_clk_cycles1_7 => \arthur_liquid/timer_1/count_clk_cycles1\,
      count_clk_cycles1_9 => \arthur_liquid/timer_2/count_clk_cycles1\,
      counter_out0_out => \arthur_liquid/timer_0/counter_out0_out\,
      counter_out0_out_10 => \arthur_liquid/timer_2/counter_out0_out\,
      counter_out0_out_12 => \arthur_liquid/timer_3/counter_out0_out\,
      counter_out0_out_14 => \arthur_liquid/timer_4/counter_out0_out\,
      counter_out0_out_16 => \arthur_liquid/timer_5/counter_out0_out\,
      counter_out0_out_18 => \arthur_liquid/timer_6/counter_out0_out\,
      counter_out0_out_20 => \arthur_liquid/timer_7/counter_out0_out\,
      counter_out0_out_8 => \arthur_liquid/timer_1/counter_out0_out\,
      counter_out_reg => counter_out_i_1_n_0,
      counter_out_reg_0 => \counter_out_i_1__0_n_0\,
      counter_out_reg_1 => \counter_out_i_1__1_n_0\,
      counter_out_reg_2 => \counter_out_i_1__2_n_0\,
      counter_out_reg_3 => \counter_out_i_1__3_n_0\,
      counter_out_reg_4 => \counter_out_i_1__4_n_0\,
      counter_out_reg_5 => \counter_out_i_1__5_n_0\,
      counter_out_reg_6 => \counter_out_i_1__6_n_0\,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(3 downto 0) => s00_axi_araddr(3 downto 0),
      s00_axi_aresetn => s00_axi_aresetn,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(3 downto 0) => s00_axi_awaddr(3 downto 0),
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bvalid => \^s00_axi_bvalid\,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rready => s00_axi_rready,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wready => \^s00_axi_wready\,
      s00_axi_wstrb(3 downto 0) => s00_axi_wstrb(3 downto 0),
      s00_axi_wvalid => s00_axi_wvalid,
      started => \arthur_liquid/timer_0/started\,
      started_0 => \arthur_liquid/timer_1/started\,
      started_1 => \arthur_liquid/timer_2/started\,
      started_2 => \arthur_liquid/timer_3/started\,
      started_3 => \arthur_liquid/timer_4/started\,
      started_4 => \arthur_liquid/timer_5/started\,
      started_5 => \arthur_liquid/timer_6/started\,
      started_6 => \arthur_liquid/timer_7/started\,
      state_read(1 downto 0) => state_read(1 downto 0),
      \state_reg[2]\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_42,
      \state_reg[2]_0\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_43,
      \state_reg[2]_1\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_44,
      \state_reg[2]_2\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_45,
      \state_reg[2]_3\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_46,
      \state_reg[2]_4\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_47,
      \state_reg[2]_5\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_48,
      \state_reg[2]_6\ => liquid_slave_lite_v1_0_S00_AXI_inst_n_49,
      state_write(1 downto 0) => state_write(1 downto 0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_liquid_0_1 is
  port (
    liquid_out : out STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 5 downto 0 );
    s00_axi_awprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_awready : out STD_LOGIC;
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    s00_axi_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 5 downto 0 );
    s00_axi_arprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_arready : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_rvalid : out STD_LOGIC;
    s00_axi_rready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_liquid_0_1 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_liquid_0_1 : entity is "design_1_liquid_0_1,liquid,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of design_1_liquid_0_1 : entity is "yes";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of design_1_liquid_0_1 : entity is "liquid,Vivado 2025.1";
end design_1_liquid_0_1;

architecture STRUCTURE of design_1_liquid_0_1 is
  signal \<const0>\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of s00_axi_aclk : signal is "xilinx.com:signal:clock:1.0 S00_AXI_CLK CLK";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of s00_axi_aclk : signal is "slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of s00_axi_aclk : signal is "XIL_INTERFACENAME S00_AXI_CLK, ASSOCIATED_BUSIF S00_AXI, ASSOCIATED_RESET s00_axi_aresetn, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of s00_axi_aresetn : signal is "xilinx.com:signal:reset:1.0 S00_AXI_RST RST";
  attribute X_INTERFACE_MODE of s00_axi_aresetn : signal is "slave";
  attribute X_INTERFACE_PARAMETER of s00_axi_aresetn : signal is "XIL_INTERFACENAME S00_AXI_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of s00_axi_arready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARREADY";
  attribute X_INTERFACE_INFO of s00_axi_arvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARVALID";
  attribute X_INTERFACE_INFO of s00_axi_awready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWREADY";
  attribute X_INTERFACE_INFO of s00_axi_awvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWVALID";
  attribute X_INTERFACE_INFO of s00_axi_bready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BREADY";
  attribute X_INTERFACE_INFO of s00_axi_bvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BVALID";
  attribute X_INTERFACE_INFO of s00_axi_rready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RREADY";
  attribute X_INTERFACE_INFO of s00_axi_rvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RVALID";
  attribute X_INTERFACE_INFO of s00_axi_wready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WREADY";
  attribute X_INTERFACE_INFO of s00_axi_wvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WVALID";
  attribute X_INTERFACE_INFO of s00_axi_araddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARADDR";
  attribute X_INTERFACE_INFO of s00_axi_arprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARPROT";
  attribute X_INTERFACE_INFO of s00_axi_awaddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWADDR";
  attribute X_INTERFACE_MODE of s00_axi_awaddr : signal is "slave";
  attribute X_INTERFACE_PARAMETER of s00_axi_awaddr : signal is "XIL_INTERFACENAME S00_AXI, WIZ_DATA_WIDTH 32, WIZ_NUM_REG 16, SUPPORTS_NARROW_BURST 0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 50000000, ID_WIDTH 0, ADDR_WIDTH 6, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0";
  attribute X_INTERFACE_INFO of s00_axi_awprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWPROT";
  attribute X_INTERFACE_INFO of s00_axi_bresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BRESP";
  attribute X_INTERFACE_INFO of s00_axi_rdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RDATA";
  attribute X_INTERFACE_INFO of s00_axi_rresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RRESP";
  attribute X_INTERFACE_INFO of s00_axi_wdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WDATA";
  attribute X_INTERFACE_INFO of s00_axi_wstrb : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WSTRB";
begin
  s00_axi_bresp(1) <= \<const0>\;
  s00_axi_bresp(0) <= \<const0>\;
  s00_axi_rresp(1) <= \<const0>\;
  s00_axi_rresp(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
inst: entity work.design_1_liquid_0_1_liquid
     port map (
      D(7 downto 0) => liquid_out(7 downto 0),
      axi_arready_reg => s00_axi_arready,
      axi_awready_reg => s00_axi_awready,
      axi_rvalid_reg => s00_axi_rvalid,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(3 downto 0) => s00_axi_araddr(5 downto 2),
      s00_axi_aresetn => s00_axi_aresetn,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(3 downto 0) => s00_axi_awaddr(5 downto 2),
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bready => s00_axi_bready,
      s00_axi_bvalid => s00_axi_bvalid,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rready => s00_axi_rready,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wready => s00_axi_wready,
      s00_axi_wstrb(3 downto 0) => s00_axi_wstrb(3 downto 0),
      s00_axi_wvalid => s00_axi_wvalid
    );
end STRUCTURE;
