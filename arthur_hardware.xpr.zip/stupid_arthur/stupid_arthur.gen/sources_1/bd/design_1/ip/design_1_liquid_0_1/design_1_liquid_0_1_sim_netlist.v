// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (lin64) Build 6140274 Wed May 21 22:58:25 MDT 2025
// Date        : Thu Dec  4 16:43:52 2025
// Host        : framed running 64-bit Arch Linux
// Command     : write_verilog -force -mode funcsim
//               /home/dom/Documents/FPGA_Projects/stupid_arthur/stupid_arthur.gen/sources_1/bd/design_1/ip/design_1_liquid_0_1/design_1_liquid_0_1_sim_netlist.v
// Design      : design_1_liquid_0_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z007sclg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_liquid_0_1,liquid,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* X_CORE_INFO = "liquid,Vivado 2025.1" *) 
(* NotValidForBitStream *)
module design_1_liquid_0_1
   (liquid_out,
    s00_axi_aclk,
    s00_axi_aresetn,
    s00_axi_awaddr,
    s00_axi_awprot,
    s00_axi_awvalid,
    s00_axi_awready,
    s00_axi_wdata,
    s00_axi_wstrb,
    s00_axi_wvalid,
    s00_axi_wready,
    s00_axi_bresp,
    s00_axi_bvalid,
    s00_axi_bready,
    s00_axi_araddr,
    s00_axi_arprot,
    s00_axi_arvalid,
    s00_axi_arready,
    s00_axi_rdata,
    s00_axi_rresp,
    s00_axi_rvalid,
    s00_axi_rready);
  output [7:0]liquid_out;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 S00_AXI_CLK CLK" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI_CLK, ASSOCIATED_BUSIF S00_AXI, ASSOCIATED_RESET s00_axi_aresetn, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *) input s00_axi_aclk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 S00_AXI_RST RST" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input s00_axi_aresetn;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWADDR" *) (* X_INTERFACE_MODE = "slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S00_AXI, WIZ_DATA_WIDTH 32, WIZ_NUM_REG 16, SUPPORTS_NARROW_BURST 0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 50000000, ID_WIDTH 0, ADDR_WIDTH 6, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, NUM_READ_OUTSTANDING 8, NUM_WRITE_OUTSTANDING 8, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *) input [5:0]s00_axi_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWPROT" *) input [2:0]s00_axi_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWVALID" *) input s00_axi_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI AWREADY" *) output s00_axi_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WDATA" *) input [31:0]s00_axi_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WSTRB" *) input [3:0]s00_axi_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WVALID" *) input s00_axi_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI WREADY" *) output s00_axi_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BRESP" *) output [1:0]s00_axi_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BVALID" *) output s00_axi_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI BREADY" *) input s00_axi_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARADDR" *) input [5:0]s00_axi_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARPROT" *) input [2:0]s00_axi_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARVALID" *) input s00_axi_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI ARREADY" *) output s00_axi_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RDATA" *) output [31:0]s00_axi_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RRESP" *) output [1:0]s00_axi_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RVALID" *) output s00_axi_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 S00_AXI RREADY" *) input s00_axi_rready;

  wire \<const0> ;
  wire [7:0]liquid_out;
  wire s00_axi_aclk;
  wire [5:0]s00_axi_araddr;
  wire s00_axi_aresetn;
  wire s00_axi_arready;
  wire s00_axi_arvalid;
  wire [5:0]s00_axi_awaddr;
  wire s00_axi_awready;
  wire s00_axi_awvalid;
  wire s00_axi_bready;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire s00_axi_rready;
  wire s00_axi_rvalid;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wready;
  wire [3:0]s00_axi_wstrb;
  wire s00_axi_wvalid;

  assign s00_axi_bresp[1] = \<const0> ;
  assign s00_axi_bresp[0] = \<const0> ;
  assign s00_axi_rresp[1] = \<const0> ;
  assign s00_axi_rresp[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  design_1_liquid_0_1_liquid inst
       (.D(liquid_out),
        .axi_arready_reg(s00_axi_arready),
        .axi_awready_reg(s00_axi_awready),
        .axi_rvalid_reg(s00_axi_rvalid),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_araddr(s00_axi_araddr[5:2]),
        .s00_axi_aresetn(s00_axi_aresetn),
        .s00_axi_arvalid(s00_axi_arvalid),
        .s00_axi_awaddr(s00_axi_awaddr[5:2]),
        .s00_axi_awvalid(s00_axi_awvalid),
        .s00_axi_bready(s00_axi_bready),
        .s00_axi_bvalid(s00_axi_bvalid),
        .s00_axi_rdata(s00_axi_rdata),
        .s00_axi_rready(s00_axi_rready),
        .s00_axi_wdata(s00_axi_wdata),
        .s00_axi_wready(s00_axi_wready),
        .s00_axi_wstrb(s00_axi_wstrb),
        .s00_axi_wvalid(s00_axi_wvalid));
endmodule

(* ORIG_REF_NAME = "arthur" *) 
module design_1_liquid_0_1_arthur
   (SR,
    D,
    started_reg,
    prev_was_load_reg_0,
    counter_out0_out,
    started_reg_0,
    prev_was_load_reg_1,
    counter_out0_out_8,
    started_reg_1,
    prev_was_load_reg_2,
    counter_out0_out_10,
    started_reg_2,
    prev_was_load_reg_3,
    counter_out0_out_12,
    started_reg_3,
    prev_was_load_reg_4,
    counter_out0_out_14,
    started_reg_4,
    prev_was_load_reg_5,
    counter_out0_out_16,
    started_reg_5,
    prev_was_load_reg_6,
    counter_out0_out_18,
    started_reg_6,
    prev_was_load_reg_7,
    counter_out0_out_20,
    \state_reg[2] ,
    \state_reg[2]_0 ,
    \state_reg[2]_1 ,
    \state_reg[2]_2 ,
    \state_reg[2]_3 ,
    \state_reg[2]_4 ,
    \state_reg[2]_5 ,
    \state_reg[2]_6 ,
    s00_axi_aclk,
    counter_out_reg,
    counter_out_reg_0,
    counter_out_reg_1,
    counter_out_reg_2,
    counter_out_reg_3,
    counter_out_reg_4,
    counter_out_reg_5,
    counter_out_reg_6,
    Q,
    seconds_relay_1__8_carry__0_i_7_0,
    seconds_relay_2__8_carry__0_i_7_0,
    seconds_relay_3__8_carry__0_i_7_0,
    seconds_relay_4__8_carry__0_i_7_0,
    seconds_relay_5__8_carry__0_i_7_0,
    seconds_relay_6__8_carry__0_i_7_0,
    seconds_relay_7__8_carry__0_i_7_0,
    s00_axi_aresetn,
    p_2_in,
    \state_reg[7] ,
    \liquid_division_reg_reg[8]_0 );
  output [0:0]SR;
  output [7:0]D;
  output started_reg;
  output prev_was_load_reg_0;
  output counter_out0_out;
  output started_reg_0;
  output prev_was_load_reg_1;
  output counter_out0_out_8;
  output started_reg_1;
  output prev_was_load_reg_2;
  output counter_out0_out_10;
  output started_reg_2;
  output prev_was_load_reg_3;
  output counter_out0_out_12;
  output started_reg_3;
  output prev_was_load_reg_4;
  output counter_out0_out_14;
  output started_reg_4;
  output prev_was_load_reg_5;
  output counter_out0_out_16;
  output started_reg_5;
  output prev_was_load_reg_6;
  output counter_out0_out_18;
  output started_reg_6;
  output prev_was_load_reg_7;
  output counter_out0_out_20;
  output \state_reg[2] ;
  output \state_reg[2]_0 ;
  output \state_reg[2]_1 ;
  output \state_reg[2]_2 ;
  output \state_reg[2]_3 ;
  output \state_reg[2]_4 ;
  output \state_reg[2]_5 ;
  output \state_reg[2]_6 ;
  input s00_axi_aclk;
  input counter_out_reg;
  input counter_out_reg_0;
  input counter_out_reg_1;
  input counter_out_reg_2;
  input counter_out_reg_3;
  input counter_out_reg_4;
  input counter_out_reg_5;
  input counter_out_reg_6;
  input [8:0]Q;
  input [8:0]seconds_relay_1__8_carry__0_i_7_0;
  input [8:0]seconds_relay_2__8_carry__0_i_7_0;
  input [8:0]seconds_relay_3__8_carry__0_i_7_0;
  input [8:0]seconds_relay_4__8_carry__0_i_7_0;
  input [8:0]seconds_relay_5__8_carry__0_i_7_0;
  input [8:0]seconds_relay_6__8_carry__0_i_7_0;
  input [8:0]seconds_relay_7__8_carry__0_i_7_0;
  input s00_axi_aresetn;
  input [0:0]p_2_in;
  input [7:0]\state_reg[7] ;
  input [8:0]\liquid_division_reg_reg[8]_0 ;

  wire [7:0]D;
  wire \FSM_onehot_current_state[3]_i_1_n_0 ;
  wire \FSM_onehot_current_state_reg_n_0_[1] ;
  wire \FSM_onehot_current_state_reg_n_0_[3] ;
  wire [8:0]Q;
  wire [0:0]SR;
  wire counter_out0_out;
  wire counter_out0_out_10;
  wire counter_out0_out_12;
  wire counter_out0_out_14;
  wire counter_out0_out_16;
  wire counter_out0_out_18;
  wire counter_out0_out_20;
  wire counter_out0_out_8;
  wire counter_out_reg;
  wire counter_out_reg_0;
  wire counter_out_reg_1;
  wire counter_out_reg_2;
  wire counter_out_reg_3;
  wire counter_out_reg_4;
  wire counter_out_reg_5;
  wire counter_out_reg_6;
  wire [8:0]liquid_division_reg;
  wire [8:0]\liquid_division_reg_reg[8]_0 ;
  wire load_liquid_division;
  wire p_0_in_0;
  wire [0:0]p_2_in;
  wire prev_was_load;
  wire prev_was_load_reg_0;
  wire prev_was_load_reg_1;
  wire prev_was_load_reg_2;
  wire prev_was_load_reg_3;
  wire prev_was_load_reg_4;
  wire prev_was_load_reg_5;
  wire prev_was_load_reg_6;
  wire prev_was_load_reg_7;
  wire reg_r0_n_0;
  wire reg_r0_n_1;
  wire reg_r0_n_11;
  wire reg_r0_n_12;
  wire reg_r0_n_13;
  wire reg_r0_n_14;
  wire reg_r0_n_15;
  wire reg_r0_n_16;
  wire reg_r0_n_17;
  wire reg_r0_n_18;
  wire reg_r0_n_19;
  wire reg_r0_n_2;
  wire reg_r0_n_20;
  wire reg_r0_n_21;
  wire reg_r0_n_22;
  wire reg_r0_n_3;
  wire reg_r0_n_5;
  wire reg_r0_n_6;
  wire reg_r0_n_7;
  wire reg_r0_n_8;
  wire reg_r0_n_9;
  wire reg_r1_n_0;
  wire reg_r1_n_1;
  wire reg_r1_n_11;
  wire reg_r1_n_12;
  wire reg_r1_n_13;
  wire reg_r1_n_14;
  wire reg_r1_n_15;
  wire reg_r1_n_16;
  wire reg_r1_n_17;
  wire reg_r1_n_18;
  wire reg_r1_n_19;
  wire reg_r1_n_2;
  wire reg_r1_n_20;
  wire reg_r1_n_21;
  wire reg_r1_n_22;
  wire reg_r1_n_3;
  wire reg_r1_n_5;
  wire reg_r1_n_6;
  wire reg_r1_n_7;
  wire reg_r1_n_8;
  wire reg_r1_n_9;
  wire reg_r2_n_0;
  wire reg_r2_n_1;
  wire reg_r2_n_11;
  wire reg_r2_n_12;
  wire reg_r2_n_13;
  wire reg_r2_n_14;
  wire reg_r2_n_15;
  wire reg_r2_n_16;
  wire reg_r2_n_17;
  wire reg_r2_n_18;
  wire reg_r2_n_19;
  wire reg_r2_n_2;
  wire reg_r2_n_20;
  wire reg_r2_n_21;
  wire reg_r2_n_22;
  wire reg_r2_n_3;
  wire reg_r2_n_5;
  wire reg_r2_n_6;
  wire reg_r2_n_7;
  wire reg_r2_n_8;
  wire reg_r2_n_9;
  wire reg_r3_n_0;
  wire reg_r3_n_1;
  wire reg_r3_n_11;
  wire reg_r3_n_12;
  wire reg_r3_n_13;
  wire reg_r3_n_14;
  wire reg_r3_n_15;
  wire reg_r3_n_16;
  wire reg_r3_n_17;
  wire reg_r3_n_18;
  wire reg_r3_n_19;
  wire reg_r3_n_2;
  wire reg_r3_n_20;
  wire reg_r3_n_21;
  wire reg_r3_n_22;
  wire reg_r3_n_3;
  wire reg_r3_n_5;
  wire reg_r3_n_6;
  wire reg_r3_n_7;
  wire reg_r3_n_8;
  wire reg_r3_n_9;
  wire reg_r4_n_0;
  wire reg_r4_n_1;
  wire reg_r4_n_11;
  wire reg_r4_n_12;
  wire reg_r4_n_13;
  wire reg_r4_n_14;
  wire reg_r4_n_15;
  wire reg_r4_n_16;
  wire reg_r4_n_17;
  wire reg_r4_n_18;
  wire reg_r4_n_19;
  wire reg_r4_n_2;
  wire reg_r4_n_20;
  wire reg_r4_n_21;
  wire reg_r4_n_22;
  wire reg_r4_n_3;
  wire reg_r4_n_5;
  wire reg_r4_n_6;
  wire reg_r4_n_7;
  wire reg_r4_n_8;
  wire reg_r4_n_9;
  wire reg_r5_n_0;
  wire reg_r5_n_1;
  wire reg_r5_n_11;
  wire reg_r5_n_12;
  wire reg_r5_n_13;
  wire reg_r5_n_14;
  wire reg_r5_n_15;
  wire reg_r5_n_16;
  wire reg_r5_n_17;
  wire reg_r5_n_18;
  wire reg_r5_n_19;
  wire reg_r5_n_2;
  wire reg_r5_n_20;
  wire reg_r5_n_21;
  wire reg_r5_n_22;
  wire reg_r5_n_3;
  wire reg_r5_n_5;
  wire reg_r5_n_6;
  wire reg_r5_n_7;
  wire reg_r5_n_8;
  wire reg_r5_n_9;
  wire reg_r6_n_0;
  wire reg_r6_n_1;
  wire reg_r6_n_11;
  wire reg_r6_n_12;
  wire reg_r6_n_13;
  wire reg_r6_n_14;
  wire reg_r6_n_15;
  wire reg_r6_n_16;
  wire reg_r6_n_17;
  wire reg_r6_n_18;
  wire reg_r6_n_19;
  wire reg_r6_n_2;
  wire reg_r6_n_20;
  wire reg_r6_n_21;
  wire reg_r6_n_22;
  wire reg_r6_n_3;
  wire reg_r6_n_5;
  wire reg_r6_n_6;
  wire reg_r6_n_7;
  wire reg_r6_n_8;
  wire reg_r6_n_9;
  wire reg_r7_n_0;
  wire reg_r7_n_1;
  wire reg_r7_n_11;
  wire reg_r7_n_12;
  wire reg_r7_n_13;
  wire reg_r7_n_14;
  wire reg_r7_n_15;
  wire reg_r7_n_16;
  wire reg_r7_n_17;
  wire reg_r7_n_18;
  wire reg_r7_n_19;
  wire reg_r7_n_2;
  wire reg_r7_n_20;
  wire reg_r7_n_21;
  wire reg_r7_n_22;
  wire reg_r7_n_3;
  wire reg_r7_n_5;
  wire reg_r7_n_6;
  wire reg_r7_n_7;
  wire reg_r7_n_8;
  wire reg_r7_n_9;
  wire [7:0]relay_register_out;
  wire s00_axi_aclk;
  wire s00_axi_aresetn;
  wire [1:0]seconds_relay_0;
  wire seconds_relay_0__274_carry__0_i_2_n_0;
  wire seconds_relay_0__274_carry__0_i_3_n_0;
  wire seconds_relay_0__274_carry__0_i_4_n_0;
  wire seconds_relay_0__274_carry__0_i_5_n_0;
  wire seconds_relay_0__274_carry__0_n_0;
  wire seconds_relay_0__274_carry__0_n_1;
  wire seconds_relay_0__274_carry__0_n_2;
  wire seconds_relay_0__274_carry__0_n_3;
  wire seconds_relay_0__274_carry__1_n_3;
  wire seconds_relay_0__274_carry_i_2_n_0;
  wire seconds_relay_0__274_carry_i_3_n_0;
  wire seconds_relay_0__274_carry_i_4_n_0;
  wire seconds_relay_0__274_carry_i_5_n_0;
  wire seconds_relay_0__274_carry_n_0;
  wire seconds_relay_0__274_carry_n_1;
  wire seconds_relay_0__274_carry_n_2;
  wire seconds_relay_0__274_carry_n_3;
  wire seconds_relay_0__8_carry__0_i_1_n_0;
  wire seconds_relay_0__8_carry__0_i_2_n_0;
  wire seconds_relay_0__8_carry__0_i_3_n_0;
  wire seconds_relay_0__8_carry__0_i_4_n_0;
  wire seconds_relay_0__8_carry__0_i_5_n_0;
  wire seconds_relay_0__8_carry__0_i_6_n_0;
  wire seconds_relay_0__8_carry__0_i_7_n_0;
  wire seconds_relay_0__8_carry__0_i_8_n_0;
  wire seconds_relay_0__8_carry__0_i_9_n_0;
  wire seconds_relay_0__8_carry__0_n_0;
  wire seconds_relay_0__8_carry__0_n_1;
  wire seconds_relay_0__8_carry__0_n_2;
  wire seconds_relay_0__8_carry__0_n_3;
  wire seconds_relay_0__8_carry__0_n_4;
  wire seconds_relay_0__8_carry__0_n_5;
  wire seconds_relay_0__8_carry__0_n_6;
  wire seconds_relay_0__8_carry__0_n_7;
  wire seconds_relay_0__8_carry__1_n_2;
  wire seconds_relay_0__8_carry__1_n_3;
  wire seconds_relay_0__8_carry__1_n_7;
  wire seconds_relay_0__8_carry_i_2_n_0;
  wire seconds_relay_0__8_carry_i_3_n_0;
  wire seconds_relay_0__8_carry_i_4_n_0;
  wire seconds_relay_0__8_carry_i_5_n_0;
  wire seconds_relay_0__8_carry_i_6_n_0;
  wire seconds_relay_0__8_carry_i_7_n_0;
  wire seconds_relay_0__8_carry_i_8_n_0;
  wire seconds_relay_0__8_carry_n_0;
  wire seconds_relay_0__8_carry_n_1;
  wire seconds_relay_0__8_carry_n_2;
  wire seconds_relay_0__8_carry_n_3;
  wire seconds_relay_0__8_carry_n_4;
  wire seconds_relay_0__8_carry_n_5;
  wire seconds_relay_0__8_carry_n_6;
  wire seconds_relay_0__8_carry_n_7;
  wire [1:0]seconds_relay_1;
  wire seconds_relay_1__274_carry__0_i_2_n_0;
  wire seconds_relay_1__274_carry__0_i_3_n_0;
  wire seconds_relay_1__274_carry__0_i_4_n_0;
  wire seconds_relay_1__274_carry__0_i_5_n_0;
  wire seconds_relay_1__274_carry__0_n_0;
  wire seconds_relay_1__274_carry__0_n_1;
  wire seconds_relay_1__274_carry__0_n_2;
  wire seconds_relay_1__274_carry__0_n_3;
  wire seconds_relay_1__274_carry__1_n_3;
  wire seconds_relay_1__274_carry_i_2_n_0;
  wire seconds_relay_1__274_carry_i_3_n_0;
  wire seconds_relay_1__274_carry_i_4_n_0;
  wire seconds_relay_1__274_carry_i_5_n_0;
  wire seconds_relay_1__274_carry_n_0;
  wire seconds_relay_1__274_carry_n_1;
  wire seconds_relay_1__274_carry_n_2;
  wire seconds_relay_1__274_carry_n_3;
  wire seconds_relay_1__8_carry__0_i_1_n_0;
  wire seconds_relay_1__8_carry__0_i_2_n_0;
  wire seconds_relay_1__8_carry__0_i_3_n_0;
  wire seconds_relay_1__8_carry__0_i_4_n_0;
  wire seconds_relay_1__8_carry__0_i_5_n_0;
  wire seconds_relay_1__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_1__8_carry__0_i_7_0;
  wire seconds_relay_1__8_carry__0_i_7_n_0;
  wire seconds_relay_1__8_carry__0_i_8_n_0;
  wire seconds_relay_1__8_carry__0_i_9_n_0;
  wire seconds_relay_1__8_carry__0_n_0;
  wire seconds_relay_1__8_carry__0_n_1;
  wire seconds_relay_1__8_carry__0_n_2;
  wire seconds_relay_1__8_carry__0_n_3;
  wire seconds_relay_1__8_carry__0_n_4;
  wire seconds_relay_1__8_carry__0_n_5;
  wire seconds_relay_1__8_carry__0_n_6;
  wire seconds_relay_1__8_carry__0_n_7;
  wire seconds_relay_1__8_carry__1_n_2;
  wire seconds_relay_1__8_carry__1_n_3;
  wire seconds_relay_1__8_carry__1_n_7;
  wire seconds_relay_1__8_carry_i_2_n_0;
  wire seconds_relay_1__8_carry_i_3_n_0;
  wire seconds_relay_1__8_carry_i_4_n_0;
  wire seconds_relay_1__8_carry_i_5_n_0;
  wire seconds_relay_1__8_carry_i_6_n_0;
  wire seconds_relay_1__8_carry_i_7_n_0;
  wire seconds_relay_1__8_carry_i_8_n_0;
  wire seconds_relay_1__8_carry_n_0;
  wire seconds_relay_1__8_carry_n_1;
  wire seconds_relay_1__8_carry_n_2;
  wire seconds_relay_1__8_carry_n_3;
  wire seconds_relay_1__8_carry_n_4;
  wire seconds_relay_1__8_carry_n_5;
  wire seconds_relay_1__8_carry_n_6;
  wire seconds_relay_1__8_carry_n_7;
  wire [1:0]seconds_relay_2;
  wire seconds_relay_2__274_carry__0_i_2_n_0;
  wire seconds_relay_2__274_carry__0_i_3_n_0;
  wire seconds_relay_2__274_carry__0_i_4_n_0;
  wire seconds_relay_2__274_carry__0_i_5_n_0;
  wire seconds_relay_2__274_carry__0_n_0;
  wire seconds_relay_2__274_carry__0_n_1;
  wire seconds_relay_2__274_carry__0_n_2;
  wire seconds_relay_2__274_carry__0_n_3;
  wire seconds_relay_2__274_carry__1_n_3;
  wire seconds_relay_2__274_carry_i_2_n_0;
  wire seconds_relay_2__274_carry_i_3_n_0;
  wire seconds_relay_2__274_carry_i_4_n_0;
  wire seconds_relay_2__274_carry_i_5_n_0;
  wire seconds_relay_2__274_carry_n_0;
  wire seconds_relay_2__274_carry_n_1;
  wire seconds_relay_2__274_carry_n_2;
  wire seconds_relay_2__274_carry_n_3;
  wire seconds_relay_2__8_carry__0_i_1_n_0;
  wire seconds_relay_2__8_carry__0_i_2_n_0;
  wire seconds_relay_2__8_carry__0_i_3_n_0;
  wire seconds_relay_2__8_carry__0_i_4_n_0;
  wire seconds_relay_2__8_carry__0_i_5_n_0;
  wire seconds_relay_2__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_2__8_carry__0_i_7_0;
  wire seconds_relay_2__8_carry__0_i_7_n_0;
  wire seconds_relay_2__8_carry__0_i_8_n_0;
  wire seconds_relay_2__8_carry__0_i_9_n_0;
  wire seconds_relay_2__8_carry__0_n_0;
  wire seconds_relay_2__8_carry__0_n_1;
  wire seconds_relay_2__8_carry__0_n_2;
  wire seconds_relay_2__8_carry__0_n_3;
  wire seconds_relay_2__8_carry__0_n_4;
  wire seconds_relay_2__8_carry__0_n_5;
  wire seconds_relay_2__8_carry__0_n_6;
  wire seconds_relay_2__8_carry__0_n_7;
  wire seconds_relay_2__8_carry__1_n_2;
  wire seconds_relay_2__8_carry__1_n_3;
  wire seconds_relay_2__8_carry__1_n_7;
  wire seconds_relay_2__8_carry_i_2_n_0;
  wire seconds_relay_2__8_carry_i_3_n_0;
  wire seconds_relay_2__8_carry_i_4_n_0;
  wire seconds_relay_2__8_carry_i_5_n_0;
  wire seconds_relay_2__8_carry_i_6_n_0;
  wire seconds_relay_2__8_carry_i_7_n_0;
  wire seconds_relay_2__8_carry_i_8_n_0;
  wire seconds_relay_2__8_carry_n_0;
  wire seconds_relay_2__8_carry_n_1;
  wire seconds_relay_2__8_carry_n_2;
  wire seconds_relay_2__8_carry_n_3;
  wire seconds_relay_2__8_carry_n_4;
  wire seconds_relay_2__8_carry_n_5;
  wire seconds_relay_2__8_carry_n_6;
  wire seconds_relay_2__8_carry_n_7;
  wire [1:0]seconds_relay_3;
  wire seconds_relay_3__274_carry__0_i_2_n_0;
  wire seconds_relay_3__274_carry__0_i_3_n_0;
  wire seconds_relay_3__274_carry__0_i_4_n_0;
  wire seconds_relay_3__274_carry__0_i_5_n_0;
  wire seconds_relay_3__274_carry__0_n_0;
  wire seconds_relay_3__274_carry__0_n_1;
  wire seconds_relay_3__274_carry__0_n_2;
  wire seconds_relay_3__274_carry__0_n_3;
  wire seconds_relay_3__274_carry__1_n_3;
  wire seconds_relay_3__274_carry_i_2_n_0;
  wire seconds_relay_3__274_carry_i_3_n_0;
  wire seconds_relay_3__274_carry_i_4_n_0;
  wire seconds_relay_3__274_carry_i_5_n_0;
  wire seconds_relay_3__274_carry_n_0;
  wire seconds_relay_3__274_carry_n_1;
  wire seconds_relay_3__274_carry_n_2;
  wire seconds_relay_3__274_carry_n_3;
  wire seconds_relay_3__8_carry__0_i_1_n_0;
  wire seconds_relay_3__8_carry__0_i_2_n_0;
  wire seconds_relay_3__8_carry__0_i_3_n_0;
  wire seconds_relay_3__8_carry__0_i_4_n_0;
  wire seconds_relay_3__8_carry__0_i_5_n_0;
  wire seconds_relay_3__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_3__8_carry__0_i_7_0;
  wire seconds_relay_3__8_carry__0_i_7_n_0;
  wire seconds_relay_3__8_carry__0_i_8_n_0;
  wire seconds_relay_3__8_carry__0_i_9_n_0;
  wire seconds_relay_3__8_carry__0_n_0;
  wire seconds_relay_3__8_carry__0_n_1;
  wire seconds_relay_3__8_carry__0_n_2;
  wire seconds_relay_3__8_carry__0_n_3;
  wire seconds_relay_3__8_carry__0_n_4;
  wire seconds_relay_3__8_carry__0_n_5;
  wire seconds_relay_3__8_carry__0_n_6;
  wire seconds_relay_3__8_carry__0_n_7;
  wire seconds_relay_3__8_carry__1_n_2;
  wire seconds_relay_3__8_carry__1_n_3;
  wire seconds_relay_3__8_carry__1_n_7;
  wire seconds_relay_3__8_carry_i_2_n_0;
  wire seconds_relay_3__8_carry_i_3_n_0;
  wire seconds_relay_3__8_carry_i_4_n_0;
  wire seconds_relay_3__8_carry_i_5_n_0;
  wire seconds_relay_3__8_carry_i_6_n_0;
  wire seconds_relay_3__8_carry_i_7_n_0;
  wire seconds_relay_3__8_carry_i_8_n_0;
  wire seconds_relay_3__8_carry_n_0;
  wire seconds_relay_3__8_carry_n_1;
  wire seconds_relay_3__8_carry_n_2;
  wire seconds_relay_3__8_carry_n_3;
  wire seconds_relay_3__8_carry_n_4;
  wire seconds_relay_3__8_carry_n_5;
  wire seconds_relay_3__8_carry_n_6;
  wire seconds_relay_3__8_carry_n_7;
  wire [1:0]seconds_relay_4;
  wire seconds_relay_4__274_carry__0_i_2_n_0;
  wire seconds_relay_4__274_carry__0_i_3_n_0;
  wire seconds_relay_4__274_carry__0_i_4_n_0;
  wire seconds_relay_4__274_carry__0_i_5_n_0;
  wire seconds_relay_4__274_carry__0_n_0;
  wire seconds_relay_4__274_carry__0_n_1;
  wire seconds_relay_4__274_carry__0_n_2;
  wire seconds_relay_4__274_carry__0_n_3;
  wire seconds_relay_4__274_carry__1_n_3;
  wire seconds_relay_4__274_carry_i_2_n_0;
  wire seconds_relay_4__274_carry_i_3_n_0;
  wire seconds_relay_4__274_carry_i_4_n_0;
  wire seconds_relay_4__274_carry_i_5_n_0;
  wire seconds_relay_4__274_carry_n_0;
  wire seconds_relay_4__274_carry_n_1;
  wire seconds_relay_4__274_carry_n_2;
  wire seconds_relay_4__274_carry_n_3;
  wire seconds_relay_4__8_carry__0_i_1_n_0;
  wire seconds_relay_4__8_carry__0_i_2_n_0;
  wire seconds_relay_4__8_carry__0_i_3_n_0;
  wire seconds_relay_4__8_carry__0_i_4_n_0;
  wire seconds_relay_4__8_carry__0_i_5_n_0;
  wire seconds_relay_4__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_4__8_carry__0_i_7_0;
  wire seconds_relay_4__8_carry__0_i_7_n_0;
  wire seconds_relay_4__8_carry__0_i_8_n_0;
  wire seconds_relay_4__8_carry__0_i_9_n_0;
  wire seconds_relay_4__8_carry__0_n_0;
  wire seconds_relay_4__8_carry__0_n_1;
  wire seconds_relay_4__8_carry__0_n_2;
  wire seconds_relay_4__8_carry__0_n_3;
  wire seconds_relay_4__8_carry__0_n_4;
  wire seconds_relay_4__8_carry__0_n_5;
  wire seconds_relay_4__8_carry__0_n_6;
  wire seconds_relay_4__8_carry__0_n_7;
  wire seconds_relay_4__8_carry__1_n_2;
  wire seconds_relay_4__8_carry__1_n_3;
  wire seconds_relay_4__8_carry__1_n_7;
  wire seconds_relay_4__8_carry_i_2_n_0;
  wire seconds_relay_4__8_carry_i_3_n_0;
  wire seconds_relay_4__8_carry_i_4_n_0;
  wire seconds_relay_4__8_carry_i_5_n_0;
  wire seconds_relay_4__8_carry_i_6_n_0;
  wire seconds_relay_4__8_carry_i_7_n_0;
  wire seconds_relay_4__8_carry_i_8_n_0;
  wire seconds_relay_4__8_carry_n_0;
  wire seconds_relay_4__8_carry_n_1;
  wire seconds_relay_4__8_carry_n_2;
  wire seconds_relay_4__8_carry_n_3;
  wire seconds_relay_4__8_carry_n_4;
  wire seconds_relay_4__8_carry_n_5;
  wire seconds_relay_4__8_carry_n_6;
  wire seconds_relay_4__8_carry_n_7;
  wire [1:0]seconds_relay_5;
  wire seconds_relay_5__274_carry__0_i_2_n_0;
  wire seconds_relay_5__274_carry__0_i_3_n_0;
  wire seconds_relay_5__274_carry__0_i_4_n_0;
  wire seconds_relay_5__274_carry__0_i_5_n_0;
  wire seconds_relay_5__274_carry__0_n_0;
  wire seconds_relay_5__274_carry__0_n_1;
  wire seconds_relay_5__274_carry__0_n_2;
  wire seconds_relay_5__274_carry__0_n_3;
  wire seconds_relay_5__274_carry__1_n_3;
  wire seconds_relay_5__274_carry_i_2_n_0;
  wire seconds_relay_5__274_carry_i_3_n_0;
  wire seconds_relay_5__274_carry_i_4_n_0;
  wire seconds_relay_5__274_carry_i_5_n_0;
  wire seconds_relay_5__274_carry_n_0;
  wire seconds_relay_5__274_carry_n_1;
  wire seconds_relay_5__274_carry_n_2;
  wire seconds_relay_5__274_carry_n_3;
  wire seconds_relay_5__8_carry__0_i_1_n_0;
  wire seconds_relay_5__8_carry__0_i_2_n_0;
  wire seconds_relay_5__8_carry__0_i_3_n_0;
  wire seconds_relay_5__8_carry__0_i_4_n_0;
  wire seconds_relay_5__8_carry__0_i_5_n_0;
  wire seconds_relay_5__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_5__8_carry__0_i_7_0;
  wire seconds_relay_5__8_carry__0_i_7_n_0;
  wire seconds_relay_5__8_carry__0_i_8_n_0;
  wire seconds_relay_5__8_carry__0_i_9_n_0;
  wire seconds_relay_5__8_carry__0_n_0;
  wire seconds_relay_5__8_carry__0_n_1;
  wire seconds_relay_5__8_carry__0_n_2;
  wire seconds_relay_5__8_carry__0_n_3;
  wire seconds_relay_5__8_carry__0_n_4;
  wire seconds_relay_5__8_carry__0_n_5;
  wire seconds_relay_5__8_carry__0_n_6;
  wire seconds_relay_5__8_carry__0_n_7;
  wire seconds_relay_5__8_carry__1_n_2;
  wire seconds_relay_5__8_carry__1_n_3;
  wire seconds_relay_5__8_carry__1_n_7;
  wire seconds_relay_5__8_carry_i_2_n_0;
  wire seconds_relay_5__8_carry_i_3_n_0;
  wire seconds_relay_5__8_carry_i_4_n_0;
  wire seconds_relay_5__8_carry_i_5_n_0;
  wire seconds_relay_5__8_carry_i_6_n_0;
  wire seconds_relay_5__8_carry_i_7_n_0;
  wire seconds_relay_5__8_carry_i_8_n_0;
  wire seconds_relay_5__8_carry_n_0;
  wire seconds_relay_5__8_carry_n_1;
  wire seconds_relay_5__8_carry_n_2;
  wire seconds_relay_5__8_carry_n_3;
  wire seconds_relay_5__8_carry_n_4;
  wire seconds_relay_5__8_carry_n_5;
  wire seconds_relay_5__8_carry_n_6;
  wire seconds_relay_5__8_carry_n_7;
  wire [1:0]seconds_relay_6;
  wire seconds_relay_6__274_carry__0_i_2_n_0;
  wire seconds_relay_6__274_carry__0_i_3_n_0;
  wire seconds_relay_6__274_carry__0_i_4_n_0;
  wire seconds_relay_6__274_carry__0_i_5_n_0;
  wire seconds_relay_6__274_carry__0_n_0;
  wire seconds_relay_6__274_carry__0_n_1;
  wire seconds_relay_6__274_carry__0_n_2;
  wire seconds_relay_6__274_carry__0_n_3;
  wire seconds_relay_6__274_carry__1_n_3;
  wire seconds_relay_6__274_carry_i_2_n_0;
  wire seconds_relay_6__274_carry_i_3_n_0;
  wire seconds_relay_6__274_carry_i_4_n_0;
  wire seconds_relay_6__274_carry_i_5_n_0;
  wire seconds_relay_6__274_carry_n_0;
  wire seconds_relay_6__274_carry_n_1;
  wire seconds_relay_6__274_carry_n_2;
  wire seconds_relay_6__274_carry_n_3;
  wire seconds_relay_6__8_carry__0_i_1_n_0;
  wire seconds_relay_6__8_carry__0_i_2_n_0;
  wire seconds_relay_6__8_carry__0_i_3_n_0;
  wire seconds_relay_6__8_carry__0_i_4_n_0;
  wire seconds_relay_6__8_carry__0_i_5_n_0;
  wire seconds_relay_6__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_6__8_carry__0_i_7_0;
  wire seconds_relay_6__8_carry__0_i_7_n_0;
  wire seconds_relay_6__8_carry__0_i_8_n_0;
  wire seconds_relay_6__8_carry__0_i_9_n_0;
  wire seconds_relay_6__8_carry__0_n_0;
  wire seconds_relay_6__8_carry__0_n_1;
  wire seconds_relay_6__8_carry__0_n_2;
  wire seconds_relay_6__8_carry__0_n_3;
  wire seconds_relay_6__8_carry__0_n_4;
  wire seconds_relay_6__8_carry__0_n_5;
  wire seconds_relay_6__8_carry__0_n_6;
  wire seconds_relay_6__8_carry__0_n_7;
  wire seconds_relay_6__8_carry__1_n_2;
  wire seconds_relay_6__8_carry__1_n_3;
  wire seconds_relay_6__8_carry__1_n_7;
  wire seconds_relay_6__8_carry_i_2_n_0;
  wire seconds_relay_6__8_carry_i_3_n_0;
  wire seconds_relay_6__8_carry_i_4_n_0;
  wire seconds_relay_6__8_carry_i_5_n_0;
  wire seconds_relay_6__8_carry_i_6_n_0;
  wire seconds_relay_6__8_carry_i_7_n_0;
  wire seconds_relay_6__8_carry_i_8_n_0;
  wire seconds_relay_6__8_carry_n_0;
  wire seconds_relay_6__8_carry_n_1;
  wire seconds_relay_6__8_carry_n_2;
  wire seconds_relay_6__8_carry_n_3;
  wire seconds_relay_6__8_carry_n_4;
  wire seconds_relay_6__8_carry_n_5;
  wire seconds_relay_6__8_carry_n_6;
  wire seconds_relay_6__8_carry_n_7;
  wire [1:0]seconds_relay_7;
  wire seconds_relay_7__274_carry__0_i_2_n_0;
  wire seconds_relay_7__274_carry__0_i_3_n_0;
  wire seconds_relay_7__274_carry__0_i_4_n_0;
  wire seconds_relay_7__274_carry__0_i_5_n_0;
  wire seconds_relay_7__274_carry__0_n_0;
  wire seconds_relay_7__274_carry__0_n_1;
  wire seconds_relay_7__274_carry__0_n_2;
  wire seconds_relay_7__274_carry__0_n_3;
  wire seconds_relay_7__274_carry__1_n_3;
  wire seconds_relay_7__274_carry_i_2_n_0;
  wire seconds_relay_7__274_carry_i_3_n_0;
  wire seconds_relay_7__274_carry_i_4_n_0;
  wire seconds_relay_7__274_carry_i_5_n_0;
  wire seconds_relay_7__274_carry_n_0;
  wire seconds_relay_7__274_carry_n_1;
  wire seconds_relay_7__274_carry_n_2;
  wire seconds_relay_7__274_carry_n_3;
  wire seconds_relay_7__8_carry__0_i_1_n_0;
  wire seconds_relay_7__8_carry__0_i_2_n_0;
  wire seconds_relay_7__8_carry__0_i_3_n_0;
  wire seconds_relay_7__8_carry__0_i_4_n_0;
  wire seconds_relay_7__8_carry__0_i_5_n_0;
  wire seconds_relay_7__8_carry__0_i_6_n_0;
  wire [8:0]seconds_relay_7__8_carry__0_i_7_0;
  wire seconds_relay_7__8_carry__0_i_7_n_0;
  wire seconds_relay_7__8_carry__0_i_8_n_0;
  wire seconds_relay_7__8_carry__0_i_9_n_0;
  wire seconds_relay_7__8_carry__0_n_0;
  wire seconds_relay_7__8_carry__0_n_1;
  wire seconds_relay_7__8_carry__0_n_2;
  wire seconds_relay_7__8_carry__0_n_3;
  wire seconds_relay_7__8_carry__0_n_4;
  wire seconds_relay_7__8_carry__0_n_5;
  wire seconds_relay_7__8_carry__0_n_6;
  wire seconds_relay_7__8_carry__0_n_7;
  wire seconds_relay_7__8_carry__1_n_2;
  wire seconds_relay_7__8_carry__1_n_3;
  wire seconds_relay_7__8_carry__1_n_7;
  wire seconds_relay_7__8_carry_i_2_n_0;
  wire seconds_relay_7__8_carry_i_3_n_0;
  wire seconds_relay_7__8_carry_i_4_n_0;
  wire seconds_relay_7__8_carry_i_5_n_0;
  wire seconds_relay_7__8_carry_i_6_n_0;
  wire seconds_relay_7__8_carry_i_7_n_0;
  wire seconds_relay_7__8_carry_i_8_n_0;
  wire seconds_relay_7__8_carry_n_0;
  wire seconds_relay_7__8_carry_n_1;
  wire seconds_relay_7__8_carry_n_2;
  wire seconds_relay_7__8_carry_n_3;
  wire seconds_relay_7__8_carry_n_4;
  wire seconds_relay_7__8_carry_n_5;
  wire seconds_relay_7__8_carry_n_6;
  wire seconds_relay_7__8_carry_n_7;
  wire started_reg;
  wire started_reg_0;
  wire started_reg_1;
  wire started_reg_2;
  wire started_reg_3;
  wire started_reg_4;
  wire started_reg_5;
  wire started_reg_6;
  wire \state_reg[2] ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_1 ;
  wire \state_reg[2]_2 ;
  wire \state_reg[2]_3 ;
  wire \state_reg[2]_4 ;
  wire \state_reg[2]_5 ;
  wire \state_reg[2]_6 ;
  wire [7:0]\state_reg[7] ;
  wire timer_2_n_3;
  wire timer_2_n_4;
  wire timer_5_n_3;
  wire [3:0]NLW_seconds_relay_0__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_0__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_0__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_0__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_0__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_0__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_1__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_1__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_1__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_1__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_1__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_1__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_2__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_2__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_2__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_2__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_2__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_2__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_3__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_3__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_3__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_3__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_3__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_3__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_4__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_4__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_4__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_4__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_4__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_4__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_5__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_5__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_5__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_5__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_5__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_5__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_6__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_6__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_6__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_6__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_6__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_6__8_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_7__274_carry_O_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_7__274_carry__0_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_7__274_carry__1_CO_UNCONNECTED;
  wire [3:0]NLW_seconds_relay_7__274_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_seconds_relay_7__8_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_seconds_relay_7__8_carry__1_O_UNCONNECTED;

  LUT2 #(
    .INIT(4'h8)) 
    \FSM_onehot_current_state[3]_i_1 
       (.I0(load_liquid_division),
        .I1(p_2_in),
        .O(\FSM_onehot_current_state[3]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010" *) 
  FDPE #(
    .INIT(1'b1)) 
    \FSM_onehot_current_state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(timer_2_n_4),
        .PRE(SR),
        .Q(load_liquid_division));
  (* FSM_ENCODED_STATES = "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_current_state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .CLR(SR),
        .D(timer_2_n_3),
        .Q(\FSM_onehot_current_state_reg_n_0_[1] ));
  (* FSM_ENCODED_STATES = "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_current_state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .CLR(SR),
        .D(\FSM_onehot_current_state_reg_n_0_[3] ),
        .Q(p_0_in_0));
  (* FSM_ENCODED_STATES = "WAIT:0100,LOAD:1000,IDLE:0001,PROCESS:0010" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_current_state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .CLR(SR),
        .D(\FSM_onehot_current_state[3]_i_1_n_0 ),
        .Q(\FSM_onehot_current_state_reg_n_0_[3] ));
  LUT1 #(
    .INIT(2'h1)) 
    axi_awready_i_1
       (.I0(s00_axi_aresetn),
        .O(SR));
  FDPE \liquid_division_reg_reg[0] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .D(\liquid_division_reg_reg[8]_0 [0]),
        .PRE(SR),
        .Q(liquid_division_reg[0]));
  FDCE \liquid_division_reg_reg[1] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [1]),
        .Q(liquid_division_reg[1]));
  FDPE \liquid_division_reg_reg[2] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .D(\liquid_division_reg_reg[8]_0 [2]),
        .PRE(SR),
        .Q(liquid_division_reg[2]));
  FDCE \liquid_division_reg_reg[3] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [3]),
        .Q(liquid_division_reg[3]));
  FDPE \liquid_division_reg_reg[4] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .D(\liquid_division_reg_reg[8]_0 [4]),
        .PRE(SR),
        .Q(liquid_division_reg[4]));
  FDCE \liquid_division_reg_reg[5] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [5]),
        .Q(liquid_division_reg[5]));
  FDCE \liquid_division_reg_reg[6] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [6]),
        .Q(liquid_division_reg[6]));
  FDCE \liquid_division_reg_reg[7] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [7]),
        .Q(liquid_division_reg[7]));
  FDCE \liquid_division_reg_reg[8] 
       (.C(s00_axi_aclk),
        .CE(load_liquid_division),
        .CLR(SR),
        .D(\liquid_division_reg_reg[8]_0 [8]),
        .Q(liquid_division_reg[8]));
  FDCE prev_was_load_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .CLR(SR),
        .D(\FSM_onehot_current_state_reg_n_0_[3] ),
        .Q(prev_was_load));
  design_1_liquid_0_1_register__parameterized0 reg_r0
       (.CO(seconds_relay_0__8_carry__1_n_2),
        .D(seconds_relay_0[0]),
        .DI({reg_r0_n_2,reg_r0_n_3}),
        .O({seconds_relay_0__8_carry_n_4,seconds_relay_0__8_carry_n_5,seconds_relay_0__8_carry_n_6,seconds_relay_0__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r0_n_19,reg_r0_n_20}),
        .\liquid_division_reg_reg[3] (reg_r0_n_1),
        .\liquid_division_reg_reg[7] (reg_r0_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_0[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r0_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_0__8_carry__0_i_6({Q[8],Q[6:1]}),
        .\slv_reg2_reg[1] ({reg_r0_n_11,reg_r0_n_12,reg_r0_n_13}),
        .\slv_reg2_reg[1]_0 ({reg_r0_n_14,reg_r0_n_15,reg_r0_n_16,reg_r0_n_17}),
        .\state_reg[1]_i_1_0 ({reg_r0_n_21,reg_r0_n_22}),
        .\state_reg[2]_0 (\state_reg[2] ),
        .\state_reg[4]_0 ({reg_r0_n_5,reg_r0_n_6,reg_r0_n_7,reg_r0_n_8,reg_r0_n_9}),
        .\state_reg[4]_1 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[4]_i_14_0 ({seconds_relay_0__8_carry__0_n_4,seconds_relay_0__8_carry__0_n_5,seconds_relay_0__8_carry__0_n_6,seconds_relay_0__8_carry__0_n_7}),
        .\state_reg[4]_i_14_1 (seconds_relay_0__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_0 reg_r1
       (.CO(seconds_relay_1__8_carry__1_n_2),
        .D(seconds_relay_1[0]),
        .DI({reg_r1_n_2,reg_r1_n_3}),
        .O({seconds_relay_1__8_carry_n_4,seconds_relay_1__8_carry_n_5,seconds_relay_1__8_carry_n_6,seconds_relay_1__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r1_n_19,reg_r1_n_20}),
        .\liquid_division_reg_reg[3] (reg_r1_n_1),
        .\liquid_division_reg_reg[7] (reg_r1_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_1[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r1_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_1__8_carry__0_i_6({seconds_relay_1__8_carry__0_i_7_0[8],seconds_relay_1__8_carry__0_i_7_0[6:1]}),
        .\slv_reg3_reg[1] ({reg_r1_n_11,reg_r1_n_12,reg_r1_n_13}),
        .\slv_reg3_reg[1]_0 ({reg_r1_n_14,reg_r1_n_15,reg_r1_n_16,reg_r1_n_17}),
        .\state_reg[0]_0 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[1]_i_1__0_0 ({reg_r1_n_21,reg_r1_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_0 ),
        .\state_reg[4]_0 ({reg_r1_n_5,reg_r1_n_6,reg_r1_n_7,reg_r1_n_8,reg_r1_n_9}),
        .\state_reg[4]_i_14__0_0 ({seconds_relay_1__8_carry__0_n_4,seconds_relay_1__8_carry__0_n_5,seconds_relay_1__8_carry__0_n_6,seconds_relay_1__8_carry__0_n_7}),
        .\state_reg[4]_i_14__0_1 (seconds_relay_1__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_1 reg_r2
       (.CO(seconds_relay_2__8_carry__1_n_2),
        .D(seconds_relay_2[0]),
        .DI({reg_r2_n_2,reg_r2_n_3}),
        .O({seconds_relay_2__8_carry_n_4,seconds_relay_2__8_carry_n_5,seconds_relay_2__8_carry_n_6,seconds_relay_2__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r2_n_19,reg_r2_n_20}),
        .\liquid_division_reg_reg[3] (reg_r2_n_1),
        .\liquid_division_reg_reg[7] (reg_r2_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_2[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r2_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_2__8_carry__0_i_6({seconds_relay_2__8_carry__0_i_7_0[8],seconds_relay_2__8_carry__0_i_7_0[6:1]}),
        .\slv_reg4_reg[1] ({reg_r2_n_11,reg_r2_n_12,reg_r2_n_13}),
        .\slv_reg4_reg[1]_0 ({reg_r2_n_14,reg_r2_n_15,reg_r2_n_16,reg_r2_n_17}),
        .\state_reg[1]_i_1__1_0 ({reg_r2_n_21,reg_r2_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_1 ),
        .\state_reg[4]_0 ({reg_r2_n_5,reg_r2_n_6,reg_r2_n_7,reg_r2_n_8,reg_r2_n_9}),
        .\state_reg[4]_1 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[4]_i_14__1_0 ({seconds_relay_2__8_carry__0_n_4,seconds_relay_2__8_carry__0_n_5,seconds_relay_2__8_carry__0_n_6,seconds_relay_2__8_carry__0_n_7}),
        .\state_reg[4]_i_14__1_1 (seconds_relay_2__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_2 reg_r3
       (.CO(seconds_relay_3__8_carry__1_n_2),
        .D(seconds_relay_3[0]),
        .DI({reg_r3_n_2,reg_r3_n_3}),
        .O({seconds_relay_3__8_carry_n_4,seconds_relay_3__8_carry_n_5,seconds_relay_3__8_carry_n_6,seconds_relay_3__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r3_n_19,reg_r3_n_20}),
        .\liquid_division_reg_reg[3] (reg_r3_n_1),
        .\liquid_division_reg_reg[7] (reg_r3_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_3[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r3_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_3__8_carry__0_i_6({seconds_relay_3__8_carry__0_i_7_0[8],seconds_relay_3__8_carry__0_i_7_0[6:1]}),
        .\slv_reg5_reg[1] ({reg_r3_n_11,reg_r3_n_12,reg_r3_n_13}),
        .\slv_reg5_reg[1]_0 ({reg_r3_n_14,reg_r3_n_15,reg_r3_n_16,reg_r3_n_17}),
        .\state_reg[0]_0 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[1]_i_1__2_0 ({reg_r3_n_21,reg_r3_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_2 ),
        .\state_reg[4]_0 ({reg_r3_n_5,reg_r3_n_6,reg_r3_n_7,reg_r3_n_8,reg_r3_n_9}),
        .\state_reg[4]_i_14__2_0 ({seconds_relay_3__8_carry__0_n_4,seconds_relay_3__8_carry__0_n_5,seconds_relay_3__8_carry__0_n_6,seconds_relay_3__8_carry__0_n_7}),
        .\state_reg[4]_i_14__2_1 (seconds_relay_3__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_3 reg_r4
       (.CO(seconds_relay_4__8_carry__1_n_2),
        .D(seconds_relay_4[0]),
        .DI({reg_r4_n_2,reg_r4_n_3}),
        .O({seconds_relay_4__8_carry_n_4,seconds_relay_4__8_carry_n_5,seconds_relay_4__8_carry_n_6,seconds_relay_4__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r4_n_19,reg_r4_n_20}),
        .\liquid_division_reg_reg[3] (reg_r4_n_1),
        .\liquid_division_reg_reg[7] (reg_r4_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_4[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r4_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_4__8_carry__0_i_6({seconds_relay_4__8_carry__0_i_7_0[8],seconds_relay_4__8_carry__0_i_7_0[6:1]}),
        .\slv_reg6_reg[1] ({reg_r4_n_11,reg_r4_n_12,reg_r4_n_13}),
        .\slv_reg6_reg[1]_0 ({reg_r4_n_14,reg_r4_n_15,reg_r4_n_16,reg_r4_n_17}),
        .\state_reg[1]_i_1__3_0 ({reg_r4_n_21,reg_r4_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_3 ),
        .\state_reg[4]_0 ({reg_r4_n_5,reg_r4_n_6,reg_r4_n_7,reg_r4_n_8,reg_r4_n_9}),
        .\state_reg[4]_1 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[4]_i_14__3_0 ({seconds_relay_4__8_carry__0_n_4,seconds_relay_4__8_carry__0_n_5,seconds_relay_4__8_carry__0_n_6,seconds_relay_4__8_carry__0_n_7}),
        .\state_reg[4]_i_14__3_1 (seconds_relay_4__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_4 reg_r5
       (.CO(seconds_relay_5__8_carry__1_n_2),
        .D(seconds_relay_5[0]),
        .DI({reg_r5_n_2,reg_r5_n_3}),
        .O({seconds_relay_5__8_carry_n_4,seconds_relay_5__8_carry_n_5,seconds_relay_5__8_carry_n_6,seconds_relay_5__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r5_n_19,reg_r5_n_20}),
        .\liquid_division_reg_reg[3] (reg_r5_n_1),
        .\liquid_division_reg_reg[7] (reg_r5_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_5[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r5_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_5__8_carry__0_i_6({seconds_relay_5__8_carry__0_i_7_0[8],seconds_relay_5__8_carry__0_i_7_0[6:1]}),
        .\slv_reg7_reg[1] ({reg_r5_n_11,reg_r5_n_12,reg_r5_n_13}),
        .\slv_reg7_reg[1]_0 ({reg_r5_n_14,reg_r5_n_15,reg_r5_n_16,reg_r5_n_17}),
        .\state_reg[0]_0 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[1]_i_1__4_0 ({reg_r5_n_21,reg_r5_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_4 ),
        .\state_reg[4]_0 ({reg_r5_n_5,reg_r5_n_6,reg_r5_n_7,reg_r5_n_8,reg_r5_n_9}),
        .\state_reg[4]_i_14__4_0 ({seconds_relay_5__8_carry__0_n_4,seconds_relay_5__8_carry__0_n_5,seconds_relay_5__8_carry__0_n_6,seconds_relay_5__8_carry__0_n_7}),
        .\state_reg[4]_i_14__4_1 (seconds_relay_5__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_5 reg_r6
       (.CO(seconds_relay_6__8_carry__1_n_2),
        .D(seconds_relay_6[0]),
        .DI({reg_r6_n_2,reg_r6_n_3}),
        .O({seconds_relay_6__8_carry_n_4,seconds_relay_6__8_carry_n_5,seconds_relay_6__8_carry_n_6,seconds_relay_6__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r6_n_19,reg_r6_n_20}),
        .\liquid_division_reg_reg[3] (reg_r6_n_1),
        .\liquid_division_reg_reg[7] (reg_r6_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_6[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r6_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_6__8_carry__0_i_6({seconds_relay_6__8_carry__0_i_7_0[8],seconds_relay_6__8_carry__0_i_7_0[6:1]}),
        .\slv_reg8_reg[1] ({reg_r6_n_11,reg_r6_n_12,reg_r6_n_13}),
        .\slv_reg8_reg[1]_0 ({reg_r6_n_14,reg_r6_n_15,reg_r6_n_16,reg_r6_n_17}),
        .\state_reg[1]_i_1__5_0 ({reg_r6_n_21,reg_r6_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_5 ),
        .\state_reg[4]_0 ({reg_r6_n_5,reg_r6_n_6,reg_r6_n_7,reg_r6_n_8,reg_r6_n_9}),
        .\state_reg[4]_1 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[4]_i_14__5_0 ({seconds_relay_6__8_carry__0_n_4,seconds_relay_6__8_carry__0_n_5,seconds_relay_6__8_carry__0_n_6,seconds_relay_6__8_carry__0_n_7}),
        .\state_reg[4]_i_14__5_1 (seconds_relay_6__8_carry__1_n_7));
  design_1_liquid_0_1_register__parameterized0_6 reg_r7
       (.CO(seconds_relay_7__8_carry__1_n_2),
        .D(seconds_relay_7[0]),
        .DI({reg_r7_n_2,reg_r7_n_3}),
        .O({seconds_relay_7__8_carry_n_4,seconds_relay_7__8_carry_n_5,seconds_relay_7__8_carry_n_6,seconds_relay_7__8_carry_n_7}),
        .Q(liquid_division_reg),
        .S({reg_r7_n_19,reg_r7_n_20}),
        .\liquid_division_reg_reg[3] (reg_r7_n_1),
        .\liquid_division_reg_reg[7] (reg_r7_n_0),
        .\liquid_division_reg_reg[8] (seconds_relay_7[1]),
        .\liquid_division_reg_reg[8]_0 (reg_r7_n_18),
        .s00_axi_aclk(s00_axi_aclk),
        .seconds_relay_7__8_carry__0_i_6({seconds_relay_7__8_carry__0_i_7_0[8],seconds_relay_7__8_carry__0_i_7_0[6:1]}),
        .\slv_reg9_reg[1] ({reg_r7_n_11,reg_r7_n_12,reg_r7_n_13}),
        .\slv_reg9_reg[1]_0 ({reg_r7_n_14,reg_r7_n_15,reg_r7_n_16,reg_r7_n_17}),
        .\state_reg[0]_0 ({\FSM_onehot_current_state_reg_n_0_[3] ,load_liquid_division}),
        .\state_reg[1]_i_1__6_0 ({reg_r7_n_21,reg_r7_n_22}),
        .\state_reg[2]_0 (\state_reg[2]_6 ),
        .\state_reg[4]_0 ({reg_r7_n_5,reg_r7_n_6,reg_r7_n_7,reg_r7_n_8,reg_r7_n_9}),
        .\state_reg[4]_i_14__6_0 ({seconds_relay_7__8_carry__0_n_4,seconds_relay_7__8_carry__0_n_5,seconds_relay_7__8_carry__0_n_6,seconds_relay_7__8_carry__0_n_7}),
        .\state_reg[4]_i_14__6_1 (seconds_relay_7__8_carry__1_n_7));
  design_1_liquid_0_1_register relay_reg
       (.Q({\FSM_onehot_current_state_reg_n_0_[3] ,p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0] (started_reg),
        .\count_clk_cycles_reg[0]_0 (started_reg_0),
        .\count_clk_cycles_reg[0]_1 (started_reg_1),
        .\count_clk_cycles_reg[0]_2 (started_reg_2),
        .\count_clk_cycles_reg[0]_3 (started_reg_3),
        .\count_clk_cycles_reg[0]_4 (started_reg_4),
        .\count_clk_cycles_reg[0]_5 (started_reg_5),
        .\count_clk_cycles_reg[0]_6 (started_reg_6),
        .prev_was_load(prev_was_load),
        .prev_was_load_reg(prev_was_load_reg_0),
        .prev_was_load_reg_0(prev_was_load_reg_1),
        .prev_was_load_reg_1(prev_was_load_reg_2),
        .prev_was_load_reg_2(prev_was_load_reg_3),
        .prev_was_load_reg_3(prev_was_load_reg_4),
        .prev_was_load_reg_4(prev_was_load_reg_5),
        .prev_was_load_reg_5(prev_was_load_reg_6),
        .prev_was_load_reg_6(prev_was_load_reg_7),
        .s00_axi_aclk(s00_axi_aclk),
        .\state_reg[7]_0 (relay_register_out),
        .\state_reg[7]_1 (\state_reg[7] ));
  CARRY4 seconds_relay_0__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_0__274_carry_n_0,seconds_relay_0__274_carry_n_1,seconds_relay_0__274_carry_n_2,seconds_relay_0__274_carry_n_3}),
        .CYINIT(seconds_relay_0[1]),
        .DI({reg_r0_n_11,reg_r0_n_12,reg_r0_n_13,Q[0]}),
        .O(NLW_seconds_relay_0__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_0__274_carry_i_2_n_0,seconds_relay_0__274_carry_i_3_n_0,seconds_relay_0__274_carry_i_4_n_0,seconds_relay_0__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_0__274_carry__0
       (.CI(seconds_relay_0__274_carry_n_0),
        .CO({seconds_relay_0__274_carry__0_n_0,seconds_relay_0__274_carry__0_n_1,seconds_relay_0__274_carry__0_n_2,seconds_relay_0__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r0_n_14,reg_r0_n_15,reg_r0_n_16,reg_r0_n_17}),
        .O(NLW_seconds_relay_0__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_0__274_carry__0_i_2_n_0,seconds_relay_0__274_carry__0_i_3_n_0,seconds_relay_0__274_carry__0_i_4_n_0,seconds_relay_0__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_2
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r0_n_14),
        .O(seconds_relay_0__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_3
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r0_n_15),
        .O(seconds_relay_0__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_4
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r0_n_16),
        .O(seconds_relay_0__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_5
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r0_n_17),
        .O(seconds_relay_0__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_0__274_carry__1
       (.CI(seconds_relay_0__274_carry__0_n_0),
        .CO({NLW_seconds_relay_0__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_0[0],seconds_relay_0__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_0[1],reg_r0_n_18}),
        .O(NLW_seconds_relay_0__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r0_n_21,reg_r0_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_2
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r0_n_11),
        .O(seconds_relay_0__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_3
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r0_n_12),
        .O(seconds_relay_0__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_4
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r0_n_13),
        .O(seconds_relay_0__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_5
       (.I0(seconds_relay_0[1]),
        .I1(liquid_division_reg[0]),
        .I2(Q[0]),
        .O(seconds_relay_0__274_carry_i_5_n_0));
  CARRY4 seconds_relay_0__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_0__8_carry_n_0,seconds_relay_0__8_carry_n_1,seconds_relay_0__8_carry_n_2,seconds_relay_0__8_carry_n_3}),
        .CYINIT(reg_r0_n_0),
        .DI({seconds_relay_0__8_carry_i_2_n_0,seconds_relay_0__8_carry_i_3_n_0,seconds_relay_0__8_carry_i_4_n_0,Q[7]}),
        .O({seconds_relay_0__8_carry_n_4,seconds_relay_0__8_carry_n_5,seconds_relay_0__8_carry_n_6,seconds_relay_0__8_carry_n_7}),
        .S({seconds_relay_0__8_carry_i_5_n_0,seconds_relay_0__8_carry_i_6_n_0,seconds_relay_0__8_carry_i_7_n_0,seconds_relay_0__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_0__8_carry__0
       (.CI(seconds_relay_0__8_carry_n_0),
        .CO({seconds_relay_0__8_carry__0_n_0,seconds_relay_0__8_carry__0_n_1,seconds_relay_0__8_carry__0_n_2,seconds_relay_0__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_0__8_carry__0_i_1_n_0,seconds_relay_0__8_carry__0_i_2_n_0,seconds_relay_0__8_carry__0_i_3_n_0,seconds_relay_0__8_carry__0_i_4_n_0}),
        .O({seconds_relay_0__8_carry__0_n_4,seconds_relay_0__8_carry__0_n_5,seconds_relay_0__8_carry__0_n_6,seconds_relay_0__8_carry__0_n_7}),
        .S({seconds_relay_0__8_carry__0_i_5_n_0,seconds_relay_0__8_carry__0_i_6_n_0,seconds_relay_0__8_carry__0_i_7_n_0,seconds_relay_0__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_0__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r0_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_0__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_0__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r0_n_1),
        .O(seconds_relay_0__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_0__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_0__8_carry__0_i_9_n_0),
        .O(seconds_relay_0__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_0__8_carry__0_i_8
       (.I0(seconds_relay_0__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(Q[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_0__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_0__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(Q[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_0__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_0__8_carry__1
       (.CI(seconds_relay_0__8_carry__0_n_0),
        .CO({NLW_seconds_relay_0__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_0__8_carry__1_n_2,seconds_relay_0__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r0_n_2,reg_r0_n_3}),
        .O({NLW_seconds_relay_0__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_0__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r0_n_19,reg_r0_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r0_n_0),
        .O(seconds_relay_0__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_0__8_carry_i_5
       (.I0(reg_r0_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(Q[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_0__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_0__8_carry_i_6
       (.I0(reg_r0_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(Q[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_0__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_0__8_carry_i_7
       (.I0(reg_r0_n_0),
        .I1(liquid_division_reg[1]),
        .I2(Q[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_0__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__8_carry_i_8
       (.I0(reg_r0_n_0),
        .I1(liquid_division_reg[0]),
        .I2(Q[7]),
        .O(seconds_relay_0__8_carry_i_8_n_0));
  CARRY4 seconds_relay_1__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_1__274_carry_n_0,seconds_relay_1__274_carry_n_1,seconds_relay_1__274_carry_n_2,seconds_relay_1__274_carry_n_3}),
        .CYINIT(seconds_relay_1[1]),
        .DI({reg_r1_n_11,reg_r1_n_12,reg_r1_n_13,seconds_relay_1__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_1__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_1__274_carry_i_2_n_0,seconds_relay_1__274_carry_i_3_n_0,seconds_relay_1__274_carry_i_4_n_0,seconds_relay_1__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_1__274_carry__0
       (.CI(seconds_relay_1__274_carry_n_0),
        .CO({seconds_relay_1__274_carry__0_n_0,seconds_relay_1__274_carry__0_n_1,seconds_relay_1__274_carry__0_n_2,seconds_relay_1__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r1_n_14,reg_r1_n_15,reg_r1_n_16,reg_r1_n_17}),
        .O(NLW_seconds_relay_1__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_1__274_carry__0_i_2_n_0,seconds_relay_1__274_carry__0_i_3_n_0,seconds_relay_1__274_carry__0_i_4_n_0,seconds_relay_1__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_2
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r1_n_14),
        .O(seconds_relay_1__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_3
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r1_n_15),
        .O(seconds_relay_1__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_4
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r1_n_16),
        .O(seconds_relay_1__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_5
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r1_n_17),
        .O(seconds_relay_1__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_1__274_carry__1
       (.CI(seconds_relay_1__274_carry__0_n_0),
        .CO({NLW_seconds_relay_1__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_1[0],seconds_relay_1__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_1[1],reg_r1_n_18}),
        .O(NLW_seconds_relay_1__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r1_n_21,reg_r1_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_2
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r1_n_11),
        .O(seconds_relay_1__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_3
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r1_n_12),
        .O(seconds_relay_1__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_4
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r1_n_13),
        .O(seconds_relay_1__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_5
       (.I0(seconds_relay_1[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_1__8_carry__0_i_7_0[0]),
        .O(seconds_relay_1__274_carry_i_5_n_0));
  CARRY4 seconds_relay_1__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_1__8_carry_n_0,seconds_relay_1__8_carry_n_1,seconds_relay_1__8_carry_n_2,seconds_relay_1__8_carry_n_3}),
        .CYINIT(reg_r1_n_0),
        .DI({seconds_relay_1__8_carry_i_2_n_0,seconds_relay_1__8_carry_i_3_n_0,seconds_relay_1__8_carry_i_4_n_0,seconds_relay_1__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_1__8_carry_n_4,seconds_relay_1__8_carry_n_5,seconds_relay_1__8_carry_n_6,seconds_relay_1__8_carry_n_7}),
        .S({seconds_relay_1__8_carry_i_5_n_0,seconds_relay_1__8_carry_i_6_n_0,seconds_relay_1__8_carry_i_7_n_0,seconds_relay_1__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_1__8_carry__0
       (.CI(seconds_relay_1__8_carry_n_0),
        .CO({seconds_relay_1__8_carry__0_n_0,seconds_relay_1__8_carry__0_n_1,seconds_relay_1__8_carry__0_n_2,seconds_relay_1__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_1__8_carry__0_i_1_n_0,seconds_relay_1__8_carry__0_i_2_n_0,seconds_relay_1__8_carry__0_i_3_n_0,seconds_relay_1__8_carry__0_i_4_n_0}),
        .O({seconds_relay_1__8_carry__0_n_4,seconds_relay_1__8_carry__0_n_5,seconds_relay_1__8_carry__0_n_6,seconds_relay_1__8_carry__0_n_7}),
        .S({seconds_relay_1__8_carry__0_i_5_n_0,seconds_relay_1__8_carry__0_i_6_n_0,seconds_relay_1__8_carry__0_i_7_n_0,seconds_relay_1__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_1__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r1_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_1__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_1__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r1_n_1),
        .O(seconds_relay_1__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_1__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_1__8_carry__0_i_9_n_0),
        .O(seconds_relay_1__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_1__8_carry__0_i_8
       (.I0(seconds_relay_1__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_1__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_1__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_1__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_1__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_1__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_1__8_carry__1
       (.CI(seconds_relay_1__8_carry__0_n_0),
        .CO({NLW_seconds_relay_1__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_1__8_carry__1_n_2,seconds_relay_1__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r1_n_2,reg_r1_n_3}),
        .O({NLW_seconds_relay_1__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_1__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r1_n_19,reg_r1_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r1_n_0),
        .O(seconds_relay_1__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_1__8_carry_i_5
       (.I0(reg_r1_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_1__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_1__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_1__8_carry_i_6
       (.I0(reg_r1_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_1__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_1__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_1__8_carry_i_7
       (.I0(reg_r1_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_1__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_1__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__8_carry_i_8
       (.I0(reg_r1_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_1__8_carry__0_i_7_0[7]),
        .O(seconds_relay_1__8_carry_i_8_n_0));
  CARRY4 seconds_relay_2__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_2__274_carry_n_0,seconds_relay_2__274_carry_n_1,seconds_relay_2__274_carry_n_2,seconds_relay_2__274_carry_n_3}),
        .CYINIT(seconds_relay_2[1]),
        .DI({reg_r2_n_11,reg_r2_n_12,reg_r2_n_13,seconds_relay_2__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_2__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_2__274_carry_i_2_n_0,seconds_relay_2__274_carry_i_3_n_0,seconds_relay_2__274_carry_i_4_n_0,seconds_relay_2__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_2__274_carry__0
       (.CI(seconds_relay_2__274_carry_n_0),
        .CO({seconds_relay_2__274_carry__0_n_0,seconds_relay_2__274_carry__0_n_1,seconds_relay_2__274_carry__0_n_2,seconds_relay_2__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r2_n_14,reg_r2_n_15,reg_r2_n_16,reg_r2_n_17}),
        .O(NLW_seconds_relay_2__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_2__274_carry__0_i_2_n_0,seconds_relay_2__274_carry__0_i_3_n_0,seconds_relay_2__274_carry__0_i_4_n_0,seconds_relay_2__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_2
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r2_n_14),
        .O(seconds_relay_2__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_3
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r2_n_15),
        .O(seconds_relay_2__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_4
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r2_n_16),
        .O(seconds_relay_2__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_5
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r2_n_17),
        .O(seconds_relay_2__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_2__274_carry__1
       (.CI(seconds_relay_2__274_carry__0_n_0),
        .CO({NLW_seconds_relay_2__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_2[0],seconds_relay_2__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_2[1],reg_r2_n_18}),
        .O(NLW_seconds_relay_2__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r2_n_21,reg_r2_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_2
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r2_n_11),
        .O(seconds_relay_2__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_3
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r2_n_12),
        .O(seconds_relay_2__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_4
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r2_n_13),
        .O(seconds_relay_2__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_5
       (.I0(seconds_relay_2[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_2__8_carry__0_i_7_0[0]),
        .O(seconds_relay_2__274_carry_i_5_n_0));
  CARRY4 seconds_relay_2__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_2__8_carry_n_0,seconds_relay_2__8_carry_n_1,seconds_relay_2__8_carry_n_2,seconds_relay_2__8_carry_n_3}),
        .CYINIT(reg_r2_n_0),
        .DI({seconds_relay_2__8_carry_i_2_n_0,seconds_relay_2__8_carry_i_3_n_0,seconds_relay_2__8_carry_i_4_n_0,seconds_relay_2__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_2__8_carry_n_4,seconds_relay_2__8_carry_n_5,seconds_relay_2__8_carry_n_6,seconds_relay_2__8_carry_n_7}),
        .S({seconds_relay_2__8_carry_i_5_n_0,seconds_relay_2__8_carry_i_6_n_0,seconds_relay_2__8_carry_i_7_n_0,seconds_relay_2__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_2__8_carry__0
       (.CI(seconds_relay_2__8_carry_n_0),
        .CO({seconds_relay_2__8_carry__0_n_0,seconds_relay_2__8_carry__0_n_1,seconds_relay_2__8_carry__0_n_2,seconds_relay_2__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_2__8_carry__0_i_1_n_0,seconds_relay_2__8_carry__0_i_2_n_0,seconds_relay_2__8_carry__0_i_3_n_0,seconds_relay_2__8_carry__0_i_4_n_0}),
        .O({seconds_relay_2__8_carry__0_n_4,seconds_relay_2__8_carry__0_n_5,seconds_relay_2__8_carry__0_n_6,seconds_relay_2__8_carry__0_n_7}),
        .S({seconds_relay_2__8_carry__0_i_5_n_0,seconds_relay_2__8_carry__0_i_6_n_0,seconds_relay_2__8_carry__0_i_7_n_0,seconds_relay_2__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_2__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r2_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_2__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_2__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r2_n_1),
        .O(seconds_relay_2__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_2__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_2__8_carry__0_i_9_n_0),
        .O(seconds_relay_2__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_2__8_carry__0_i_8
       (.I0(seconds_relay_2__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_2__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_2__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_2__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_2__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_2__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_2__8_carry__1
       (.CI(seconds_relay_2__8_carry__0_n_0),
        .CO({NLW_seconds_relay_2__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_2__8_carry__1_n_2,seconds_relay_2__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r2_n_2,reg_r2_n_3}),
        .O({NLW_seconds_relay_2__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_2__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r2_n_19,reg_r2_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r2_n_0),
        .O(seconds_relay_2__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_2__8_carry_i_5
       (.I0(reg_r2_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_2__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_2__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_2__8_carry_i_6
       (.I0(reg_r2_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_2__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_2__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_2__8_carry_i_7
       (.I0(reg_r2_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_2__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_2__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__8_carry_i_8
       (.I0(reg_r2_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_2__8_carry__0_i_7_0[7]),
        .O(seconds_relay_2__8_carry_i_8_n_0));
  CARRY4 seconds_relay_3__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_3__274_carry_n_0,seconds_relay_3__274_carry_n_1,seconds_relay_3__274_carry_n_2,seconds_relay_3__274_carry_n_3}),
        .CYINIT(seconds_relay_3[1]),
        .DI({reg_r3_n_11,reg_r3_n_12,reg_r3_n_13,seconds_relay_3__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_3__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_3__274_carry_i_2_n_0,seconds_relay_3__274_carry_i_3_n_0,seconds_relay_3__274_carry_i_4_n_0,seconds_relay_3__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_3__274_carry__0
       (.CI(seconds_relay_3__274_carry_n_0),
        .CO({seconds_relay_3__274_carry__0_n_0,seconds_relay_3__274_carry__0_n_1,seconds_relay_3__274_carry__0_n_2,seconds_relay_3__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r3_n_14,reg_r3_n_15,reg_r3_n_16,reg_r3_n_17}),
        .O(NLW_seconds_relay_3__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_3__274_carry__0_i_2_n_0,seconds_relay_3__274_carry__0_i_3_n_0,seconds_relay_3__274_carry__0_i_4_n_0,seconds_relay_3__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_2
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r3_n_14),
        .O(seconds_relay_3__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_3
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r3_n_15),
        .O(seconds_relay_3__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_4
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r3_n_16),
        .O(seconds_relay_3__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_5
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r3_n_17),
        .O(seconds_relay_3__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_3__274_carry__1
       (.CI(seconds_relay_3__274_carry__0_n_0),
        .CO({NLW_seconds_relay_3__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_3[0],seconds_relay_3__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_3[1],reg_r3_n_18}),
        .O(NLW_seconds_relay_3__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r3_n_21,reg_r3_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_2
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r3_n_11),
        .O(seconds_relay_3__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_3
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r3_n_12),
        .O(seconds_relay_3__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_4
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r3_n_13),
        .O(seconds_relay_3__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_5
       (.I0(seconds_relay_3[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_3__8_carry__0_i_7_0[0]),
        .O(seconds_relay_3__274_carry_i_5_n_0));
  CARRY4 seconds_relay_3__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_3__8_carry_n_0,seconds_relay_3__8_carry_n_1,seconds_relay_3__8_carry_n_2,seconds_relay_3__8_carry_n_3}),
        .CYINIT(reg_r3_n_0),
        .DI({seconds_relay_3__8_carry_i_2_n_0,seconds_relay_3__8_carry_i_3_n_0,seconds_relay_3__8_carry_i_4_n_0,seconds_relay_3__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_3__8_carry_n_4,seconds_relay_3__8_carry_n_5,seconds_relay_3__8_carry_n_6,seconds_relay_3__8_carry_n_7}),
        .S({seconds_relay_3__8_carry_i_5_n_0,seconds_relay_3__8_carry_i_6_n_0,seconds_relay_3__8_carry_i_7_n_0,seconds_relay_3__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_3__8_carry__0
       (.CI(seconds_relay_3__8_carry_n_0),
        .CO({seconds_relay_3__8_carry__0_n_0,seconds_relay_3__8_carry__0_n_1,seconds_relay_3__8_carry__0_n_2,seconds_relay_3__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_3__8_carry__0_i_1_n_0,seconds_relay_3__8_carry__0_i_2_n_0,seconds_relay_3__8_carry__0_i_3_n_0,seconds_relay_3__8_carry__0_i_4_n_0}),
        .O({seconds_relay_3__8_carry__0_n_4,seconds_relay_3__8_carry__0_n_5,seconds_relay_3__8_carry__0_n_6,seconds_relay_3__8_carry__0_n_7}),
        .S({seconds_relay_3__8_carry__0_i_5_n_0,seconds_relay_3__8_carry__0_i_6_n_0,seconds_relay_3__8_carry__0_i_7_n_0,seconds_relay_3__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_3__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r3_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_3__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_3__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r3_n_1),
        .O(seconds_relay_3__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_3__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_3__8_carry__0_i_9_n_0),
        .O(seconds_relay_3__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_3__8_carry__0_i_8
       (.I0(seconds_relay_3__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_3__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_3__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_3__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_3__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_3__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_3__8_carry__1
       (.CI(seconds_relay_3__8_carry__0_n_0),
        .CO({NLW_seconds_relay_3__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_3__8_carry__1_n_2,seconds_relay_3__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r3_n_2,reg_r3_n_3}),
        .O({NLW_seconds_relay_3__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_3__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r3_n_19,reg_r3_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r3_n_0),
        .O(seconds_relay_3__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_3__8_carry_i_5
       (.I0(reg_r3_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_3__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_3__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_3__8_carry_i_6
       (.I0(reg_r3_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_3__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_3__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_3__8_carry_i_7
       (.I0(reg_r3_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_3__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_3__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__8_carry_i_8
       (.I0(reg_r3_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_3__8_carry__0_i_7_0[7]),
        .O(seconds_relay_3__8_carry_i_8_n_0));
  CARRY4 seconds_relay_4__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_4__274_carry_n_0,seconds_relay_4__274_carry_n_1,seconds_relay_4__274_carry_n_2,seconds_relay_4__274_carry_n_3}),
        .CYINIT(seconds_relay_4[1]),
        .DI({reg_r4_n_11,reg_r4_n_12,reg_r4_n_13,seconds_relay_4__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_4__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_4__274_carry_i_2_n_0,seconds_relay_4__274_carry_i_3_n_0,seconds_relay_4__274_carry_i_4_n_0,seconds_relay_4__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_4__274_carry__0
       (.CI(seconds_relay_4__274_carry_n_0),
        .CO({seconds_relay_4__274_carry__0_n_0,seconds_relay_4__274_carry__0_n_1,seconds_relay_4__274_carry__0_n_2,seconds_relay_4__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r4_n_14,reg_r4_n_15,reg_r4_n_16,reg_r4_n_17}),
        .O(NLW_seconds_relay_4__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_4__274_carry__0_i_2_n_0,seconds_relay_4__274_carry__0_i_3_n_0,seconds_relay_4__274_carry__0_i_4_n_0,seconds_relay_4__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_2
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r4_n_14),
        .O(seconds_relay_4__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_3
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r4_n_15),
        .O(seconds_relay_4__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_4
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r4_n_16),
        .O(seconds_relay_4__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_5
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r4_n_17),
        .O(seconds_relay_4__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_4__274_carry__1
       (.CI(seconds_relay_4__274_carry__0_n_0),
        .CO({NLW_seconds_relay_4__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_4[0],seconds_relay_4__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_4[1],reg_r4_n_18}),
        .O(NLW_seconds_relay_4__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r4_n_21,reg_r4_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_2
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r4_n_11),
        .O(seconds_relay_4__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_3
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r4_n_12),
        .O(seconds_relay_4__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_4
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r4_n_13),
        .O(seconds_relay_4__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_5
       (.I0(seconds_relay_4[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_4__8_carry__0_i_7_0[0]),
        .O(seconds_relay_4__274_carry_i_5_n_0));
  CARRY4 seconds_relay_4__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_4__8_carry_n_0,seconds_relay_4__8_carry_n_1,seconds_relay_4__8_carry_n_2,seconds_relay_4__8_carry_n_3}),
        .CYINIT(reg_r4_n_0),
        .DI({seconds_relay_4__8_carry_i_2_n_0,seconds_relay_4__8_carry_i_3_n_0,seconds_relay_4__8_carry_i_4_n_0,seconds_relay_4__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_4__8_carry_n_4,seconds_relay_4__8_carry_n_5,seconds_relay_4__8_carry_n_6,seconds_relay_4__8_carry_n_7}),
        .S({seconds_relay_4__8_carry_i_5_n_0,seconds_relay_4__8_carry_i_6_n_0,seconds_relay_4__8_carry_i_7_n_0,seconds_relay_4__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_4__8_carry__0
       (.CI(seconds_relay_4__8_carry_n_0),
        .CO({seconds_relay_4__8_carry__0_n_0,seconds_relay_4__8_carry__0_n_1,seconds_relay_4__8_carry__0_n_2,seconds_relay_4__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_4__8_carry__0_i_1_n_0,seconds_relay_4__8_carry__0_i_2_n_0,seconds_relay_4__8_carry__0_i_3_n_0,seconds_relay_4__8_carry__0_i_4_n_0}),
        .O({seconds_relay_4__8_carry__0_n_4,seconds_relay_4__8_carry__0_n_5,seconds_relay_4__8_carry__0_n_6,seconds_relay_4__8_carry__0_n_7}),
        .S({seconds_relay_4__8_carry__0_i_5_n_0,seconds_relay_4__8_carry__0_i_6_n_0,seconds_relay_4__8_carry__0_i_7_n_0,seconds_relay_4__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_4__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r4_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_4__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_4__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r4_n_1),
        .O(seconds_relay_4__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_4__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_4__8_carry__0_i_9_n_0),
        .O(seconds_relay_4__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_4__8_carry__0_i_8
       (.I0(seconds_relay_4__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_4__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_4__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_4__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_4__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_4__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_4__8_carry__1
       (.CI(seconds_relay_4__8_carry__0_n_0),
        .CO({NLW_seconds_relay_4__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_4__8_carry__1_n_2,seconds_relay_4__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r4_n_2,reg_r4_n_3}),
        .O({NLW_seconds_relay_4__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_4__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r4_n_19,reg_r4_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r4_n_0),
        .O(seconds_relay_4__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_4__8_carry_i_5
       (.I0(reg_r4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_4__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_4__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_4__8_carry_i_6
       (.I0(reg_r4_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_4__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_4__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_4__8_carry_i_7
       (.I0(reg_r4_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_4__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_4__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__8_carry_i_8
       (.I0(reg_r4_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_4__8_carry__0_i_7_0[7]),
        .O(seconds_relay_4__8_carry_i_8_n_0));
  CARRY4 seconds_relay_5__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_5__274_carry_n_0,seconds_relay_5__274_carry_n_1,seconds_relay_5__274_carry_n_2,seconds_relay_5__274_carry_n_3}),
        .CYINIT(seconds_relay_5[1]),
        .DI({reg_r5_n_11,reg_r5_n_12,reg_r5_n_13,seconds_relay_5__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_5__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_5__274_carry_i_2_n_0,seconds_relay_5__274_carry_i_3_n_0,seconds_relay_5__274_carry_i_4_n_0,seconds_relay_5__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_5__274_carry__0
       (.CI(seconds_relay_5__274_carry_n_0),
        .CO({seconds_relay_5__274_carry__0_n_0,seconds_relay_5__274_carry__0_n_1,seconds_relay_5__274_carry__0_n_2,seconds_relay_5__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r5_n_14,reg_r5_n_15,reg_r5_n_16,reg_r5_n_17}),
        .O(NLW_seconds_relay_5__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_5__274_carry__0_i_2_n_0,seconds_relay_5__274_carry__0_i_3_n_0,seconds_relay_5__274_carry__0_i_4_n_0,seconds_relay_5__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_2
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r5_n_14),
        .O(seconds_relay_5__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_3
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r5_n_15),
        .O(seconds_relay_5__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_4
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r5_n_16),
        .O(seconds_relay_5__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_5
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r5_n_17),
        .O(seconds_relay_5__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_5__274_carry__1
       (.CI(seconds_relay_5__274_carry__0_n_0),
        .CO({NLW_seconds_relay_5__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_5[0],seconds_relay_5__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_5[1],reg_r5_n_18}),
        .O(NLW_seconds_relay_5__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r5_n_21,reg_r5_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_2
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r5_n_11),
        .O(seconds_relay_5__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_3
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r5_n_12),
        .O(seconds_relay_5__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_4
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r5_n_13),
        .O(seconds_relay_5__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_5
       (.I0(seconds_relay_5[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_5__8_carry__0_i_7_0[0]),
        .O(seconds_relay_5__274_carry_i_5_n_0));
  CARRY4 seconds_relay_5__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_5__8_carry_n_0,seconds_relay_5__8_carry_n_1,seconds_relay_5__8_carry_n_2,seconds_relay_5__8_carry_n_3}),
        .CYINIT(reg_r5_n_0),
        .DI({seconds_relay_5__8_carry_i_2_n_0,seconds_relay_5__8_carry_i_3_n_0,seconds_relay_5__8_carry_i_4_n_0,seconds_relay_5__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_5__8_carry_n_4,seconds_relay_5__8_carry_n_5,seconds_relay_5__8_carry_n_6,seconds_relay_5__8_carry_n_7}),
        .S({seconds_relay_5__8_carry_i_5_n_0,seconds_relay_5__8_carry_i_6_n_0,seconds_relay_5__8_carry_i_7_n_0,seconds_relay_5__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_5__8_carry__0
       (.CI(seconds_relay_5__8_carry_n_0),
        .CO({seconds_relay_5__8_carry__0_n_0,seconds_relay_5__8_carry__0_n_1,seconds_relay_5__8_carry__0_n_2,seconds_relay_5__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_5__8_carry__0_i_1_n_0,seconds_relay_5__8_carry__0_i_2_n_0,seconds_relay_5__8_carry__0_i_3_n_0,seconds_relay_5__8_carry__0_i_4_n_0}),
        .O({seconds_relay_5__8_carry__0_n_4,seconds_relay_5__8_carry__0_n_5,seconds_relay_5__8_carry__0_n_6,seconds_relay_5__8_carry__0_n_7}),
        .S({seconds_relay_5__8_carry__0_i_5_n_0,seconds_relay_5__8_carry__0_i_6_n_0,seconds_relay_5__8_carry__0_i_7_n_0,seconds_relay_5__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_5__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r5_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_5__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_5__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r5_n_1),
        .O(seconds_relay_5__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_5__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_5__8_carry__0_i_9_n_0),
        .O(seconds_relay_5__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_5__8_carry__0_i_8
       (.I0(seconds_relay_5__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_5__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_5__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_5__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_5__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_5__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_5__8_carry__1
       (.CI(seconds_relay_5__8_carry__0_n_0),
        .CO({NLW_seconds_relay_5__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_5__8_carry__1_n_2,seconds_relay_5__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r5_n_2,reg_r5_n_3}),
        .O({NLW_seconds_relay_5__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_5__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r5_n_19,reg_r5_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r5_n_0),
        .O(seconds_relay_5__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_5__8_carry_i_5
       (.I0(reg_r5_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_5__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_5__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_5__8_carry_i_6
       (.I0(reg_r5_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_5__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_5__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_5__8_carry_i_7
       (.I0(reg_r5_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_5__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_5__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__8_carry_i_8
       (.I0(reg_r5_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_5__8_carry__0_i_7_0[7]),
        .O(seconds_relay_5__8_carry_i_8_n_0));
  CARRY4 seconds_relay_6__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_6__274_carry_n_0,seconds_relay_6__274_carry_n_1,seconds_relay_6__274_carry_n_2,seconds_relay_6__274_carry_n_3}),
        .CYINIT(seconds_relay_6[1]),
        .DI({reg_r6_n_11,reg_r6_n_12,reg_r6_n_13,seconds_relay_6__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_6__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_6__274_carry_i_2_n_0,seconds_relay_6__274_carry_i_3_n_0,seconds_relay_6__274_carry_i_4_n_0,seconds_relay_6__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_6__274_carry__0
       (.CI(seconds_relay_6__274_carry_n_0),
        .CO({seconds_relay_6__274_carry__0_n_0,seconds_relay_6__274_carry__0_n_1,seconds_relay_6__274_carry__0_n_2,seconds_relay_6__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r6_n_14,reg_r6_n_15,reg_r6_n_16,reg_r6_n_17}),
        .O(NLW_seconds_relay_6__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_6__274_carry__0_i_2_n_0,seconds_relay_6__274_carry__0_i_3_n_0,seconds_relay_6__274_carry__0_i_4_n_0,seconds_relay_6__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_2
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r6_n_14),
        .O(seconds_relay_6__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_3
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r6_n_15),
        .O(seconds_relay_6__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_4
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r6_n_16),
        .O(seconds_relay_6__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_5
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r6_n_17),
        .O(seconds_relay_6__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_6__274_carry__1
       (.CI(seconds_relay_6__274_carry__0_n_0),
        .CO({NLW_seconds_relay_6__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_6[0],seconds_relay_6__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_6[1],reg_r6_n_18}),
        .O(NLW_seconds_relay_6__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r6_n_21,reg_r6_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_2
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r6_n_11),
        .O(seconds_relay_6__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_3
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r6_n_12),
        .O(seconds_relay_6__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_4
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r6_n_13),
        .O(seconds_relay_6__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_5
       (.I0(seconds_relay_6[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_6__8_carry__0_i_7_0[0]),
        .O(seconds_relay_6__274_carry_i_5_n_0));
  CARRY4 seconds_relay_6__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_6__8_carry_n_0,seconds_relay_6__8_carry_n_1,seconds_relay_6__8_carry_n_2,seconds_relay_6__8_carry_n_3}),
        .CYINIT(reg_r6_n_0),
        .DI({seconds_relay_6__8_carry_i_2_n_0,seconds_relay_6__8_carry_i_3_n_0,seconds_relay_6__8_carry_i_4_n_0,seconds_relay_6__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_6__8_carry_n_4,seconds_relay_6__8_carry_n_5,seconds_relay_6__8_carry_n_6,seconds_relay_6__8_carry_n_7}),
        .S({seconds_relay_6__8_carry_i_5_n_0,seconds_relay_6__8_carry_i_6_n_0,seconds_relay_6__8_carry_i_7_n_0,seconds_relay_6__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_6__8_carry__0
       (.CI(seconds_relay_6__8_carry_n_0),
        .CO({seconds_relay_6__8_carry__0_n_0,seconds_relay_6__8_carry__0_n_1,seconds_relay_6__8_carry__0_n_2,seconds_relay_6__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_6__8_carry__0_i_1_n_0,seconds_relay_6__8_carry__0_i_2_n_0,seconds_relay_6__8_carry__0_i_3_n_0,seconds_relay_6__8_carry__0_i_4_n_0}),
        .O({seconds_relay_6__8_carry__0_n_4,seconds_relay_6__8_carry__0_n_5,seconds_relay_6__8_carry__0_n_6,seconds_relay_6__8_carry__0_n_7}),
        .S({seconds_relay_6__8_carry__0_i_5_n_0,seconds_relay_6__8_carry__0_i_6_n_0,seconds_relay_6__8_carry__0_i_7_n_0,seconds_relay_6__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_6__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r6_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_6__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_6__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r6_n_1),
        .O(seconds_relay_6__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_6__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_6__8_carry__0_i_9_n_0),
        .O(seconds_relay_6__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_6__8_carry__0_i_8
       (.I0(seconds_relay_6__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_6__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_6__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_6__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_6__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_6__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_6__8_carry__1
       (.CI(seconds_relay_6__8_carry__0_n_0),
        .CO({NLW_seconds_relay_6__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_6__8_carry__1_n_2,seconds_relay_6__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r6_n_2,reg_r6_n_3}),
        .O({NLW_seconds_relay_6__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_6__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r6_n_19,reg_r6_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r6_n_0),
        .O(seconds_relay_6__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_6__8_carry_i_5
       (.I0(reg_r6_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_6__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_6__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_6__8_carry_i_6
       (.I0(reg_r6_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_6__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_6__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_6__8_carry_i_7
       (.I0(reg_r6_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_6__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_6__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__8_carry_i_8
       (.I0(reg_r6_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_6__8_carry__0_i_7_0[7]),
        .O(seconds_relay_6__8_carry_i_8_n_0));
  CARRY4 seconds_relay_7__274_carry
       (.CI(1'b0),
        .CO({seconds_relay_7__274_carry_n_0,seconds_relay_7__274_carry_n_1,seconds_relay_7__274_carry_n_2,seconds_relay_7__274_carry_n_3}),
        .CYINIT(seconds_relay_7[1]),
        .DI({reg_r7_n_11,reg_r7_n_12,reg_r7_n_13,seconds_relay_7__8_carry__0_i_7_0[0]}),
        .O(NLW_seconds_relay_7__274_carry_O_UNCONNECTED[3:0]),
        .S({seconds_relay_7__274_carry_i_2_n_0,seconds_relay_7__274_carry_i_3_n_0,seconds_relay_7__274_carry_i_4_n_0,seconds_relay_7__274_carry_i_5_n_0}));
  CARRY4 seconds_relay_7__274_carry__0
       (.CI(seconds_relay_7__274_carry_n_0),
        .CO({seconds_relay_7__274_carry__0_n_0,seconds_relay_7__274_carry__0_n_1,seconds_relay_7__274_carry__0_n_2,seconds_relay_7__274_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({reg_r7_n_14,reg_r7_n_15,reg_r7_n_16,reg_r7_n_17}),
        .O(NLW_seconds_relay_7__274_carry__0_O_UNCONNECTED[3:0]),
        .S({seconds_relay_7__274_carry__0_i_2_n_0,seconds_relay_7__274_carry__0_i_3_n_0,seconds_relay_7__274_carry__0_i_4_n_0,seconds_relay_7__274_carry__0_i_5_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_2
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[7]),
        .I2(reg_r7_n_14),
        .O(seconds_relay_7__274_carry__0_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_3
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[6]),
        .I2(reg_r7_n_15),
        .O(seconds_relay_7__274_carry__0_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_4
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[5]),
        .I2(reg_r7_n_16),
        .O(seconds_relay_7__274_carry__0_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_5
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[4]),
        .I2(reg_r7_n_17),
        .O(seconds_relay_7__274_carry__0_i_5_n_0));
  CARRY4 seconds_relay_7__274_carry__1
       (.CI(seconds_relay_7__274_carry__0_n_0),
        .CO({NLW_seconds_relay_7__274_carry__1_CO_UNCONNECTED[3:2],seconds_relay_7[0],seconds_relay_7__274_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,seconds_relay_7[1],reg_r7_n_18}),
        .O(NLW_seconds_relay_7__274_carry__1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,reg_r7_n_21,reg_r7_n_22}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_2
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[3]),
        .I2(reg_r7_n_11),
        .O(seconds_relay_7__274_carry_i_2_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_3
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[2]),
        .I2(reg_r7_n_12),
        .O(seconds_relay_7__274_carry_i_3_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_4
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[1]),
        .I2(reg_r7_n_13),
        .O(seconds_relay_7__274_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_5
       (.I0(seconds_relay_7[1]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_7__8_carry__0_i_7_0[0]),
        .O(seconds_relay_7__274_carry_i_5_n_0));
  CARRY4 seconds_relay_7__8_carry
       (.CI(1'b0),
        .CO({seconds_relay_7__8_carry_n_0,seconds_relay_7__8_carry_n_1,seconds_relay_7__8_carry_n_2,seconds_relay_7__8_carry_n_3}),
        .CYINIT(reg_r7_n_0),
        .DI({seconds_relay_7__8_carry_i_2_n_0,seconds_relay_7__8_carry_i_3_n_0,seconds_relay_7__8_carry_i_4_n_0,seconds_relay_7__8_carry__0_i_7_0[7]}),
        .O({seconds_relay_7__8_carry_n_4,seconds_relay_7__8_carry_n_5,seconds_relay_7__8_carry_n_6,seconds_relay_7__8_carry_n_7}),
        .S({seconds_relay_7__8_carry_i_5_n_0,seconds_relay_7__8_carry_i_6_n_0,seconds_relay_7__8_carry_i_7_n_0,seconds_relay_7__8_carry_i_8_n_0}));
  CARRY4 seconds_relay_7__8_carry__0
       (.CI(seconds_relay_7__8_carry_n_0),
        .CO({seconds_relay_7__8_carry__0_n_0,seconds_relay_7__8_carry__0_n_1,seconds_relay_7__8_carry__0_n_2,seconds_relay_7__8_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({seconds_relay_7__8_carry__0_i_1_n_0,seconds_relay_7__8_carry__0_i_2_n_0,seconds_relay_7__8_carry__0_i_3_n_0,seconds_relay_7__8_carry__0_i_4_n_0}),
        .O({seconds_relay_7__8_carry__0_n_4,seconds_relay_7__8_carry__0_n_5,seconds_relay_7__8_carry__0_n_6,seconds_relay_7__8_carry__0_n_7}),
        .S({seconds_relay_7__8_carry__0_i_5_n_0,seconds_relay_7__8_carry__0_i_6_n_0,seconds_relay_7__8_carry__0_i_7_n_0,seconds_relay_7__8_carry__0_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry__0_i_1
       (.I0(liquid_division_reg[7]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry__0_i_2
       (.I0(liquid_division_reg[6]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry__0_i_3
       (.I0(liquid_division_reg[5]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry__0_i_4
       (.I0(liquid_division_reg[4]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry__0_i_4_n_0));
  LUT5 #(
    .INIT(32'hA5A55BA5)) 
    seconds_relay_7__8_carry__0_i_5
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[8]),
        .I2(liquid_division_reg[6]),
        .I3(reg_r7_n_1),
        .I4(liquid_division_reg[5]),
        .O(seconds_relay_7__8_carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'h33CDCC33)) 
    seconds_relay_7__8_carry__0_i_6
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[6]),
        .I2(liquid_division_reg[8]),
        .I3(liquid_division_reg[5]),
        .I4(reg_r7_n_1),
        .O(seconds_relay_7__8_carry__0_i_6_n_0));
  LUT6 #(
    .INIT(64'h3333CCCDCCCC3333)) 
    seconds_relay_7__8_carry__0_i_7
       (.I0(liquid_division_reg[7]),
        .I1(liquid_division_reg[5]),
        .I2(liquid_division_reg[6]),
        .I3(liquid_division_reg[8]),
        .I4(liquid_division_reg[4]),
        .I5(seconds_relay_7__8_carry__0_i_9_n_0),
        .O(seconds_relay_7__8_carry__0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9999999996999696)) 
    seconds_relay_7__8_carry__0_i_8
       (.I0(seconds_relay_7__8_carry__0_i_4_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_7__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .I5(liquid_division_reg[2]),
        .O(seconds_relay_7__8_carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000051)) 
    seconds_relay_7__8_carry__0_i_9
       (.I0(liquid_division_reg[2]),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_7__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[1]),
        .I4(liquid_division_reg[3]),
        .O(seconds_relay_7__8_carry__0_i_9_n_0));
  CARRY4 seconds_relay_7__8_carry__1
       (.CI(seconds_relay_7__8_carry__0_n_0),
        .CO({NLW_seconds_relay_7__8_carry__1_CO_UNCONNECTED[3:2],seconds_relay_7__8_carry__1_n_2,seconds_relay_7__8_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,reg_r7_n_2,reg_r7_n_3}),
        .O({NLW_seconds_relay_7__8_carry__1_O_UNCONNECTED[3:1],seconds_relay_7__8_carry__1_n_7}),
        .S({1'b0,1'b0,reg_r7_n_19,reg_r7_n_20}));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry_i_2
       (.I0(liquid_division_reg[3]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry_i_3
       (.I0(liquid_division_reg[2]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry_i_4
       (.I0(liquid_division_reg[1]),
        .I1(reg_r7_n_0),
        .O(seconds_relay_7__8_carry_i_4_n_0));
  LUT6 #(
    .INIT(64'h6969696996966996)) 
    seconds_relay_7__8_carry_i_5
       (.I0(reg_r7_n_0),
        .I1(liquid_division_reg[3]),
        .I2(liquid_division_reg[2]),
        .I3(liquid_division_reg[0]),
        .I4(seconds_relay_7__8_carry__0_i_7_0[8]),
        .I5(liquid_division_reg[1]),
        .O(seconds_relay_7__8_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'h96699696)) 
    seconds_relay_7__8_carry_i_6
       (.I0(reg_r7_n_0),
        .I1(liquid_division_reg[2]),
        .I2(liquid_division_reg[1]),
        .I3(seconds_relay_7__8_carry__0_i_7_0[8]),
        .I4(liquid_division_reg[0]),
        .O(seconds_relay_7__8_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'h6996)) 
    seconds_relay_7__8_carry_i_7
       (.I0(reg_r7_n_0),
        .I1(liquid_division_reg[1]),
        .I2(seconds_relay_7__8_carry__0_i_7_0[8]),
        .I3(liquid_division_reg[0]),
        .O(seconds_relay_7__8_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__8_carry_i_8
       (.I0(reg_r7_n_0),
        .I1(liquid_division_reg[0]),
        .I2(seconds_relay_7__8_carry__0_i_7_0[7]),
        .O(seconds_relay_7__8_carry_i_8_n_0));
  design_1_liquid_0_1_timer timer_0
       (.D(D[0]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_0),
        .\count_seconds_reg[4]_0 ({reg_r0_n_5,reg_r0_n_6,reg_r0_n_7,reg_r0_n_8,reg_r0_n_9}),
        .counter_out0_out(counter_out0_out),
        .counter_out_reg_0(counter_out_reg),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg),
        .started_reg_1(relay_register_out[0]));
  design_1_liquid_0_1_timer_7 timer_1
       (.D(D[1]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_1),
        .\count_seconds_reg[4]_0 ({reg_r1_n_5,reg_r1_n_6,reg_r1_n_7,reg_r1_n_8,reg_r1_n_9}),
        .counter_out0_out_8(counter_out0_out_8),
        .counter_out_reg_0(counter_out_reg_0),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_0),
        .started_reg_1(relay_register_out[1]));
  design_1_liquid_0_1_timer_8 timer_2
       (.D(D[2]),
        .\FSM_onehot_current_state_reg[1] ({D[3],D[1:0]}),
        .\FSM_onehot_current_state_reg[1]_0 (timer_5_n_3),
        .\FSM_onehot_current_state_reg[2] ({timer_2_n_3,timer_2_n_4}),
        .Q({p_0_in_0,\FSM_onehot_current_state_reg_n_0_[1] ,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_2),
        .\count_seconds_reg[4]_0 ({reg_r2_n_5,reg_r2_n_6,reg_r2_n_7,reg_r2_n_8,reg_r2_n_9}),
        .counter_out0_out_10(counter_out0_out_10),
        .counter_out_reg_0(counter_out_reg_1),
        .p_2_in(p_2_in),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_1),
        .started_reg_1(relay_register_out[2]));
  design_1_liquid_0_1_timer_9 timer_3
       (.D(D[3]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_3),
        .\count_seconds_reg[4]_0 ({reg_r3_n_5,reg_r3_n_6,reg_r3_n_7,reg_r3_n_8,reg_r3_n_9}),
        .counter_out0_out_12(counter_out0_out_12),
        .counter_out_reg_0(counter_out_reg_2),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_2),
        .started_reg_1(relay_register_out[3]));
  design_1_liquid_0_1_timer_10 timer_4
       (.D(D[4]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_4),
        .\count_seconds_reg[4]_0 ({reg_r4_n_5,reg_r4_n_6,reg_r4_n_7,reg_r4_n_8,reg_r4_n_9}),
        .counter_out0_out_14(counter_out0_out_14),
        .counter_out_reg_0(counter_out_reg_3),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_3),
        .started_reg_1(relay_register_out[4]));
  design_1_liquid_0_1_timer_11 timer_5
       (.D(D[5]),
        .\FSM_onehot_current_state[1]_i_2 ({D[7:6],D[4]}),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_5),
        .\count_seconds_reg[4]_0 ({reg_r5_n_5,reg_r5_n_6,reg_r5_n_7,reg_r5_n_8,reg_r5_n_9}),
        .counter_out0_out_16(counter_out0_out_16),
        .counter_out_reg_0(timer_5_n_3),
        .counter_out_reg_1(counter_out_reg_4),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_4),
        .started_reg_1(relay_register_out[5]));
  design_1_liquid_0_1_timer_12 timer_6
       (.D(D[6]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_6),
        .\count_seconds_reg[4]_0 ({reg_r6_n_5,reg_r6_n_6,reg_r6_n_7,reg_r6_n_8,reg_r6_n_9}),
        .counter_out0_out_18(counter_out0_out_18),
        .counter_out_reg_0(counter_out_reg_5),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_5),
        .started_reg_1(relay_register_out[6]));
  design_1_liquid_0_1_timer_13 timer_7
       (.D(D[7]),
        .Q({p_0_in_0,load_liquid_division}),
        .\count_clk_cycles_reg[0]_0 (prev_was_load_reg_7),
        .\count_seconds_reg[4]_0 ({reg_r7_n_5,reg_r7_n_6,reg_r7_n_7,reg_r7_n_8,reg_r7_n_9}),
        .counter_out0_out_20(counter_out0_out_20),
        .counter_out_reg_0(counter_out_reg_6),
        .prev_was_load(prev_was_load),
        .s00_axi_aclk(s00_axi_aclk),
        .started_reg_0(started_reg_6),
        .started_reg_1(relay_register_out[7]));
endmodule

(* ORIG_REF_NAME = "liquid" *) 
module design_1_liquid_0_1_liquid
   (axi_awready_reg,
    axi_arready_reg,
    axi_rvalid_reg,
    D,
    s00_axi_rdata,
    s00_axi_bvalid,
    s00_axi_wready,
    s00_axi_aclk,
    s00_axi_awvalid,
    s00_axi_wvalid,
    s00_axi_arvalid,
    s00_axi_rready,
    s00_axi_awaddr,
    s00_axi_wdata,
    s00_axi_araddr,
    s00_axi_wstrb,
    s00_axi_aresetn,
    s00_axi_bready);
  output axi_awready_reg;
  output axi_arready_reg;
  output axi_rvalid_reg;
  output [7:0]D;
  output [31:0]s00_axi_rdata;
  output s00_axi_bvalid;
  output s00_axi_wready;
  input s00_axi_aclk;
  input s00_axi_awvalid;
  input s00_axi_wvalid;
  input s00_axi_arvalid;
  input s00_axi_rready;
  input [3:0]s00_axi_awaddr;
  input [31:0]s00_axi_wdata;
  input [3:0]s00_axi_araddr;
  input [3:0]s00_axi_wstrb;
  input s00_axi_aresetn;
  input s00_axi_bready;

  wire [7:0]D;
  wire \arthur_liquid/timer_0/count_clk_cycles1 ;
  wire \arthur_liquid/timer_0/counter_out0_out ;
  wire \arthur_liquid/timer_0/started ;
  wire \arthur_liquid/timer_1/count_clk_cycles1 ;
  wire \arthur_liquid/timer_1/counter_out0_out ;
  wire \arthur_liquid/timer_1/started ;
  wire \arthur_liquid/timer_2/count_clk_cycles1 ;
  wire \arthur_liquid/timer_2/counter_out0_out ;
  wire \arthur_liquid/timer_2/started ;
  wire \arthur_liquid/timer_3/count_clk_cycles1 ;
  wire \arthur_liquid/timer_3/counter_out0_out ;
  wire \arthur_liquid/timer_3/started ;
  wire \arthur_liquid/timer_4/count_clk_cycles1 ;
  wire \arthur_liquid/timer_4/counter_out0_out ;
  wire \arthur_liquid/timer_4/started ;
  wire \arthur_liquid/timer_5/count_clk_cycles1 ;
  wire \arthur_liquid/timer_5/counter_out0_out ;
  wire \arthur_liquid/timer_5/started ;
  wire \arthur_liquid/timer_6/count_clk_cycles1 ;
  wire \arthur_liquid/timer_6/counter_out0_out ;
  wire \arthur_liquid/timer_6/started ;
  wire \arthur_liquid/timer_7/count_clk_cycles1 ;
  wire \arthur_liquid/timer_7/counter_out0_out ;
  wire \arthur_liquid/timer_7/started ;
  wire axi_arready_i_1_n_0;
  wire axi_arready_reg;
  wire axi_awready0__0;
  wire axi_awready_i_2_n_0;
  wire axi_awready_reg;
  wire axi_bvalid_i_1_n_0;
  wire axi_rvalid_i_1_n_0;
  wire axi_rvalid_reg;
  wire axi_wready_i_1_n_0;
  wire counter_out_i_1__0_n_0;
  wire counter_out_i_1__1_n_0;
  wire counter_out_i_1__2_n_0;
  wire counter_out_i_1__3_n_0;
  wire counter_out_i_1__4_n_0;
  wire counter_out_i_1__5_n_0;
  wire counter_out_i_1__6_n_0;
  wire counter_out_i_1_n_0;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_42;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_43;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_44;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_45;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_46;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_47;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_48;
  wire liquid_slave_lite_v1_0_S00_AXI_inst_n_49;
  wire s00_axi_aclk;
  wire [3:0]s00_axi_araddr;
  wire s00_axi_aresetn;
  wire s00_axi_arvalid;
  wire [3:0]s00_axi_awaddr;
  wire s00_axi_awvalid;
  wire s00_axi_bready;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire s00_axi_rready;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wready;
  wire [3:0]s00_axi_wstrb;
  wire s00_axi_wvalid;
  wire [1:0]state_read;
  wire [1:0]state_write;

  LUT6 #(
    .INIT(64'hC4C4C4C4FFCFCFCF)) 
    axi_arready_i_1
       (.I0(s00_axi_arvalid),
        .I1(axi_arready_reg),
        .I2(state_read[1]),
        .I3(s00_axi_rready),
        .I4(axi_rvalid_reg),
        .I5(state_read[0]),
        .O(axi_arready_i_1_n_0));
  LUT5 #(
    .INIT(32'hCCC4FFCF)) 
    axi_awready_i_2
       (.I0(s00_axi_awvalid),
        .I1(axi_awready_reg),
        .I2(state_write[1]),
        .I3(s00_axi_wvalid),
        .I4(state_write[0]),
        .O(axi_awready_i_2_n_0));
  LUT6 #(
    .INIT(64'hFBFF3838C3FF0000)) 
    axi_bvalid_i_1
       (.I0(axi_awready0__0),
        .I1(state_write[0]),
        .I2(state_write[1]),
        .I3(s00_axi_bready),
        .I4(s00_axi_bvalid),
        .I5(s00_axi_wvalid),
        .O(axi_bvalid_i_1_n_0));
  LUT6 #(
    .INIT(64'hF0FFFFFF00800080)) 
    axi_rvalid_i_1
       (.I0(axi_arready_reg),
        .I1(s00_axi_arvalid),
        .I2(state_read[0]),
        .I3(state_read[1]),
        .I4(s00_axi_rready),
        .I5(axi_rvalid_reg),
        .O(axi_rvalid_i_1_n_0));
  LUT3 #(
    .INIT(8'hF1)) 
    axi_wready_i_1
       (.I0(state_write[1]),
        .I1(state_write[0]),
        .I2(s00_axi_wready),
        .O(axi_wready_i_1_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_42),
        .I1(\arthur_liquid/timer_0/counter_out0_out ),
        .I2(\arthur_liquid/timer_0/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_0/started ),
        .I4(D[0]),
        .O(counter_out_i_1_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__0
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_43),
        .I1(\arthur_liquid/timer_1/counter_out0_out ),
        .I2(\arthur_liquid/timer_1/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_1/started ),
        .I4(D[1]),
        .O(counter_out_i_1__0_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__1
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_44),
        .I1(\arthur_liquid/timer_2/counter_out0_out ),
        .I2(\arthur_liquid/timer_2/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_2/started ),
        .I4(D[2]),
        .O(counter_out_i_1__1_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__2
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_45),
        .I1(\arthur_liquid/timer_3/counter_out0_out ),
        .I2(\arthur_liquid/timer_3/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_3/started ),
        .I4(D[3]),
        .O(counter_out_i_1__2_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__3
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_46),
        .I1(\arthur_liquid/timer_4/counter_out0_out ),
        .I2(\arthur_liquid/timer_4/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_4/started ),
        .I4(D[4]),
        .O(counter_out_i_1__3_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__4
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_47),
        .I1(\arthur_liquid/timer_5/counter_out0_out ),
        .I2(\arthur_liquid/timer_5/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_5/started ),
        .I4(D[5]),
        .O(counter_out_i_1__4_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__5
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_48),
        .I1(\arthur_liquid/timer_6/counter_out0_out ),
        .I2(\arthur_liquid/timer_6/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_6/started ),
        .I4(D[6]),
        .O(counter_out_i_1__5_n_0));
  LUT5 #(
    .INIT(32'hACAFACA0)) 
    counter_out_i_1__6
       (.I0(liquid_slave_lite_v1_0_S00_AXI_inst_n_49),
        .I1(\arthur_liquid/timer_7/counter_out0_out ),
        .I2(\arthur_liquid/timer_7/count_clk_cycles1 ),
        .I3(\arthur_liquid/timer_7/started ),
        .I4(D[7]),
        .O(counter_out_i_1__6_n_0));
  design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI liquid_slave_lite_v1_0_S00_AXI_inst
       (.D(D),
        .axi_arready_reg_0(axi_arready_reg),
        .axi_arready_reg_1(axi_arready_i_1_n_0),
        .axi_awready0__0(axi_awready0__0),
        .axi_awready_reg_0(axi_awready_reg),
        .axi_awready_reg_1(axi_awready_i_2_n_0),
        .axi_bvalid_reg_0(axi_bvalid_i_1_n_0),
        .axi_rvalid_reg_0(axi_rvalid_reg),
        .axi_rvalid_reg_1(axi_rvalid_i_1_n_0),
        .axi_wready_reg_0(axi_wready_i_1_n_0),
        .count_clk_cycles1(\arthur_liquid/timer_0/count_clk_cycles1 ),
        .count_clk_cycles1_11(\arthur_liquid/timer_3/count_clk_cycles1 ),
        .count_clk_cycles1_13(\arthur_liquid/timer_4/count_clk_cycles1 ),
        .count_clk_cycles1_15(\arthur_liquid/timer_5/count_clk_cycles1 ),
        .count_clk_cycles1_17(\arthur_liquid/timer_6/count_clk_cycles1 ),
        .count_clk_cycles1_19(\arthur_liquid/timer_7/count_clk_cycles1 ),
        .count_clk_cycles1_7(\arthur_liquid/timer_1/count_clk_cycles1 ),
        .count_clk_cycles1_9(\arthur_liquid/timer_2/count_clk_cycles1 ),
        .counter_out0_out(\arthur_liquid/timer_0/counter_out0_out ),
        .counter_out0_out_10(\arthur_liquid/timer_2/counter_out0_out ),
        .counter_out0_out_12(\arthur_liquid/timer_3/counter_out0_out ),
        .counter_out0_out_14(\arthur_liquid/timer_4/counter_out0_out ),
        .counter_out0_out_16(\arthur_liquid/timer_5/counter_out0_out ),
        .counter_out0_out_18(\arthur_liquid/timer_6/counter_out0_out ),
        .counter_out0_out_20(\arthur_liquid/timer_7/counter_out0_out ),
        .counter_out0_out_8(\arthur_liquid/timer_1/counter_out0_out ),
        .counter_out_reg(counter_out_i_1_n_0),
        .counter_out_reg_0(counter_out_i_1__0_n_0),
        .counter_out_reg_1(counter_out_i_1__1_n_0),
        .counter_out_reg_2(counter_out_i_1__2_n_0),
        .counter_out_reg_3(counter_out_i_1__3_n_0),
        .counter_out_reg_4(counter_out_i_1__4_n_0),
        .counter_out_reg_5(counter_out_i_1__5_n_0),
        .counter_out_reg_6(counter_out_i_1__6_n_0),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_araddr(s00_axi_araddr),
        .s00_axi_aresetn(s00_axi_aresetn),
        .s00_axi_arvalid(s00_axi_arvalid),
        .s00_axi_awaddr(s00_axi_awaddr),
        .s00_axi_awvalid(s00_axi_awvalid),
        .s00_axi_bvalid(s00_axi_bvalid),
        .s00_axi_rdata(s00_axi_rdata),
        .s00_axi_rready(s00_axi_rready),
        .s00_axi_wdata(s00_axi_wdata),
        .s00_axi_wready(s00_axi_wready),
        .s00_axi_wstrb(s00_axi_wstrb),
        .s00_axi_wvalid(s00_axi_wvalid),
        .started(\arthur_liquid/timer_0/started ),
        .started_0(\arthur_liquid/timer_1/started ),
        .started_1(\arthur_liquid/timer_2/started ),
        .started_2(\arthur_liquid/timer_3/started ),
        .started_3(\arthur_liquid/timer_4/started ),
        .started_4(\arthur_liquid/timer_5/started ),
        .started_5(\arthur_liquid/timer_6/started ),
        .started_6(\arthur_liquid/timer_7/started ),
        .state_read(state_read),
        .\state_reg[2] (liquid_slave_lite_v1_0_S00_AXI_inst_n_42),
        .\state_reg[2]_0 (liquid_slave_lite_v1_0_S00_AXI_inst_n_43),
        .\state_reg[2]_1 (liquid_slave_lite_v1_0_S00_AXI_inst_n_44),
        .\state_reg[2]_2 (liquid_slave_lite_v1_0_S00_AXI_inst_n_45),
        .\state_reg[2]_3 (liquid_slave_lite_v1_0_S00_AXI_inst_n_46),
        .\state_reg[2]_4 (liquid_slave_lite_v1_0_S00_AXI_inst_n_47),
        .\state_reg[2]_5 (liquid_slave_lite_v1_0_S00_AXI_inst_n_48),
        .\state_reg[2]_6 (liquid_slave_lite_v1_0_S00_AXI_inst_n_49),
        .state_write(state_write));
endmodule

(* ORIG_REF_NAME = "liquid_slave_lite_v1_0_S00_AXI" *) 
module design_1_liquid_0_1_liquid_slave_lite_v1_0_S00_AXI
   (D,
    s00_axi_bvalid,
    axi_awready_reg_0,
    s00_axi_wready,
    axi_rvalid_reg_0,
    axi_arready_reg_0,
    started,
    started_0,
    started_1,
    started_2,
    started_3,
    started_4,
    started_5,
    started_6,
    state_write,
    state_read,
    count_clk_cycles1,
    counter_out0_out,
    count_clk_cycles1_7,
    counter_out0_out_8,
    count_clk_cycles1_9,
    counter_out0_out_10,
    count_clk_cycles1_11,
    counter_out0_out_12,
    count_clk_cycles1_13,
    counter_out0_out_14,
    count_clk_cycles1_15,
    counter_out0_out_16,
    count_clk_cycles1_17,
    counter_out0_out_18,
    count_clk_cycles1_19,
    counter_out0_out_20,
    axi_awready0__0,
    \state_reg[2] ,
    \state_reg[2]_0 ,
    \state_reg[2]_1 ,
    \state_reg[2]_2 ,
    \state_reg[2]_3 ,
    \state_reg[2]_4 ,
    \state_reg[2]_5 ,
    \state_reg[2]_6 ,
    s00_axi_rdata,
    s00_axi_aclk,
    counter_out_reg,
    counter_out_reg_0,
    counter_out_reg_1,
    counter_out_reg_2,
    counter_out_reg_3,
    counter_out_reg_4,
    counter_out_reg_5,
    counter_out_reg_6,
    axi_bvalid_reg_0,
    axi_awready_reg_1,
    axi_wready_reg_0,
    axi_rvalid_reg_1,
    axi_arready_reg_1,
    s00_axi_awvalid,
    s00_axi_wvalid,
    s00_axi_arvalid,
    s00_axi_rready,
    s00_axi_awaddr,
    s00_axi_wdata,
    s00_axi_araddr,
    s00_axi_aresetn,
    s00_axi_wstrb);
  output [7:0]D;
  output s00_axi_bvalid;
  output axi_awready_reg_0;
  output s00_axi_wready;
  output axi_rvalid_reg_0;
  output axi_arready_reg_0;
  output started;
  output started_0;
  output started_1;
  output started_2;
  output started_3;
  output started_4;
  output started_5;
  output started_6;
  output [1:0]state_write;
  output [1:0]state_read;
  output count_clk_cycles1;
  output counter_out0_out;
  output count_clk_cycles1_7;
  output counter_out0_out_8;
  output count_clk_cycles1_9;
  output counter_out0_out_10;
  output count_clk_cycles1_11;
  output counter_out0_out_12;
  output count_clk_cycles1_13;
  output counter_out0_out_14;
  output count_clk_cycles1_15;
  output counter_out0_out_16;
  output count_clk_cycles1_17;
  output counter_out0_out_18;
  output count_clk_cycles1_19;
  output counter_out0_out_20;
  output axi_awready0__0;
  output \state_reg[2] ;
  output \state_reg[2]_0 ;
  output \state_reg[2]_1 ;
  output \state_reg[2]_2 ;
  output \state_reg[2]_3 ;
  output \state_reg[2]_4 ;
  output \state_reg[2]_5 ;
  output \state_reg[2]_6 ;
  output [31:0]s00_axi_rdata;
  input s00_axi_aclk;
  input counter_out_reg;
  input counter_out_reg_0;
  input counter_out_reg_1;
  input counter_out_reg_2;
  input counter_out_reg_3;
  input counter_out_reg_4;
  input counter_out_reg_5;
  input counter_out_reg_6;
  input axi_bvalid_reg_0;
  input axi_awready_reg_1;
  input axi_wready_reg_0;
  input axi_rvalid_reg_1;
  input axi_arready_reg_1;
  input s00_axi_awvalid;
  input s00_axi_wvalid;
  input s00_axi_arvalid;
  input s00_axi_rready;
  input [3:0]s00_axi_awaddr;
  input [31:0]s00_axi_wdata;
  input [3:0]s00_axi_araddr;
  input s00_axi_aresetn;
  input [3:0]s00_axi_wstrb;

  wire [7:0]D;
  wire \FSM_sequential_state_read[0]_i_1_n_0 ;
  wire \FSM_sequential_state_read[1]_i_1_n_0 ;
  wire \FSM_sequential_state_write[0]_i_1_n_0 ;
  wire \FSM_sequential_state_write[1]_i_1_n_0 ;
  wire arthur_liquid_n_0;
  wire \axi_araddr[5]_i_1_n_0 ;
  wire axi_arready_reg_0;
  wire axi_arready_reg_1;
  wire axi_awaddr;
  wire \axi_awaddr_reg_n_0_[2] ;
  wire \axi_awaddr_reg_n_0_[3] ;
  wire \axi_awaddr_reg_n_0_[4] ;
  wire \axi_awaddr_reg_n_0_[5] ;
  wire axi_awready0__0;
  wire axi_awready_reg_0;
  wire axi_awready_reg_1;
  wire axi_bvalid_reg_0;
  wire axi_rvalid_reg_0;
  wire axi_rvalid_reg_1;
  wire axi_wready_reg_0;
  wire count_clk_cycles1;
  wire count_clk_cycles1_11;
  wire count_clk_cycles1_13;
  wire count_clk_cycles1_15;
  wire count_clk_cycles1_17;
  wire count_clk_cycles1_19;
  wire count_clk_cycles1_7;
  wire count_clk_cycles1_9;
  wire counter_out0_out;
  wire counter_out0_out_10;
  wire counter_out0_out_12;
  wire counter_out0_out_14;
  wire counter_out0_out_16;
  wire counter_out0_out_18;
  wire counter_out0_out_20;
  wire counter_out0_out_8;
  wire counter_out_reg;
  wire counter_out_reg_0;
  wire counter_out_reg_1;
  wire counter_out_reg_2;
  wire counter_out_reg_3;
  wire counter_out_reg_4;
  wire counter_out_reg_5;
  wire counter_out_reg_6;
  wire [31:7]p_1_in;
  wire [0:0]p_2_in;
  wire s00_axi_aclk;
  wire [3:0]s00_axi_araddr;
  wire s00_axi_aresetn;
  wire s00_axi_arvalid;
  wire [3:0]s00_axi_awaddr;
  wire s00_axi_awvalid;
  wire s00_axi_bvalid;
  wire [31:0]s00_axi_rdata;
  wire \s00_axi_rdata[0]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[0]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[0]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[10]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[10]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[10]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[11]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[11]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[11]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[12]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[12]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[12]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[13]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[13]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[13]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[14]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[14]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[14]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[15]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[15]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[15]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[16]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[16]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[16]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[17]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[17]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[17]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[18]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[18]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[18]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[19]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[19]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[19]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[1]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[1]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[1]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[20]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[20]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[20]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[21]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[21]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[21]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[22]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[22]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[22]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[23]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[23]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[23]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[24]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[24]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[24]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[25]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[25]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[25]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[26]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[26]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[26]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[27]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[27]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[27]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[28]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[28]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[28]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[29]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[29]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[29]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[2]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[2]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[2]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[30]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[30]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[30]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[31]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[31]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[31]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[3]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[3]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[3]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[4]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[4]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[4]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[5]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[5]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[5]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[6]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[6]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[6]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[7]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[7]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[7]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[8]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[8]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[8]_INST_0_i_3_n_0 ;
  wire \s00_axi_rdata[9]_INST_0_i_1_n_0 ;
  wire \s00_axi_rdata[9]_INST_0_i_2_n_0 ;
  wire \s00_axi_rdata[9]_INST_0_i_3_n_0 ;
  wire s00_axi_rready;
  wire [31:0]s00_axi_wdata;
  wire s00_axi_wready;
  wire [3:0]s00_axi_wstrb;
  wire s00_axi_wvalid;
  wire [3:0]sel0;
  wire [7:0]slv_reg0;
  wire \slv_reg0[31]_i_2_n_0 ;
  wire \slv_reg0[31]_i_3_n_0 ;
  wire \slv_reg0[31]_i_4_n_0 ;
  wire \slv_reg0[31]_i_5_n_0 ;
  wire [31:8]slv_reg0__0;
  wire [8:0]slv_reg10;
  wire \slv_reg10[15]_i_1_n_0 ;
  wire \slv_reg10[23]_i_1_n_0 ;
  wire \slv_reg10[31]_i_1_n_0 ;
  wire \slv_reg10[7]_i_1_n_0 ;
  wire [31:9]slv_reg10__0;
  wire [7:0]slv_reg11;
  wire \slv_reg1[0]_i_1_n_0 ;
  wire \slv_reg1[0]_i_2_n_0 ;
  wire \slv_reg1[0]_i_3_n_0 ;
  wire \slv_reg1[15]_i_1_n_0 ;
  wire \slv_reg1[23]_i_1_n_0 ;
  wire \slv_reg1[31]_i_1_n_0 ;
  wire \slv_reg1[7]_i_1_n_0 ;
  wire \slv_reg1_reg_n_0_[10] ;
  wire \slv_reg1_reg_n_0_[11] ;
  wire \slv_reg1_reg_n_0_[12] ;
  wire \slv_reg1_reg_n_0_[13] ;
  wire \slv_reg1_reg_n_0_[14] ;
  wire \slv_reg1_reg_n_0_[15] ;
  wire \slv_reg1_reg_n_0_[16] ;
  wire \slv_reg1_reg_n_0_[17] ;
  wire \slv_reg1_reg_n_0_[18] ;
  wire \slv_reg1_reg_n_0_[19] ;
  wire \slv_reg1_reg_n_0_[1] ;
  wire \slv_reg1_reg_n_0_[20] ;
  wire \slv_reg1_reg_n_0_[21] ;
  wire \slv_reg1_reg_n_0_[22] ;
  wire \slv_reg1_reg_n_0_[23] ;
  wire \slv_reg1_reg_n_0_[24] ;
  wire \slv_reg1_reg_n_0_[25] ;
  wire \slv_reg1_reg_n_0_[26] ;
  wire \slv_reg1_reg_n_0_[27] ;
  wire \slv_reg1_reg_n_0_[28] ;
  wire \slv_reg1_reg_n_0_[29] ;
  wire \slv_reg1_reg_n_0_[2] ;
  wire \slv_reg1_reg_n_0_[30] ;
  wire \slv_reg1_reg_n_0_[31] ;
  wire \slv_reg1_reg_n_0_[3] ;
  wire \slv_reg1_reg_n_0_[4] ;
  wire \slv_reg1_reg_n_0_[5] ;
  wire \slv_reg1_reg_n_0_[6] ;
  wire \slv_reg1_reg_n_0_[7] ;
  wire \slv_reg1_reg_n_0_[8] ;
  wire \slv_reg1_reg_n_0_[9] ;
  wire [8:0]slv_reg2;
  wire \slv_reg2[15]_i_1_n_0 ;
  wire \slv_reg2[23]_i_1_n_0 ;
  wire \slv_reg2[31]_i_1_n_0 ;
  wire \slv_reg2[7]_i_1_n_0 ;
  wire [31:9]slv_reg2__0;
  wire [8:0]slv_reg3;
  wire \slv_reg3[15]_i_1_n_0 ;
  wire \slv_reg3[23]_i_1_n_0 ;
  wire \slv_reg3[31]_i_1_n_0 ;
  wire \slv_reg3[7]_i_1_n_0 ;
  wire [31:9]slv_reg3__0;
  wire [8:0]slv_reg4;
  wire \slv_reg4[15]_i_1_n_0 ;
  wire \slv_reg4[23]_i_1_n_0 ;
  wire \slv_reg4[31]_i_1_n_0 ;
  wire \slv_reg4[7]_i_1_n_0 ;
  wire [31:9]slv_reg4__0;
  wire [8:0]slv_reg5;
  wire \slv_reg5[15]_i_1_n_0 ;
  wire \slv_reg5[23]_i_1_n_0 ;
  wire \slv_reg5[31]_i_1_n_0 ;
  wire \slv_reg5[7]_i_1_n_0 ;
  wire [31:9]slv_reg5__0;
  wire [8:0]slv_reg6;
  wire \slv_reg6[15]_i_1_n_0 ;
  wire \slv_reg6[23]_i_1_n_0 ;
  wire \slv_reg6[31]_i_1_n_0 ;
  wire \slv_reg6[31]_i_2_n_0 ;
  wire \slv_reg6[7]_i_1_n_0 ;
  wire [31:9]slv_reg6__0;
  wire [8:0]slv_reg7;
  wire \slv_reg7[15]_i_1_n_0 ;
  wire \slv_reg7[23]_i_1_n_0 ;
  wire \slv_reg7[31]_i_1_n_0 ;
  wire \slv_reg7[7]_i_1_n_0 ;
  wire [31:9]slv_reg7__0;
  wire [8:0]slv_reg8;
  wire \slv_reg8[15]_i_1_n_0 ;
  wire \slv_reg8[23]_i_1_n_0 ;
  wire \slv_reg8[31]_i_1_n_0 ;
  wire \slv_reg8[7]_i_1_n_0 ;
  wire [31:9]slv_reg8__0;
  wire [8:0]slv_reg9;
  wire \slv_reg9[15]_i_1_n_0 ;
  wire \slv_reg9[23]_i_1_n_0 ;
  wire \slv_reg9[31]_i_1_n_0 ;
  wire \slv_reg9[7]_i_1_n_0 ;
  wire [31:9]slv_reg9__0;
  wire started;
  wire started_0;
  wire started_1;
  wire started_2;
  wire started_3;
  wire started_4;
  wire started_5;
  wire started_6;
  wire [1:0]state_read;
  wire \state_reg[2] ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_1 ;
  wire \state_reg[2]_2 ;
  wire \state_reg[2]_3 ;
  wire \state_reg[2]_4 ;
  wire \state_reg[2]_5 ;
  wire \state_reg[2]_6 ;
  wire [1:0]state_write;

  LUT6 #(
    .INIT(64'hFFFFF0007777FFFF)) 
    \FSM_sequential_state_read[0]_i_1 
       (.I0(s00_axi_arvalid),
        .I1(axi_arready_reg_0),
        .I2(s00_axi_rready),
        .I3(axi_rvalid_reg_0),
        .I4(state_read[0]),
        .I5(state_read[1]),
        .O(\FSM_sequential_state_read[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF0FFF88880000)) 
    \FSM_sequential_state_read[1]_i_1 
       (.I0(axi_arready_reg_0),
        .I1(s00_axi_arvalid),
        .I2(s00_axi_rready),
        .I3(axi_rvalid_reg_0),
        .I4(state_read[0]),
        .I5(state_read[1]),
        .O(\FSM_sequential_state_read[1]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "Idle:00,Rdata:10,Raddr:01" *) 
  FDRE \FSM_sequential_state_read_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_read[0]_i_1_n_0 ),
        .Q(state_read[0]),
        .R(arthur_liquid_n_0));
  (* FSM_ENCODED_STATES = "Idle:00,Rdata:10,Raddr:01" *) 
  FDRE \FSM_sequential_state_read_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_read[1]_i_1_n_0 ),
        .Q(state_read[1]),
        .R(arthur_liquid_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hFFF0F7FF)) 
    \FSM_sequential_state_write[0]_i_1 
       (.I0(axi_awready_reg_0),
        .I1(s00_axi_awvalid),
        .I2(s00_axi_wvalid),
        .I3(state_write[0]),
        .I4(state_write[1]),
        .O(\FSM_sequential_state_write[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hFF0F0800)) 
    \FSM_sequential_state_write[1]_i_1 
       (.I0(s00_axi_awvalid),
        .I1(axi_awready_reg_0),
        .I2(s00_axi_wvalid),
        .I3(state_write[0]),
        .I4(state_write[1]),
        .O(\FSM_sequential_state_write[1]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "Idle:00,Wdata:10,Waddr:01" *) 
  FDRE \FSM_sequential_state_write_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_write[0]_i_1_n_0 ),
        .Q(state_write[0]),
        .R(arthur_liquid_n_0));
  (* FSM_ENCODED_STATES = "Idle:00,Wdata:10,Waddr:01" *) 
  FDRE \FSM_sequential_state_write_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_write[1]_i_1_n_0 ),
        .Q(state_write[1]),
        .R(arthur_liquid_n_0));
  design_1_liquid_0_1_arthur arthur_liquid
       (.D(D),
        .Q(slv_reg2),
        .SR(arthur_liquid_n_0),
        .counter_out0_out(counter_out0_out),
        .counter_out0_out_10(counter_out0_out_10),
        .counter_out0_out_12(counter_out0_out_12),
        .counter_out0_out_14(counter_out0_out_14),
        .counter_out0_out_16(counter_out0_out_16),
        .counter_out0_out_18(counter_out0_out_18),
        .counter_out0_out_20(counter_out0_out_20),
        .counter_out0_out_8(counter_out0_out_8),
        .counter_out_reg(counter_out_reg),
        .counter_out_reg_0(counter_out_reg_0),
        .counter_out_reg_1(counter_out_reg_1),
        .counter_out_reg_2(counter_out_reg_2),
        .counter_out_reg_3(counter_out_reg_3),
        .counter_out_reg_4(counter_out_reg_4),
        .counter_out_reg_5(counter_out_reg_5),
        .counter_out_reg_6(counter_out_reg_6),
        .\liquid_division_reg_reg[8]_0 (slv_reg10),
        .p_2_in(p_2_in),
        .prev_was_load_reg_0(count_clk_cycles1),
        .prev_was_load_reg_1(count_clk_cycles1_7),
        .prev_was_load_reg_2(count_clk_cycles1_9),
        .prev_was_load_reg_3(count_clk_cycles1_11),
        .prev_was_load_reg_4(count_clk_cycles1_13),
        .prev_was_load_reg_5(count_clk_cycles1_15),
        .prev_was_load_reg_6(count_clk_cycles1_17),
        .prev_was_load_reg_7(count_clk_cycles1_19),
        .s00_axi_aclk(s00_axi_aclk),
        .s00_axi_aresetn(s00_axi_aresetn),
        .seconds_relay_1__8_carry__0_i_7_0(slv_reg3),
        .seconds_relay_2__8_carry__0_i_7_0(slv_reg4),
        .seconds_relay_3__8_carry__0_i_7_0(slv_reg5),
        .seconds_relay_4__8_carry__0_i_7_0(slv_reg6),
        .seconds_relay_5__8_carry__0_i_7_0(slv_reg7),
        .seconds_relay_6__8_carry__0_i_7_0(slv_reg8),
        .seconds_relay_7__8_carry__0_i_7_0(slv_reg9),
        .started_reg(started),
        .started_reg_0(started_0),
        .started_reg_1(started_1),
        .started_reg_2(started_2),
        .started_reg_3(started_3),
        .started_reg_4(started_4),
        .started_reg_5(started_5),
        .started_reg_6(started_6),
        .\state_reg[2] (\state_reg[2] ),
        .\state_reg[2]_0 (\state_reg[2]_0 ),
        .\state_reg[2]_1 (\state_reg[2]_1 ),
        .\state_reg[2]_2 (\state_reg[2]_2 ),
        .\state_reg[2]_3 (\state_reg[2]_3 ),
        .\state_reg[2]_4 (\state_reg[2]_4 ),
        .\state_reg[2]_5 (\state_reg[2]_5 ),
        .\state_reg[2]_6 (\state_reg[2]_6 ),
        .\state_reg[7] (slv_reg0));
  LUT5 #(
    .INIT(32'h00008000)) 
    \axi_araddr[5]_i_1 
       (.I0(s00_axi_aresetn),
        .I1(axi_arready_reg_0),
        .I2(s00_axi_arvalid),
        .I3(state_read[0]),
        .I4(state_read[1]),
        .O(\axi_araddr[5]_i_1_n_0 ));
  FDRE \axi_araddr_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\axi_araddr[5]_i_1_n_0 ),
        .D(s00_axi_araddr[0]),
        .Q(sel0[0]),
        .R(1'b0));
  FDRE \axi_araddr_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\axi_araddr[5]_i_1_n_0 ),
        .D(s00_axi_araddr[1]),
        .Q(sel0[1]),
        .R(1'b0));
  FDRE \axi_araddr_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\axi_araddr[5]_i_1_n_0 ),
        .D(s00_axi_araddr[2]),
        .Q(sel0[2]),
        .R(1'b0));
  FDRE \axi_araddr_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\axi_araddr[5]_i_1_n_0 ),
        .D(s00_axi_araddr[3]),
        .Q(sel0[3]),
        .R(1'b0));
  FDRE axi_arready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_arready_reg_1),
        .Q(axi_arready_reg_0),
        .R(arthur_liquid_n_0));
  LUT4 #(
    .INIT(16'h4000)) 
    \axi_awaddr[5]_i_1 
       (.I0(state_write[1]),
        .I1(state_write[0]),
        .I2(s00_axi_awvalid),
        .I3(axi_awready_reg_0),
        .O(axi_awaddr));
  FDRE \axi_awaddr_reg[2] 
       (.C(s00_axi_aclk),
        .CE(axi_awaddr),
        .D(s00_axi_awaddr[0]),
        .Q(\axi_awaddr_reg_n_0_[2] ),
        .R(arthur_liquid_n_0));
  FDRE \axi_awaddr_reg[3] 
       (.C(s00_axi_aclk),
        .CE(axi_awaddr),
        .D(s00_axi_awaddr[1]),
        .Q(\axi_awaddr_reg_n_0_[3] ),
        .R(arthur_liquid_n_0));
  FDRE \axi_awaddr_reg[4] 
       (.C(s00_axi_aclk),
        .CE(axi_awaddr),
        .D(s00_axi_awaddr[2]),
        .Q(\axi_awaddr_reg_n_0_[4] ),
        .R(arthur_liquid_n_0));
  FDRE \axi_awaddr_reg[5] 
       (.C(s00_axi_aclk),
        .CE(axi_awaddr),
        .D(s00_axi_awaddr[3]),
        .Q(\axi_awaddr_reg_n_0_[5] ),
        .R(arthur_liquid_n_0));
  FDRE axi_awready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_awready_reg_1),
        .Q(axi_awready_reg_0),
        .R(arthur_liquid_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    axi_bvalid_i_2
       (.I0(s00_axi_awvalid),
        .I1(axi_awready_reg_0),
        .O(axi_awready0__0));
  FDRE axi_bvalid_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_bvalid_reg_0),
        .Q(s00_axi_bvalid),
        .R(arthur_liquid_n_0));
  FDRE axi_rvalid_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_rvalid_reg_1),
        .Q(axi_rvalid_reg_0),
        .R(arthur_liquid_n_0));
  FDRE axi_wready_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(axi_wready_reg_0),
        .Q(s00_axi_wready),
        .R(arthur_liquid_n_0));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[0]_INST_0 
       (.I0(\s00_axi_rdata[0]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[0]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[0]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[0]_INST_0_i_1 
       (.I0(slv_reg11[0]),
        .I1(slv_reg10[0]),
        .I2(sel0[1]),
        .I3(slv_reg9[0]),
        .I4(sel0[0]),
        .I5(slv_reg8[0]),
        .O(\s00_axi_rdata[0]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[0]_INST_0_i_2 
       (.I0(slv_reg7[0]),
        .I1(slv_reg6[0]),
        .I2(sel0[1]),
        .I3(slv_reg5[0]),
        .I4(sel0[0]),
        .I5(slv_reg4[0]),
        .O(\s00_axi_rdata[0]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[0]_INST_0_i_3 
       (.I0(slv_reg3[0]),
        .I1(slv_reg2[0]),
        .I2(sel0[1]),
        .I3(p_2_in),
        .I4(sel0[0]),
        .I5(slv_reg0[0]),
        .O(\s00_axi_rdata[0]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[10]_INST_0 
       (.I0(\s00_axi_rdata[10]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[10]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[10]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[10]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[10]_INST_0_i_1 
       (.I0(slv_reg8__0[10]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[10]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[10]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[10]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[10]_INST_0_i_2 
       (.I0(slv_reg7__0[10]),
        .I1(slv_reg6__0[10]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[10]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[10]),
        .O(\s00_axi_rdata[10]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[10]_INST_0_i_3 
       (.I0(slv_reg3__0[10]),
        .I1(slv_reg2__0[10]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[10] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[10]),
        .O(\s00_axi_rdata[10]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[11]_INST_0 
       (.I0(\s00_axi_rdata[11]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[11]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[11]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[11]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[11]_INST_0_i_1 
       (.I0(slv_reg8__0[11]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[11]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[11]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[11]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[11]_INST_0_i_2 
       (.I0(slv_reg7__0[11]),
        .I1(slv_reg6__0[11]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[11]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[11]),
        .O(\s00_axi_rdata[11]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[11]_INST_0_i_3 
       (.I0(slv_reg3__0[11]),
        .I1(slv_reg2__0[11]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[11] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[11]),
        .O(\s00_axi_rdata[11]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[12]_INST_0 
       (.I0(\s00_axi_rdata[12]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[12]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[12]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[12]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[12]_INST_0_i_1 
       (.I0(slv_reg8__0[12]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[12]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[12]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[12]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[12]_INST_0_i_2 
       (.I0(slv_reg7__0[12]),
        .I1(slv_reg6__0[12]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[12]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[12]),
        .O(\s00_axi_rdata[12]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[12]_INST_0_i_3 
       (.I0(slv_reg3__0[12]),
        .I1(slv_reg2__0[12]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[12] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[12]),
        .O(\s00_axi_rdata[12]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[13]_INST_0 
       (.I0(\s00_axi_rdata[13]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[13]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[13]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[13]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[13]_INST_0_i_1 
       (.I0(slv_reg8__0[13]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[13]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[13]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[13]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[13]_INST_0_i_2 
       (.I0(slv_reg7__0[13]),
        .I1(slv_reg6__0[13]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[13]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[13]),
        .O(\s00_axi_rdata[13]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[13]_INST_0_i_3 
       (.I0(slv_reg3__0[13]),
        .I1(slv_reg2__0[13]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[13] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[13]),
        .O(\s00_axi_rdata[13]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[14]_INST_0 
       (.I0(\s00_axi_rdata[14]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[14]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[14]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[14]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[14]_INST_0_i_1 
       (.I0(slv_reg8__0[14]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[14]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[14]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[14]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[14]_INST_0_i_2 
       (.I0(slv_reg7__0[14]),
        .I1(slv_reg6__0[14]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[14]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[14]),
        .O(\s00_axi_rdata[14]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[14]_INST_0_i_3 
       (.I0(slv_reg3__0[14]),
        .I1(slv_reg2__0[14]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[14] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[14]),
        .O(\s00_axi_rdata[14]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[15]_INST_0 
       (.I0(\s00_axi_rdata[15]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[15]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[15]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[15]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[15]_INST_0_i_1 
       (.I0(slv_reg8__0[15]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[15]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[15]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[15]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[15]_INST_0_i_2 
       (.I0(slv_reg7__0[15]),
        .I1(slv_reg6__0[15]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[15]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[15]),
        .O(\s00_axi_rdata[15]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[15]_INST_0_i_3 
       (.I0(slv_reg3__0[15]),
        .I1(slv_reg2__0[15]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[15] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[15]),
        .O(\s00_axi_rdata[15]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[16]_INST_0 
       (.I0(\s00_axi_rdata[16]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[16]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[16]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[16]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[16]_INST_0_i_1 
       (.I0(slv_reg8__0[16]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[16]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[16]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[16]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[16]_INST_0_i_2 
       (.I0(slv_reg7__0[16]),
        .I1(slv_reg6__0[16]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[16]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[16]),
        .O(\s00_axi_rdata[16]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[16]_INST_0_i_3 
       (.I0(slv_reg3__0[16]),
        .I1(slv_reg2__0[16]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[16] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[16]),
        .O(\s00_axi_rdata[16]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[17]_INST_0 
       (.I0(\s00_axi_rdata[17]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[17]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[17]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[17]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[17]_INST_0_i_1 
       (.I0(slv_reg8__0[17]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[17]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[17]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[17]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[17]_INST_0_i_2 
       (.I0(slv_reg7__0[17]),
        .I1(slv_reg6__0[17]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[17]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[17]),
        .O(\s00_axi_rdata[17]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[17]_INST_0_i_3 
       (.I0(slv_reg3__0[17]),
        .I1(slv_reg2__0[17]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[17] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[17]),
        .O(\s00_axi_rdata[17]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[18]_INST_0 
       (.I0(\s00_axi_rdata[18]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[18]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[18]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[18]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[18]_INST_0_i_1 
       (.I0(slv_reg8__0[18]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[18]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[18]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[18]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[18]_INST_0_i_2 
       (.I0(slv_reg7__0[18]),
        .I1(slv_reg6__0[18]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[18]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[18]),
        .O(\s00_axi_rdata[18]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[18]_INST_0_i_3 
       (.I0(slv_reg3__0[18]),
        .I1(slv_reg2__0[18]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[18] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[18]),
        .O(\s00_axi_rdata[18]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[19]_INST_0 
       (.I0(\s00_axi_rdata[19]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[19]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[19]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[19]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[19]_INST_0_i_1 
       (.I0(slv_reg8__0[19]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[19]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[19]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[19]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[19]_INST_0_i_2 
       (.I0(slv_reg7__0[19]),
        .I1(slv_reg6__0[19]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[19]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[19]),
        .O(\s00_axi_rdata[19]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[19]_INST_0_i_3 
       (.I0(slv_reg3__0[19]),
        .I1(slv_reg2__0[19]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[19] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[19]),
        .O(\s00_axi_rdata[19]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[1]_INST_0 
       (.I0(\s00_axi_rdata[1]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[1]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[1]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[1]_INST_0_i_1 
       (.I0(slv_reg11[1]),
        .I1(slv_reg10[1]),
        .I2(sel0[1]),
        .I3(slv_reg9[1]),
        .I4(sel0[0]),
        .I5(slv_reg8[1]),
        .O(\s00_axi_rdata[1]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[1]_INST_0_i_2 
       (.I0(slv_reg7[1]),
        .I1(slv_reg6[1]),
        .I2(sel0[1]),
        .I3(slv_reg5[1]),
        .I4(sel0[0]),
        .I5(slv_reg4[1]),
        .O(\s00_axi_rdata[1]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[1]_INST_0_i_3 
       (.I0(slv_reg3[1]),
        .I1(slv_reg2[1]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[1] ),
        .I4(sel0[0]),
        .I5(slv_reg0[1]),
        .O(\s00_axi_rdata[1]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[20]_INST_0 
       (.I0(\s00_axi_rdata[20]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[20]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[20]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[20]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[20]_INST_0_i_1 
       (.I0(slv_reg8__0[20]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[20]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[20]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[20]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[20]_INST_0_i_2 
       (.I0(slv_reg7__0[20]),
        .I1(slv_reg6__0[20]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[20]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[20]),
        .O(\s00_axi_rdata[20]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[20]_INST_0_i_3 
       (.I0(slv_reg3__0[20]),
        .I1(slv_reg2__0[20]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[20] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[20]),
        .O(\s00_axi_rdata[20]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[21]_INST_0 
       (.I0(\s00_axi_rdata[21]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[21]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[21]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[21]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[21]_INST_0_i_1 
       (.I0(slv_reg8__0[21]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[21]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[21]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[21]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[21]_INST_0_i_2 
       (.I0(slv_reg7__0[21]),
        .I1(slv_reg6__0[21]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[21]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[21]),
        .O(\s00_axi_rdata[21]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[21]_INST_0_i_3 
       (.I0(slv_reg3__0[21]),
        .I1(slv_reg2__0[21]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[21] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[21]),
        .O(\s00_axi_rdata[21]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[22]_INST_0 
       (.I0(\s00_axi_rdata[22]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[22]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[22]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[22]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[22]_INST_0_i_1 
       (.I0(slv_reg8__0[22]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[22]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[22]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[22]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[22]_INST_0_i_2 
       (.I0(slv_reg7__0[22]),
        .I1(slv_reg6__0[22]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[22]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[22]),
        .O(\s00_axi_rdata[22]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[22]_INST_0_i_3 
       (.I0(slv_reg3__0[22]),
        .I1(slv_reg2__0[22]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[22] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[22]),
        .O(\s00_axi_rdata[22]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[23]_INST_0 
       (.I0(\s00_axi_rdata[23]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[23]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[23]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[23]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[23]_INST_0_i_1 
       (.I0(slv_reg8__0[23]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[23]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[23]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[23]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[23]_INST_0_i_2 
       (.I0(slv_reg7__0[23]),
        .I1(slv_reg6__0[23]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[23]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[23]),
        .O(\s00_axi_rdata[23]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[23]_INST_0_i_3 
       (.I0(slv_reg3__0[23]),
        .I1(slv_reg2__0[23]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[23] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[23]),
        .O(\s00_axi_rdata[23]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[24]_INST_0 
       (.I0(\s00_axi_rdata[24]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[24]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[24]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[24]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[24]_INST_0_i_1 
       (.I0(slv_reg8__0[24]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[24]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[24]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[24]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[24]_INST_0_i_2 
       (.I0(slv_reg7__0[24]),
        .I1(slv_reg6__0[24]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[24]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[24]),
        .O(\s00_axi_rdata[24]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[24]_INST_0_i_3 
       (.I0(slv_reg3__0[24]),
        .I1(slv_reg2__0[24]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[24] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[24]),
        .O(\s00_axi_rdata[24]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[25]_INST_0 
       (.I0(\s00_axi_rdata[25]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[25]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[25]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[25]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[25]_INST_0_i_1 
       (.I0(slv_reg8__0[25]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[25]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[25]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[25]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[25]_INST_0_i_2 
       (.I0(slv_reg7__0[25]),
        .I1(slv_reg6__0[25]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[25]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[25]),
        .O(\s00_axi_rdata[25]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[25]_INST_0_i_3 
       (.I0(slv_reg3__0[25]),
        .I1(slv_reg2__0[25]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[25] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[25]),
        .O(\s00_axi_rdata[25]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[26]_INST_0 
       (.I0(\s00_axi_rdata[26]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[26]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[26]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[26]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[26]_INST_0_i_1 
       (.I0(slv_reg8__0[26]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[26]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[26]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[26]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[26]_INST_0_i_2 
       (.I0(slv_reg7__0[26]),
        .I1(slv_reg6__0[26]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[26]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[26]),
        .O(\s00_axi_rdata[26]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[26]_INST_0_i_3 
       (.I0(slv_reg3__0[26]),
        .I1(slv_reg2__0[26]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[26] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[26]),
        .O(\s00_axi_rdata[26]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[27]_INST_0 
       (.I0(\s00_axi_rdata[27]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[27]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[27]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[27]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[27]_INST_0_i_1 
       (.I0(slv_reg8__0[27]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[27]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[27]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[27]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[27]_INST_0_i_2 
       (.I0(slv_reg7__0[27]),
        .I1(slv_reg6__0[27]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[27]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[27]),
        .O(\s00_axi_rdata[27]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[27]_INST_0_i_3 
       (.I0(slv_reg3__0[27]),
        .I1(slv_reg2__0[27]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[27] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[27]),
        .O(\s00_axi_rdata[27]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[28]_INST_0 
       (.I0(\s00_axi_rdata[28]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[28]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[28]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[28]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[28]_INST_0_i_1 
       (.I0(slv_reg8__0[28]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[28]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[28]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[28]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[28]_INST_0_i_2 
       (.I0(slv_reg7__0[28]),
        .I1(slv_reg6__0[28]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[28]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[28]),
        .O(\s00_axi_rdata[28]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[28]_INST_0_i_3 
       (.I0(slv_reg3__0[28]),
        .I1(slv_reg2__0[28]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[28] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[28]),
        .O(\s00_axi_rdata[28]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[29]_INST_0 
       (.I0(\s00_axi_rdata[29]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[29]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[29]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[29]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[29]_INST_0_i_1 
       (.I0(slv_reg8__0[29]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[29]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[29]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[29]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[29]_INST_0_i_2 
       (.I0(slv_reg7__0[29]),
        .I1(slv_reg6__0[29]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[29]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[29]),
        .O(\s00_axi_rdata[29]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[29]_INST_0_i_3 
       (.I0(slv_reg3__0[29]),
        .I1(slv_reg2__0[29]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[29] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[29]),
        .O(\s00_axi_rdata[29]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[2]_INST_0 
       (.I0(\s00_axi_rdata[2]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[2]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[2]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[2]_INST_0_i_1 
       (.I0(slv_reg11[2]),
        .I1(slv_reg10[2]),
        .I2(sel0[1]),
        .I3(slv_reg9[2]),
        .I4(sel0[0]),
        .I5(slv_reg8[2]),
        .O(\s00_axi_rdata[2]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[2]_INST_0_i_2 
       (.I0(slv_reg7[2]),
        .I1(slv_reg6[2]),
        .I2(sel0[1]),
        .I3(slv_reg5[2]),
        .I4(sel0[0]),
        .I5(slv_reg4[2]),
        .O(\s00_axi_rdata[2]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[2]_INST_0_i_3 
       (.I0(slv_reg3[2]),
        .I1(slv_reg2[2]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[2] ),
        .I4(sel0[0]),
        .I5(slv_reg0[2]),
        .O(\s00_axi_rdata[2]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[30]_INST_0 
       (.I0(\s00_axi_rdata[30]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[30]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[30]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[30]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[30]_INST_0_i_1 
       (.I0(slv_reg8__0[30]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[30]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[30]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[30]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[30]_INST_0_i_2 
       (.I0(slv_reg7__0[30]),
        .I1(slv_reg6__0[30]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[30]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[30]),
        .O(\s00_axi_rdata[30]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[30]_INST_0_i_3 
       (.I0(slv_reg3__0[30]),
        .I1(slv_reg2__0[30]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[30] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[30]),
        .O(\s00_axi_rdata[30]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[31]_INST_0 
       (.I0(\s00_axi_rdata[31]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[31]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[31]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[31]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[31]_INST_0_i_1 
       (.I0(slv_reg8__0[31]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[31]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[31]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[31]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[31]_INST_0_i_2 
       (.I0(slv_reg7__0[31]),
        .I1(slv_reg6__0[31]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[31]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[31]),
        .O(\s00_axi_rdata[31]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[31]_INST_0_i_3 
       (.I0(slv_reg3__0[31]),
        .I1(slv_reg2__0[31]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[31] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[31]),
        .O(\s00_axi_rdata[31]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[3]_INST_0 
       (.I0(\s00_axi_rdata[3]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[3]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[3]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[3]_INST_0_i_1 
       (.I0(slv_reg11[3]),
        .I1(slv_reg10[3]),
        .I2(sel0[1]),
        .I3(slv_reg9[3]),
        .I4(sel0[0]),
        .I5(slv_reg8[3]),
        .O(\s00_axi_rdata[3]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[3]_INST_0_i_2 
       (.I0(slv_reg7[3]),
        .I1(slv_reg6[3]),
        .I2(sel0[1]),
        .I3(slv_reg5[3]),
        .I4(sel0[0]),
        .I5(slv_reg4[3]),
        .O(\s00_axi_rdata[3]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[3]_INST_0_i_3 
       (.I0(slv_reg3[3]),
        .I1(slv_reg2[3]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[3] ),
        .I4(sel0[0]),
        .I5(slv_reg0[3]),
        .O(\s00_axi_rdata[3]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[4]_INST_0 
       (.I0(\s00_axi_rdata[4]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[4]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[4]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[4]_INST_0_i_1 
       (.I0(slv_reg11[4]),
        .I1(slv_reg10[4]),
        .I2(sel0[1]),
        .I3(slv_reg9[4]),
        .I4(sel0[0]),
        .I5(slv_reg8[4]),
        .O(\s00_axi_rdata[4]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[4]_INST_0_i_2 
       (.I0(slv_reg7[4]),
        .I1(slv_reg6[4]),
        .I2(sel0[1]),
        .I3(slv_reg5[4]),
        .I4(sel0[0]),
        .I5(slv_reg4[4]),
        .O(\s00_axi_rdata[4]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[4]_INST_0_i_3 
       (.I0(slv_reg3[4]),
        .I1(slv_reg2[4]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[4] ),
        .I4(sel0[0]),
        .I5(slv_reg0[4]),
        .O(\s00_axi_rdata[4]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[5]_INST_0 
       (.I0(\s00_axi_rdata[5]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[5]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[5]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[5]_INST_0_i_1 
       (.I0(slv_reg11[5]),
        .I1(slv_reg10[5]),
        .I2(sel0[1]),
        .I3(slv_reg9[5]),
        .I4(sel0[0]),
        .I5(slv_reg8[5]),
        .O(\s00_axi_rdata[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[5]_INST_0_i_2 
       (.I0(slv_reg7[5]),
        .I1(slv_reg6[5]),
        .I2(sel0[1]),
        .I3(slv_reg5[5]),
        .I4(sel0[0]),
        .I5(slv_reg4[5]),
        .O(\s00_axi_rdata[5]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[5]_INST_0_i_3 
       (.I0(slv_reg3[5]),
        .I1(slv_reg2[5]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[5] ),
        .I4(sel0[0]),
        .I5(slv_reg0[5]),
        .O(\s00_axi_rdata[5]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[6]_INST_0 
       (.I0(\s00_axi_rdata[6]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[6]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[6]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[6]_INST_0_i_1 
       (.I0(slv_reg11[6]),
        .I1(slv_reg10[6]),
        .I2(sel0[1]),
        .I3(slv_reg9[6]),
        .I4(sel0[0]),
        .I5(slv_reg8[6]),
        .O(\s00_axi_rdata[6]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[6]_INST_0_i_2 
       (.I0(slv_reg7[6]),
        .I1(slv_reg6[6]),
        .I2(sel0[1]),
        .I3(slv_reg5[6]),
        .I4(sel0[0]),
        .I5(slv_reg4[6]),
        .O(\s00_axi_rdata[6]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[6]_INST_0_i_3 
       (.I0(slv_reg3[6]),
        .I1(slv_reg2[6]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[6] ),
        .I4(sel0[0]),
        .I5(slv_reg0[6]),
        .O(\s00_axi_rdata[6]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \s00_axi_rdata[7]_INST_0 
       (.I0(\s00_axi_rdata[7]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[7]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[7]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[7]_INST_0_i_1 
       (.I0(slv_reg11[7]),
        .I1(slv_reg10[7]),
        .I2(sel0[1]),
        .I3(slv_reg9[7]),
        .I4(sel0[0]),
        .I5(slv_reg8[7]),
        .O(\s00_axi_rdata[7]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[7]_INST_0_i_2 
       (.I0(slv_reg7[7]),
        .I1(slv_reg6[7]),
        .I2(sel0[1]),
        .I3(slv_reg5[7]),
        .I4(sel0[0]),
        .I5(slv_reg4[7]),
        .O(\s00_axi_rdata[7]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[7]_INST_0_i_3 
       (.I0(slv_reg3[7]),
        .I1(slv_reg2[7]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[7] ),
        .I4(sel0[0]),
        .I5(slv_reg0[7]),
        .O(\s00_axi_rdata[7]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[8]_INST_0 
       (.I0(\s00_axi_rdata[8]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[8]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[8]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[8]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[8]_INST_0_i_1 
       (.I0(slv_reg8[8]),
        .I1(sel0[0]),
        .I2(slv_reg9[8]),
        .I3(sel0[1]),
        .I4(slv_reg10[8]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[8]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[8]_INST_0_i_2 
       (.I0(slv_reg7[8]),
        .I1(slv_reg6[8]),
        .I2(sel0[1]),
        .I3(slv_reg5[8]),
        .I4(sel0[0]),
        .I5(slv_reg4[8]),
        .O(\s00_axi_rdata[8]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[8]_INST_0_i_3 
       (.I0(slv_reg3[8]),
        .I1(slv_reg2[8]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[8] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[8]),
        .O(\s00_axi_rdata[8]_INST_0_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \s00_axi_rdata[9]_INST_0 
       (.I0(\s00_axi_rdata[9]_INST_0_i_1_n_0 ),
        .I1(sel0[3]),
        .I2(\s00_axi_rdata[9]_INST_0_i_2_n_0 ),
        .I3(sel0[2]),
        .I4(\s00_axi_rdata[9]_INST_0_i_3_n_0 ),
        .O(s00_axi_rdata[9]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \s00_axi_rdata[9]_INST_0_i_1 
       (.I0(slv_reg8__0[9]),
        .I1(sel0[0]),
        .I2(slv_reg9__0[9]),
        .I3(sel0[1]),
        .I4(slv_reg10__0[9]),
        .I5(sel0[2]),
        .O(\s00_axi_rdata[9]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[9]_INST_0_i_2 
       (.I0(slv_reg7__0[9]),
        .I1(slv_reg6__0[9]),
        .I2(sel0[1]),
        .I3(slv_reg5__0[9]),
        .I4(sel0[0]),
        .I5(slv_reg4__0[9]),
        .O(\s00_axi_rdata[9]_INST_0_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \s00_axi_rdata[9]_INST_0_i_3 
       (.I0(slv_reg3__0[9]),
        .I1(slv_reg2__0[9]),
        .I2(sel0[1]),
        .I3(\slv_reg1_reg_n_0_[9] ),
        .I4(sel0[0]),
        .I5(slv_reg0__0[9]),
        .O(\s00_axi_rdata[9]_INST_0_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \slv_reg0[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_2_n_0 ),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[1]),
        .O(p_1_in[15]));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \slv_reg0[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_2_n_0 ),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[2]),
        .O(p_1_in[23]));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \slv_reg0[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_2_n_0 ),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[3]),
        .O(p_1_in[31]));
  LUT3 #(
    .INIT(8'hB8)) 
    \slv_reg0[31]_i_2 
       (.I0(s00_axi_awaddr[0]),
        .I1(s00_axi_awvalid),
        .I2(\axi_awaddr_reg_n_0_[2] ),
        .O(\slv_reg0[31]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \slv_reg0[31]_i_3 
       (.I0(s00_axi_awaddr[3]),
        .I1(s00_axi_awvalid),
        .I2(\axi_awaddr_reg_n_0_[5] ),
        .O(\slv_reg0[31]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \slv_reg0[31]_i_4 
       (.I0(s00_axi_awaddr[1]),
        .I1(s00_axi_awvalid),
        .I2(\axi_awaddr_reg_n_0_[3] ),
        .O(\slv_reg0[31]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \slv_reg0[31]_i_5 
       (.I0(s00_axi_awaddr[2]),
        .I1(s00_axi_awvalid),
        .I2(\axi_awaddr_reg_n_0_[4] ),
        .O(\slv_reg0[31]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \slv_reg0[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_2_n_0 ),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[0]),
        .O(p_1_in[7]));
  FDRE \slv_reg0_reg[0] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg0[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[10] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg0__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[11] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg0__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[12] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg0__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[13] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg0__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[14] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg0__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[15] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg0__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[16] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg0__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[17] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg0__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[18] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg0__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[19] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg0__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[1] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg0[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[20] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg0__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[21] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg0__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[22] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg0__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[23] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[23]),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg0__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[24] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg0__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[25] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg0__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[26] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg0__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[27] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg0__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[28] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg0__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[29] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg0__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[2] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg0[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[30] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg0__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[31] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[31]),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg0__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[3] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg0[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[4] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg0[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[5] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg0[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[6] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg0[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[7] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[7]),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg0[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[8] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg0__0[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg0_reg[9] 
       (.C(s00_axi_aclk),
        .CE(p_1_in[15]),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg0__0[9]),
        .R(arthur_liquid_n_0));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg10[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(s00_axi_wstrb[1]),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg10[15]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg10[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(s00_axi_wstrb[2]),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg10[23]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg10[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(s00_axi_wstrb[3]),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg10[31]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg10[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(s00_axi_wstrb[0]),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg10[7]_i_1_n_0 ));
  FDRE \slv_reg10_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg10[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg10__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg10__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg10__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg10__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg10__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg10__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg10__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg10__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg10__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg10__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg10[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg10__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg10__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg10__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg10__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg10__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg10__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg10__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg10__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg10__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg10__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg10[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg10__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg10__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg10[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg10[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg10[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg10[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg10[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg10[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg10_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg10[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg10__0[9]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[0]),
        .Q(slv_reg11[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[1] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[1]),
        .Q(slv_reg11[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[2] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[2]),
        .Q(slv_reg11[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[3] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[3]),
        .Q(slv_reg11[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[4] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[4]),
        .Q(slv_reg11[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[5] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[5]),
        .Q(slv_reg11[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[6] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[6]),
        .Q(slv_reg11[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg11_reg[7] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(D[7]),
        .Q(slv_reg11[7]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'hFFFB000000080000)) 
    \slv_reg1[0]_i_1 
       (.I0(s00_axi_wdata[0]),
        .I1(\slv_reg0[31]_i_2_n_0 ),
        .I2(\slv_reg1[0]_i_2_n_0 ),
        .I3(\slv_reg1[0]_i_3_n_0 ),
        .I4(s00_axi_wvalid),
        .I5(p_2_in),
        .O(\slv_reg1[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \slv_reg1[0]_i_2 
       (.I0(\axi_awaddr_reg_n_0_[4] ),
        .I1(s00_axi_awaddr[2]),
        .I2(\axi_awaddr_reg_n_0_[3] ),
        .I3(s00_axi_awvalid),
        .I4(s00_axi_awaddr[1]),
        .O(\slv_reg1[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hE2FF)) 
    \slv_reg1[0]_i_3 
       (.I0(\axi_awaddr_reg_n_0_[5] ),
        .I1(s00_axi_awvalid),
        .I2(s00_axi_awaddr[3]),
        .I3(s00_axi_wstrb[0]),
        .O(\slv_reg1[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg1[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_2_n_0 ),
        .O(\slv_reg1[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg1[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_2_n_0 ),
        .O(\slv_reg1[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg1[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_2_n_0 ),
        .O(\slv_reg1[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg1[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_2_n_0 ),
        .O(\slv_reg1[7]_i_1_n_0 ));
  FDRE \slv_reg1_reg[0] 
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(\slv_reg1[0]_i_1_n_0 ),
        .Q(p_2_in),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(\slv_reg1_reg_n_0_[10] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(\slv_reg1_reg_n_0_[11] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(\slv_reg1_reg_n_0_[12] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(\slv_reg1_reg_n_0_[13] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(\slv_reg1_reg_n_0_[14] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(\slv_reg1_reg_n_0_[15] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(\slv_reg1_reg_n_0_[16] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(\slv_reg1_reg_n_0_[17] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(\slv_reg1_reg_n_0_[18] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(\slv_reg1_reg_n_0_[19] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(\slv_reg1_reg_n_0_[1] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(\slv_reg1_reg_n_0_[20] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(\slv_reg1_reg_n_0_[21] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(\slv_reg1_reg_n_0_[22] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(\slv_reg1_reg_n_0_[23] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(\slv_reg1_reg_n_0_[24] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(\slv_reg1_reg_n_0_[25] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(\slv_reg1_reg_n_0_[26] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(\slv_reg1_reg_n_0_[27] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(\slv_reg1_reg_n_0_[28] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(\slv_reg1_reg_n_0_[29] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(\slv_reg1_reg_n_0_[2] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(\slv_reg1_reg_n_0_[30] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(\slv_reg1_reg_n_0_[31] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(\slv_reg1_reg_n_0_[3] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(\slv_reg1_reg_n_0_[4] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(\slv_reg1_reg_n_0_[5] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(\slv_reg1_reg_n_0_[6] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(\slv_reg1_reg_n_0_[7] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(\slv_reg1_reg_n_0_[8] ),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg1_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg1[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(\slv_reg1_reg_n_0_[9] ),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg2[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_4_n_0 ),
        .O(\slv_reg2[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg2[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_4_n_0 ),
        .O(\slv_reg2[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg2[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_4_n_0 ),
        .O(\slv_reg2[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg2[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_4_n_0 ),
        .O(\slv_reg2[7]_i_1_n_0 ));
  FDRE \slv_reg2_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg2[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg2__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg2__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg2__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg2__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg2__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg2__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg2__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg2__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg2__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg2__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg2[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg2__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg2__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg2__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg2__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg2__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg2__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg2__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg2__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg2__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg2__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg2[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg2__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg2__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg2[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg2[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg2[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg2[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg2[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg2[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg2_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg2[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg2__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg3[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg3[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg3[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg3[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg3[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg3[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg3[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg3[7]_i_1_n_0 ));
  FDRE \slv_reg3_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg3[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg3__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg3__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg3__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg3__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg3__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg3__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg3__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg3__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg3__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg3__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg3[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg3__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg3__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg3__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg3__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg3__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg3__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg3__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg3__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg3__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg3__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg3[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg3__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg3__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg3[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg3[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg3[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg3[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg3[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg3[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg3_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg3[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg3__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg4[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_2_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg4[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg4[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_2_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg4[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg4[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_2_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg4[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg4[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_3_n_0 ),
        .I3(\slv_reg0[31]_i_4_n_0 ),
        .I4(\slv_reg0[31]_i_2_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg4[7]_i_1_n_0 ));
  FDRE \slv_reg4_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg4[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg4__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg4__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg4__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg4__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg4__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg4__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg4__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg4__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg4__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg4__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg4[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg4__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg4__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg4__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg4__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg4__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg4__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg4__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg4__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg4__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg4__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg4[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg4__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg4__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg4[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg4[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg4[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg4[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg4[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg4[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg4_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg4[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg4__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg5[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_5_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg5[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg5[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_5_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg5[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg5[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_5_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg5[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg5[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(\slv_reg0[31]_i_5_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg5[7]_i_1_n_0 ));
  FDRE \slv_reg5_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg5[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg5__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg5__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg5__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg5__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg5__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg5__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg5__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg5__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg5__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg5__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg5[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg5__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg5__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg5__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg5__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg5__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg5__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg5__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg5__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg5__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg5__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg5[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg5__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg5__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg5[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg5[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg5[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg5[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg5[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg5[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg5_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg5[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg5__0[9]),
        .R(arthur_liquid_n_0));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg6[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[1]),
        .I2(\slv_reg0[31]_i_5_n_0 ),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg6[15]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg6[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[2]),
        .I2(\slv_reg0[31]_i_5_n_0 ),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg6[23]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg6[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[3]),
        .I2(\slv_reg0[31]_i_5_n_0 ),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg6[31]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hCCAFFFAF)) 
    \slv_reg6[31]_i_2 
       (.I0(\axi_awaddr_reg_n_0_[2] ),
        .I1(s00_axi_awaddr[0]),
        .I2(\axi_awaddr_reg_n_0_[3] ),
        .I3(s00_axi_awvalid),
        .I4(s00_axi_awaddr[1]),
        .O(\slv_reg6[31]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \slv_reg6[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(s00_axi_wstrb[0]),
        .I2(\slv_reg0[31]_i_5_n_0 ),
        .I3(\slv_reg6[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg6[7]_i_1_n_0 ));
  FDRE \slv_reg6_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg6[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg6__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg6__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg6__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg6__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg6__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg6__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg6__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg6__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg6__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg6__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg6[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg6__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg6__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg6__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg6__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg6__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg6__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg6__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg6__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg6__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg6__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg6[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg6__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg6__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg6[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg6[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg6[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg6[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg6[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg6[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg6_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg6[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg6__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \slv_reg7[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_5_n_0 ),
        .I2(s00_axi_wstrb[1]),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg7[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \slv_reg7[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_5_n_0 ),
        .I2(s00_axi_wstrb[2]),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg7[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \slv_reg7[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_5_n_0 ),
        .I2(s00_axi_wstrb[3]),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg7[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080000000)) 
    \slv_reg7[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_5_n_0 ),
        .I2(s00_axi_wstrb[0]),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_3_n_0 ),
        .O(\slv_reg7[7]_i_1_n_0 ));
  FDRE \slv_reg7_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg7[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg7__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg7__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg7__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg7__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg7__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg7__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg7__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg7__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg7__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg7__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg7[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg7__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg7__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg7__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg7__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg7__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg7__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg7__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg7__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg7__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg7__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg7[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg7__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg7__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg7[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg7[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg7[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg7[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg7[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg7[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg7_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg7[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg7__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg8[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_4_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[1]),
        .O(\slv_reg8[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg8[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_4_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[2]),
        .O(\slv_reg8[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg8[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_4_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[3]),
        .O(\slv_reg8[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000800000000)) 
    \slv_reg8[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_4_n_0 ),
        .I3(\slv_reg0[31]_i_2_n_0 ),
        .I4(\slv_reg0[31]_i_5_n_0 ),
        .I5(s00_axi_wstrb[0]),
        .O(\slv_reg8[7]_i_1_n_0 ));
  FDRE \slv_reg8_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg8[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg8__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg8__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg8__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg8__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg8__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg8__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg8__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg8__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg8__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg8__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg8[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg8__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg8__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg8__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg8__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg8__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg8__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg8__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg8__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg8__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg8__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg8[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg8__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg8__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg8[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg8[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg8[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg8[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg8[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg8[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg8_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg8[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg8__0[9]),
        .R(arthur_liquid_n_0));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg9[15]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(s00_axi_wstrb[1]),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg9[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg9[23]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(s00_axi_wstrb[2]),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg9[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg9[31]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(s00_axi_wstrb[3]),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg9[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \slv_reg9[7]_i_1 
       (.I0(s00_axi_wvalid),
        .I1(\slv_reg0[31]_i_3_n_0 ),
        .I2(\slv_reg0[31]_i_2_n_0 ),
        .I3(s00_axi_wstrb[0]),
        .I4(\slv_reg0[31]_i_4_n_0 ),
        .I5(\slv_reg0[31]_i_5_n_0 ),
        .O(\slv_reg9[7]_i_1_n_0 ));
  FDRE \slv_reg9_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[0]),
        .Q(slv_reg9[0]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[10]),
        .Q(slv_reg9__0[10]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[11]),
        .Q(slv_reg9__0[11]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[12]),
        .Q(slv_reg9__0[12]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[13]),
        .Q(slv_reg9__0[13]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[14]),
        .Q(slv_reg9__0[14]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[15]),
        .Q(slv_reg9__0[15]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[16]),
        .Q(slv_reg9__0[16]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[17]),
        .Q(slv_reg9__0[17]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[18]),
        .Q(slv_reg9__0[18]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[19]),
        .Q(slv_reg9__0[19]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[1]),
        .Q(slv_reg9[1]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[20]),
        .Q(slv_reg9__0[20]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[21]),
        .Q(slv_reg9__0[21]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[22]),
        .Q(slv_reg9__0[22]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[23]_i_1_n_0 ),
        .D(s00_axi_wdata[23]),
        .Q(slv_reg9__0[23]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[24]),
        .Q(slv_reg9__0[24]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[25]),
        .Q(slv_reg9__0[25]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[26] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[26]),
        .Q(slv_reg9__0[26]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[27] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[27]),
        .Q(slv_reg9__0[27]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[28] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[28]),
        .Q(slv_reg9__0[28]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[29] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[29]),
        .Q(slv_reg9__0[29]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[2]),
        .Q(slv_reg9[2]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[30] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[30]),
        .Q(slv_reg9__0[30]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[31] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[31]_i_1_n_0 ),
        .D(s00_axi_wdata[31]),
        .Q(slv_reg9__0[31]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[3]),
        .Q(slv_reg9[3]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[4]),
        .Q(slv_reg9[4]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[5]),
        .Q(slv_reg9[5]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[6]),
        .Q(slv_reg9[6]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[7]_i_1_n_0 ),
        .D(s00_axi_wdata[7]),
        .Q(slv_reg9[7]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[8]),
        .Q(slv_reg9[8]),
        .R(arthur_liquid_n_0));
  FDRE \slv_reg9_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\slv_reg9[15]_i_1_n_0 ),
        .D(s00_axi_wdata[9]),
        .Q(slv_reg9__0[9]),
        .R(arthur_liquid_n_0));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register
   (prev_was_load_reg,
    \state_reg[7]_0 ,
    prev_was_load_reg_0,
    prev_was_load_reg_1,
    prev_was_load_reg_2,
    prev_was_load_reg_3,
    prev_was_load_reg_4,
    prev_was_load_reg_5,
    prev_was_load_reg_6,
    prev_was_load,
    Q,
    \count_clk_cycles_reg[0] ,
    \count_clk_cycles_reg[0]_0 ,
    \count_clk_cycles_reg[0]_1 ,
    \count_clk_cycles_reg[0]_2 ,
    \count_clk_cycles_reg[0]_3 ,
    \count_clk_cycles_reg[0]_4 ,
    \count_clk_cycles_reg[0]_5 ,
    \count_clk_cycles_reg[0]_6 ,
    \state_reg[7]_1 ,
    s00_axi_aclk);
  output prev_was_load_reg;
  output [7:0]\state_reg[7]_0 ;
  output prev_was_load_reg_0;
  output prev_was_load_reg_1;
  output prev_was_load_reg_2;
  output prev_was_load_reg_3;
  output prev_was_load_reg_4;
  output prev_was_load_reg_5;
  output prev_was_load_reg_6;
  input prev_was_load;
  input [2:0]Q;
  input \count_clk_cycles_reg[0] ;
  input \count_clk_cycles_reg[0]_0 ;
  input \count_clk_cycles_reg[0]_1 ;
  input \count_clk_cycles_reg[0]_2 ;
  input \count_clk_cycles_reg[0]_3 ;
  input \count_clk_cycles_reg[0]_4 ;
  input \count_clk_cycles_reg[0]_5 ;
  input \count_clk_cycles_reg[0]_6 ;
  input [7:0]\state_reg[7]_1 ;
  input s00_axi_aclk;

  wire [2:0]Q;
  wire \count_clk_cycles_reg[0] ;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_1 ;
  wire \count_clk_cycles_reg[0]_2 ;
  wire \count_clk_cycles_reg[0]_3 ;
  wire \count_clk_cycles_reg[0]_4 ;
  wire \count_clk_cycles_reg[0]_5 ;
  wire \count_clk_cycles_reg[0]_6 ;
  wire prev_was_load;
  wire prev_was_load_reg;
  wire prev_was_load_reg_0;
  wire prev_was_load_reg_1;
  wire prev_was_load_reg_2;
  wire prev_was_load_reg_3;
  wire prev_was_load_reg_4;
  wire prev_was_load_reg_5;
  wire prev_was_load_reg_6;
  wire s00_axi_aclk;
  wire [7:0]\state_reg[7]_0 ;
  wire [7:0]\state_reg[7]_1 ;

  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [0]),
        .I3(\count_clk_cycles_reg[0] ),
        .O(prev_was_load_reg));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__0
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [1]),
        .I3(\count_clk_cycles_reg[0]_0 ),
        .O(prev_was_load_reg_0));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__1
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [2]),
        .I3(\count_clk_cycles_reg[0]_1 ),
        .O(prev_was_load_reg_1));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__2
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [3]),
        .I3(\count_clk_cycles_reg[0]_2 ),
        .O(prev_was_load_reg_2));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__3
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [4]),
        .I3(\count_clk_cycles_reg[0]_3 ),
        .O(prev_was_load_reg_3));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__4
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [5]),
        .I3(\count_clk_cycles_reg[0]_4 ),
        .O(prev_was_load_reg_4));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__5
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [6]),
        .I3(\count_clk_cycles_reg[0]_5 ),
        .O(prev_was_load_reg_5));
  LUT4 #(
    .INIT(16'h0080)) 
    counter_out_i_4__6
       (.I0(prev_was_load),
        .I1(Q[1]),
        .I2(\state_reg[7]_0 [7]),
        .I3(\count_clk_cycles_reg[0]_6 ),
        .O(prev_was_load_reg_6));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [0]),
        .Q(\state_reg[7]_0 [0]),
        .R(Q[0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [1]),
        .Q(\state_reg[7]_0 [1]),
        .R(Q[0]));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [2]),
        .Q(\state_reg[7]_0 [2]),
        .R(Q[0]));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [3]),
        .Q(\state_reg[7]_0 [3]),
        .R(Q[0]));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [4]),
        .Q(\state_reg[7]_0 [4]),
        .R(Q[0]));
  FDRE \state_reg[5] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [5]),
        .Q(\state_reg[7]_0 [5]),
        .R(Q[0]));
  FDRE \state_reg[6] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [6]),
        .Q(\state_reg[7]_0 [6]),
        .R(Q[0]));
  FDRE \state_reg[7] 
       (.C(s00_axi_aclk),
        .CE(Q[2]),
        .D(\state_reg[7]_1 [7]),
        .Q(\state_reg[7]_0 [7]),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg2_reg[1] ,
    \slv_reg2_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1_0 ,
    Q,
    seconds_relay_0__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14_0 ,
    D,
    \state_reg[4]_i_14_1 ,
    \state_reg[4]_1 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg2_reg[1] ;
  output [3:0]\slv_reg2_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_0__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14_1 ;
  input [1:0]\state_reg[4]_1 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_0;
  wire seconds_relay_0__274_carry__0_i_1_n_0;
  wire seconds_relay_0__274_carry__0_i_1_n_1;
  wire seconds_relay_0__274_carry__0_i_1_n_2;
  wire seconds_relay_0__274_carry__0_i_1_n_3;
  wire seconds_relay_0__274_carry__0_i_6_n_0;
  wire seconds_relay_0__274_carry__0_i_7_n_0;
  wire seconds_relay_0__274_carry__0_i_8_n_0;
  wire seconds_relay_0__274_carry__0_i_9_n_0;
  wire seconds_relay_0__274_carry_i_10_n_0;
  wire seconds_relay_0__274_carry_i_11_n_0;
  wire seconds_relay_0__274_carry_i_12_n_0;
  wire seconds_relay_0__274_carry_i_1_n_0;
  wire seconds_relay_0__274_carry_i_1_n_1;
  wire seconds_relay_0__274_carry_i_1_n_2;
  wire seconds_relay_0__274_carry_i_1_n_3;
  wire seconds_relay_0__274_carry_i_6_n_0;
  wire seconds_relay_0__274_carry_i_6_n_1;
  wire seconds_relay_0__274_carry_i_6_n_2;
  wire seconds_relay_0__274_carry_i_6_n_3;
  wire seconds_relay_0__274_carry_i_6_n_4;
  wire seconds_relay_0__274_carry_i_6_n_5;
  wire seconds_relay_0__274_carry_i_6_n_6;
  wire seconds_relay_0__274_carry_i_7_n_0;
  wire seconds_relay_0__274_carry_i_8_n_0;
  wire seconds_relay_0__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_0__8_carry__0_i_6;
  wire [2:0]\slv_reg2_reg[1] ;
  wire [3:0]\slv_reg2_reg[1]_0 ;
  wire \state[1]_i_2_n_0 ;
  wire \state[1]_i_3_n_0 ;
  wire \state[1]_i_4_n_0 ;
  wire \state[2]_i_3_n_0 ;
  wire \state[2]_i_4_n_0 ;
  wire \state[2]_i_5_n_0 ;
  wire \state[2]_i_6_n_0 ;
  wire \state[2]_i_7_n_0 ;
  wire \state[2]_i_8_n_0 ;
  wire \state[2]_i_9_n_0 ;
  wire \state[3]_i_10_n_0 ;
  wire \state[3]_i_11_n_0 ;
  wire \state[3]_i_12_n_0 ;
  wire \state[3]_i_13_n_0 ;
  wire \state[3]_i_3_n_0 ;
  wire \state[3]_i_4_n_0 ;
  wire \state[3]_i_5_n_0 ;
  wire \state[3]_i_7_n_0 ;
  wire \state[3]_i_8_n_0 ;
  wire \state[3]_i_9_n_0 ;
  wire \state[4]_i_10_n_0 ;
  wire \state[4]_i_11_n_0 ;
  wire \state[4]_i_12_n_0 ;
  wire \state[4]_i_13_n_0 ;
  wire \state[4]_i_16_n_0 ;
  wire \state[4]_i_17_n_0 ;
  wire \state[4]_i_18_n_0 ;
  wire \state[4]_i_20_n_0 ;
  wire \state[4]_i_21_n_0 ;
  wire \state[4]_i_22_n_0 ;
  wire \state[4]_i_23_n_0 ;
  wire \state[4]_i_24_n_0 ;
  wire \state[4]_i_25_n_0 ;
  wire \state[4]_i_26_n_0 ;
  wire \state[4]_i_27_n_0 ;
  wire \state[4]_i_28_n_0 ;
  wire \state[4]_i_29_n_0 ;
  wire \state[4]_i_30_n_0 ;
  wire \state[4]_i_31_n_0 ;
  wire \state[4]_i_32_n_0 ;
  wire \state[4]_i_33_n_0 ;
  wire \state[4]_i_34_n_0 ;
  wire \state[4]_i_35_n_0 ;
  wire \state[4]_i_36_n_0 ;
  wire \state[4]_i_37_n_0 ;
  wire \state[4]_i_38_n_0 ;
  wire \state[4]_i_39_n_0 ;
  wire \state[4]_i_5_n_0 ;
  wire \state[4]_i_6_n_0 ;
  wire \state[4]_i_7_n_0 ;
  wire [1:0]\state_reg[1]_i_1_0 ;
  wire \state_reg[1]_i_1_n_2 ;
  wire \state_reg[1]_i_1_n_3 ;
  wire \state_reg[1]_i_1_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1_n_2 ;
  wire \state_reg[2]_i_1_n_3 ;
  wire \state_reg[2]_i_1_n_6 ;
  wire \state_reg[2]_i_1_n_7 ;
  wire \state_reg[2]_i_2_n_0 ;
  wire \state_reg[2]_i_2_n_1 ;
  wire \state_reg[2]_i_2_n_2 ;
  wire \state_reg[2]_i_2_n_3 ;
  wire \state_reg[2]_i_2_n_4 ;
  wire \state_reg[2]_i_2_n_5 ;
  wire \state_reg[2]_i_2_n_6 ;
  wire \state_reg[2]_i_2_n_7 ;
  wire \state_reg[3]_i_1_n_2 ;
  wire \state_reg[3]_i_1_n_3 ;
  wire \state_reg[3]_i_1_n_6 ;
  wire \state_reg[3]_i_1_n_7 ;
  wire \state_reg[3]_i_2_n_0 ;
  wire \state_reg[3]_i_2_n_1 ;
  wire \state_reg[3]_i_2_n_2 ;
  wire \state_reg[3]_i_2_n_3 ;
  wire \state_reg[3]_i_2_n_4 ;
  wire \state_reg[3]_i_2_n_5 ;
  wire \state_reg[3]_i_2_n_6 ;
  wire \state_reg[3]_i_2_n_7 ;
  wire \state_reg[3]_i_6_n_0 ;
  wire \state_reg[3]_i_6_n_1 ;
  wire \state_reg[3]_i_6_n_2 ;
  wire \state_reg[3]_i_6_n_3 ;
  wire \state_reg[3]_i_6_n_4 ;
  wire \state_reg[3]_i_6_n_5 ;
  wire \state_reg[3]_i_6_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [1:0]\state_reg[4]_1 ;
  wire [3:0]\state_reg[4]_i_14_0 ;
  wire [0:0]\state_reg[4]_i_14_1 ;
  wire \state_reg[4]_i_14_n_1 ;
  wire \state_reg[4]_i_14_n_2 ;
  wire \state_reg[4]_i_14_n_3 ;
  wire \state_reg[4]_i_14_n_6 ;
  wire \state_reg[4]_i_14_n_7 ;
  wire \state_reg[4]_i_15_n_0 ;
  wire \state_reg[4]_i_15_n_1 ;
  wire \state_reg[4]_i_15_n_2 ;
  wire \state_reg[4]_i_15_n_3 ;
  wire \state_reg[4]_i_15_n_4 ;
  wire \state_reg[4]_i_15_n_5 ;
  wire \state_reg[4]_i_15_n_6 ;
  wire \state_reg[4]_i_15_n_7 ;
  wire \state_reg[4]_i_19_n_0 ;
  wire \state_reg[4]_i_19_n_1 ;
  wire \state_reg[4]_i_19_n_2 ;
  wire \state_reg[4]_i_19_n_3 ;
  wire \state_reg[4]_i_19_n_4 ;
  wire \state_reg[4]_i_19_n_5 ;
  wire \state_reg[4]_i_19_n_6 ;
  wire \state_reg[4]_i_1_n_2 ;
  wire \state_reg[4]_i_1_n_3 ;
  wire \state_reg[4]_i_1_n_6 ;
  wire \state_reg[4]_i_1_n_7 ;
  wire \state_reg[4]_i_2_n_0 ;
  wire \state_reg[4]_i_2_n_1 ;
  wire \state_reg[4]_i_2_n_2 ;
  wire \state_reg[4]_i_2_n_3 ;
  wire \state_reg[4]_i_2_n_4 ;
  wire \state_reg[4]_i_2_n_5 ;
  wire \state_reg[4]_i_2_n_6 ;
  wire \state_reg[4]_i_2_n_7 ;
  wire \state_reg[4]_i_3_n_1 ;
  wire \state_reg[4]_i_3_n_2 ;
  wire \state_reg[4]_i_3_n_3 ;
  wire \state_reg[4]_i_3_n_6 ;
  wire \state_reg[4]_i_3_n_7 ;
  wire \state_reg[4]_i_4_n_0 ;
  wire \state_reg[4]_i_4_n_1 ;
  wire \state_reg[4]_i_4_n_2 ;
  wire \state_reg[4]_i_4_n_3 ;
  wire \state_reg[4]_i_4_n_4 ;
  wire \state_reg[4]_i_4_n_5 ;
  wire \state_reg[4]_i_4_n_6 ;
  wire \state_reg[4]_i_4_n_7 ;
  wire \state_reg[4]_i_8_n_0 ;
  wire \state_reg[4]_i_8_n_1 ;
  wire \state_reg[4]_i_8_n_2 ;
  wire \state_reg[4]_i_8_n_3 ;
  wire \state_reg[4]_i_8_n_4 ;
  wire \state_reg[4]_i_8_n_5 ;
  wire \state_reg[4]_i_8_n_6 ;
  wire \state_reg[4]_i_9_n_0 ;
  wire \state_reg[4]_i_9_n_1 ;
  wire \state_reg[4]_i_9_n_2 ;
  wire \state_reg[4]_i_9_n_3 ;
  wire \state_reg[4]_i_9_n_4 ;
  wire \state_reg[4]_i_9_n_5 ;
  wire \state_reg[4]_i_9_n_6 ;
  wire [0:0]NLW_seconds_relay_0__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_0__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_0__274_carry__0_i_1
       (.CI(seconds_relay_0__274_carry_i_1_n_0),
        .CO({seconds_relay_0__274_carry__0_i_1_n_0,seconds_relay_0__274_carry__0_i_1_n_1,seconds_relay_0__274_carry__0_i_1_n_2,seconds_relay_0__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2_n_5 ,\state_reg[2]_i_2_n_6 ,\state_reg[2]_i_2_n_7 ,seconds_relay_0__274_carry_i_6_n_4}),
        .O(\slv_reg2_reg[1]_0 ),
        .S({seconds_relay_0__274_carry__0_i_6_n_0,seconds_relay_0__274_carry__0_i_7_n_0,seconds_relay_0__274_carry__0_i_8_n_0,seconds_relay_0__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_6
       (.I0(seconds_relay_0[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2_n_5 ),
        .O(seconds_relay_0__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_7
       (.I0(seconds_relay_0[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2_n_6 ),
        .O(seconds_relay_0__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_8
       (.I0(seconds_relay_0[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2_n_7 ),
        .O(seconds_relay_0__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__0_i_9
       (.I0(seconds_relay_0[2]),
        .I1(Q[3]),
        .I2(seconds_relay_0__274_carry_i_6_n_4),
        .O(seconds_relay_0__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1_n_6 ),
        .O(\state_reg[1]_i_1_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1_0 [0]));
  CARRY4 seconds_relay_0__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_0__274_carry_i_1_n_0,seconds_relay_0__274_carry_i_1_n_1,seconds_relay_0__274_carry_i_1_n_2,seconds_relay_0__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_0[2]),
        .DI({seconds_relay_0__274_carry_i_6_n_5,seconds_relay_0__274_carry_i_6_n_6,seconds_relay_0__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg2_reg[1] ,NLW_seconds_relay_0__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_0__274_carry_i_7_n_0,seconds_relay_0__274_carry_i_8_n_0,seconds_relay_0__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_10
       (.I0(seconds_relay_0[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6_n_5 ),
        .O(seconds_relay_0__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_11
       (.I0(seconds_relay_0[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6_n_6 ),
        .O(seconds_relay_0__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_12
       (.I0(seconds_relay_0[3]),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[1]),
        .O(seconds_relay_0__274_carry_i_12_n_0));
  CARRY4 seconds_relay_0__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_0__274_carry_i_6_n_0,seconds_relay_0__274_carry_i_6_n_1,seconds_relay_0__274_carry_i_6_n_2,seconds_relay_0__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_0[3]),
        .DI({\state_reg[3]_i_6_n_5 ,\state_reg[3]_i_6_n_6 ,seconds_relay_0__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_0__274_carry_i_6_n_4,seconds_relay_0__274_carry_i_6_n_5,seconds_relay_0__274_carry_i_6_n_6,NLW_seconds_relay_0__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_0__274_carry_i_10_n_0,seconds_relay_0__274_carry_i_11_n_0,seconds_relay_0__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_7
       (.I0(seconds_relay_0[2]),
        .I1(Q[2]),
        .I2(seconds_relay_0__274_carry_i_6_n_5),
        .O(seconds_relay_0__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_8
       (.I0(seconds_relay_0[2]),
        .I1(Q[1]),
        .I2(seconds_relay_0__274_carry_i_6_n_6),
        .O(seconds_relay_0__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_0__274_carry_i_9
       (.I0(seconds_relay_0[2]),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[0]),
        .O(seconds_relay_0__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_0__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_0__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_0__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_0__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_0__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_0__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_0__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2 
       (.I0(seconds_relay_0[2]),
        .I1(\state_reg[2]_i_1_n_6 ),
        .O(\state[1]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3 
       (.I0(seconds_relay_0[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1_n_7 ),
        .O(\state[1]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4 
       (.I0(seconds_relay_0[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2_n_4 ),
        .O(\state[1]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3 
       (.I0(seconds_relay_0[3]),
        .I1(\state_reg[3]_i_1_n_6 ),
        .O(\state[2]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4 
       (.I0(seconds_relay_0[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1_n_7 ),
        .O(\state[2]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5 
       (.I0(seconds_relay_0[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2_n_4 ),
        .O(\state[2]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6 
       (.I0(seconds_relay_0[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2_n_5 ),
        .O(\state[2]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7 
       (.I0(seconds_relay_0[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2_n_6 ),
        .O(\state[2]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8 
       (.I0(seconds_relay_0[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2_n_7 ),
        .O(\state[2]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9 
       (.I0(seconds_relay_0[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6_n_4 ),
        .O(\state[2]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10 
       (.I0(seconds_relay_0[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8_n_4 ),
        .O(\state[3]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11 
       (.I0(seconds_relay_0[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8_n_5 ),
        .O(\state[3]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12 
       (.I0(seconds_relay_0[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8_n_6 ),
        .O(\state[3]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13 
       (.I0(seconds_relay_0[4]),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[2]),
        .O(\state[3]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3 
       (.I0(seconds_relay_0[4]),
        .I1(\state_reg[4]_i_1_n_6 ),
        .O(\state[3]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4 
       (.I0(seconds_relay_0[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1_n_7 ),
        .O(\state[3]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5 
       (.I0(seconds_relay_0[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2_n_4 ),
        .O(\state[3]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7 
       (.I0(seconds_relay_0[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2_n_5 ),
        .O(\state[3]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8 
       (.I0(seconds_relay_0[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2_n_6 ),
        .O(\state[3]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9 
       (.I0(seconds_relay_0[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2_n_7 ),
        .O(\state[3]_i_9_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4_n_5 ),
        .O(\state[4]_i_10_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4_n_6 ),
        .O(\state[4]_i_11_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4_n_7 ),
        .O(\state[4]_i_12_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9_n_4 ),
        .O(\state[4]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(\state_reg[4]_i_14_n_6 ),
        .O(\state[4]_i_16_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14_n_7 ),
        .O(\state[4]_i_17_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15_n_4 ),
        .O(\state[4]_i_18_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15_n_5 ),
        .O(\state[4]_i_20_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15_n_6 ),
        .O(\state[4]_i_21_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15_n_7 ),
        .O(\state[4]_i_22_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19_n_4 ),
        .O(\state[4]_i_23_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9_n_5 ),
        .O(\state[4]_i_24_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9_n_6 ),
        .O(\state[4]_i_25_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[3]),
        .O(\state[4]_i_26_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19_n_5 ),
        .O(\state[4]_i_27_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19_n_6 ),
        .O(\state[4]_i_28_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29 
       (.I0(\state_reg[4]_i_14_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[4]),
        .O(\state[4]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30 
       (.I0(CO),
        .I1(\state_reg[4]_i_14_1 ),
        .O(\state[4]_i_30_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14_0 [3]),
        .O(\state[4]_i_31_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14_0 [2]),
        .O(\state[4]_i_32_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14_0 [1]),
        .O(\state[4]_i_33_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14_0 [0]),
        .O(\state[4]_i_34_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_0__8_carry__0_i_6[5]),
        .O(\state[4]_i_39_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(\state_reg[4]_i_3_n_6 ),
        .O(\state[4]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3_n_7 ),
        .O(\state[4]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7 
       (.I0(\state_reg[4]_i_3_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4_n_4 ),
        .O(\state[4]_i_7_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[4]_1 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[1]_i_1 
       (.CI(seconds_relay_0__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1_n_2 ,\state_reg[1]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_0[2],\state_reg[2]_i_1_n_7 ,\state_reg[2]_i_2_n_4 }),
        .O({\NLW_state_reg[1]_i_1_O_UNCONNECTED [3:2],\state_reg[1]_i_1_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2_n_0 ,\state[1]_i_3_n_0 ,\state[1]_i_4_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_0[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[2]_i_1 
       (.CI(\state_reg[2]_i_2_n_0 ),
        .CO({\NLW_state_reg[2]_i_1_CO_UNCONNECTED [3],seconds_relay_0[2],\state_reg[2]_i_1_n_2 ,\state_reg[2]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_0[3],\state_reg[3]_i_1_n_7 ,\state_reg[3]_i_2_n_4 }),
        .O({\NLW_state_reg[2]_i_1_O_UNCONNECTED [3:2],\state_reg[2]_i_1_n_6 ,\state_reg[2]_i_1_n_7 }),
        .S({1'b0,\state[2]_i_3_n_0 ,\state[2]_i_4_n_0 ,\state[2]_i_5_n_0 }));
  CARRY4 \state_reg[2]_i_2 
       (.CI(seconds_relay_0__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2_n_0 ,\state_reg[2]_i_2_n_1 ,\state_reg[2]_i_2_n_2 ,\state_reg[2]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2_n_5 ,\state_reg[3]_i_2_n_6 ,\state_reg[3]_i_2_n_7 ,\state_reg[3]_i_6_n_4 }),
        .O({\state_reg[2]_i_2_n_4 ,\state_reg[2]_i_2_n_5 ,\state_reg[2]_i_2_n_6 ,\state_reg[2]_i_2_n_7 }),
        .S({\state[2]_i_6_n_0 ,\state[2]_i_7_n_0 ,\state[2]_i_8_n_0 ,\state[2]_i_9_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_0[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[3]_i_1 
       (.CI(\state_reg[3]_i_2_n_0 ),
        .CO({\NLW_state_reg[3]_i_1_CO_UNCONNECTED [3],seconds_relay_0[3],\state_reg[3]_i_1_n_2 ,\state_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_0[4],\state_reg[4]_i_1_n_7 ,\state_reg[4]_i_2_n_4 }),
        .O({\NLW_state_reg[3]_i_1_O_UNCONNECTED [3:2],\state_reg[3]_i_1_n_6 ,\state_reg[3]_i_1_n_7 }),
        .S({1'b0,\state[3]_i_3_n_0 ,\state[3]_i_4_n_0 ,\state[3]_i_5_n_0 }));
  CARRY4 \state_reg[3]_i_2 
       (.CI(\state_reg[3]_i_6_n_0 ),
        .CO({\state_reg[3]_i_2_n_0 ,\state_reg[3]_i_2_n_1 ,\state_reg[3]_i_2_n_2 ,\state_reg[3]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2_n_5 ,\state_reg[4]_i_2_n_6 ,\state_reg[4]_i_2_n_7 ,\state_reg[4]_i_8_n_4 }),
        .O({\state_reg[3]_i_2_n_4 ,\state_reg[3]_i_2_n_5 ,\state_reg[3]_i_2_n_6 ,\state_reg[3]_i_2_n_7 }),
        .S({\state[3]_i_7_n_0 ,\state[3]_i_8_n_0 ,\state[3]_i_9_n_0 ,\state[3]_i_10_n_0 }));
  CARRY4 \state_reg[3]_i_6 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6_n_0 ,\state_reg[3]_i_6_n_1 ,\state_reg[3]_i_6_n_2 ,\state_reg[3]_i_6_n_3 }),
        .CYINIT(seconds_relay_0[4]),
        .DI({\state_reg[4]_i_8_n_5 ,\state_reg[4]_i_8_n_6 ,seconds_relay_0__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6_n_4 ,\state_reg[3]_i_6_n_5 ,\state_reg[3]_i_6_n_6 ,\NLW_state_reg[3]_i_6_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11_n_0 ,\state[3]_i_12_n_0 ,\state[3]_i_13_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_0[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[4]_i_1 
       (.CI(\state_reg[4]_i_2_n_0 ),
        .CO({\NLW_state_reg[4]_i_1_CO_UNCONNECTED [3],seconds_relay_0[4],\state_reg[4]_i_1_n_2 ,\state_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3_n_1 ,\state_reg[4]_i_3_n_7 ,\state_reg[4]_i_4_n_4 }),
        .O({\NLW_state_reg[4]_i_1_O_UNCONNECTED [3:2],\state_reg[4]_i_1_n_6 ,\state_reg[4]_i_1_n_7 }),
        .S({1'b0,\state[4]_i_5_n_0 ,\state[4]_i_6_n_0 ,\state[4]_i_7_n_0 }));
  CARRY4 \state_reg[4]_i_14 
       (.CI(\state_reg[4]_i_15_n_0 ),
        .CO({\NLW_state_reg[4]_i_14_CO_UNCONNECTED [3],\state_reg[4]_i_14_n_1 ,\state_reg[4]_i_14_n_2 ,\state_reg[4]_i_14_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14_O_UNCONNECTED [3:2],\state_reg[4]_i_14_n_6 ,\state_reg[4]_i_14_n_7 }),
        .S({1'b0,\state[4]_i_30_n_0 ,\state[4]_i_31_n_0 ,\state[4]_i_32_n_0 }));
  CARRY4 \state_reg[4]_i_15 
       (.CI(\state_reg[4]_i_19_n_0 ),
        .CO({\state_reg[4]_i_15_n_0 ,\state_reg[4]_i_15_n_1 ,\state_reg[4]_i_15_n_2 ,\state_reg[4]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15_n_4 ,\state_reg[4]_i_15_n_5 ,\state_reg[4]_i_15_n_6 ,\state_reg[4]_i_15_n_7 }),
        .S({\state[4]_i_33_n_0 ,\state[4]_i_34_n_0 ,\state[4]_i_35_n_0 ,\state[4]_i_36_n_0 }));
  CARRY4 \state_reg[4]_i_19 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19_n_0 ,\state_reg[4]_i_19_n_1 ,\state_reg[4]_i_19_n_2 ,\state_reg[4]_i_19_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_0__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19_n_4 ,\state_reg[4]_i_19_n_5 ,\state_reg[4]_i_19_n_6 ,\NLW_state_reg[4]_i_19_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37_n_0 ,\state[4]_i_38_n_0 ,\state[4]_i_39_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_2 
       (.CI(\state_reg[4]_i_8_n_0 ),
        .CO({\state_reg[4]_i_2_n_0 ,\state_reg[4]_i_2_n_1 ,\state_reg[4]_i_2_n_2 ,\state_reg[4]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4_n_5 ,\state_reg[4]_i_4_n_6 ,\state_reg[4]_i_4_n_7 ,\state_reg[4]_i_9_n_4 }),
        .O({\state_reg[4]_i_2_n_4 ,\state_reg[4]_i_2_n_5 ,\state_reg[4]_i_2_n_6 ,\state_reg[4]_i_2_n_7 }),
        .S({\state[4]_i_10_n_0 ,\state[4]_i_11_n_0 ,\state[4]_i_12_n_0 ,\state[4]_i_13_n_0 }));
  CARRY4 \state_reg[4]_i_3 
       (.CI(\state_reg[4]_i_4_n_0 ),
        .CO({\NLW_state_reg[4]_i_3_CO_UNCONNECTED [3],\state_reg[4]_i_3_n_1 ,\state_reg[4]_i_3_n_2 ,\state_reg[4]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14_n_1 ,\state_reg[4]_i_14_n_7 ,\state_reg[4]_i_15_n_4 }),
        .O({\NLW_state_reg[4]_i_3_O_UNCONNECTED [3:2],\state_reg[4]_i_3_n_6 ,\state_reg[4]_i_3_n_7 }),
        .S({1'b0,\state[4]_i_16_n_0 ,\state[4]_i_17_n_0 ,\state[4]_i_18_n_0 }));
  CARRY4 \state_reg[4]_i_4 
       (.CI(\state_reg[4]_i_9_n_0 ),
        .CO({\state_reg[4]_i_4_n_0 ,\state_reg[4]_i_4_n_1 ,\state_reg[4]_i_4_n_2 ,\state_reg[4]_i_4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15_n_5 ,\state_reg[4]_i_15_n_6 ,\state_reg[4]_i_15_n_7 ,\state_reg[4]_i_19_n_4 }),
        .O({\state_reg[4]_i_4_n_4 ,\state_reg[4]_i_4_n_5 ,\state_reg[4]_i_4_n_6 ,\state_reg[4]_i_4_n_7 }),
        .S({\state[4]_i_20_n_0 ,\state[4]_i_21_n_0 ,\state[4]_i_22_n_0 ,\state[4]_i_23_n_0 }));
  CARRY4 \state_reg[4]_i_8 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8_n_0 ,\state_reg[4]_i_8_n_1 ,\state_reg[4]_i_8_n_2 ,\state_reg[4]_i_8_n_3 }),
        .CYINIT(\state_reg[4]_i_3_n_1 ),
        .DI({\state_reg[4]_i_9_n_5 ,\state_reg[4]_i_9_n_6 ,seconds_relay_0__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8_n_4 ,\state_reg[4]_i_8_n_5 ,\state_reg[4]_i_8_n_6 ,\NLW_state_reg[4]_i_8_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24_n_0 ,\state[4]_i_25_n_0 ,\state[4]_i_26_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9_n_0 ,\state_reg[4]_i_9_n_1 ,\state_reg[4]_i_9_n_2 ,\state_reg[4]_i_9_n_3 }),
        .CYINIT(\state_reg[4]_i_14_n_1 ),
        .DI({\state_reg[4]_i_19_n_5 ,\state_reg[4]_i_19_n_6 ,seconds_relay_0__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9_n_4 ,\state_reg[4]_i_9_n_5 ,\state_reg[4]_i_9_n_6 ,\NLW_state_reg[4]_i_9_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27_n_0 ,\state[4]_i_28_n_0 ,\state[4]_i_29_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_0
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg3_reg[1] ,
    \slv_reg3_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__0_0 ,
    Q,
    seconds_relay_1__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__0_0 ,
    D,
    \state_reg[4]_i_14__0_1 ,
    \state_reg[0]_0 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg3_reg[1] ;
  output [3:0]\slv_reg3_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__0_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_1__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__0_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__0_1 ;
  input [1:0]\state_reg[0]_0 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_1;
  wire seconds_relay_1__274_carry__0_i_1_n_0;
  wire seconds_relay_1__274_carry__0_i_1_n_1;
  wire seconds_relay_1__274_carry__0_i_1_n_2;
  wire seconds_relay_1__274_carry__0_i_1_n_3;
  wire seconds_relay_1__274_carry__0_i_6_n_0;
  wire seconds_relay_1__274_carry__0_i_7_n_0;
  wire seconds_relay_1__274_carry__0_i_8_n_0;
  wire seconds_relay_1__274_carry__0_i_9_n_0;
  wire seconds_relay_1__274_carry_i_10_n_0;
  wire seconds_relay_1__274_carry_i_11_n_0;
  wire seconds_relay_1__274_carry_i_12_n_0;
  wire seconds_relay_1__274_carry_i_1_n_0;
  wire seconds_relay_1__274_carry_i_1_n_1;
  wire seconds_relay_1__274_carry_i_1_n_2;
  wire seconds_relay_1__274_carry_i_1_n_3;
  wire seconds_relay_1__274_carry_i_6_n_0;
  wire seconds_relay_1__274_carry_i_6_n_1;
  wire seconds_relay_1__274_carry_i_6_n_2;
  wire seconds_relay_1__274_carry_i_6_n_3;
  wire seconds_relay_1__274_carry_i_6_n_4;
  wire seconds_relay_1__274_carry_i_6_n_5;
  wire seconds_relay_1__274_carry_i_6_n_6;
  wire seconds_relay_1__274_carry_i_7_n_0;
  wire seconds_relay_1__274_carry_i_8_n_0;
  wire seconds_relay_1__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_1__8_carry__0_i_6;
  wire [2:0]\slv_reg3_reg[1] ;
  wire [3:0]\slv_reg3_reg[1]_0 ;
  wire \state[1]_i_2__0_n_0 ;
  wire \state[1]_i_3__0_n_0 ;
  wire \state[1]_i_4__0_n_0 ;
  wire \state[2]_i_3__0_n_0 ;
  wire \state[2]_i_4__0_n_0 ;
  wire \state[2]_i_5__0_n_0 ;
  wire \state[2]_i_6__0_n_0 ;
  wire \state[2]_i_7__0_n_0 ;
  wire \state[2]_i_8__0_n_0 ;
  wire \state[2]_i_9__0_n_0 ;
  wire \state[3]_i_10__0_n_0 ;
  wire \state[3]_i_11__0_n_0 ;
  wire \state[3]_i_12__0_n_0 ;
  wire \state[3]_i_13__0_n_0 ;
  wire \state[3]_i_3__0_n_0 ;
  wire \state[3]_i_4__0_n_0 ;
  wire \state[3]_i_5__0_n_0 ;
  wire \state[3]_i_7__0_n_0 ;
  wire \state[3]_i_8__0_n_0 ;
  wire \state[3]_i_9__0_n_0 ;
  wire \state[4]_i_10__0_n_0 ;
  wire \state[4]_i_11__0_n_0 ;
  wire \state[4]_i_12__0_n_0 ;
  wire \state[4]_i_13__0_n_0 ;
  wire \state[4]_i_16__0_n_0 ;
  wire \state[4]_i_17__0_n_0 ;
  wire \state[4]_i_18__0_n_0 ;
  wire \state[4]_i_20__0_n_0 ;
  wire \state[4]_i_21__0_n_0 ;
  wire \state[4]_i_22__0_n_0 ;
  wire \state[4]_i_23__0_n_0 ;
  wire \state[4]_i_24__0_n_0 ;
  wire \state[4]_i_25__0_n_0 ;
  wire \state[4]_i_26__0_n_0 ;
  wire \state[4]_i_27__0_n_0 ;
  wire \state[4]_i_28__0_n_0 ;
  wire \state[4]_i_29__0_n_0 ;
  wire \state[4]_i_30__0_n_0 ;
  wire \state[4]_i_31__0_n_0 ;
  wire \state[4]_i_32__0_n_0 ;
  wire \state[4]_i_33__0_n_0 ;
  wire \state[4]_i_34__0_n_0 ;
  wire \state[4]_i_35__0_n_0 ;
  wire \state[4]_i_36__0_n_0 ;
  wire \state[4]_i_37__0_n_0 ;
  wire \state[4]_i_38__0_n_0 ;
  wire \state[4]_i_39__0_n_0 ;
  wire \state[4]_i_5__0_n_0 ;
  wire \state[4]_i_6__0_n_0 ;
  wire \state[4]_i_7__0_n_0 ;
  wire [1:0]\state_reg[0]_0 ;
  wire [1:0]\state_reg[1]_i_1__0_0 ;
  wire \state_reg[1]_i_1__0_n_2 ;
  wire \state_reg[1]_i_1__0_n_3 ;
  wire \state_reg[1]_i_1__0_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__0_n_2 ;
  wire \state_reg[2]_i_1__0_n_3 ;
  wire \state_reg[2]_i_1__0_n_6 ;
  wire \state_reg[2]_i_1__0_n_7 ;
  wire \state_reg[2]_i_2__0_n_0 ;
  wire \state_reg[2]_i_2__0_n_1 ;
  wire \state_reg[2]_i_2__0_n_2 ;
  wire \state_reg[2]_i_2__0_n_3 ;
  wire \state_reg[2]_i_2__0_n_4 ;
  wire \state_reg[2]_i_2__0_n_5 ;
  wire \state_reg[2]_i_2__0_n_6 ;
  wire \state_reg[2]_i_2__0_n_7 ;
  wire \state_reg[3]_i_1__0_n_2 ;
  wire \state_reg[3]_i_1__0_n_3 ;
  wire \state_reg[3]_i_1__0_n_6 ;
  wire \state_reg[3]_i_1__0_n_7 ;
  wire \state_reg[3]_i_2__0_n_0 ;
  wire \state_reg[3]_i_2__0_n_1 ;
  wire \state_reg[3]_i_2__0_n_2 ;
  wire \state_reg[3]_i_2__0_n_3 ;
  wire \state_reg[3]_i_2__0_n_4 ;
  wire \state_reg[3]_i_2__0_n_5 ;
  wire \state_reg[3]_i_2__0_n_6 ;
  wire \state_reg[3]_i_2__0_n_7 ;
  wire \state_reg[3]_i_6__0_n_0 ;
  wire \state_reg[3]_i_6__0_n_1 ;
  wire \state_reg[3]_i_6__0_n_2 ;
  wire \state_reg[3]_i_6__0_n_3 ;
  wire \state_reg[3]_i_6__0_n_4 ;
  wire \state_reg[3]_i_6__0_n_5 ;
  wire \state_reg[3]_i_6__0_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [3:0]\state_reg[4]_i_14__0_0 ;
  wire [0:0]\state_reg[4]_i_14__0_1 ;
  wire \state_reg[4]_i_14__0_n_1 ;
  wire \state_reg[4]_i_14__0_n_2 ;
  wire \state_reg[4]_i_14__0_n_3 ;
  wire \state_reg[4]_i_14__0_n_6 ;
  wire \state_reg[4]_i_14__0_n_7 ;
  wire \state_reg[4]_i_15__0_n_0 ;
  wire \state_reg[4]_i_15__0_n_1 ;
  wire \state_reg[4]_i_15__0_n_2 ;
  wire \state_reg[4]_i_15__0_n_3 ;
  wire \state_reg[4]_i_15__0_n_4 ;
  wire \state_reg[4]_i_15__0_n_5 ;
  wire \state_reg[4]_i_15__0_n_6 ;
  wire \state_reg[4]_i_15__0_n_7 ;
  wire \state_reg[4]_i_19__0_n_0 ;
  wire \state_reg[4]_i_19__0_n_1 ;
  wire \state_reg[4]_i_19__0_n_2 ;
  wire \state_reg[4]_i_19__0_n_3 ;
  wire \state_reg[4]_i_19__0_n_4 ;
  wire \state_reg[4]_i_19__0_n_5 ;
  wire \state_reg[4]_i_19__0_n_6 ;
  wire \state_reg[4]_i_1__0_n_2 ;
  wire \state_reg[4]_i_1__0_n_3 ;
  wire \state_reg[4]_i_1__0_n_6 ;
  wire \state_reg[4]_i_1__0_n_7 ;
  wire \state_reg[4]_i_2__0_n_0 ;
  wire \state_reg[4]_i_2__0_n_1 ;
  wire \state_reg[4]_i_2__0_n_2 ;
  wire \state_reg[4]_i_2__0_n_3 ;
  wire \state_reg[4]_i_2__0_n_4 ;
  wire \state_reg[4]_i_2__0_n_5 ;
  wire \state_reg[4]_i_2__0_n_6 ;
  wire \state_reg[4]_i_2__0_n_7 ;
  wire \state_reg[4]_i_3__0_n_1 ;
  wire \state_reg[4]_i_3__0_n_2 ;
  wire \state_reg[4]_i_3__0_n_3 ;
  wire \state_reg[4]_i_3__0_n_6 ;
  wire \state_reg[4]_i_3__0_n_7 ;
  wire \state_reg[4]_i_4__0_n_0 ;
  wire \state_reg[4]_i_4__0_n_1 ;
  wire \state_reg[4]_i_4__0_n_2 ;
  wire \state_reg[4]_i_4__0_n_3 ;
  wire \state_reg[4]_i_4__0_n_4 ;
  wire \state_reg[4]_i_4__0_n_5 ;
  wire \state_reg[4]_i_4__0_n_6 ;
  wire \state_reg[4]_i_4__0_n_7 ;
  wire \state_reg[4]_i_8__0_n_0 ;
  wire \state_reg[4]_i_8__0_n_1 ;
  wire \state_reg[4]_i_8__0_n_2 ;
  wire \state_reg[4]_i_8__0_n_3 ;
  wire \state_reg[4]_i_8__0_n_4 ;
  wire \state_reg[4]_i_8__0_n_5 ;
  wire \state_reg[4]_i_8__0_n_6 ;
  wire \state_reg[4]_i_9__0_n_0 ;
  wire \state_reg[4]_i_9__0_n_1 ;
  wire \state_reg[4]_i_9__0_n_2 ;
  wire \state_reg[4]_i_9__0_n_3 ;
  wire \state_reg[4]_i_9__0_n_4 ;
  wire \state_reg[4]_i_9__0_n_5 ;
  wire \state_reg[4]_i_9__0_n_6 ;
  wire [0:0]NLW_seconds_relay_1__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_1__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__0_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__0_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__0_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__0_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__0_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__0_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__0_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__0_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__0_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__0_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__0
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_1__274_carry__0_i_1
       (.CI(seconds_relay_1__274_carry_i_1_n_0),
        .CO({seconds_relay_1__274_carry__0_i_1_n_0,seconds_relay_1__274_carry__0_i_1_n_1,seconds_relay_1__274_carry__0_i_1_n_2,seconds_relay_1__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__0_n_5 ,\state_reg[2]_i_2__0_n_6 ,\state_reg[2]_i_2__0_n_7 ,seconds_relay_1__274_carry_i_6_n_4}),
        .O(\slv_reg3_reg[1]_0 ),
        .S({seconds_relay_1__274_carry__0_i_6_n_0,seconds_relay_1__274_carry__0_i_7_n_0,seconds_relay_1__274_carry__0_i_8_n_0,seconds_relay_1__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_6
       (.I0(seconds_relay_1[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__0_n_5 ),
        .O(seconds_relay_1__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_7
       (.I0(seconds_relay_1[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__0_n_6 ),
        .O(seconds_relay_1__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_8
       (.I0(seconds_relay_1[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__0_n_7 ),
        .O(seconds_relay_1__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__0_i_9
       (.I0(seconds_relay_1[2]),
        .I1(Q[3]),
        .I2(seconds_relay_1__274_carry_i_6_n_4),
        .O(seconds_relay_1__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__0_n_6 ),
        .O(\state_reg[1]_i_1__0_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__0_0 [0]));
  CARRY4 seconds_relay_1__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_1__274_carry_i_1_n_0,seconds_relay_1__274_carry_i_1_n_1,seconds_relay_1__274_carry_i_1_n_2,seconds_relay_1__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_1[2]),
        .DI({seconds_relay_1__274_carry_i_6_n_5,seconds_relay_1__274_carry_i_6_n_6,seconds_relay_1__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg3_reg[1] ,NLW_seconds_relay_1__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_1__274_carry_i_7_n_0,seconds_relay_1__274_carry_i_8_n_0,seconds_relay_1__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_10
       (.I0(seconds_relay_1[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__0_n_5 ),
        .O(seconds_relay_1__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_11
       (.I0(seconds_relay_1[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__0_n_6 ),
        .O(seconds_relay_1__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_12
       (.I0(seconds_relay_1[3]),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[1]),
        .O(seconds_relay_1__274_carry_i_12_n_0));
  CARRY4 seconds_relay_1__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_1__274_carry_i_6_n_0,seconds_relay_1__274_carry_i_6_n_1,seconds_relay_1__274_carry_i_6_n_2,seconds_relay_1__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_1[3]),
        .DI({\state_reg[3]_i_6__0_n_5 ,\state_reg[3]_i_6__0_n_6 ,seconds_relay_1__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_1__274_carry_i_6_n_4,seconds_relay_1__274_carry_i_6_n_5,seconds_relay_1__274_carry_i_6_n_6,NLW_seconds_relay_1__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_1__274_carry_i_10_n_0,seconds_relay_1__274_carry_i_11_n_0,seconds_relay_1__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_7
       (.I0(seconds_relay_1[2]),
        .I1(Q[2]),
        .I2(seconds_relay_1__274_carry_i_6_n_5),
        .O(seconds_relay_1__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_8
       (.I0(seconds_relay_1[2]),
        .I1(Q[1]),
        .I2(seconds_relay_1__274_carry_i_6_n_6),
        .O(seconds_relay_1__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_1__274_carry_i_9
       (.I0(seconds_relay_1[2]),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[0]),
        .O(seconds_relay_1__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_1__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_1__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_1__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_1__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_1__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_1__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_1__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__0 
       (.I0(seconds_relay_1[2]),
        .I1(\state_reg[2]_i_1__0_n_6 ),
        .O(\state[1]_i_2__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__0 
       (.I0(seconds_relay_1[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__0_n_7 ),
        .O(\state[1]_i_3__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__0 
       (.I0(seconds_relay_1[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__0_n_4 ),
        .O(\state[1]_i_4__0_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__0 
       (.I0(seconds_relay_1[3]),
        .I1(\state_reg[3]_i_1__0_n_6 ),
        .O(\state[2]_i_3__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__0_n_7 ),
        .O(\state[2]_i_4__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__0_n_4 ),
        .O(\state[2]_i_5__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__0_n_5 ),
        .O(\state[2]_i_6__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__0_n_6 ),
        .O(\state[2]_i_7__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__0_n_7 ),
        .O(\state[2]_i_8__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__0 
       (.I0(seconds_relay_1[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__0_n_4 ),
        .O(\state[2]_i_9__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__0_n_4 ),
        .O(\state[3]_i_10__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__0_n_5 ),
        .O(\state[3]_i_11__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__0_n_6 ),
        .O(\state[3]_i_12__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__0_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__0 
       (.I0(seconds_relay_1[4]),
        .I1(\state_reg[4]_i_1__0_n_6 ),
        .O(\state[3]_i_3__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__0_n_7 ),
        .O(\state[3]_i_4__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__0_n_4 ),
        .O(\state[3]_i_5__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__0_n_5 ),
        .O(\state[3]_i_7__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__0_n_6 ),
        .O(\state[3]_i_8__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__0 
       (.I0(seconds_relay_1[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__0_n_7 ),
        .O(\state[3]_i_9__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__0_n_5 ),
        .O(\state[4]_i_10__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__0_n_6 ),
        .O(\state[4]_i_11__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__0_n_7 ),
        .O(\state[4]_i_12__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__0_n_4 ),
        .O(\state[4]_i_13__0_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(\state_reg[4]_i_14__0_n_6 ),
        .O(\state[4]_i_16__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__0_n_7 ),
        .O(\state[4]_i_17__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__0_n_4 ),
        .O(\state[4]_i_18__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__0_n_5 ),
        .O(\state[4]_i_20__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__0_n_6 ),
        .O(\state[4]_i_21__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__0_n_7 ),
        .O(\state[4]_i_22__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__0_n_4 ),
        .O(\state[4]_i_23__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__0_n_5 ),
        .O(\state[4]_i_24__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__0_n_6 ),
        .O(\state[4]_i_25__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__0_n_5 ),
        .O(\state[4]_i_27__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__0_n_6 ),
        .O(\state[4]_i_28__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__0 
       (.I0(\state_reg[4]_i_14__0_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__0_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__0 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__0_1 ),
        .O(\state[4]_i_30__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__0 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__0_0 [3]),
        .O(\state[4]_i_31__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__0 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__0_0 [2]),
        .O(\state[4]_i_32__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__0 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__0_0 [1]),
        .O(\state[4]_i_33__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__0 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__0_0 [0]),
        .O(\state[4]_i_34__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__0 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__0 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__0 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__0 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__0 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_1__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__0_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(\state_reg[4]_i_3__0_n_6 ),
        .O(\state[4]_i_5__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__0_n_7 ),
        .O(\state[4]_i_6__0_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__0 
       (.I0(\state_reg[4]_i_3__0_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__0_n_4 ),
        .O(\state[4]_i_7__0_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[0]_0 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[1]_i_1__0 
       (.CI(seconds_relay_1__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__0_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__0_n_2 ,\state_reg[1]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_1[2],\state_reg[2]_i_1__0_n_7 ,\state_reg[2]_i_2__0_n_4 }),
        .O({\NLW_state_reg[1]_i_1__0_O_UNCONNECTED [3:2],\state_reg[1]_i_1__0_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__0_n_0 ,\state[1]_i_3__0_n_0 ,\state[1]_i_4__0_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_1[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[2]_i_1__0 
       (.CI(\state_reg[2]_i_2__0_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__0_CO_UNCONNECTED [3],seconds_relay_1[2],\state_reg[2]_i_1__0_n_2 ,\state_reg[2]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_1[3],\state_reg[3]_i_1__0_n_7 ,\state_reg[3]_i_2__0_n_4 }),
        .O({\NLW_state_reg[2]_i_1__0_O_UNCONNECTED [3:2],\state_reg[2]_i_1__0_n_6 ,\state_reg[2]_i_1__0_n_7 }),
        .S({1'b0,\state[2]_i_3__0_n_0 ,\state[2]_i_4__0_n_0 ,\state[2]_i_5__0_n_0 }));
  CARRY4 \state_reg[2]_i_2__0 
       (.CI(seconds_relay_1__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__0_n_0 ,\state_reg[2]_i_2__0_n_1 ,\state_reg[2]_i_2__0_n_2 ,\state_reg[2]_i_2__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__0_n_5 ,\state_reg[3]_i_2__0_n_6 ,\state_reg[3]_i_2__0_n_7 ,\state_reg[3]_i_6__0_n_4 }),
        .O({\state_reg[2]_i_2__0_n_4 ,\state_reg[2]_i_2__0_n_5 ,\state_reg[2]_i_2__0_n_6 ,\state_reg[2]_i_2__0_n_7 }),
        .S({\state[2]_i_6__0_n_0 ,\state[2]_i_7__0_n_0 ,\state[2]_i_8__0_n_0 ,\state[2]_i_9__0_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_1[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[3]_i_1__0 
       (.CI(\state_reg[3]_i_2__0_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__0_CO_UNCONNECTED [3],seconds_relay_1[3],\state_reg[3]_i_1__0_n_2 ,\state_reg[3]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_1[4],\state_reg[4]_i_1__0_n_7 ,\state_reg[4]_i_2__0_n_4 }),
        .O({\NLW_state_reg[3]_i_1__0_O_UNCONNECTED [3:2],\state_reg[3]_i_1__0_n_6 ,\state_reg[3]_i_1__0_n_7 }),
        .S({1'b0,\state[3]_i_3__0_n_0 ,\state[3]_i_4__0_n_0 ,\state[3]_i_5__0_n_0 }));
  CARRY4 \state_reg[3]_i_2__0 
       (.CI(\state_reg[3]_i_6__0_n_0 ),
        .CO({\state_reg[3]_i_2__0_n_0 ,\state_reg[3]_i_2__0_n_1 ,\state_reg[3]_i_2__0_n_2 ,\state_reg[3]_i_2__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__0_n_5 ,\state_reg[4]_i_2__0_n_6 ,\state_reg[4]_i_2__0_n_7 ,\state_reg[4]_i_8__0_n_4 }),
        .O({\state_reg[3]_i_2__0_n_4 ,\state_reg[3]_i_2__0_n_5 ,\state_reg[3]_i_2__0_n_6 ,\state_reg[3]_i_2__0_n_7 }),
        .S({\state[3]_i_7__0_n_0 ,\state[3]_i_8__0_n_0 ,\state[3]_i_9__0_n_0 ,\state[3]_i_10__0_n_0 }));
  CARRY4 \state_reg[3]_i_6__0 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__0_n_0 ,\state_reg[3]_i_6__0_n_1 ,\state_reg[3]_i_6__0_n_2 ,\state_reg[3]_i_6__0_n_3 }),
        .CYINIT(seconds_relay_1[4]),
        .DI({\state_reg[4]_i_8__0_n_5 ,\state_reg[4]_i_8__0_n_6 ,seconds_relay_1__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__0_n_4 ,\state_reg[3]_i_6__0_n_5 ,\state_reg[3]_i_6__0_n_6 ,\NLW_state_reg[3]_i_6__0_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__0_n_0 ,\state[3]_i_12__0_n_0 ,\state[3]_i_13__0_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_1[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[4]_i_14__0 
       (.CI(\state_reg[4]_i_15__0_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__0_CO_UNCONNECTED [3],\state_reg[4]_i_14__0_n_1 ,\state_reg[4]_i_14__0_n_2 ,\state_reg[4]_i_14__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__0_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__0_O_UNCONNECTED [3:2],\state_reg[4]_i_14__0_n_6 ,\state_reg[4]_i_14__0_n_7 }),
        .S({1'b0,\state[4]_i_30__0_n_0 ,\state[4]_i_31__0_n_0 ,\state[4]_i_32__0_n_0 }));
  CARRY4 \state_reg[4]_i_15__0 
       (.CI(\state_reg[4]_i_19__0_n_0 ),
        .CO({\state_reg[4]_i_15__0_n_0 ,\state_reg[4]_i_15__0_n_1 ,\state_reg[4]_i_15__0_n_2 ,\state_reg[4]_i_15__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__0_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__0_n_4 ,\state_reg[4]_i_15__0_n_5 ,\state_reg[4]_i_15__0_n_6 ,\state_reg[4]_i_15__0_n_7 }),
        .S({\state[4]_i_33__0_n_0 ,\state[4]_i_34__0_n_0 ,\state[4]_i_35__0_n_0 ,\state[4]_i_36__0_n_0 }));
  CARRY4 \state_reg[4]_i_19__0 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__0_n_0 ,\state_reg[4]_i_19__0_n_1 ,\state_reg[4]_i_19__0_n_2 ,\state_reg[4]_i_19__0_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_1__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__0_n_4 ,\state_reg[4]_i_19__0_n_5 ,\state_reg[4]_i_19__0_n_6 ,\NLW_state_reg[4]_i_19__0_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__0_n_0 ,\state[4]_i_38__0_n_0 ,\state[4]_i_39__0_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__0 
       (.CI(\state_reg[4]_i_2__0_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__0_CO_UNCONNECTED [3],seconds_relay_1[4],\state_reg[4]_i_1__0_n_2 ,\state_reg[4]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__0_n_1 ,\state_reg[4]_i_3__0_n_7 ,\state_reg[4]_i_4__0_n_4 }),
        .O({\NLW_state_reg[4]_i_1__0_O_UNCONNECTED [3:2],\state_reg[4]_i_1__0_n_6 ,\state_reg[4]_i_1__0_n_7 }),
        .S({1'b0,\state[4]_i_5__0_n_0 ,\state[4]_i_6__0_n_0 ,\state[4]_i_7__0_n_0 }));
  CARRY4 \state_reg[4]_i_2__0 
       (.CI(\state_reg[4]_i_8__0_n_0 ),
        .CO({\state_reg[4]_i_2__0_n_0 ,\state_reg[4]_i_2__0_n_1 ,\state_reg[4]_i_2__0_n_2 ,\state_reg[4]_i_2__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__0_n_5 ,\state_reg[4]_i_4__0_n_6 ,\state_reg[4]_i_4__0_n_7 ,\state_reg[4]_i_9__0_n_4 }),
        .O({\state_reg[4]_i_2__0_n_4 ,\state_reg[4]_i_2__0_n_5 ,\state_reg[4]_i_2__0_n_6 ,\state_reg[4]_i_2__0_n_7 }),
        .S({\state[4]_i_10__0_n_0 ,\state[4]_i_11__0_n_0 ,\state[4]_i_12__0_n_0 ,\state[4]_i_13__0_n_0 }));
  CARRY4 \state_reg[4]_i_3__0 
       (.CI(\state_reg[4]_i_4__0_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__0_CO_UNCONNECTED [3],\state_reg[4]_i_3__0_n_1 ,\state_reg[4]_i_3__0_n_2 ,\state_reg[4]_i_3__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__0_n_1 ,\state_reg[4]_i_14__0_n_7 ,\state_reg[4]_i_15__0_n_4 }),
        .O({\NLW_state_reg[4]_i_3__0_O_UNCONNECTED [3:2],\state_reg[4]_i_3__0_n_6 ,\state_reg[4]_i_3__0_n_7 }),
        .S({1'b0,\state[4]_i_16__0_n_0 ,\state[4]_i_17__0_n_0 ,\state[4]_i_18__0_n_0 }));
  CARRY4 \state_reg[4]_i_4__0 
       (.CI(\state_reg[4]_i_9__0_n_0 ),
        .CO({\state_reg[4]_i_4__0_n_0 ,\state_reg[4]_i_4__0_n_1 ,\state_reg[4]_i_4__0_n_2 ,\state_reg[4]_i_4__0_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__0_n_5 ,\state_reg[4]_i_15__0_n_6 ,\state_reg[4]_i_15__0_n_7 ,\state_reg[4]_i_19__0_n_4 }),
        .O({\state_reg[4]_i_4__0_n_4 ,\state_reg[4]_i_4__0_n_5 ,\state_reg[4]_i_4__0_n_6 ,\state_reg[4]_i_4__0_n_7 }),
        .S({\state[4]_i_20__0_n_0 ,\state[4]_i_21__0_n_0 ,\state[4]_i_22__0_n_0 ,\state[4]_i_23__0_n_0 }));
  CARRY4 \state_reg[4]_i_8__0 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__0_n_0 ,\state_reg[4]_i_8__0_n_1 ,\state_reg[4]_i_8__0_n_2 ,\state_reg[4]_i_8__0_n_3 }),
        .CYINIT(\state_reg[4]_i_3__0_n_1 ),
        .DI({\state_reg[4]_i_9__0_n_5 ,\state_reg[4]_i_9__0_n_6 ,seconds_relay_1__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__0_n_4 ,\state_reg[4]_i_8__0_n_5 ,\state_reg[4]_i_8__0_n_6 ,\NLW_state_reg[4]_i_8__0_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__0_n_0 ,\state[4]_i_25__0_n_0 ,\state[4]_i_26__0_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__0 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__0_n_0 ,\state_reg[4]_i_9__0_n_1 ,\state_reg[4]_i_9__0_n_2 ,\state_reg[4]_i_9__0_n_3 }),
        .CYINIT(\state_reg[4]_i_14__0_n_1 ),
        .DI({\state_reg[4]_i_19__0_n_5 ,\state_reg[4]_i_19__0_n_6 ,seconds_relay_1__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__0_n_4 ,\state_reg[4]_i_9__0_n_5 ,\state_reg[4]_i_9__0_n_6 ,\NLW_state_reg[4]_i_9__0_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__0_n_0 ,\state[4]_i_28__0_n_0 ,\state[4]_i_29__0_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_1
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg4_reg[1] ,
    \slv_reg4_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__1_0 ,
    Q,
    seconds_relay_2__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__1_0 ,
    D,
    \state_reg[4]_i_14__1_1 ,
    \state_reg[4]_1 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg4_reg[1] ;
  output [3:0]\slv_reg4_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__1_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_2__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__1_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__1_1 ;
  input [1:0]\state_reg[4]_1 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_2;
  wire seconds_relay_2__274_carry__0_i_1_n_0;
  wire seconds_relay_2__274_carry__0_i_1_n_1;
  wire seconds_relay_2__274_carry__0_i_1_n_2;
  wire seconds_relay_2__274_carry__0_i_1_n_3;
  wire seconds_relay_2__274_carry__0_i_6_n_0;
  wire seconds_relay_2__274_carry__0_i_7_n_0;
  wire seconds_relay_2__274_carry__0_i_8_n_0;
  wire seconds_relay_2__274_carry__0_i_9_n_0;
  wire seconds_relay_2__274_carry_i_10_n_0;
  wire seconds_relay_2__274_carry_i_11_n_0;
  wire seconds_relay_2__274_carry_i_12_n_0;
  wire seconds_relay_2__274_carry_i_1_n_0;
  wire seconds_relay_2__274_carry_i_1_n_1;
  wire seconds_relay_2__274_carry_i_1_n_2;
  wire seconds_relay_2__274_carry_i_1_n_3;
  wire seconds_relay_2__274_carry_i_6_n_0;
  wire seconds_relay_2__274_carry_i_6_n_1;
  wire seconds_relay_2__274_carry_i_6_n_2;
  wire seconds_relay_2__274_carry_i_6_n_3;
  wire seconds_relay_2__274_carry_i_6_n_4;
  wire seconds_relay_2__274_carry_i_6_n_5;
  wire seconds_relay_2__274_carry_i_6_n_6;
  wire seconds_relay_2__274_carry_i_7_n_0;
  wire seconds_relay_2__274_carry_i_8_n_0;
  wire seconds_relay_2__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_2__8_carry__0_i_6;
  wire [2:0]\slv_reg4_reg[1] ;
  wire [3:0]\slv_reg4_reg[1]_0 ;
  wire \state[1]_i_2__1_n_0 ;
  wire \state[1]_i_3__1_n_0 ;
  wire \state[1]_i_4__1_n_0 ;
  wire \state[2]_i_3__1_n_0 ;
  wire \state[2]_i_4__1_n_0 ;
  wire \state[2]_i_5__1_n_0 ;
  wire \state[2]_i_6__1_n_0 ;
  wire \state[2]_i_7__1_n_0 ;
  wire \state[2]_i_8__1_n_0 ;
  wire \state[2]_i_9__1_n_0 ;
  wire \state[3]_i_10__1_n_0 ;
  wire \state[3]_i_11__1_n_0 ;
  wire \state[3]_i_12__1_n_0 ;
  wire \state[3]_i_13__1_n_0 ;
  wire \state[3]_i_3__1_n_0 ;
  wire \state[3]_i_4__1_n_0 ;
  wire \state[3]_i_5__1_n_0 ;
  wire \state[3]_i_7__1_n_0 ;
  wire \state[3]_i_8__1_n_0 ;
  wire \state[3]_i_9__1_n_0 ;
  wire \state[4]_i_10__1_n_0 ;
  wire \state[4]_i_11__1_n_0 ;
  wire \state[4]_i_12__1_n_0 ;
  wire \state[4]_i_13__1_n_0 ;
  wire \state[4]_i_16__1_n_0 ;
  wire \state[4]_i_17__1_n_0 ;
  wire \state[4]_i_18__1_n_0 ;
  wire \state[4]_i_20__1_n_0 ;
  wire \state[4]_i_21__1_n_0 ;
  wire \state[4]_i_22__1_n_0 ;
  wire \state[4]_i_23__1_n_0 ;
  wire \state[4]_i_24__1_n_0 ;
  wire \state[4]_i_25__1_n_0 ;
  wire \state[4]_i_26__1_n_0 ;
  wire \state[4]_i_27__1_n_0 ;
  wire \state[4]_i_28__1_n_0 ;
  wire \state[4]_i_29__1_n_0 ;
  wire \state[4]_i_30__1_n_0 ;
  wire \state[4]_i_31__1_n_0 ;
  wire \state[4]_i_32__1_n_0 ;
  wire \state[4]_i_33__1_n_0 ;
  wire \state[4]_i_34__1_n_0 ;
  wire \state[4]_i_35__1_n_0 ;
  wire \state[4]_i_36__1_n_0 ;
  wire \state[4]_i_37__1_n_0 ;
  wire \state[4]_i_38__1_n_0 ;
  wire \state[4]_i_39__1_n_0 ;
  wire \state[4]_i_5__1_n_0 ;
  wire \state[4]_i_6__1_n_0 ;
  wire \state[4]_i_7__1_n_0 ;
  wire [1:0]\state_reg[1]_i_1__1_0 ;
  wire \state_reg[1]_i_1__1_n_2 ;
  wire \state_reg[1]_i_1__1_n_3 ;
  wire \state_reg[1]_i_1__1_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__1_n_2 ;
  wire \state_reg[2]_i_1__1_n_3 ;
  wire \state_reg[2]_i_1__1_n_6 ;
  wire \state_reg[2]_i_1__1_n_7 ;
  wire \state_reg[2]_i_2__1_n_0 ;
  wire \state_reg[2]_i_2__1_n_1 ;
  wire \state_reg[2]_i_2__1_n_2 ;
  wire \state_reg[2]_i_2__1_n_3 ;
  wire \state_reg[2]_i_2__1_n_4 ;
  wire \state_reg[2]_i_2__1_n_5 ;
  wire \state_reg[2]_i_2__1_n_6 ;
  wire \state_reg[2]_i_2__1_n_7 ;
  wire \state_reg[3]_i_1__1_n_2 ;
  wire \state_reg[3]_i_1__1_n_3 ;
  wire \state_reg[3]_i_1__1_n_6 ;
  wire \state_reg[3]_i_1__1_n_7 ;
  wire \state_reg[3]_i_2__1_n_0 ;
  wire \state_reg[3]_i_2__1_n_1 ;
  wire \state_reg[3]_i_2__1_n_2 ;
  wire \state_reg[3]_i_2__1_n_3 ;
  wire \state_reg[3]_i_2__1_n_4 ;
  wire \state_reg[3]_i_2__1_n_5 ;
  wire \state_reg[3]_i_2__1_n_6 ;
  wire \state_reg[3]_i_2__1_n_7 ;
  wire \state_reg[3]_i_6__1_n_0 ;
  wire \state_reg[3]_i_6__1_n_1 ;
  wire \state_reg[3]_i_6__1_n_2 ;
  wire \state_reg[3]_i_6__1_n_3 ;
  wire \state_reg[3]_i_6__1_n_4 ;
  wire \state_reg[3]_i_6__1_n_5 ;
  wire \state_reg[3]_i_6__1_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [1:0]\state_reg[4]_1 ;
  wire [3:0]\state_reg[4]_i_14__1_0 ;
  wire [0:0]\state_reg[4]_i_14__1_1 ;
  wire \state_reg[4]_i_14__1_n_1 ;
  wire \state_reg[4]_i_14__1_n_2 ;
  wire \state_reg[4]_i_14__1_n_3 ;
  wire \state_reg[4]_i_14__1_n_6 ;
  wire \state_reg[4]_i_14__1_n_7 ;
  wire \state_reg[4]_i_15__1_n_0 ;
  wire \state_reg[4]_i_15__1_n_1 ;
  wire \state_reg[4]_i_15__1_n_2 ;
  wire \state_reg[4]_i_15__1_n_3 ;
  wire \state_reg[4]_i_15__1_n_4 ;
  wire \state_reg[4]_i_15__1_n_5 ;
  wire \state_reg[4]_i_15__1_n_6 ;
  wire \state_reg[4]_i_15__1_n_7 ;
  wire \state_reg[4]_i_19__1_n_0 ;
  wire \state_reg[4]_i_19__1_n_1 ;
  wire \state_reg[4]_i_19__1_n_2 ;
  wire \state_reg[4]_i_19__1_n_3 ;
  wire \state_reg[4]_i_19__1_n_4 ;
  wire \state_reg[4]_i_19__1_n_5 ;
  wire \state_reg[4]_i_19__1_n_6 ;
  wire \state_reg[4]_i_1__1_n_2 ;
  wire \state_reg[4]_i_1__1_n_3 ;
  wire \state_reg[4]_i_1__1_n_6 ;
  wire \state_reg[4]_i_1__1_n_7 ;
  wire \state_reg[4]_i_2__1_n_0 ;
  wire \state_reg[4]_i_2__1_n_1 ;
  wire \state_reg[4]_i_2__1_n_2 ;
  wire \state_reg[4]_i_2__1_n_3 ;
  wire \state_reg[4]_i_2__1_n_4 ;
  wire \state_reg[4]_i_2__1_n_5 ;
  wire \state_reg[4]_i_2__1_n_6 ;
  wire \state_reg[4]_i_2__1_n_7 ;
  wire \state_reg[4]_i_3__1_n_1 ;
  wire \state_reg[4]_i_3__1_n_2 ;
  wire \state_reg[4]_i_3__1_n_3 ;
  wire \state_reg[4]_i_3__1_n_6 ;
  wire \state_reg[4]_i_3__1_n_7 ;
  wire \state_reg[4]_i_4__1_n_0 ;
  wire \state_reg[4]_i_4__1_n_1 ;
  wire \state_reg[4]_i_4__1_n_2 ;
  wire \state_reg[4]_i_4__1_n_3 ;
  wire \state_reg[4]_i_4__1_n_4 ;
  wire \state_reg[4]_i_4__1_n_5 ;
  wire \state_reg[4]_i_4__1_n_6 ;
  wire \state_reg[4]_i_4__1_n_7 ;
  wire \state_reg[4]_i_8__1_n_0 ;
  wire \state_reg[4]_i_8__1_n_1 ;
  wire \state_reg[4]_i_8__1_n_2 ;
  wire \state_reg[4]_i_8__1_n_3 ;
  wire \state_reg[4]_i_8__1_n_4 ;
  wire \state_reg[4]_i_8__1_n_5 ;
  wire \state_reg[4]_i_8__1_n_6 ;
  wire \state_reg[4]_i_9__1_n_0 ;
  wire \state_reg[4]_i_9__1_n_1 ;
  wire \state_reg[4]_i_9__1_n_2 ;
  wire \state_reg[4]_i_9__1_n_3 ;
  wire \state_reg[4]_i_9__1_n_4 ;
  wire \state_reg[4]_i_9__1_n_5 ;
  wire \state_reg[4]_i_9__1_n_6 ;
  wire [0:0]NLW_seconds_relay_2__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_2__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__1_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__1_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__1_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__1_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__1_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__1_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__1
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_2__274_carry__0_i_1
       (.CI(seconds_relay_2__274_carry_i_1_n_0),
        .CO({seconds_relay_2__274_carry__0_i_1_n_0,seconds_relay_2__274_carry__0_i_1_n_1,seconds_relay_2__274_carry__0_i_1_n_2,seconds_relay_2__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__1_n_5 ,\state_reg[2]_i_2__1_n_6 ,\state_reg[2]_i_2__1_n_7 ,seconds_relay_2__274_carry_i_6_n_4}),
        .O(\slv_reg4_reg[1]_0 ),
        .S({seconds_relay_2__274_carry__0_i_6_n_0,seconds_relay_2__274_carry__0_i_7_n_0,seconds_relay_2__274_carry__0_i_8_n_0,seconds_relay_2__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_6
       (.I0(seconds_relay_2[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__1_n_5 ),
        .O(seconds_relay_2__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_7
       (.I0(seconds_relay_2[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__1_n_6 ),
        .O(seconds_relay_2__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_8
       (.I0(seconds_relay_2[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__1_n_7 ),
        .O(seconds_relay_2__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__0_i_9
       (.I0(seconds_relay_2[2]),
        .I1(Q[3]),
        .I2(seconds_relay_2__274_carry_i_6_n_4),
        .O(seconds_relay_2__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__1_n_6 ),
        .O(\state_reg[1]_i_1__1_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__1_0 [0]));
  CARRY4 seconds_relay_2__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_2__274_carry_i_1_n_0,seconds_relay_2__274_carry_i_1_n_1,seconds_relay_2__274_carry_i_1_n_2,seconds_relay_2__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_2[2]),
        .DI({seconds_relay_2__274_carry_i_6_n_5,seconds_relay_2__274_carry_i_6_n_6,seconds_relay_2__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg4_reg[1] ,NLW_seconds_relay_2__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_2__274_carry_i_7_n_0,seconds_relay_2__274_carry_i_8_n_0,seconds_relay_2__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_10
       (.I0(seconds_relay_2[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__1_n_5 ),
        .O(seconds_relay_2__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_11
       (.I0(seconds_relay_2[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__1_n_6 ),
        .O(seconds_relay_2__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_12
       (.I0(seconds_relay_2[3]),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[1]),
        .O(seconds_relay_2__274_carry_i_12_n_0));
  CARRY4 seconds_relay_2__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_2__274_carry_i_6_n_0,seconds_relay_2__274_carry_i_6_n_1,seconds_relay_2__274_carry_i_6_n_2,seconds_relay_2__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_2[3]),
        .DI({\state_reg[3]_i_6__1_n_5 ,\state_reg[3]_i_6__1_n_6 ,seconds_relay_2__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_2__274_carry_i_6_n_4,seconds_relay_2__274_carry_i_6_n_5,seconds_relay_2__274_carry_i_6_n_6,NLW_seconds_relay_2__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_2__274_carry_i_10_n_0,seconds_relay_2__274_carry_i_11_n_0,seconds_relay_2__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_7
       (.I0(seconds_relay_2[2]),
        .I1(Q[2]),
        .I2(seconds_relay_2__274_carry_i_6_n_5),
        .O(seconds_relay_2__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_8
       (.I0(seconds_relay_2[2]),
        .I1(Q[1]),
        .I2(seconds_relay_2__274_carry_i_6_n_6),
        .O(seconds_relay_2__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_2__274_carry_i_9
       (.I0(seconds_relay_2[2]),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[0]),
        .O(seconds_relay_2__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_2__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_2__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_2__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_2__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_2__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_2__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_2__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__1 
       (.I0(seconds_relay_2[2]),
        .I1(\state_reg[2]_i_1__1_n_6 ),
        .O(\state[1]_i_2__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__1 
       (.I0(seconds_relay_2[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__1_n_7 ),
        .O(\state[1]_i_3__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__1 
       (.I0(seconds_relay_2[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__1_n_4 ),
        .O(\state[1]_i_4__1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__1 
       (.I0(seconds_relay_2[3]),
        .I1(\state_reg[3]_i_1__1_n_6 ),
        .O(\state[2]_i_3__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__1_n_7 ),
        .O(\state[2]_i_4__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__1_n_4 ),
        .O(\state[2]_i_5__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__1_n_5 ),
        .O(\state[2]_i_6__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__1_n_6 ),
        .O(\state[2]_i_7__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__1_n_7 ),
        .O(\state[2]_i_8__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__1 
       (.I0(seconds_relay_2[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__1_n_4 ),
        .O(\state[2]_i_9__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__1_n_4 ),
        .O(\state[3]_i_10__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__1_n_5 ),
        .O(\state[3]_i_11__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__1_n_6 ),
        .O(\state[3]_i_12__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__1 
       (.I0(seconds_relay_2[4]),
        .I1(\state_reg[4]_i_1__1_n_6 ),
        .O(\state[3]_i_3__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__1_n_7 ),
        .O(\state[3]_i_4__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__1_n_4 ),
        .O(\state[3]_i_5__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__1_n_5 ),
        .O(\state[3]_i_7__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__1_n_6 ),
        .O(\state[3]_i_8__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__1 
       (.I0(seconds_relay_2[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__1_n_7 ),
        .O(\state[3]_i_9__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__1_n_5 ),
        .O(\state[4]_i_10__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__1_n_6 ),
        .O(\state[4]_i_11__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__1_n_7 ),
        .O(\state[4]_i_12__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__1_n_4 ),
        .O(\state[4]_i_13__1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(\state_reg[4]_i_14__1_n_6 ),
        .O(\state[4]_i_16__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__1_n_7 ),
        .O(\state[4]_i_17__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__1_n_4 ),
        .O(\state[4]_i_18__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__1_n_5 ),
        .O(\state[4]_i_20__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__1_n_6 ),
        .O(\state[4]_i_21__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__1_n_7 ),
        .O(\state[4]_i_22__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__1_n_4 ),
        .O(\state[4]_i_23__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__1_n_5 ),
        .O(\state[4]_i_24__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__1_n_6 ),
        .O(\state[4]_i_25__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__1_n_5 ),
        .O(\state[4]_i_27__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__1_n_6 ),
        .O(\state[4]_i_28__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__1 
       (.I0(\state_reg[4]_i_14__1_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__1 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__1_1 ),
        .O(\state[4]_i_30__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__1 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__1_0 [3]),
        .O(\state[4]_i_31__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__1 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__1_0 [2]),
        .O(\state[4]_i_32__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__1 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__1_0 [1]),
        .O(\state[4]_i_33__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__1 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__1_0 [0]),
        .O(\state[4]_i_34__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__1 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__1 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__1 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__1 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__1 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_2__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(\state_reg[4]_i_3__1_n_6 ),
        .O(\state[4]_i_5__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__1_n_7 ),
        .O(\state[4]_i_6__1_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__1 
       (.I0(\state_reg[4]_i_3__1_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__1_n_4 ),
        .O(\state[4]_i_7__1_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[4]_1 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[1]_i_1__1 
       (.CI(seconds_relay_2__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__1_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__1_n_2 ,\state_reg[1]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_2[2],\state_reg[2]_i_1__1_n_7 ,\state_reg[2]_i_2__1_n_4 }),
        .O({\NLW_state_reg[1]_i_1__1_O_UNCONNECTED [3:2],\state_reg[1]_i_1__1_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__1_n_0 ,\state[1]_i_3__1_n_0 ,\state[1]_i_4__1_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_2[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[2]_i_1__1 
       (.CI(\state_reg[2]_i_2__1_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__1_CO_UNCONNECTED [3],seconds_relay_2[2],\state_reg[2]_i_1__1_n_2 ,\state_reg[2]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_2[3],\state_reg[3]_i_1__1_n_7 ,\state_reg[3]_i_2__1_n_4 }),
        .O({\NLW_state_reg[2]_i_1__1_O_UNCONNECTED [3:2],\state_reg[2]_i_1__1_n_6 ,\state_reg[2]_i_1__1_n_7 }),
        .S({1'b0,\state[2]_i_3__1_n_0 ,\state[2]_i_4__1_n_0 ,\state[2]_i_5__1_n_0 }));
  CARRY4 \state_reg[2]_i_2__1 
       (.CI(seconds_relay_2__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__1_n_0 ,\state_reg[2]_i_2__1_n_1 ,\state_reg[2]_i_2__1_n_2 ,\state_reg[2]_i_2__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__1_n_5 ,\state_reg[3]_i_2__1_n_6 ,\state_reg[3]_i_2__1_n_7 ,\state_reg[3]_i_6__1_n_4 }),
        .O({\state_reg[2]_i_2__1_n_4 ,\state_reg[2]_i_2__1_n_5 ,\state_reg[2]_i_2__1_n_6 ,\state_reg[2]_i_2__1_n_7 }),
        .S({\state[2]_i_6__1_n_0 ,\state[2]_i_7__1_n_0 ,\state[2]_i_8__1_n_0 ,\state[2]_i_9__1_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_2[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[3]_i_1__1 
       (.CI(\state_reg[3]_i_2__1_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__1_CO_UNCONNECTED [3],seconds_relay_2[3],\state_reg[3]_i_1__1_n_2 ,\state_reg[3]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_2[4],\state_reg[4]_i_1__1_n_7 ,\state_reg[4]_i_2__1_n_4 }),
        .O({\NLW_state_reg[3]_i_1__1_O_UNCONNECTED [3:2],\state_reg[3]_i_1__1_n_6 ,\state_reg[3]_i_1__1_n_7 }),
        .S({1'b0,\state[3]_i_3__1_n_0 ,\state[3]_i_4__1_n_0 ,\state[3]_i_5__1_n_0 }));
  CARRY4 \state_reg[3]_i_2__1 
       (.CI(\state_reg[3]_i_6__1_n_0 ),
        .CO({\state_reg[3]_i_2__1_n_0 ,\state_reg[3]_i_2__1_n_1 ,\state_reg[3]_i_2__1_n_2 ,\state_reg[3]_i_2__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__1_n_5 ,\state_reg[4]_i_2__1_n_6 ,\state_reg[4]_i_2__1_n_7 ,\state_reg[4]_i_8__1_n_4 }),
        .O({\state_reg[3]_i_2__1_n_4 ,\state_reg[3]_i_2__1_n_5 ,\state_reg[3]_i_2__1_n_6 ,\state_reg[3]_i_2__1_n_7 }),
        .S({\state[3]_i_7__1_n_0 ,\state[3]_i_8__1_n_0 ,\state[3]_i_9__1_n_0 ,\state[3]_i_10__1_n_0 }));
  CARRY4 \state_reg[3]_i_6__1 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__1_n_0 ,\state_reg[3]_i_6__1_n_1 ,\state_reg[3]_i_6__1_n_2 ,\state_reg[3]_i_6__1_n_3 }),
        .CYINIT(seconds_relay_2[4]),
        .DI({\state_reg[4]_i_8__1_n_5 ,\state_reg[4]_i_8__1_n_6 ,seconds_relay_2__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__1_n_4 ,\state_reg[3]_i_6__1_n_5 ,\state_reg[3]_i_6__1_n_6 ,\NLW_state_reg[3]_i_6__1_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__1_n_0 ,\state[3]_i_12__1_n_0 ,\state[3]_i_13__1_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_2[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[4]_i_14__1 
       (.CI(\state_reg[4]_i_15__1_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__1_CO_UNCONNECTED [3],\state_reg[4]_i_14__1_n_1 ,\state_reg[4]_i_14__1_n_2 ,\state_reg[4]_i_14__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__1_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__1_O_UNCONNECTED [3:2],\state_reg[4]_i_14__1_n_6 ,\state_reg[4]_i_14__1_n_7 }),
        .S({1'b0,\state[4]_i_30__1_n_0 ,\state[4]_i_31__1_n_0 ,\state[4]_i_32__1_n_0 }));
  CARRY4 \state_reg[4]_i_15__1 
       (.CI(\state_reg[4]_i_19__1_n_0 ),
        .CO({\state_reg[4]_i_15__1_n_0 ,\state_reg[4]_i_15__1_n_1 ,\state_reg[4]_i_15__1_n_2 ,\state_reg[4]_i_15__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__1_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__1_n_4 ,\state_reg[4]_i_15__1_n_5 ,\state_reg[4]_i_15__1_n_6 ,\state_reg[4]_i_15__1_n_7 }),
        .S({\state[4]_i_33__1_n_0 ,\state[4]_i_34__1_n_0 ,\state[4]_i_35__1_n_0 ,\state[4]_i_36__1_n_0 }));
  CARRY4 \state_reg[4]_i_19__1 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__1_n_0 ,\state_reg[4]_i_19__1_n_1 ,\state_reg[4]_i_19__1_n_2 ,\state_reg[4]_i_19__1_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_2__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__1_n_4 ,\state_reg[4]_i_19__1_n_5 ,\state_reg[4]_i_19__1_n_6 ,\NLW_state_reg[4]_i_19__1_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__1_n_0 ,\state[4]_i_38__1_n_0 ,\state[4]_i_39__1_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__1 
       (.CI(\state_reg[4]_i_2__1_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__1_CO_UNCONNECTED [3],seconds_relay_2[4],\state_reg[4]_i_1__1_n_2 ,\state_reg[4]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__1_n_1 ,\state_reg[4]_i_3__1_n_7 ,\state_reg[4]_i_4__1_n_4 }),
        .O({\NLW_state_reg[4]_i_1__1_O_UNCONNECTED [3:2],\state_reg[4]_i_1__1_n_6 ,\state_reg[4]_i_1__1_n_7 }),
        .S({1'b0,\state[4]_i_5__1_n_0 ,\state[4]_i_6__1_n_0 ,\state[4]_i_7__1_n_0 }));
  CARRY4 \state_reg[4]_i_2__1 
       (.CI(\state_reg[4]_i_8__1_n_0 ),
        .CO({\state_reg[4]_i_2__1_n_0 ,\state_reg[4]_i_2__1_n_1 ,\state_reg[4]_i_2__1_n_2 ,\state_reg[4]_i_2__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__1_n_5 ,\state_reg[4]_i_4__1_n_6 ,\state_reg[4]_i_4__1_n_7 ,\state_reg[4]_i_9__1_n_4 }),
        .O({\state_reg[4]_i_2__1_n_4 ,\state_reg[4]_i_2__1_n_5 ,\state_reg[4]_i_2__1_n_6 ,\state_reg[4]_i_2__1_n_7 }),
        .S({\state[4]_i_10__1_n_0 ,\state[4]_i_11__1_n_0 ,\state[4]_i_12__1_n_0 ,\state[4]_i_13__1_n_0 }));
  CARRY4 \state_reg[4]_i_3__1 
       (.CI(\state_reg[4]_i_4__1_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__1_CO_UNCONNECTED [3],\state_reg[4]_i_3__1_n_1 ,\state_reg[4]_i_3__1_n_2 ,\state_reg[4]_i_3__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__1_n_1 ,\state_reg[4]_i_14__1_n_7 ,\state_reg[4]_i_15__1_n_4 }),
        .O({\NLW_state_reg[4]_i_3__1_O_UNCONNECTED [3:2],\state_reg[4]_i_3__1_n_6 ,\state_reg[4]_i_3__1_n_7 }),
        .S({1'b0,\state[4]_i_16__1_n_0 ,\state[4]_i_17__1_n_0 ,\state[4]_i_18__1_n_0 }));
  CARRY4 \state_reg[4]_i_4__1 
       (.CI(\state_reg[4]_i_9__1_n_0 ),
        .CO({\state_reg[4]_i_4__1_n_0 ,\state_reg[4]_i_4__1_n_1 ,\state_reg[4]_i_4__1_n_2 ,\state_reg[4]_i_4__1_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__1_n_5 ,\state_reg[4]_i_15__1_n_6 ,\state_reg[4]_i_15__1_n_7 ,\state_reg[4]_i_19__1_n_4 }),
        .O({\state_reg[4]_i_4__1_n_4 ,\state_reg[4]_i_4__1_n_5 ,\state_reg[4]_i_4__1_n_6 ,\state_reg[4]_i_4__1_n_7 }),
        .S({\state[4]_i_20__1_n_0 ,\state[4]_i_21__1_n_0 ,\state[4]_i_22__1_n_0 ,\state[4]_i_23__1_n_0 }));
  CARRY4 \state_reg[4]_i_8__1 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__1_n_0 ,\state_reg[4]_i_8__1_n_1 ,\state_reg[4]_i_8__1_n_2 ,\state_reg[4]_i_8__1_n_3 }),
        .CYINIT(\state_reg[4]_i_3__1_n_1 ),
        .DI({\state_reg[4]_i_9__1_n_5 ,\state_reg[4]_i_9__1_n_6 ,seconds_relay_2__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__1_n_4 ,\state_reg[4]_i_8__1_n_5 ,\state_reg[4]_i_8__1_n_6 ,\NLW_state_reg[4]_i_8__1_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__1_n_0 ,\state[4]_i_25__1_n_0 ,\state[4]_i_26__1_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__1 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__1_n_0 ,\state_reg[4]_i_9__1_n_1 ,\state_reg[4]_i_9__1_n_2 ,\state_reg[4]_i_9__1_n_3 }),
        .CYINIT(\state_reg[4]_i_14__1_n_1 ),
        .DI({\state_reg[4]_i_19__1_n_5 ,\state_reg[4]_i_19__1_n_6 ,seconds_relay_2__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__1_n_4 ,\state_reg[4]_i_9__1_n_5 ,\state_reg[4]_i_9__1_n_6 ,\NLW_state_reg[4]_i_9__1_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__1_n_0 ,\state[4]_i_28__1_n_0 ,\state[4]_i_29__1_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_2
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg5_reg[1] ,
    \slv_reg5_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__2_0 ,
    Q,
    seconds_relay_3__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__2_0 ,
    D,
    \state_reg[4]_i_14__2_1 ,
    \state_reg[0]_0 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg5_reg[1] ;
  output [3:0]\slv_reg5_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__2_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_3__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__2_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__2_1 ;
  input [1:0]\state_reg[0]_0 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_3;
  wire seconds_relay_3__274_carry__0_i_1_n_0;
  wire seconds_relay_3__274_carry__0_i_1_n_1;
  wire seconds_relay_3__274_carry__0_i_1_n_2;
  wire seconds_relay_3__274_carry__0_i_1_n_3;
  wire seconds_relay_3__274_carry__0_i_6_n_0;
  wire seconds_relay_3__274_carry__0_i_7_n_0;
  wire seconds_relay_3__274_carry__0_i_8_n_0;
  wire seconds_relay_3__274_carry__0_i_9_n_0;
  wire seconds_relay_3__274_carry_i_10_n_0;
  wire seconds_relay_3__274_carry_i_11_n_0;
  wire seconds_relay_3__274_carry_i_12_n_0;
  wire seconds_relay_3__274_carry_i_1_n_0;
  wire seconds_relay_3__274_carry_i_1_n_1;
  wire seconds_relay_3__274_carry_i_1_n_2;
  wire seconds_relay_3__274_carry_i_1_n_3;
  wire seconds_relay_3__274_carry_i_6_n_0;
  wire seconds_relay_3__274_carry_i_6_n_1;
  wire seconds_relay_3__274_carry_i_6_n_2;
  wire seconds_relay_3__274_carry_i_6_n_3;
  wire seconds_relay_3__274_carry_i_6_n_4;
  wire seconds_relay_3__274_carry_i_6_n_5;
  wire seconds_relay_3__274_carry_i_6_n_6;
  wire seconds_relay_3__274_carry_i_7_n_0;
  wire seconds_relay_3__274_carry_i_8_n_0;
  wire seconds_relay_3__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_3__8_carry__0_i_6;
  wire [2:0]\slv_reg5_reg[1] ;
  wire [3:0]\slv_reg5_reg[1]_0 ;
  wire \state[1]_i_2__2_n_0 ;
  wire \state[1]_i_3__2_n_0 ;
  wire \state[1]_i_4__2_n_0 ;
  wire \state[2]_i_3__2_n_0 ;
  wire \state[2]_i_4__2_n_0 ;
  wire \state[2]_i_5__2_n_0 ;
  wire \state[2]_i_6__2_n_0 ;
  wire \state[2]_i_7__2_n_0 ;
  wire \state[2]_i_8__2_n_0 ;
  wire \state[2]_i_9__2_n_0 ;
  wire \state[3]_i_10__2_n_0 ;
  wire \state[3]_i_11__2_n_0 ;
  wire \state[3]_i_12__2_n_0 ;
  wire \state[3]_i_13__2_n_0 ;
  wire \state[3]_i_3__2_n_0 ;
  wire \state[3]_i_4__2_n_0 ;
  wire \state[3]_i_5__2_n_0 ;
  wire \state[3]_i_7__2_n_0 ;
  wire \state[3]_i_8__2_n_0 ;
  wire \state[3]_i_9__2_n_0 ;
  wire \state[4]_i_10__2_n_0 ;
  wire \state[4]_i_11__2_n_0 ;
  wire \state[4]_i_12__2_n_0 ;
  wire \state[4]_i_13__2_n_0 ;
  wire \state[4]_i_16__2_n_0 ;
  wire \state[4]_i_17__2_n_0 ;
  wire \state[4]_i_18__2_n_0 ;
  wire \state[4]_i_20__2_n_0 ;
  wire \state[4]_i_21__2_n_0 ;
  wire \state[4]_i_22__2_n_0 ;
  wire \state[4]_i_23__2_n_0 ;
  wire \state[4]_i_24__2_n_0 ;
  wire \state[4]_i_25__2_n_0 ;
  wire \state[4]_i_26__2_n_0 ;
  wire \state[4]_i_27__2_n_0 ;
  wire \state[4]_i_28__2_n_0 ;
  wire \state[4]_i_29__2_n_0 ;
  wire \state[4]_i_30__2_n_0 ;
  wire \state[4]_i_31__2_n_0 ;
  wire \state[4]_i_32__2_n_0 ;
  wire \state[4]_i_33__2_n_0 ;
  wire \state[4]_i_34__2_n_0 ;
  wire \state[4]_i_35__2_n_0 ;
  wire \state[4]_i_36__2_n_0 ;
  wire \state[4]_i_37__2_n_0 ;
  wire \state[4]_i_38__2_n_0 ;
  wire \state[4]_i_39__2_n_0 ;
  wire \state[4]_i_5__2_n_0 ;
  wire \state[4]_i_6__2_n_0 ;
  wire \state[4]_i_7__2_n_0 ;
  wire [1:0]\state_reg[0]_0 ;
  wire [1:0]\state_reg[1]_i_1__2_0 ;
  wire \state_reg[1]_i_1__2_n_2 ;
  wire \state_reg[1]_i_1__2_n_3 ;
  wire \state_reg[1]_i_1__2_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__2_n_2 ;
  wire \state_reg[2]_i_1__2_n_3 ;
  wire \state_reg[2]_i_1__2_n_6 ;
  wire \state_reg[2]_i_1__2_n_7 ;
  wire \state_reg[2]_i_2__2_n_0 ;
  wire \state_reg[2]_i_2__2_n_1 ;
  wire \state_reg[2]_i_2__2_n_2 ;
  wire \state_reg[2]_i_2__2_n_3 ;
  wire \state_reg[2]_i_2__2_n_4 ;
  wire \state_reg[2]_i_2__2_n_5 ;
  wire \state_reg[2]_i_2__2_n_6 ;
  wire \state_reg[2]_i_2__2_n_7 ;
  wire \state_reg[3]_i_1__2_n_2 ;
  wire \state_reg[3]_i_1__2_n_3 ;
  wire \state_reg[3]_i_1__2_n_6 ;
  wire \state_reg[3]_i_1__2_n_7 ;
  wire \state_reg[3]_i_2__2_n_0 ;
  wire \state_reg[3]_i_2__2_n_1 ;
  wire \state_reg[3]_i_2__2_n_2 ;
  wire \state_reg[3]_i_2__2_n_3 ;
  wire \state_reg[3]_i_2__2_n_4 ;
  wire \state_reg[3]_i_2__2_n_5 ;
  wire \state_reg[3]_i_2__2_n_6 ;
  wire \state_reg[3]_i_2__2_n_7 ;
  wire \state_reg[3]_i_6__2_n_0 ;
  wire \state_reg[3]_i_6__2_n_1 ;
  wire \state_reg[3]_i_6__2_n_2 ;
  wire \state_reg[3]_i_6__2_n_3 ;
  wire \state_reg[3]_i_6__2_n_4 ;
  wire \state_reg[3]_i_6__2_n_5 ;
  wire \state_reg[3]_i_6__2_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [3:0]\state_reg[4]_i_14__2_0 ;
  wire [0:0]\state_reg[4]_i_14__2_1 ;
  wire \state_reg[4]_i_14__2_n_1 ;
  wire \state_reg[4]_i_14__2_n_2 ;
  wire \state_reg[4]_i_14__2_n_3 ;
  wire \state_reg[4]_i_14__2_n_6 ;
  wire \state_reg[4]_i_14__2_n_7 ;
  wire \state_reg[4]_i_15__2_n_0 ;
  wire \state_reg[4]_i_15__2_n_1 ;
  wire \state_reg[4]_i_15__2_n_2 ;
  wire \state_reg[4]_i_15__2_n_3 ;
  wire \state_reg[4]_i_15__2_n_4 ;
  wire \state_reg[4]_i_15__2_n_5 ;
  wire \state_reg[4]_i_15__2_n_6 ;
  wire \state_reg[4]_i_15__2_n_7 ;
  wire \state_reg[4]_i_19__2_n_0 ;
  wire \state_reg[4]_i_19__2_n_1 ;
  wire \state_reg[4]_i_19__2_n_2 ;
  wire \state_reg[4]_i_19__2_n_3 ;
  wire \state_reg[4]_i_19__2_n_4 ;
  wire \state_reg[4]_i_19__2_n_5 ;
  wire \state_reg[4]_i_19__2_n_6 ;
  wire \state_reg[4]_i_1__2_n_2 ;
  wire \state_reg[4]_i_1__2_n_3 ;
  wire \state_reg[4]_i_1__2_n_6 ;
  wire \state_reg[4]_i_1__2_n_7 ;
  wire \state_reg[4]_i_2__2_n_0 ;
  wire \state_reg[4]_i_2__2_n_1 ;
  wire \state_reg[4]_i_2__2_n_2 ;
  wire \state_reg[4]_i_2__2_n_3 ;
  wire \state_reg[4]_i_2__2_n_4 ;
  wire \state_reg[4]_i_2__2_n_5 ;
  wire \state_reg[4]_i_2__2_n_6 ;
  wire \state_reg[4]_i_2__2_n_7 ;
  wire \state_reg[4]_i_3__2_n_1 ;
  wire \state_reg[4]_i_3__2_n_2 ;
  wire \state_reg[4]_i_3__2_n_3 ;
  wire \state_reg[4]_i_3__2_n_6 ;
  wire \state_reg[4]_i_3__2_n_7 ;
  wire \state_reg[4]_i_4__2_n_0 ;
  wire \state_reg[4]_i_4__2_n_1 ;
  wire \state_reg[4]_i_4__2_n_2 ;
  wire \state_reg[4]_i_4__2_n_3 ;
  wire \state_reg[4]_i_4__2_n_4 ;
  wire \state_reg[4]_i_4__2_n_5 ;
  wire \state_reg[4]_i_4__2_n_6 ;
  wire \state_reg[4]_i_4__2_n_7 ;
  wire \state_reg[4]_i_8__2_n_0 ;
  wire \state_reg[4]_i_8__2_n_1 ;
  wire \state_reg[4]_i_8__2_n_2 ;
  wire \state_reg[4]_i_8__2_n_3 ;
  wire \state_reg[4]_i_8__2_n_4 ;
  wire \state_reg[4]_i_8__2_n_5 ;
  wire \state_reg[4]_i_8__2_n_6 ;
  wire \state_reg[4]_i_9__2_n_0 ;
  wire \state_reg[4]_i_9__2_n_1 ;
  wire \state_reg[4]_i_9__2_n_2 ;
  wire \state_reg[4]_i_9__2_n_3 ;
  wire \state_reg[4]_i_9__2_n_4 ;
  wire \state_reg[4]_i_9__2_n_5 ;
  wire \state_reg[4]_i_9__2_n_6 ;
  wire [0:0]NLW_seconds_relay_3__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_3__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__2_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__2_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__2_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__2_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__2_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__2_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__2_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__2_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__2_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__2_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__2
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_3__274_carry__0_i_1
       (.CI(seconds_relay_3__274_carry_i_1_n_0),
        .CO({seconds_relay_3__274_carry__0_i_1_n_0,seconds_relay_3__274_carry__0_i_1_n_1,seconds_relay_3__274_carry__0_i_1_n_2,seconds_relay_3__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__2_n_5 ,\state_reg[2]_i_2__2_n_6 ,\state_reg[2]_i_2__2_n_7 ,seconds_relay_3__274_carry_i_6_n_4}),
        .O(\slv_reg5_reg[1]_0 ),
        .S({seconds_relay_3__274_carry__0_i_6_n_0,seconds_relay_3__274_carry__0_i_7_n_0,seconds_relay_3__274_carry__0_i_8_n_0,seconds_relay_3__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_6
       (.I0(seconds_relay_3[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__2_n_5 ),
        .O(seconds_relay_3__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_7
       (.I0(seconds_relay_3[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__2_n_6 ),
        .O(seconds_relay_3__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_8
       (.I0(seconds_relay_3[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__2_n_7 ),
        .O(seconds_relay_3__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__0_i_9
       (.I0(seconds_relay_3[2]),
        .I1(Q[3]),
        .I2(seconds_relay_3__274_carry_i_6_n_4),
        .O(seconds_relay_3__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__2_n_6 ),
        .O(\state_reg[1]_i_1__2_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__2_0 [0]));
  CARRY4 seconds_relay_3__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_3__274_carry_i_1_n_0,seconds_relay_3__274_carry_i_1_n_1,seconds_relay_3__274_carry_i_1_n_2,seconds_relay_3__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_3[2]),
        .DI({seconds_relay_3__274_carry_i_6_n_5,seconds_relay_3__274_carry_i_6_n_6,seconds_relay_3__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg5_reg[1] ,NLW_seconds_relay_3__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_3__274_carry_i_7_n_0,seconds_relay_3__274_carry_i_8_n_0,seconds_relay_3__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_10
       (.I0(seconds_relay_3[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__2_n_5 ),
        .O(seconds_relay_3__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_11
       (.I0(seconds_relay_3[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__2_n_6 ),
        .O(seconds_relay_3__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_12
       (.I0(seconds_relay_3[3]),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[1]),
        .O(seconds_relay_3__274_carry_i_12_n_0));
  CARRY4 seconds_relay_3__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_3__274_carry_i_6_n_0,seconds_relay_3__274_carry_i_6_n_1,seconds_relay_3__274_carry_i_6_n_2,seconds_relay_3__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_3[3]),
        .DI({\state_reg[3]_i_6__2_n_5 ,\state_reg[3]_i_6__2_n_6 ,seconds_relay_3__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_3__274_carry_i_6_n_4,seconds_relay_3__274_carry_i_6_n_5,seconds_relay_3__274_carry_i_6_n_6,NLW_seconds_relay_3__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_3__274_carry_i_10_n_0,seconds_relay_3__274_carry_i_11_n_0,seconds_relay_3__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_7
       (.I0(seconds_relay_3[2]),
        .I1(Q[2]),
        .I2(seconds_relay_3__274_carry_i_6_n_5),
        .O(seconds_relay_3__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_8
       (.I0(seconds_relay_3[2]),
        .I1(Q[1]),
        .I2(seconds_relay_3__274_carry_i_6_n_6),
        .O(seconds_relay_3__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_3__274_carry_i_9
       (.I0(seconds_relay_3[2]),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[0]),
        .O(seconds_relay_3__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_3__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_3__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_3__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_3__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_3__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_3__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_3__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__2 
       (.I0(seconds_relay_3[2]),
        .I1(\state_reg[2]_i_1__2_n_6 ),
        .O(\state[1]_i_2__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__2 
       (.I0(seconds_relay_3[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__2_n_7 ),
        .O(\state[1]_i_3__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__2 
       (.I0(seconds_relay_3[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__2_n_4 ),
        .O(\state[1]_i_4__2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__2 
       (.I0(seconds_relay_3[3]),
        .I1(\state_reg[3]_i_1__2_n_6 ),
        .O(\state[2]_i_3__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__2_n_7 ),
        .O(\state[2]_i_4__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__2_n_4 ),
        .O(\state[2]_i_5__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__2_n_5 ),
        .O(\state[2]_i_6__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__2_n_6 ),
        .O(\state[2]_i_7__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__2_n_7 ),
        .O(\state[2]_i_8__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__2 
       (.I0(seconds_relay_3[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__2_n_4 ),
        .O(\state[2]_i_9__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__2_n_4 ),
        .O(\state[3]_i_10__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__2_n_5 ),
        .O(\state[3]_i_11__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__2_n_6 ),
        .O(\state[3]_i_12__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__2 
       (.I0(seconds_relay_3[4]),
        .I1(\state_reg[4]_i_1__2_n_6 ),
        .O(\state[3]_i_3__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__2_n_7 ),
        .O(\state[3]_i_4__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__2_n_4 ),
        .O(\state[3]_i_5__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__2_n_5 ),
        .O(\state[3]_i_7__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__2_n_6 ),
        .O(\state[3]_i_8__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__2 
       (.I0(seconds_relay_3[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__2_n_7 ),
        .O(\state[3]_i_9__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__2_n_5 ),
        .O(\state[4]_i_10__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__2_n_6 ),
        .O(\state[4]_i_11__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__2_n_7 ),
        .O(\state[4]_i_12__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__2_n_4 ),
        .O(\state[4]_i_13__2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(\state_reg[4]_i_14__2_n_6 ),
        .O(\state[4]_i_16__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__2_n_7 ),
        .O(\state[4]_i_17__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__2_n_4 ),
        .O(\state[4]_i_18__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__2_n_5 ),
        .O(\state[4]_i_20__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__2_n_6 ),
        .O(\state[4]_i_21__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__2_n_7 ),
        .O(\state[4]_i_22__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__2_n_4 ),
        .O(\state[4]_i_23__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__2_n_5 ),
        .O(\state[4]_i_24__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__2_n_6 ),
        .O(\state[4]_i_25__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__2_n_5 ),
        .O(\state[4]_i_27__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__2_n_6 ),
        .O(\state[4]_i_28__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__2 
       (.I0(\state_reg[4]_i_14__2_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__2 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__2_1 ),
        .O(\state[4]_i_30__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__2 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__2_0 [3]),
        .O(\state[4]_i_31__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__2 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__2_0 [2]),
        .O(\state[4]_i_32__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__2 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__2_0 [1]),
        .O(\state[4]_i_33__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__2 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__2_0 [0]),
        .O(\state[4]_i_34__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__2 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__2 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__2 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__2 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__2 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_3__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(\state_reg[4]_i_3__2_n_6 ),
        .O(\state[4]_i_5__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__2_n_7 ),
        .O(\state[4]_i_6__2_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__2 
       (.I0(\state_reg[4]_i_3__2_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__2_n_4 ),
        .O(\state[4]_i_7__2_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[0]_0 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[1]_i_1__2 
       (.CI(seconds_relay_3__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__2_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__2_n_2 ,\state_reg[1]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_3[2],\state_reg[2]_i_1__2_n_7 ,\state_reg[2]_i_2__2_n_4 }),
        .O({\NLW_state_reg[1]_i_1__2_O_UNCONNECTED [3:2],\state_reg[1]_i_1__2_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__2_n_0 ,\state[1]_i_3__2_n_0 ,\state[1]_i_4__2_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_3[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[2]_i_1__2 
       (.CI(\state_reg[2]_i_2__2_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__2_CO_UNCONNECTED [3],seconds_relay_3[2],\state_reg[2]_i_1__2_n_2 ,\state_reg[2]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_3[3],\state_reg[3]_i_1__2_n_7 ,\state_reg[3]_i_2__2_n_4 }),
        .O({\NLW_state_reg[2]_i_1__2_O_UNCONNECTED [3:2],\state_reg[2]_i_1__2_n_6 ,\state_reg[2]_i_1__2_n_7 }),
        .S({1'b0,\state[2]_i_3__2_n_0 ,\state[2]_i_4__2_n_0 ,\state[2]_i_5__2_n_0 }));
  CARRY4 \state_reg[2]_i_2__2 
       (.CI(seconds_relay_3__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__2_n_0 ,\state_reg[2]_i_2__2_n_1 ,\state_reg[2]_i_2__2_n_2 ,\state_reg[2]_i_2__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__2_n_5 ,\state_reg[3]_i_2__2_n_6 ,\state_reg[3]_i_2__2_n_7 ,\state_reg[3]_i_6__2_n_4 }),
        .O({\state_reg[2]_i_2__2_n_4 ,\state_reg[2]_i_2__2_n_5 ,\state_reg[2]_i_2__2_n_6 ,\state_reg[2]_i_2__2_n_7 }),
        .S({\state[2]_i_6__2_n_0 ,\state[2]_i_7__2_n_0 ,\state[2]_i_8__2_n_0 ,\state[2]_i_9__2_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_3[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[3]_i_1__2 
       (.CI(\state_reg[3]_i_2__2_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__2_CO_UNCONNECTED [3],seconds_relay_3[3],\state_reg[3]_i_1__2_n_2 ,\state_reg[3]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_3[4],\state_reg[4]_i_1__2_n_7 ,\state_reg[4]_i_2__2_n_4 }),
        .O({\NLW_state_reg[3]_i_1__2_O_UNCONNECTED [3:2],\state_reg[3]_i_1__2_n_6 ,\state_reg[3]_i_1__2_n_7 }),
        .S({1'b0,\state[3]_i_3__2_n_0 ,\state[3]_i_4__2_n_0 ,\state[3]_i_5__2_n_0 }));
  CARRY4 \state_reg[3]_i_2__2 
       (.CI(\state_reg[3]_i_6__2_n_0 ),
        .CO({\state_reg[3]_i_2__2_n_0 ,\state_reg[3]_i_2__2_n_1 ,\state_reg[3]_i_2__2_n_2 ,\state_reg[3]_i_2__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__2_n_5 ,\state_reg[4]_i_2__2_n_6 ,\state_reg[4]_i_2__2_n_7 ,\state_reg[4]_i_8__2_n_4 }),
        .O({\state_reg[3]_i_2__2_n_4 ,\state_reg[3]_i_2__2_n_5 ,\state_reg[3]_i_2__2_n_6 ,\state_reg[3]_i_2__2_n_7 }),
        .S({\state[3]_i_7__2_n_0 ,\state[3]_i_8__2_n_0 ,\state[3]_i_9__2_n_0 ,\state[3]_i_10__2_n_0 }));
  CARRY4 \state_reg[3]_i_6__2 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__2_n_0 ,\state_reg[3]_i_6__2_n_1 ,\state_reg[3]_i_6__2_n_2 ,\state_reg[3]_i_6__2_n_3 }),
        .CYINIT(seconds_relay_3[4]),
        .DI({\state_reg[4]_i_8__2_n_5 ,\state_reg[4]_i_8__2_n_6 ,seconds_relay_3__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__2_n_4 ,\state_reg[3]_i_6__2_n_5 ,\state_reg[3]_i_6__2_n_6 ,\NLW_state_reg[3]_i_6__2_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__2_n_0 ,\state[3]_i_12__2_n_0 ,\state[3]_i_13__2_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_3[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[4]_i_14__2 
       (.CI(\state_reg[4]_i_15__2_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__2_CO_UNCONNECTED [3],\state_reg[4]_i_14__2_n_1 ,\state_reg[4]_i_14__2_n_2 ,\state_reg[4]_i_14__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__2_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__2_O_UNCONNECTED [3:2],\state_reg[4]_i_14__2_n_6 ,\state_reg[4]_i_14__2_n_7 }),
        .S({1'b0,\state[4]_i_30__2_n_0 ,\state[4]_i_31__2_n_0 ,\state[4]_i_32__2_n_0 }));
  CARRY4 \state_reg[4]_i_15__2 
       (.CI(\state_reg[4]_i_19__2_n_0 ),
        .CO({\state_reg[4]_i_15__2_n_0 ,\state_reg[4]_i_15__2_n_1 ,\state_reg[4]_i_15__2_n_2 ,\state_reg[4]_i_15__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__2_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__2_n_4 ,\state_reg[4]_i_15__2_n_5 ,\state_reg[4]_i_15__2_n_6 ,\state_reg[4]_i_15__2_n_7 }),
        .S({\state[4]_i_33__2_n_0 ,\state[4]_i_34__2_n_0 ,\state[4]_i_35__2_n_0 ,\state[4]_i_36__2_n_0 }));
  CARRY4 \state_reg[4]_i_19__2 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__2_n_0 ,\state_reg[4]_i_19__2_n_1 ,\state_reg[4]_i_19__2_n_2 ,\state_reg[4]_i_19__2_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_3__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__2_n_4 ,\state_reg[4]_i_19__2_n_5 ,\state_reg[4]_i_19__2_n_6 ,\NLW_state_reg[4]_i_19__2_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__2_n_0 ,\state[4]_i_38__2_n_0 ,\state[4]_i_39__2_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__2 
       (.CI(\state_reg[4]_i_2__2_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__2_CO_UNCONNECTED [3],seconds_relay_3[4],\state_reg[4]_i_1__2_n_2 ,\state_reg[4]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__2_n_1 ,\state_reg[4]_i_3__2_n_7 ,\state_reg[4]_i_4__2_n_4 }),
        .O({\NLW_state_reg[4]_i_1__2_O_UNCONNECTED [3:2],\state_reg[4]_i_1__2_n_6 ,\state_reg[4]_i_1__2_n_7 }),
        .S({1'b0,\state[4]_i_5__2_n_0 ,\state[4]_i_6__2_n_0 ,\state[4]_i_7__2_n_0 }));
  CARRY4 \state_reg[4]_i_2__2 
       (.CI(\state_reg[4]_i_8__2_n_0 ),
        .CO({\state_reg[4]_i_2__2_n_0 ,\state_reg[4]_i_2__2_n_1 ,\state_reg[4]_i_2__2_n_2 ,\state_reg[4]_i_2__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__2_n_5 ,\state_reg[4]_i_4__2_n_6 ,\state_reg[4]_i_4__2_n_7 ,\state_reg[4]_i_9__2_n_4 }),
        .O({\state_reg[4]_i_2__2_n_4 ,\state_reg[4]_i_2__2_n_5 ,\state_reg[4]_i_2__2_n_6 ,\state_reg[4]_i_2__2_n_7 }),
        .S({\state[4]_i_10__2_n_0 ,\state[4]_i_11__2_n_0 ,\state[4]_i_12__2_n_0 ,\state[4]_i_13__2_n_0 }));
  CARRY4 \state_reg[4]_i_3__2 
       (.CI(\state_reg[4]_i_4__2_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__2_CO_UNCONNECTED [3],\state_reg[4]_i_3__2_n_1 ,\state_reg[4]_i_3__2_n_2 ,\state_reg[4]_i_3__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__2_n_1 ,\state_reg[4]_i_14__2_n_7 ,\state_reg[4]_i_15__2_n_4 }),
        .O({\NLW_state_reg[4]_i_3__2_O_UNCONNECTED [3:2],\state_reg[4]_i_3__2_n_6 ,\state_reg[4]_i_3__2_n_7 }),
        .S({1'b0,\state[4]_i_16__2_n_0 ,\state[4]_i_17__2_n_0 ,\state[4]_i_18__2_n_0 }));
  CARRY4 \state_reg[4]_i_4__2 
       (.CI(\state_reg[4]_i_9__2_n_0 ),
        .CO({\state_reg[4]_i_4__2_n_0 ,\state_reg[4]_i_4__2_n_1 ,\state_reg[4]_i_4__2_n_2 ,\state_reg[4]_i_4__2_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__2_n_5 ,\state_reg[4]_i_15__2_n_6 ,\state_reg[4]_i_15__2_n_7 ,\state_reg[4]_i_19__2_n_4 }),
        .O({\state_reg[4]_i_4__2_n_4 ,\state_reg[4]_i_4__2_n_5 ,\state_reg[4]_i_4__2_n_6 ,\state_reg[4]_i_4__2_n_7 }),
        .S({\state[4]_i_20__2_n_0 ,\state[4]_i_21__2_n_0 ,\state[4]_i_22__2_n_0 ,\state[4]_i_23__2_n_0 }));
  CARRY4 \state_reg[4]_i_8__2 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__2_n_0 ,\state_reg[4]_i_8__2_n_1 ,\state_reg[4]_i_8__2_n_2 ,\state_reg[4]_i_8__2_n_3 }),
        .CYINIT(\state_reg[4]_i_3__2_n_1 ),
        .DI({\state_reg[4]_i_9__2_n_5 ,\state_reg[4]_i_9__2_n_6 ,seconds_relay_3__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__2_n_4 ,\state_reg[4]_i_8__2_n_5 ,\state_reg[4]_i_8__2_n_6 ,\NLW_state_reg[4]_i_8__2_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__2_n_0 ,\state[4]_i_25__2_n_0 ,\state[4]_i_26__2_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__2 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__2_n_0 ,\state_reg[4]_i_9__2_n_1 ,\state_reg[4]_i_9__2_n_2 ,\state_reg[4]_i_9__2_n_3 }),
        .CYINIT(\state_reg[4]_i_14__2_n_1 ),
        .DI({\state_reg[4]_i_19__2_n_5 ,\state_reg[4]_i_19__2_n_6 ,seconds_relay_3__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__2_n_4 ,\state_reg[4]_i_9__2_n_5 ,\state_reg[4]_i_9__2_n_6 ,\NLW_state_reg[4]_i_9__2_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__2_n_0 ,\state[4]_i_28__2_n_0 ,\state[4]_i_29__2_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_3
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg6_reg[1] ,
    \slv_reg6_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__3_0 ,
    Q,
    seconds_relay_4__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__3_0 ,
    D,
    \state_reg[4]_i_14__3_1 ,
    \state_reg[4]_1 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg6_reg[1] ;
  output [3:0]\slv_reg6_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__3_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_4__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__3_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__3_1 ;
  input [1:0]\state_reg[4]_1 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_4;
  wire seconds_relay_4__274_carry__0_i_1_n_0;
  wire seconds_relay_4__274_carry__0_i_1_n_1;
  wire seconds_relay_4__274_carry__0_i_1_n_2;
  wire seconds_relay_4__274_carry__0_i_1_n_3;
  wire seconds_relay_4__274_carry__0_i_6_n_0;
  wire seconds_relay_4__274_carry__0_i_7_n_0;
  wire seconds_relay_4__274_carry__0_i_8_n_0;
  wire seconds_relay_4__274_carry__0_i_9_n_0;
  wire seconds_relay_4__274_carry_i_10_n_0;
  wire seconds_relay_4__274_carry_i_11_n_0;
  wire seconds_relay_4__274_carry_i_12_n_0;
  wire seconds_relay_4__274_carry_i_1_n_0;
  wire seconds_relay_4__274_carry_i_1_n_1;
  wire seconds_relay_4__274_carry_i_1_n_2;
  wire seconds_relay_4__274_carry_i_1_n_3;
  wire seconds_relay_4__274_carry_i_6_n_0;
  wire seconds_relay_4__274_carry_i_6_n_1;
  wire seconds_relay_4__274_carry_i_6_n_2;
  wire seconds_relay_4__274_carry_i_6_n_3;
  wire seconds_relay_4__274_carry_i_6_n_4;
  wire seconds_relay_4__274_carry_i_6_n_5;
  wire seconds_relay_4__274_carry_i_6_n_6;
  wire seconds_relay_4__274_carry_i_7_n_0;
  wire seconds_relay_4__274_carry_i_8_n_0;
  wire seconds_relay_4__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_4__8_carry__0_i_6;
  wire [2:0]\slv_reg6_reg[1] ;
  wire [3:0]\slv_reg6_reg[1]_0 ;
  wire \state[1]_i_2__3_n_0 ;
  wire \state[1]_i_3__3_n_0 ;
  wire \state[1]_i_4__3_n_0 ;
  wire \state[2]_i_3__3_n_0 ;
  wire \state[2]_i_4__3_n_0 ;
  wire \state[2]_i_5__3_n_0 ;
  wire \state[2]_i_6__3_n_0 ;
  wire \state[2]_i_7__3_n_0 ;
  wire \state[2]_i_8__3_n_0 ;
  wire \state[2]_i_9__3_n_0 ;
  wire \state[3]_i_10__3_n_0 ;
  wire \state[3]_i_11__3_n_0 ;
  wire \state[3]_i_12__3_n_0 ;
  wire \state[3]_i_13__3_n_0 ;
  wire \state[3]_i_3__3_n_0 ;
  wire \state[3]_i_4__3_n_0 ;
  wire \state[3]_i_5__3_n_0 ;
  wire \state[3]_i_7__3_n_0 ;
  wire \state[3]_i_8__3_n_0 ;
  wire \state[3]_i_9__3_n_0 ;
  wire \state[4]_i_10__3_n_0 ;
  wire \state[4]_i_11__3_n_0 ;
  wire \state[4]_i_12__3_n_0 ;
  wire \state[4]_i_13__3_n_0 ;
  wire \state[4]_i_16__3_n_0 ;
  wire \state[4]_i_17__3_n_0 ;
  wire \state[4]_i_18__3_n_0 ;
  wire \state[4]_i_20__3_n_0 ;
  wire \state[4]_i_21__3_n_0 ;
  wire \state[4]_i_22__3_n_0 ;
  wire \state[4]_i_23__3_n_0 ;
  wire \state[4]_i_24__3_n_0 ;
  wire \state[4]_i_25__3_n_0 ;
  wire \state[4]_i_26__3_n_0 ;
  wire \state[4]_i_27__3_n_0 ;
  wire \state[4]_i_28__3_n_0 ;
  wire \state[4]_i_29__3_n_0 ;
  wire \state[4]_i_30__3_n_0 ;
  wire \state[4]_i_31__3_n_0 ;
  wire \state[4]_i_32__3_n_0 ;
  wire \state[4]_i_33__3_n_0 ;
  wire \state[4]_i_34__3_n_0 ;
  wire \state[4]_i_35__3_n_0 ;
  wire \state[4]_i_36__3_n_0 ;
  wire \state[4]_i_37__3_n_0 ;
  wire \state[4]_i_38__3_n_0 ;
  wire \state[4]_i_39__3_n_0 ;
  wire \state[4]_i_5__3_n_0 ;
  wire \state[4]_i_6__3_n_0 ;
  wire \state[4]_i_7__3_n_0 ;
  wire [1:0]\state_reg[1]_i_1__3_0 ;
  wire \state_reg[1]_i_1__3_n_2 ;
  wire \state_reg[1]_i_1__3_n_3 ;
  wire \state_reg[1]_i_1__3_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__3_n_2 ;
  wire \state_reg[2]_i_1__3_n_3 ;
  wire \state_reg[2]_i_1__3_n_6 ;
  wire \state_reg[2]_i_1__3_n_7 ;
  wire \state_reg[2]_i_2__3_n_0 ;
  wire \state_reg[2]_i_2__3_n_1 ;
  wire \state_reg[2]_i_2__3_n_2 ;
  wire \state_reg[2]_i_2__3_n_3 ;
  wire \state_reg[2]_i_2__3_n_4 ;
  wire \state_reg[2]_i_2__3_n_5 ;
  wire \state_reg[2]_i_2__3_n_6 ;
  wire \state_reg[2]_i_2__3_n_7 ;
  wire \state_reg[3]_i_1__3_n_2 ;
  wire \state_reg[3]_i_1__3_n_3 ;
  wire \state_reg[3]_i_1__3_n_6 ;
  wire \state_reg[3]_i_1__3_n_7 ;
  wire \state_reg[3]_i_2__3_n_0 ;
  wire \state_reg[3]_i_2__3_n_1 ;
  wire \state_reg[3]_i_2__3_n_2 ;
  wire \state_reg[3]_i_2__3_n_3 ;
  wire \state_reg[3]_i_2__3_n_4 ;
  wire \state_reg[3]_i_2__3_n_5 ;
  wire \state_reg[3]_i_2__3_n_6 ;
  wire \state_reg[3]_i_2__3_n_7 ;
  wire \state_reg[3]_i_6__3_n_0 ;
  wire \state_reg[3]_i_6__3_n_1 ;
  wire \state_reg[3]_i_6__3_n_2 ;
  wire \state_reg[3]_i_6__3_n_3 ;
  wire \state_reg[3]_i_6__3_n_4 ;
  wire \state_reg[3]_i_6__3_n_5 ;
  wire \state_reg[3]_i_6__3_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [1:0]\state_reg[4]_1 ;
  wire [3:0]\state_reg[4]_i_14__3_0 ;
  wire [0:0]\state_reg[4]_i_14__3_1 ;
  wire \state_reg[4]_i_14__3_n_1 ;
  wire \state_reg[4]_i_14__3_n_2 ;
  wire \state_reg[4]_i_14__3_n_3 ;
  wire \state_reg[4]_i_14__3_n_6 ;
  wire \state_reg[4]_i_14__3_n_7 ;
  wire \state_reg[4]_i_15__3_n_0 ;
  wire \state_reg[4]_i_15__3_n_1 ;
  wire \state_reg[4]_i_15__3_n_2 ;
  wire \state_reg[4]_i_15__3_n_3 ;
  wire \state_reg[4]_i_15__3_n_4 ;
  wire \state_reg[4]_i_15__3_n_5 ;
  wire \state_reg[4]_i_15__3_n_6 ;
  wire \state_reg[4]_i_15__3_n_7 ;
  wire \state_reg[4]_i_19__3_n_0 ;
  wire \state_reg[4]_i_19__3_n_1 ;
  wire \state_reg[4]_i_19__3_n_2 ;
  wire \state_reg[4]_i_19__3_n_3 ;
  wire \state_reg[4]_i_19__3_n_4 ;
  wire \state_reg[4]_i_19__3_n_5 ;
  wire \state_reg[4]_i_19__3_n_6 ;
  wire \state_reg[4]_i_1__3_n_2 ;
  wire \state_reg[4]_i_1__3_n_3 ;
  wire \state_reg[4]_i_1__3_n_6 ;
  wire \state_reg[4]_i_1__3_n_7 ;
  wire \state_reg[4]_i_2__3_n_0 ;
  wire \state_reg[4]_i_2__3_n_1 ;
  wire \state_reg[4]_i_2__3_n_2 ;
  wire \state_reg[4]_i_2__3_n_3 ;
  wire \state_reg[4]_i_2__3_n_4 ;
  wire \state_reg[4]_i_2__3_n_5 ;
  wire \state_reg[4]_i_2__3_n_6 ;
  wire \state_reg[4]_i_2__3_n_7 ;
  wire \state_reg[4]_i_3__3_n_1 ;
  wire \state_reg[4]_i_3__3_n_2 ;
  wire \state_reg[4]_i_3__3_n_3 ;
  wire \state_reg[4]_i_3__3_n_6 ;
  wire \state_reg[4]_i_3__3_n_7 ;
  wire \state_reg[4]_i_4__3_n_0 ;
  wire \state_reg[4]_i_4__3_n_1 ;
  wire \state_reg[4]_i_4__3_n_2 ;
  wire \state_reg[4]_i_4__3_n_3 ;
  wire \state_reg[4]_i_4__3_n_4 ;
  wire \state_reg[4]_i_4__3_n_5 ;
  wire \state_reg[4]_i_4__3_n_6 ;
  wire \state_reg[4]_i_4__3_n_7 ;
  wire \state_reg[4]_i_8__3_n_0 ;
  wire \state_reg[4]_i_8__3_n_1 ;
  wire \state_reg[4]_i_8__3_n_2 ;
  wire \state_reg[4]_i_8__3_n_3 ;
  wire \state_reg[4]_i_8__3_n_4 ;
  wire \state_reg[4]_i_8__3_n_5 ;
  wire \state_reg[4]_i_8__3_n_6 ;
  wire \state_reg[4]_i_9__3_n_0 ;
  wire \state_reg[4]_i_9__3_n_1 ;
  wire \state_reg[4]_i_9__3_n_2 ;
  wire \state_reg[4]_i_9__3_n_3 ;
  wire \state_reg[4]_i_9__3_n_4 ;
  wire \state_reg[4]_i_9__3_n_5 ;
  wire \state_reg[4]_i_9__3_n_6 ;
  wire [0:0]NLW_seconds_relay_4__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_4__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__3_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__3_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__3_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__3_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__3_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__3_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__3_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__3_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__3_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__3_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__3
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_4__274_carry__0_i_1
       (.CI(seconds_relay_4__274_carry_i_1_n_0),
        .CO({seconds_relay_4__274_carry__0_i_1_n_0,seconds_relay_4__274_carry__0_i_1_n_1,seconds_relay_4__274_carry__0_i_1_n_2,seconds_relay_4__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__3_n_5 ,\state_reg[2]_i_2__3_n_6 ,\state_reg[2]_i_2__3_n_7 ,seconds_relay_4__274_carry_i_6_n_4}),
        .O(\slv_reg6_reg[1]_0 ),
        .S({seconds_relay_4__274_carry__0_i_6_n_0,seconds_relay_4__274_carry__0_i_7_n_0,seconds_relay_4__274_carry__0_i_8_n_0,seconds_relay_4__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_6
       (.I0(seconds_relay_4[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__3_n_5 ),
        .O(seconds_relay_4__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_7
       (.I0(seconds_relay_4[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__3_n_6 ),
        .O(seconds_relay_4__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_8
       (.I0(seconds_relay_4[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__3_n_7 ),
        .O(seconds_relay_4__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__0_i_9
       (.I0(seconds_relay_4[2]),
        .I1(Q[3]),
        .I2(seconds_relay_4__274_carry_i_6_n_4),
        .O(seconds_relay_4__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__3_n_6 ),
        .O(\state_reg[1]_i_1__3_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__3_0 [0]));
  CARRY4 seconds_relay_4__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_4__274_carry_i_1_n_0,seconds_relay_4__274_carry_i_1_n_1,seconds_relay_4__274_carry_i_1_n_2,seconds_relay_4__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_4[2]),
        .DI({seconds_relay_4__274_carry_i_6_n_5,seconds_relay_4__274_carry_i_6_n_6,seconds_relay_4__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg6_reg[1] ,NLW_seconds_relay_4__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_4__274_carry_i_7_n_0,seconds_relay_4__274_carry_i_8_n_0,seconds_relay_4__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_10
       (.I0(seconds_relay_4[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__3_n_5 ),
        .O(seconds_relay_4__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_11
       (.I0(seconds_relay_4[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__3_n_6 ),
        .O(seconds_relay_4__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_12
       (.I0(seconds_relay_4[3]),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[1]),
        .O(seconds_relay_4__274_carry_i_12_n_0));
  CARRY4 seconds_relay_4__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_4__274_carry_i_6_n_0,seconds_relay_4__274_carry_i_6_n_1,seconds_relay_4__274_carry_i_6_n_2,seconds_relay_4__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_4[3]),
        .DI({\state_reg[3]_i_6__3_n_5 ,\state_reg[3]_i_6__3_n_6 ,seconds_relay_4__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_4__274_carry_i_6_n_4,seconds_relay_4__274_carry_i_6_n_5,seconds_relay_4__274_carry_i_6_n_6,NLW_seconds_relay_4__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_4__274_carry_i_10_n_0,seconds_relay_4__274_carry_i_11_n_0,seconds_relay_4__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_7
       (.I0(seconds_relay_4[2]),
        .I1(Q[2]),
        .I2(seconds_relay_4__274_carry_i_6_n_5),
        .O(seconds_relay_4__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_8
       (.I0(seconds_relay_4[2]),
        .I1(Q[1]),
        .I2(seconds_relay_4__274_carry_i_6_n_6),
        .O(seconds_relay_4__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_4__274_carry_i_9
       (.I0(seconds_relay_4[2]),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[0]),
        .O(seconds_relay_4__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_4__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_4__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_4__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_4__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_4__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_4__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_4__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__3 
       (.I0(seconds_relay_4[2]),
        .I1(\state_reg[2]_i_1__3_n_6 ),
        .O(\state[1]_i_2__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__3 
       (.I0(seconds_relay_4[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__3_n_7 ),
        .O(\state[1]_i_3__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__3 
       (.I0(seconds_relay_4[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__3_n_4 ),
        .O(\state[1]_i_4__3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__3 
       (.I0(seconds_relay_4[3]),
        .I1(\state_reg[3]_i_1__3_n_6 ),
        .O(\state[2]_i_3__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__3_n_7 ),
        .O(\state[2]_i_4__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__3_n_4 ),
        .O(\state[2]_i_5__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__3_n_5 ),
        .O(\state[2]_i_6__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__3_n_6 ),
        .O(\state[2]_i_7__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__3_n_7 ),
        .O(\state[2]_i_8__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__3 
       (.I0(seconds_relay_4[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__3_n_4 ),
        .O(\state[2]_i_9__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__3_n_4 ),
        .O(\state[3]_i_10__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__3_n_5 ),
        .O(\state[3]_i_11__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__3_n_6 ),
        .O(\state[3]_i_12__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__3 
       (.I0(seconds_relay_4[4]),
        .I1(\state_reg[4]_i_1__3_n_6 ),
        .O(\state[3]_i_3__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__3_n_7 ),
        .O(\state[3]_i_4__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__3_n_4 ),
        .O(\state[3]_i_5__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__3_n_5 ),
        .O(\state[3]_i_7__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__3_n_6 ),
        .O(\state[3]_i_8__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__3 
       (.I0(seconds_relay_4[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__3_n_7 ),
        .O(\state[3]_i_9__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__3_n_5 ),
        .O(\state[4]_i_10__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__3_n_6 ),
        .O(\state[4]_i_11__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__3_n_7 ),
        .O(\state[4]_i_12__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__3_n_4 ),
        .O(\state[4]_i_13__3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(\state_reg[4]_i_14__3_n_6 ),
        .O(\state[4]_i_16__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__3_n_7 ),
        .O(\state[4]_i_17__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__3_n_4 ),
        .O(\state[4]_i_18__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__3_n_5 ),
        .O(\state[4]_i_20__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__3_n_6 ),
        .O(\state[4]_i_21__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__3_n_7 ),
        .O(\state[4]_i_22__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__3_n_4 ),
        .O(\state[4]_i_23__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__3_n_5 ),
        .O(\state[4]_i_24__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__3_n_6 ),
        .O(\state[4]_i_25__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__3_n_5 ),
        .O(\state[4]_i_27__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__3_n_6 ),
        .O(\state[4]_i_28__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__3 
       (.I0(\state_reg[4]_i_14__3_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__3 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__3_1 ),
        .O(\state[4]_i_30__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__3 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__3_0 [3]),
        .O(\state[4]_i_31__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__3 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__3_0 [2]),
        .O(\state[4]_i_32__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__3 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__3_0 [1]),
        .O(\state[4]_i_33__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__3 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__3_0 [0]),
        .O(\state[4]_i_34__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__3 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__3 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__3 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__3 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__3 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_4__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(\state_reg[4]_i_3__3_n_6 ),
        .O(\state[4]_i_5__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__3_n_7 ),
        .O(\state[4]_i_6__3_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__3 
       (.I0(\state_reg[4]_i_3__3_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__3_n_4 ),
        .O(\state[4]_i_7__3_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[4]_1 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[1]_i_1__3 
       (.CI(seconds_relay_4__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__3_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__3_n_2 ,\state_reg[1]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_4[2],\state_reg[2]_i_1__3_n_7 ,\state_reg[2]_i_2__3_n_4 }),
        .O({\NLW_state_reg[1]_i_1__3_O_UNCONNECTED [3:2],\state_reg[1]_i_1__3_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__3_n_0 ,\state[1]_i_3__3_n_0 ,\state[1]_i_4__3_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_4[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[2]_i_1__3 
       (.CI(\state_reg[2]_i_2__3_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__3_CO_UNCONNECTED [3],seconds_relay_4[2],\state_reg[2]_i_1__3_n_2 ,\state_reg[2]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_4[3],\state_reg[3]_i_1__3_n_7 ,\state_reg[3]_i_2__3_n_4 }),
        .O({\NLW_state_reg[2]_i_1__3_O_UNCONNECTED [3:2],\state_reg[2]_i_1__3_n_6 ,\state_reg[2]_i_1__3_n_7 }),
        .S({1'b0,\state[2]_i_3__3_n_0 ,\state[2]_i_4__3_n_0 ,\state[2]_i_5__3_n_0 }));
  CARRY4 \state_reg[2]_i_2__3 
       (.CI(seconds_relay_4__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__3_n_0 ,\state_reg[2]_i_2__3_n_1 ,\state_reg[2]_i_2__3_n_2 ,\state_reg[2]_i_2__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__3_n_5 ,\state_reg[3]_i_2__3_n_6 ,\state_reg[3]_i_2__3_n_7 ,\state_reg[3]_i_6__3_n_4 }),
        .O({\state_reg[2]_i_2__3_n_4 ,\state_reg[2]_i_2__3_n_5 ,\state_reg[2]_i_2__3_n_6 ,\state_reg[2]_i_2__3_n_7 }),
        .S({\state[2]_i_6__3_n_0 ,\state[2]_i_7__3_n_0 ,\state[2]_i_8__3_n_0 ,\state[2]_i_9__3_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_4[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[3]_i_1__3 
       (.CI(\state_reg[3]_i_2__3_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__3_CO_UNCONNECTED [3],seconds_relay_4[3],\state_reg[3]_i_1__3_n_2 ,\state_reg[3]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_4[4],\state_reg[4]_i_1__3_n_7 ,\state_reg[4]_i_2__3_n_4 }),
        .O({\NLW_state_reg[3]_i_1__3_O_UNCONNECTED [3:2],\state_reg[3]_i_1__3_n_6 ,\state_reg[3]_i_1__3_n_7 }),
        .S({1'b0,\state[3]_i_3__3_n_0 ,\state[3]_i_4__3_n_0 ,\state[3]_i_5__3_n_0 }));
  CARRY4 \state_reg[3]_i_2__3 
       (.CI(\state_reg[3]_i_6__3_n_0 ),
        .CO({\state_reg[3]_i_2__3_n_0 ,\state_reg[3]_i_2__3_n_1 ,\state_reg[3]_i_2__3_n_2 ,\state_reg[3]_i_2__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__3_n_5 ,\state_reg[4]_i_2__3_n_6 ,\state_reg[4]_i_2__3_n_7 ,\state_reg[4]_i_8__3_n_4 }),
        .O({\state_reg[3]_i_2__3_n_4 ,\state_reg[3]_i_2__3_n_5 ,\state_reg[3]_i_2__3_n_6 ,\state_reg[3]_i_2__3_n_7 }),
        .S({\state[3]_i_7__3_n_0 ,\state[3]_i_8__3_n_0 ,\state[3]_i_9__3_n_0 ,\state[3]_i_10__3_n_0 }));
  CARRY4 \state_reg[3]_i_6__3 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__3_n_0 ,\state_reg[3]_i_6__3_n_1 ,\state_reg[3]_i_6__3_n_2 ,\state_reg[3]_i_6__3_n_3 }),
        .CYINIT(seconds_relay_4[4]),
        .DI({\state_reg[4]_i_8__3_n_5 ,\state_reg[4]_i_8__3_n_6 ,seconds_relay_4__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__3_n_4 ,\state_reg[3]_i_6__3_n_5 ,\state_reg[3]_i_6__3_n_6 ,\NLW_state_reg[3]_i_6__3_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__3_n_0 ,\state[3]_i_12__3_n_0 ,\state[3]_i_13__3_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_4[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[4]_i_14__3 
       (.CI(\state_reg[4]_i_15__3_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__3_CO_UNCONNECTED [3],\state_reg[4]_i_14__3_n_1 ,\state_reg[4]_i_14__3_n_2 ,\state_reg[4]_i_14__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__3_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__3_O_UNCONNECTED [3:2],\state_reg[4]_i_14__3_n_6 ,\state_reg[4]_i_14__3_n_7 }),
        .S({1'b0,\state[4]_i_30__3_n_0 ,\state[4]_i_31__3_n_0 ,\state[4]_i_32__3_n_0 }));
  CARRY4 \state_reg[4]_i_15__3 
       (.CI(\state_reg[4]_i_19__3_n_0 ),
        .CO({\state_reg[4]_i_15__3_n_0 ,\state_reg[4]_i_15__3_n_1 ,\state_reg[4]_i_15__3_n_2 ,\state_reg[4]_i_15__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__3_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__3_n_4 ,\state_reg[4]_i_15__3_n_5 ,\state_reg[4]_i_15__3_n_6 ,\state_reg[4]_i_15__3_n_7 }),
        .S({\state[4]_i_33__3_n_0 ,\state[4]_i_34__3_n_0 ,\state[4]_i_35__3_n_0 ,\state[4]_i_36__3_n_0 }));
  CARRY4 \state_reg[4]_i_19__3 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__3_n_0 ,\state_reg[4]_i_19__3_n_1 ,\state_reg[4]_i_19__3_n_2 ,\state_reg[4]_i_19__3_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_4__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__3_n_4 ,\state_reg[4]_i_19__3_n_5 ,\state_reg[4]_i_19__3_n_6 ,\NLW_state_reg[4]_i_19__3_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__3_n_0 ,\state[4]_i_38__3_n_0 ,\state[4]_i_39__3_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__3 
       (.CI(\state_reg[4]_i_2__3_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__3_CO_UNCONNECTED [3],seconds_relay_4[4],\state_reg[4]_i_1__3_n_2 ,\state_reg[4]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__3_n_1 ,\state_reg[4]_i_3__3_n_7 ,\state_reg[4]_i_4__3_n_4 }),
        .O({\NLW_state_reg[4]_i_1__3_O_UNCONNECTED [3:2],\state_reg[4]_i_1__3_n_6 ,\state_reg[4]_i_1__3_n_7 }),
        .S({1'b0,\state[4]_i_5__3_n_0 ,\state[4]_i_6__3_n_0 ,\state[4]_i_7__3_n_0 }));
  CARRY4 \state_reg[4]_i_2__3 
       (.CI(\state_reg[4]_i_8__3_n_0 ),
        .CO({\state_reg[4]_i_2__3_n_0 ,\state_reg[4]_i_2__3_n_1 ,\state_reg[4]_i_2__3_n_2 ,\state_reg[4]_i_2__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__3_n_5 ,\state_reg[4]_i_4__3_n_6 ,\state_reg[4]_i_4__3_n_7 ,\state_reg[4]_i_9__3_n_4 }),
        .O({\state_reg[4]_i_2__3_n_4 ,\state_reg[4]_i_2__3_n_5 ,\state_reg[4]_i_2__3_n_6 ,\state_reg[4]_i_2__3_n_7 }),
        .S({\state[4]_i_10__3_n_0 ,\state[4]_i_11__3_n_0 ,\state[4]_i_12__3_n_0 ,\state[4]_i_13__3_n_0 }));
  CARRY4 \state_reg[4]_i_3__3 
       (.CI(\state_reg[4]_i_4__3_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__3_CO_UNCONNECTED [3],\state_reg[4]_i_3__3_n_1 ,\state_reg[4]_i_3__3_n_2 ,\state_reg[4]_i_3__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__3_n_1 ,\state_reg[4]_i_14__3_n_7 ,\state_reg[4]_i_15__3_n_4 }),
        .O({\NLW_state_reg[4]_i_3__3_O_UNCONNECTED [3:2],\state_reg[4]_i_3__3_n_6 ,\state_reg[4]_i_3__3_n_7 }),
        .S({1'b0,\state[4]_i_16__3_n_0 ,\state[4]_i_17__3_n_0 ,\state[4]_i_18__3_n_0 }));
  CARRY4 \state_reg[4]_i_4__3 
       (.CI(\state_reg[4]_i_9__3_n_0 ),
        .CO({\state_reg[4]_i_4__3_n_0 ,\state_reg[4]_i_4__3_n_1 ,\state_reg[4]_i_4__3_n_2 ,\state_reg[4]_i_4__3_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__3_n_5 ,\state_reg[4]_i_15__3_n_6 ,\state_reg[4]_i_15__3_n_7 ,\state_reg[4]_i_19__3_n_4 }),
        .O({\state_reg[4]_i_4__3_n_4 ,\state_reg[4]_i_4__3_n_5 ,\state_reg[4]_i_4__3_n_6 ,\state_reg[4]_i_4__3_n_7 }),
        .S({\state[4]_i_20__3_n_0 ,\state[4]_i_21__3_n_0 ,\state[4]_i_22__3_n_0 ,\state[4]_i_23__3_n_0 }));
  CARRY4 \state_reg[4]_i_8__3 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__3_n_0 ,\state_reg[4]_i_8__3_n_1 ,\state_reg[4]_i_8__3_n_2 ,\state_reg[4]_i_8__3_n_3 }),
        .CYINIT(\state_reg[4]_i_3__3_n_1 ),
        .DI({\state_reg[4]_i_9__3_n_5 ,\state_reg[4]_i_9__3_n_6 ,seconds_relay_4__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__3_n_4 ,\state_reg[4]_i_8__3_n_5 ,\state_reg[4]_i_8__3_n_6 ,\NLW_state_reg[4]_i_8__3_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__3_n_0 ,\state[4]_i_25__3_n_0 ,\state[4]_i_26__3_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__3 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__3_n_0 ,\state_reg[4]_i_9__3_n_1 ,\state_reg[4]_i_9__3_n_2 ,\state_reg[4]_i_9__3_n_3 }),
        .CYINIT(\state_reg[4]_i_14__3_n_1 ),
        .DI({\state_reg[4]_i_19__3_n_5 ,\state_reg[4]_i_19__3_n_6 ,seconds_relay_4__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__3_n_4 ,\state_reg[4]_i_9__3_n_5 ,\state_reg[4]_i_9__3_n_6 ,\NLW_state_reg[4]_i_9__3_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__3_n_0 ,\state[4]_i_28__3_n_0 ,\state[4]_i_29__3_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_4
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg7_reg[1] ,
    \slv_reg7_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__4_0 ,
    Q,
    seconds_relay_5__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__4_0 ,
    D,
    \state_reg[4]_i_14__4_1 ,
    \state_reg[0]_0 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg7_reg[1] ;
  output [3:0]\slv_reg7_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__4_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_5__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__4_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__4_1 ;
  input [1:0]\state_reg[0]_0 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_5;
  wire seconds_relay_5__274_carry__0_i_1_n_0;
  wire seconds_relay_5__274_carry__0_i_1_n_1;
  wire seconds_relay_5__274_carry__0_i_1_n_2;
  wire seconds_relay_5__274_carry__0_i_1_n_3;
  wire seconds_relay_5__274_carry__0_i_6_n_0;
  wire seconds_relay_5__274_carry__0_i_7_n_0;
  wire seconds_relay_5__274_carry__0_i_8_n_0;
  wire seconds_relay_5__274_carry__0_i_9_n_0;
  wire seconds_relay_5__274_carry_i_10_n_0;
  wire seconds_relay_5__274_carry_i_11_n_0;
  wire seconds_relay_5__274_carry_i_12_n_0;
  wire seconds_relay_5__274_carry_i_1_n_0;
  wire seconds_relay_5__274_carry_i_1_n_1;
  wire seconds_relay_5__274_carry_i_1_n_2;
  wire seconds_relay_5__274_carry_i_1_n_3;
  wire seconds_relay_5__274_carry_i_6_n_0;
  wire seconds_relay_5__274_carry_i_6_n_1;
  wire seconds_relay_5__274_carry_i_6_n_2;
  wire seconds_relay_5__274_carry_i_6_n_3;
  wire seconds_relay_5__274_carry_i_6_n_4;
  wire seconds_relay_5__274_carry_i_6_n_5;
  wire seconds_relay_5__274_carry_i_6_n_6;
  wire seconds_relay_5__274_carry_i_7_n_0;
  wire seconds_relay_5__274_carry_i_8_n_0;
  wire seconds_relay_5__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_5__8_carry__0_i_6;
  wire [2:0]\slv_reg7_reg[1] ;
  wire [3:0]\slv_reg7_reg[1]_0 ;
  wire \state[1]_i_2__4_n_0 ;
  wire \state[1]_i_3__4_n_0 ;
  wire \state[1]_i_4__4_n_0 ;
  wire \state[2]_i_3__4_n_0 ;
  wire \state[2]_i_4__4_n_0 ;
  wire \state[2]_i_5__4_n_0 ;
  wire \state[2]_i_6__4_n_0 ;
  wire \state[2]_i_7__4_n_0 ;
  wire \state[2]_i_8__4_n_0 ;
  wire \state[2]_i_9__4_n_0 ;
  wire \state[3]_i_10__4_n_0 ;
  wire \state[3]_i_11__4_n_0 ;
  wire \state[3]_i_12__4_n_0 ;
  wire \state[3]_i_13__4_n_0 ;
  wire \state[3]_i_3__4_n_0 ;
  wire \state[3]_i_4__4_n_0 ;
  wire \state[3]_i_5__4_n_0 ;
  wire \state[3]_i_7__4_n_0 ;
  wire \state[3]_i_8__4_n_0 ;
  wire \state[3]_i_9__4_n_0 ;
  wire \state[4]_i_10__4_n_0 ;
  wire \state[4]_i_11__4_n_0 ;
  wire \state[4]_i_12__4_n_0 ;
  wire \state[4]_i_13__4_n_0 ;
  wire \state[4]_i_16__4_n_0 ;
  wire \state[4]_i_17__4_n_0 ;
  wire \state[4]_i_18__4_n_0 ;
  wire \state[4]_i_20__4_n_0 ;
  wire \state[4]_i_21__4_n_0 ;
  wire \state[4]_i_22__4_n_0 ;
  wire \state[4]_i_23__4_n_0 ;
  wire \state[4]_i_24__4_n_0 ;
  wire \state[4]_i_25__4_n_0 ;
  wire \state[4]_i_26__4_n_0 ;
  wire \state[4]_i_27__4_n_0 ;
  wire \state[4]_i_28__4_n_0 ;
  wire \state[4]_i_29__4_n_0 ;
  wire \state[4]_i_30__4_n_0 ;
  wire \state[4]_i_31__4_n_0 ;
  wire \state[4]_i_32__4_n_0 ;
  wire \state[4]_i_33__4_n_0 ;
  wire \state[4]_i_34__4_n_0 ;
  wire \state[4]_i_35__4_n_0 ;
  wire \state[4]_i_36__4_n_0 ;
  wire \state[4]_i_37__4_n_0 ;
  wire \state[4]_i_38__4_n_0 ;
  wire \state[4]_i_39__4_n_0 ;
  wire \state[4]_i_5__4_n_0 ;
  wire \state[4]_i_6__4_n_0 ;
  wire \state[4]_i_7__4_n_0 ;
  wire [1:0]\state_reg[0]_0 ;
  wire [1:0]\state_reg[1]_i_1__4_0 ;
  wire \state_reg[1]_i_1__4_n_2 ;
  wire \state_reg[1]_i_1__4_n_3 ;
  wire \state_reg[1]_i_1__4_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__4_n_2 ;
  wire \state_reg[2]_i_1__4_n_3 ;
  wire \state_reg[2]_i_1__4_n_6 ;
  wire \state_reg[2]_i_1__4_n_7 ;
  wire \state_reg[2]_i_2__4_n_0 ;
  wire \state_reg[2]_i_2__4_n_1 ;
  wire \state_reg[2]_i_2__4_n_2 ;
  wire \state_reg[2]_i_2__4_n_3 ;
  wire \state_reg[2]_i_2__4_n_4 ;
  wire \state_reg[2]_i_2__4_n_5 ;
  wire \state_reg[2]_i_2__4_n_6 ;
  wire \state_reg[2]_i_2__4_n_7 ;
  wire \state_reg[3]_i_1__4_n_2 ;
  wire \state_reg[3]_i_1__4_n_3 ;
  wire \state_reg[3]_i_1__4_n_6 ;
  wire \state_reg[3]_i_1__4_n_7 ;
  wire \state_reg[3]_i_2__4_n_0 ;
  wire \state_reg[3]_i_2__4_n_1 ;
  wire \state_reg[3]_i_2__4_n_2 ;
  wire \state_reg[3]_i_2__4_n_3 ;
  wire \state_reg[3]_i_2__4_n_4 ;
  wire \state_reg[3]_i_2__4_n_5 ;
  wire \state_reg[3]_i_2__4_n_6 ;
  wire \state_reg[3]_i_2__4_n_7 ;
  wire \state_reg[3]_i_6__4_n_0 ;
  wire \state_reg[3]_i_6__4_n_1 ;
  wire \state_reg[3]_i_6__4_n_2 ;
  wire \state_reg[3]_i_6__4_n_3 ;
  wire \state_reg[3]_i_6__4_n_4 ;
  wire \state_reg[3]_i_6__4_n_5 ;
  wire \state_reg[3]_i_6__4_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [3:0]\state_reg[4]_i_14__4_0 ;
  wire [0:0]\state_reg[4]_i_14__4_1 ;
  wire \state_reg[4]_i_14__4_n_1 ;
  wire \state_reg[4]_i_14__4_n_2 ;
  wire \state_reg[4]_i_14__4_n_3 ;
  wire \state_reg[4]_i_14__4_n_6 ;
  wire \state_reg[4]_i_14__4_n_7 ;
  wire \state_reg[4]_i_15__4_n_0 ;
  wire \state_reg[4]_i_15__4_n_1 ;
  wire \state_reg[4]_i_15__4_n_2 ;
  wire \state_reg[4]_i_15__4_n_3 ;
  wire \state_reg[4]_i_15__4_n_4 ;
  wire \state_reg[4]_i_15__4_n_5 ;
  wire \state_reg[4]_i_15__4_n_6 ;
  wire \state_reg[4]_i_15__4_n_7 ;
  wire \state_reg[4]_i_19__4_n_0 ;
  wire \state_reg[4]_i_19__4_n_1 ;
  wire \state_reg[4]_i_19__4_n_2 ;
  wire \state_reg[4]_i_19__4_n_3 ;
  wire \state_reg[4]_i_19__4_n_4 ;
  wire \state_reg[4]_i_19__4_n_5 ;
  wire \state_reg[4]_i_19__4_n_6 ;
  wire \state_reg[4]_i_1__4_n_2 ;
  wire \state_reg[4]_i_1__4_n_3 ;
  wire \state_reg[4]_i_1__4_n_6 ;
  wire \state_reg[4]_i_1__4_n_7 ;
  wire \state_reg[4]_i_2__4_n_0 ;
  wire \state_reg[4]_i_2__4_n_1 ;
  wire \state_reg[4]_i_2__4_n_2 ;
  wire \state_reg[4]_i_2__4_n_3 ;
  wire \state_reg[4]_i_2__4_n_4 ;
  wire \state_reg[4]_i_2__4_n_5 ;
  wire \state_reg[4]_i_2__4_n_6 ;
  wire \state_reg[4]_i_2__4_n_7 ;
  wire \state_reg[4]_i_3__4_n_1 ;
  wire \state_reg[4]_i_3__4_n_2 ;
  wire \state_reg[4]_i_3__4_n_3 ;
  wire \state_reg[4]_i_3__4_n_6 ;
  wire \state_reg[4]_i_3__4_n_7 ;
  wire \state_reg[4]_i_4__4_n_0 ;
  wire \state_reg[4]_i_4__4_n_1 ;
  wire \state_reg[4]_i_4__4_n_2 ;
  wire \state_reg[4]_i_4__4_n_3 ;
  wire \state_reg[4]_i_4__4_n_4 ;
  wire \state_reg[4]_i_4__4_n_5 ;
  wire \state_reg[4]_i_4__4_n_6 ;
  wire \state_reg[4]_i_4__4_n_7 ;
  wire \state_reg[4]_i_8__4_n_0 ;
  wire \state_reg[4]_i_8__4_n_1 ;
  wire \state_reg[4]_i_8__4_n_2 ;
  wire \state_reg[4]_i_8__4_n_3 ;
  wire \state_reg[4]_i_8__4_n_4 ;
  wire \state_reg[4]_i_8__4_n_5 ;
  wire \state_reg[4]_i_8__4_n_6 ;
  wire \state_reg[4]_i_9__4_n_0 ;
  wire \state_reg[4]_i_9__4_n_1 ;
  wire \state_reg[4]_i_9__4_n_2 ;
  wire \state_reg[4]_i_9__4_n_3 ;
  wire \state_reg[4]_i_9__4_n_4 ;
  wire \state_reg[4]_i_9__4_n_5 ;
  wire \state_reg[4]_i_9__4_n_6 ;
  wire [0:0]NLW_seconds_relay_5__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_5__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__4_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__4_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__4_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__4_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__4_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__4_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__4_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__4_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__4_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__4_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__4
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_5__274_carry__0_i_1
       (.CI(seconds_relay_5__274_carry_i_1_n_0),
        .CO({seconds_relay_5__274_carry__0_i_1_n_0,seconds_relay_5__274_carry__0_i_1_n_1,seconds_relay_5__274_carry__0_i_1_n_2,seconds_relay_5__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__4_n_5 ,\state_reg[2]_i_2__4_n_6 ,\state_reg[2]_i_2__4_n_7 ,seconds_relay_5__274_carry_i_6_n_4}),
        .O(\slv_reg7_reg[1]_0 ),
        .S({seconds_relay_5__274_carry__0_i_6_n_0,seconds_relay_5__274_carry__0_i_7_n_0,seconds_relay_5__274_carry__0_i_8_n_0,seconds_relay_5__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_6
       (.I0(seconds_relay_5[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__4_n_5 ),
        .O(seconds_relay_5__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_7
       (.I0(seconds_relay_5[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__4_n_6 ),
        .O(seconds_relay_5__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_8
       (.I0(seconds_relay_5[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__4_n_7 ),
        .O(seconds_relay_5__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__0_i_9
       (.I0(seconds_relay_5[2]),
        .I1(Q[3]),
        .I2(seconds_relay_5__274_carry_i_6_n_4),
        .O(seconds_relay_5__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__4_n_6 ),
        .O(\state_reg[1]_i_1__4_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__4_0 [0]));
  CARRY4 seconds_relay_5__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_5__274_carry_i_1_n_0,seconds_relay_5__274_carry_i_1_n_1,seconds_relay_5__274_carry_i_1_n_2,seconds_relay_5__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_5[2]),
        .DI({seconds_relay_5__274_carry_i_6_n_5,seconds_relay_5__274_carry_i_6_n_6,seconds_relay_5__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg7_reg[1] ,NLW_seconds_relay_5__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_5__274_carry_i_7_n_0,seconds_relay_5__274_carry_i_8_n_0,seconds_relay_5__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_10
       (.I0(seconds_relay_5[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__4_n_5 ),
        .O(seconds_relay_5__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_11
       (.I0(seconds_relay_5[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__4_n_6 ),
        .O(seconds_relay_5__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_12
       (.I0(seconds_relay_5[3]),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[1]),
        .O(seconds_relay_5__274_carry_i_12_n_0));
  CARRY4 seconds_relay_5__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_5__274_carry_i_6_n_0,seconds_relay_5__274_carry_i_6_n_1,seconds_relay_5__274_carry_i_6_n_2,seconds_relay_5__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_5[3]),
        .DI({\state_reg[3]_i_6__4_n_5 ,\state_reg[3]_i_6__4_n_6 ,seconds_relay_5__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_5__274_carry_i_6_n_4,seconds_relay_5__274_carry_i_6_n_5,seconds_relay_5__274_carry_i_6_n_6,NLW_seconds_relay_5__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_5__274_carry_i_10_n_0,seconds_relay_5__274_carry_i_11_n_0,seconds_relay_5__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_7
       (.I0(seconds_relay_5[2]),
        .I1(Q[2]),
        .I2(seconds_relay_5__274_carry_i_6_n_5),
        .O(seconds_relay_5__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_8
       (.I0(seconds_relay_5[2]),
        .I1(Q[1]),
        .I2(seconds_relay_5__274_carry_i_6_n_6),
        .O(seconds_relay_5__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_5__274_carry_i_9
       (.I0(seconds_relay_5[2]),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[0]),
        .O(seconds_relay_5__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_5__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_5__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_5__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_5__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_5__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_5__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_5__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__4 
       (.I0(seconds_relay_5[2]),
        .I1(\state_reg[2]_i_1__4_n_6 ),
        .O(\state[1]_i_2__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__4 
       (.I0(seconds_relay_5[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__4_n_7 ),
        .O(\state[1]_i_3__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__4 
       (.I0(seconds_relay_5[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__4_n_4 ),
        .O(\state[1]_i_4__4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__4 
       (.I0(seconds_relay_5[3]),
        .I1(\state_reg[3]_i_1__4_n_6 ),
        .O(\state[2]_i_3__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__4_n_7 ),
        .O(\state[2]_i_4__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__4_n_4 ),
        .O(\state[2]_i_5__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__4_n_5 ),
        .O(\state[2]_i_6__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__4_n_6 ),
        .O(\state[2]_i_7__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__4_n_7 ),
        .O(\state[2]_i_8__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__4 
       (.I0(seconds_relay_5[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__4_n_4 ),
        .O(\state[2]_i_9__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__4_n_4 ),
        .O(\state[3]_i_10__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__4_n_5 ),
        .O(\state[3]_i_11__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__4_n_6 ),
        .O(\state[3]_i_12__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__4 
       (.I0(seconds_relay_5[4]),
        .I1(\state_reg[4]_i_1__4_n_6 ),
        .O(\state[3]_i_3__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__4_n_7 ),
        .O(\state[3]_i_4__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__4_n_4 ),
        .O(\state[3]_i_5__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__4_n_5 ),
        .O(\state[3]_i_7__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__4_n_6 ),
        .O(\state[3]_i_8__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__4 
       (.I0(seconds_relay_5[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__4_n_7 ),
        .O(\state[3]_i_9__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__4_n_5 ),
        .O(\state[4]_i_10__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__4_n_6 ),
        .O(\state[4]_i_11__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__4_n_7 ),
        .O(\state[4]_i_12__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__4_n_4 ),
        .O(\state[4]_i_13__4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(\state_reg[4]_i_14__4_n_6 ),
        .O(\state[4]_i_16__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__4_n_7 ),
        .O(\state[4]_i_17__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__4_n_4 ),
        .O(\state[4]_i_18__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__4_n_5 ),
        .O(\state[4]_i_20__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__4_n_6 ),
        .O(\state[4]_i_21__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__4_n_7 ),
        .O(\state[4]_i_22__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__4_n_4 ),
        .O(\state[4]_i_23__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__4_n_5 ),
        .O(\state[4]_i_24__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__4_n_6 ),
        .O(\state[4]_i_25__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__4_n_5 ),
        .O(\state[4]_i_27__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__4_n_6 ),
        .O(\state[4]_i_28__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__4 
       (.I0(\state_reg[4]_i_14__4_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__4 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__4_1 ),
        .O(\state[4]_i_30__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__4 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__4_0 [3]),
        .O(\state[4]_i_31__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__4 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__4_0 [2]),
        .O(\state[4]_i_32__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__4 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__4_0 [1]),
        .O(\state[4]_i_33__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__4 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__4_0 [0]),
        .O(\state[4]_i_34__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__4 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__4 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__4 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__4 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__4 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_5__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(\state_reg[4]_i_3__4_n_6 ),
        .O(\state[4]_i_5__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__4_n_7 ),
        .O(\state[4]_i_6__4_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__4 
       (.I0(\state_reg[4]_i_3__4_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__4_n_4 ),
        .O(\state[4]_i_7__4_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[0]_0 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[1]_i_1__4 
       (.CI(seconds_relay_5__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__4_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__4_n_2 ,\state_reg[1]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_5[2],\state_reg[2]_i_1__4_n_7 ,\state_reg[2]_i_2__4_n_4 }),
        .O({\NLW_state_reg[1]_i_1__4_O_UNCONNECTED [3:2],\state_reg[1]_i_1__4_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__4_n_0 ,\state[1]_i_3__4_n_0 ,\state[1]_i_4__4_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_5[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[2]_i_1__4 
       (.CI(\state_reg[2]_i_2__4_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__4_CO_UNCONNECTED [3],seconds_relay_5[2],\state_reg[2]_i_1__4_n_2 ,\state_reg[2]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_5[3],\state_reg[3]_i_1__4_n_7 ,\state_reg[3]_i_2__4_n_4 }),
        .O({\NLW_state_reg[2]_i_1__4_O_UNCONNECTED [3:2],\state_reg[2]_i_1__4_n_6 ,\state_reg[2]_i_1__4_n_7 }),
        .S({1'b0,\state[2]_i_3__4_n_0 ,\state[2]_i_4__4_n_0 ,\state[2]_i_5__4_n_0 }));
  CARRY4 \state_reg[2]_i_2__4 
       (.CI(seconds_relay_5__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__4_n_0 ,\state_reg[2]_i_2__4_n_1 ,\state_reg[2]_i_2__4_n_2 ,\state_reg[2]_i_2__4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__4_n_5 ,\state_reg[3]_i_2__4_n_6 ,\state_reg[3]_i_2__4_n_7 ,\state_reg[3]_i_6__4_n_4 }),
        .O({\state_reg[2]_i_2__4_n_4 ,\state_reg[2]_i_2__4_n_5 ,\state_reg[2]_i_2__4_n_6 ,\state_reg[2]_i_2__4_n_7 }),
        .S({\state[2]_i_6__4_n_0 ,\state[2]_i_7__4_n_0 ,\state[2]_i_8__4_n_0 ,\state[2]_i_9__4_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_5[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[3]_i_1__4 
       (.CI(\state_reg[3]_i_2__4_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__4_CO_UNCONNECTED [3],seconds_relay_5[3],\state_reg[3]_i_1__4_n_2 ,\state_reg[3]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_5[4],\state_reg[4]_i_1__4_n_7 ,\state_reg[4]_i_2__4_n_4 }),
        .O({\NLW_state_reg[3]_i_1__4_O_UNCONNECTED [3:2],\state_reg[3]_i_1__4_n_6 ,\state_reg[3]_i_1__4_n_7 }),
        .S({1'b0,\state[3]_i_3__4_n_0 ,\state[3]_i_4__4_n_0 ,\state[3]_i_5__4_n_0 }));
  CARRY4 \state_reg[3]_i_2__4 
       (.CI(\state_reg[3]_i_6__4_n_0 ),
        .CO({\state_reg[3]_i_2__4_n_0 ,\state_reg[3]_i_2__4_n_1 ,\state_reg[3]_i_2__4_n_2 ,\state_reg[3]_i_2__4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__4_n_5 ,\state_reg[4]_i_2__4_n_6 ,\state_reg[4]_i_2__4_n_7 ,\state_reg[4]_i_8__4_n_4 }),
        .O({\state_reg[3]_i_2__4_n_4 ,\state_reg[3]_i_2__4_n_5 ,\state_reg[3]_i_2__4_n_6 ,\state_reg[3]_i_2__4_n_7 }),
        .S({\state[3]_i_7__4_n_0 ,\state[3]_i_8__4_n_0 ,\state[3]_i_9__4_n_0 ,\state[3]_i_10__4_n_0 }));
  CARRY4 \state_reg[3]_i_6__4 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__4_n_0 ,\state_reg[3]_i_6__4_n_1 ,\state_reg[3]_i_6__4_n_2 ,\state_reg[3]_i_6__4_n_3 }),
        .CYINIT(seconds_relay_5[4]),
        .DI({\state_reg[4]_i_8__4_n_5 ,\state_reg[4]_i_8__4_n_6 ,seconds_relay_5__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__4_n_4 ,\state_reg[3]_i_6__4_n_5 ,\state_reg[3]_i_6__4_n_6 ,\NLW_state_reg[3]_i_6__4_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__4_n_0 ,\state[3]_i_12__4_n_0 ,\state[3]_i_13__4_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_5[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[4]_i_14__4 
       (.CI(\state_reg[4]_i_15__4_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__4_CO_UNCONNECTED [3],\state_reg[4]_i_14__4_n_1 ,\state_reg[4]_i_14__4_n_2 ,\state_reg[4]_i_14__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__4_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__4_O_UNCONNECTED [3:2],\state_reg[4]_i_14__4_n_6 ,\state_reg[4]_i_14__4_n_7 }),
        .S({1'b0,\state[4]_i_30__4_n_0 ,\state[4]_i_31__4_n_0 ,\state[4]_i_32__4_n_0 }));
  CARRY4 \state_reg[4]_i_15__4 
       (.CI(\state_reg[4]_i_19__4_n_0 ),
        .CO({\state_reg[4]_i_15__4_n_0 ,\state_reg[4]_i_15__4_n_1 ,\state_reg[4]_i_15__4_n_2 ,\state_reg[4]_i_15__4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__4_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__4_n_4 ,\state_reg[4]_i_15__4_n_5 ,\state_reg[4]_i_15__4_n_6 ,\state_reg[4]_i_15__4_n_7 }),
        .S({\state[4]_i_33__4_n_0 ,\state[4]_i_34__4_n_0 ,\state[4]_i_35__4_n_0 ,\state[4]_i_36__4_n_0 }));
  CARRY4 \state_reg[4]_i_19__4 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__4_n_0 ,\state_reg[4]_i_19__4_n_1 ,\state_reg[4]_i_19__4_n_2 ,\state_reg[4]_i_19__4_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_5__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__4_n_4 ,\state_reg[4]_i_19__4_n_5 ,\state_reg[4]_i_19__4_n_6 ,\NLW_state_reg[4]_i_19__4_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__4_n_0 ,\state[4]_i_38__4_n_0 ,\state[4]_i_39__4_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__4 
       (.CI(\state_reg[4]_i_2__4_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__4_CO_UNCONNECTED [3],seconds_relay_5[4],\state_reg[4]_i_1__4_n_2 ,\state_reg[4]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__4_n_1 ,\state_reg[4]_i_3__4_n_7 ,\state_reg[4]_i_4__4_n_4 }),
        .O({\NLW_state_reg[4]_i_1__4_O_UNCONNECTED [3:2],\state_reg[4]_i_1__4_n_6 ,\state_reg[4]_i_1__4_n_7 }),
        .S({1'b0,\state[4]_i_5__4_n_0 ,\state[4]_i_6__4_n_0 ,\state[4]_i_7__4_n_0 }));
  CARRY4 \state_reg[4]_i_2__4 
       (.CI(\state_reg[4]_i_8__4_n_0 ),
        .CO({\state_reg[4]_i_2__4_n_0 ,\state_reg[4]_i_2__4_n_1 ,\state_reg[4]_i_2__4_n_2 ,\state_reg[4]_i_2__4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__4_n_5 ,\state_reg[4]_i_4__4_n_6 ,\state_reg[4]_i_4__4_n_7 ,\state_reg[4]_i_9__4_n_4 }),
        .O({\state_reg[4]_i_2__4_n_4 ,\state_reg[4]_i_2__4_n_5 ,\state_reg[4]_i_2__4_n_6 ,\state_reg[4]_i_2__4_n_7 }),
        .S({\state[4]_i_10__4_n_0 ,\state[4]_i_11__4_n_0 ,\state[4]_i_12__4_n_0 ,\state[4]_i_13__4_n_0 }));
  CARRY4 \state_reg[4]_i_3__4 
       (.CI(\state_reg[4]_i_4__4_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__4_CO_UNCONNECTED [3],\state_reg[4]_i_3__4_n_1 ,\state_reg[4]_i_3__4_n_2 ,\state_reg[4]_i_3__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__4_n_1 ,\state_reg[4]_i_14__4_n_7 ,\state_reg[4]_i_15__4_n_4 }),
        .O({\NLW_state_reg[4]_i_3__4_O_UNCONNECTED [3:2],\state_reg[4]_i_3__4_n_6 ,\state_reg[4]_i_3__4_n_7 }),
        .S({1'b0,\state[4]_i_16__4_n_0 ,\state[4]_i_17__4_n_0 ,\state[4]_i_18__4_n_0 }));
  CARRY4 \state_reg[4]_i_4__4 
       (.CI(\state_reg[4]_i_9__4_n_0 ),
        .CO({\state_reg[4]_i_4__4_n_0 ,\state_reg[4]_i_4__4_n_1 ,\state_reg[4]_i_4__4_n_2 ,\state_reg[4]_i_4__4_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__4_n_5 ,\state_reg[4]_i_15__4_n_6 ,\state_reg[4]_i_15__4_n_7 ,\state_reg[4]_i_19__4_n_4 }),
        .O({\state_reg[4]_i_4__4_n_4 ,\state_reg[4]_i_4__4_n_5 ,\state_reg[4]_i_4__4_n_6 ,\state_reg[4]_i_4__4_n_7 }),
        .S({\state[4]_i_20__4_n_0 ,\state[4]_i_21__4_n_0 ,\state[4]_i_22__4_n_0 ,\state[4]_i_23__4_n_0 }));
  CARRY4 \state_reg[4]_i_8__4 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__4_n_0 ,\state_reg[4]_i_8__4_n_1 ,\state_reg[4]_i_8__4_n_2 ,\state_reg[4]_i_8__4_n_3 }),
        .CYINIT(\state_reg[4]_i_3__4_n_1 ),
        .DI({\state_reg[4]_i_9__4_n_5 ,\state_reg[4]_i_9__4_n_6 ,seconds_relay_5__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__4_n_4 ,\state_reg[4]_i_8__4_n_5 ,\state_reg[4]_i_8__4_n_6 ,\NLW_state_reg[4]_i_8__4_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__4_n_0 ,\state[4]_i_25__4_n_0 ,\state[4]_i_26__4_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__4 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__4_n_0 ,\state_reg[4]_i_9__4_n_1 ,\state_reg[4]_i_9__4_n_2 ,\state_reg[4]_i_9__4_n_3 }),
        .CYINIT(\state_reg[4]_i_14__4_n_1 ),
        .DI({\state_reg[4]_i_19__4_n_5 ,\state_reg[4]_i_19__4_n_6 ,seconds_relay_5__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__4_n_4 ,\state_reg[4]_i_9__4_n_5 ,\state_reg[4]_i_9__4_n_6 ,\NLW_state_reg[4]_i_9__4_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__4_n_0 ,\state[4]_i_28__4_n_0 ,\state[4]_i_29__4_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_5
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg8_reg[1] ,
    \slv_reg8_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__5_0 ,
    Q,
    seconds_relay_6__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__5_0 ,
    D,
    \state_reg[4]_i_14__5_1 ,
    \state_reg[4]_1 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg8_reg[1] ;
  output [3:0]\slv_reg8_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__5_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_6__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__5_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__5_1 ;
  input [1:0]\state_reg[4]_1 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_6;
  wire seconds_relay_6__274_carry__0_i_1_n_0;
  wire seconds_relay_6__274_carry__0_i_1_n_1;
  wire seconds_relay_6__274_carry__0_i_1_n_2;
  wire seconds_relay_6__274_carry__0_i_1_n_3;
  wire seconds_relay_6__274_carry__0_i_6_n_0;
  wire seconds_relay_6__274_carry__0_i_7_n_0;
  wire seconds_relay_6__274_carry__0_i_8_n_0;
  wire seconds_relay_6__274_carry__0_i_9_n_0;
  wire seconds_relay_6__274_carry_i_10_n_0;
  wire seconds_relay_6__274_carry_i_11_n_0;
  wire seconds_relay_6__274_carry_i_12_n_0;
  wire seconds_relay_6__274_carry_i_1_n_0;
  wire seconds_relay_6__274_carry_i_1_n_1;
  wire seconds_relay_6__274_carry_i_1_n_2;
  wire seconds_relay_6__274_carry_i_1_n_3;
  wire seconds_relay_6__274_carry_i_6_n_0;
  wire seconds_relay_6__274_carry_i_6_n_1;
  wire seconds_relay_6__274_carry_i_6_n_2;
  wire seconds_relay_6__274_carry_i_6_n_3;
  wire seconds_relay_6__274_carry_i_6_n_4;
  wire seconds_relay_6__274_carry_i_6_n_5;
  wire seconds_relay_6__274_carry_i_6_n_6;
  wire seconds_relay_6__274_carry_i_7_n_0;
  wire seconds_relay_6__274_carry_i_8_n_0;
  wire seconds_relay_6__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_6__8_carry__0_i_6;
  wire [2:0]\slv_reg8_reg[1] ;
  wire [3:0]\slv_reg8_reg[1]_0 ;
  wire \state[1]_i_2__5_n_0 ;
  wire \state[1]_i_3__5_n_0 ;
  wire \state[1]_i_4__5_n_0 ;
  wire \state[2]_i_3__5_n_0 ;
  wire \state[2]_i_4__5_n_0 ;
  wire \state[2]_i_5__5_n_0 ;
  wire \state[2]_i_6__5_n_0 ;
  wire \state[2]_i_7__5_n_0 ;
  wire \state[2]_i_8__5_n_0 ;
  wire \state[2]_i_9__5_n_0 ;
  wire \state[3]_i_10__5_n_0 ;
  wire \state[3]_i_11__5_n_0 ;
  wire \state[3]_i_12__5_n_0 ;
  wire \state[3]_i_13__5_n_0 ;
  wire \state[3]_i_3__5_n_0 ;
  wire \state[3]_i_4__5_n_0 ;
  wire \state[3]_i_5__5_n_0 ;
  wire \state[3]_i_7__5_n_0 ;
  wire \state[3]_i_8__5_n_0 ;
  wire \state[3]_i_9__5_n_0 ;
  wire \state[4]_i_10__5_n_0 ;
  wire \state[4]_i_11__5_n_0 ;
  wire \state[4]_i_12__5_n_0 ;
  wire \state[4]_i_13__5_n_0 ;
  wire \state[4]_i_16__5_n_0 ;
  wire \state[4]_i_17__5_n_0 ;
  wire \state[4]_i_18__5_n_0 ;
  wire \state[4]_i_20__5_n_0 ;
  wire \state[4]_i_21__5_n_0 ;
  wire \state[4]_i_22__5_n_0 ;
  wire \state[4]_i_23__5_n_0 ;
  wire \state[4]_i_24__5_n_0 ;
  wire \state[4]_i_25__5_n_0 ;
  wire \state[4]_i_26__5_n_0 ;
  wire \state[4]_i_27__5_n_0 ;
  wire \state[4]_i_28__5_n_0 ;
  wire \state[4]_i_29__5_n_0 ;
  wire \state[4]_i_30__5_n_0 ;
  wire \state[4]_i_31__5_n_0 ;
  wire \state[4]_i_32__5_n_0 ;
  wire \state[4]_i_33__5_n_0 ;
  wire \state[4]_i_34__5_n_0 ;
  wire \state[4]_i_35__5_n_0 ;
  wire \state[4]_i_36__5_n_0 ;
  wire \state[4]_i_37__5_n_0 ;
  wire \state[4]_i_38__5_n_0 ;
  wire \state[4]_i_39__5_n_0 ;
  wire \state[4]_i_5__5_n_0 ;
  wire \state[4]_i_6__5_n_0 ;
  wire \state[4]_i_7__5_n_0 ;
  wire [1:0]\state_reg[1]_i_1__5_0 ;
  wire \state_reg[1]_i_1__5_n_2 ;
  wire \state_reg[1]_i_1__5_n_3 ;
  wire \state_reg[1]_i_1__5_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__5_n_2 ;
  wire \state_reg[2]_i_1__5_n_3 ;
  wire \state_reg[2]_i_1__5_n_6 ;
  wire \state_reg[2]_i_1__5_n_7 ;
  wire \state_reg[2]_i_2__5_n_0 ;
  wire \state_reg[2]_i_2__5_n_1 ;
  wire \state_reg[2]_i_2__5_n_2 ;
  wire \state_reg[2]_i_2__5_n_3 ;
  wire \state_reg[2]_i_2__5_n_4 ;
  wire \state_reg[2]_i_2__5_n_5 ;
  wire \state_reg[2]_i_2__5_n_6 ;
  wire \state_reg[2]_i_2__5_n_7 ;
  wire \state_reg[3]_i_1__5_n_2 ;
  wire \state_reg[3]_i_1__5_n_3 ;
  wire \state_reg[3]_i_1__5_n_6 ;
  wire \state_reg[3]_i_1__5_n_7 ;
  wire \state_reg[3]_i_2__5_n_0 ;
  wire \state_reg[3]_i_2__5_n_1 ;
  wire \state_reg[3]_i_2__5_n_2 ;
  wire \state_reg[3]_i_2__5_n_3 ;
  wire \state_reg[3]_i_2__5_n_4 ;
  wire \state_reg[3]_i_2__5_n_5 ;
  wire \state_reg[3]_i_2__5_n_6 ;
  wire \state_reg[3]_i_2__5_n_7 ;
  wire \state_reg[3]_i_6__5_n_0 ;
  wire \state_reg[3]_i_6__5_n_1 ;
  wire \state_reg[3]_i_6__5_n_2 ;
  wire \state_reg[3]_i_6__5_n_3 ;
  wire \state_reg[3]_i_6__5_n_4 ;
  wire \state_reg[3]_i_6__5_n_5 ;
  wire \state_reg[3]_i_6__5_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [1:0]\state_reg[4]_1 ;
  wire [3:0]\state_reg[4]_i_14__5_0 ;
  wire [0:0]\state_reg[4]_i_14__5_1 ;
  wire \state_reg[4]_i_14__5_n_1 ;
  wire \state_reg[4]_i_14__5_n_2 ;
  wire \state_reg[4]_i_14__5_n_3 ;
  wire \state_reg[4]_i_14__5_n_6 ;
  wire \state_reg[4]_i_14__5_n_7 ;
  wire \state_reg[4]_i_15__5_n_0 ;
  wire \state_reg[4]_i_15__5_n_1 ;
  wire \state_reg[4]_i_15__5_n_2 ;
  wire \state_reg[4]_i_15__5_n_3 ;
  wire \state_reg[4]_i_15__5_n_4 ;
  wire \state_reg[4]_i_15__5_n_5 ;
  wire \state_reg[4]_i_15__5_n_6 ;
  wire \state_reg[4]_i_15__5_n_7 ;
  wire \state_reg[4]_i_19__5_n_0 ;
  wire \state_reg[4]_i_19__5_n_1 ;
  wire \state_reg[4]_i_19__5_n_2 ;
  wire \state_reg[4]_i_19__5_n_3 ;
  wire \state_reg[4]_i_19__5_n_4 ;
  wire \state_reg[4]_i_19__5_n_5 ;
  wire \state_reg[4]_i_19__5_n_6 ;
  wire \state_reg[4]_i_1__5_n_2 ;
  wire \state_reg[4]_i_1__5_n_3 ;
  wire \state_reg[4]_i_1__5_n_6 ;
  wire \state_reg[4]_i_1__5_n_7 ;
  wire \state_reg[4]_i_2__5_n_0 ;
  wire \state_reg[4]_i_2__5_n_1 ;
  wire \state_reg[4]_i_2__5_n_2 ;
  wire \state_reg[4]_i_2__5_n_3 ;
  wire \state_reg[4]_i_2__5_n_4 ;
  wire \state_reg[4]_i_2__5_n_5 ;
  wire \state_reg[4]_i_2__5_n_6 ;
  wire \state_reg[4]_i_2__5_n_7 ;
  wire \state_reg[4]_i_3__5_n_1 ;
  wire \state_reg[4]_i_3__5_n_2 ;
  wire \state_reg[4]_i_3__5_n_3 ;
  wire \state_reg[4]_i_3__5_n_6 ;
  wire \state_reg[4]_i_3__5_n_7 ;
  wire \state_reg[4]_i_4__5_n_0 ;
  wire \state_reg[4]_i_4__5_n_1 ;
  wire \state_reg[4]_i_4__5_n_2 ;
  wire \state_reg[4]_i_4__5_n_3 ;
  wire \state_reg[4]_i_4__5_n_4 ;
  wire \state_reg[4]_i_4__5_n_5 ;
  wire \state_reg[4]_i_4__5_n_6 ;
  wire \state_reg[4]_i_4__5_n_7 ;
  wire \state_reg[4]_i_8__5_n_0 ;
  wire \state_reg[4]_i_8__5_n_1 ;
  wire \state_reg[4]_i_8__5_n_2 ;
  wire \state_reg[4]_i_8__5_n_3 ;
  wire \state_reg[4]_i_8__5_n_4 ;
  wire \state_reg[4]_i_8__5_n_5 ;
  wire \state_reg[4]_i_8__5_n_6 ;
  wire \state_reg[4]_i_9__5_n_0 ;
  wire \state_reg[4]_i_9__5_n_1 ;
  wire \state_reg[4]_i_9__5_n_2 ;
  wire \state_reg[4]_i_9__5_n_3 ;
  wire \state_reg[4]_i_9__5_n_4 ;
  wire \state_reg[4]_i_9__5_n_5 ;
  wire \state_reg[4]_i_9__5_n_6 ;
  wire [0:0]NLW_seconds_relay_6__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_6__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__5_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__5_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__5_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__5_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__5_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__5_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__5_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__5_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__5_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__5_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__5
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_6__274_carry__0_i_1
       (.CI(seconds_relay_6__274_carry_i_1_n_0),
        .CO({seconds_relay_6__274_carry__0_i_1_n_0,seconds_relay_6__274_carry__0_i_1_n_1,seconds_relay_6__274_carry__0_i_1_n_2,seconds_relay_6__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__5_n_5 ,\state_reg[2]_i_2__5_n_6 ,\state_reg[2]_i_2__5_n_7 ,seconds_relay_6__274_carry_i_6_n_4}),
        .O(\slv_reg8_reg[1]_0 ),
        .S({seconds_relay_6__274_carry__0_i_6_n_0,seconds_relay_6__274_carry__0_i_7_n_0,seconds_relay_6__274_carry__0_i_8_n_0,seconds_relay_6__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_6
       (.I0(seconds_relay_6[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__5_n_5 ),
        .O(seconds_relay_6__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_7
       (.I0(seconds_relay_6[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__5_n_6 ),
        .O(seconds_relay_6__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_8
       (.I0(seconds_relay_6[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__5_n_7 ),
        .O(seconds_relay_6__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__0_i_9
       (.I0(seconds_relay_6[2]),
        .I1(Q[3]),
        .I2(seconds_relay_6__274_carry_i_6_n_4),
        .O(seconds_relay_6__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__5_n_6 ),
        .O(\state_reg[1]_i_1__5_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__5_0 [0]));
  CARRY4 seconds_relay_6__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_6__274_carry_i_1_n_0,seconds_relay_6__274_carry_i_1_n_1,seconds_relay_6__274_carry_i_1_n_2,seconds_relay_6__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_6[2]),
        .DI({seconds_relay_6__274_carry_i_6_n_5,seconds_relay_6__274_carry_i_6_n_6,seconds_relay_6__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg8_reg[1] ,NLW_seconds_relay_6__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_6__274_carry_i_7_n_0,seconds_relay_6__274_carry_i_8_n_0,seconds_relay_6__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_10
       (.I0(seconds_relay_6[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__5_n_5 ),
        .O(seconds_relay_6__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_11
       (.I0(seconds_relay_6[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__5_n_6 ),
        .O(seconds_relay_6__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_12
       (.I0(seconds_relay_6[3]),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[1]),
        .O(seconds_relay_6__274_carry_i_12_n_0));
  CARRY4 seconds_relay_6__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_6__274_carry_i_6_n_0,seconds_relay_6__274_carry_i_6_n_1,seconds_relay_6__274_carry_i_6_n_2,seconds_relay_6__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_6[3]),
        .DI({\state_reg[3]_i_6__5_n_5 ,\state_reg[3]_i_6__5_n_6 ,seconds_relay_6__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_6__274_carry_i_6_n_4,seconds_relay_6__274_carry_i_6_n_5,seconds_relay_6__274_carry_i_6_n_6,NLW_seconds_relay_6__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_6__274_carry_i_10_n_0,seconds_relay_6__274_carry_i_11_n_0,seconds_relay_6__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_7
       (.I0(seconds_relay_6[2]),
        .I1(Q[2]),
        .I2(seconds_relay_6__274_carry_i_6_n_5),
        .O(seconds_relay_6__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_8
       (.I0(seconds_relay_6[2]),
        .I1(Q[1]),
        .I2(seconds_relay_6__274_carry_i_6_n_6),
        .O(seconds_relay_6__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_6__274_carry_i_9
       (.I0(seconds_relay_6[2]),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[0]),
        .O(seconds_relay_6__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_6__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_6__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_6__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_6__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_6__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_6__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_6__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__5 
       (.I0(seconds_relay_6[2]),
        .I1(\state_reg[2]_i_1__5_n_6 ),
        .O(\state[1]_i_2__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__5 
       (.I0(seconds_relay_6[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__5_n_7 ),
        .O(\state[1]_i_3__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__5 
       (.I0(seconds_relay_6[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__5_n_4 ),
        .O(\state[1]_i_4__5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__5 
       (.I0(seconds_relay_6[3]),
        .I1(\state_reg[3]_i_1__5_n_6 ),
        .O(\state[2]_i_3__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__5_n_7 ),
        .O(\state[2]_i_4__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__5_n_4 ),
        .O(\state[2]_i_5__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__5_n_5 ),
        .O(\state[2]_i_6__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__5_n_6 ),
        .O(\state[2]_i_7__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__5_n_7 ),
        .O(\state[2]_i_8__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__5 
       (.I0(seconds_relay_6[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__5_n_4 ),
        .O(\state[2]_i_9__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__5_n_4 ),
        .O(\state[3]_i_10__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__5_n_5 ),
        .O(\state[3]_i_11__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__5_n_6 ),
        .O(\state[3]_i_12__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__5 
       (.I0(seconds_relay_6[4]),
        .I1(\state_reg[4]_i_1__5_n_6 ),
        .O(\state[3]_i_3__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__5_n_7 ),
        .O(\state[3]_i_4__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__5_n_4 ),
        .O(\state[3]_i_5__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__5_n_5 ),
        .O(\state[3]_i_7__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__5_n_6 ),
        .O(\state[3]_i_8__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__5 
       (.I0(seconds_relay_6[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__5_n_7 ),
        .O(\state[3]_i_9__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__5_n_5 ),
        .O(\state[4]_i_10__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__5_n_6 ),
        .O(\state[4]_i_11__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__5_n_7 ),
        .O(\state[4]_i_12__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__5_n_4 ),
        .O(\state[4]_i_13__5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(\state_reg[4]_i_14__5_n_6 ),
        .O(\state[4]_i_16__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__5_n_7 ),
        .O(\state[4]_i_17__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__5_n_4 ),
        .O(\state[4]_i_18__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__5_n_5 ),
        .O(\state[4]_i_20__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__5_n_6 ),
        .O(\state[4]_i_21__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__5_n_7 ),
        .O(\state[4]_i_22__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__5_n_4 ),
        .O(\state[4]_i_23__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__5_n_5 ),
        .O(\state[4]_i_24__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__5_n_6 ),
        .O(\state[4]_i_25__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__5_n_5 ),
        .O(\state[4]_i_27__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__5_n_6 ),
        .O(\state[4]_i_28__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__5 
       (.I0(\state_reg[4]_i_14__5_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__5 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__5_1 ),
        .O(\state[4]_i_30__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__5 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__5_0 [3]),
        .O(\state[4]_i_31__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__5 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__5_0 [2]),
        .O(\state[4]_i_32__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__5 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__5_0 [1]),
        .O(\state[4]_i_33__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__5 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__5_0 [0]),
        .O(\state[4]_i_34__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__5 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__5 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__5 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__5 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__5 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_6__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(\state_reg[4]_i_3__5_n_6 ),
        .O(\state[4]_i_5__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__5_n_7 ),
        .O(\state[4]_i_6__5_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__5 
       (.I0(\state_reg[4]_i_3__5_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__5_n_4 ),
        .O(\state[4]_i_7__5_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[4]_1 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[1]_i_1__5 
       (.CI(seconds_relay_6__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__5_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__5_n_2 ,\state_reg[1]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_6[2],\state_reg[2]_i_1__5_n_7 ,\state_reg[2]_i_2__5_n_4 }),
        .O({\NLW_state_reg[1]_i_1__5_O_UNCONNECTED [3:2],\state_reg[1]_i_1__5_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__5_n_0 ,\state[1]_i_3__5_n_0 ,\state[1]_i_4__5_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_6[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[2]_i_1__5 
       (.CI(\state_reg[2]_i_2__5_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__5_CO_UNCONNECTED [3],seconds_relay_6[2],\state_reg[2]_i_1__5_n_2 ,\state_reg[2]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_6[3],\state_reg[3]_i_1__5_n_7 ,\state_reg[3]_i_2__5_n_4 }),
        .O({\NLW_state_reg[2]_i_1__5_O_UNCONNECTED [3:2],\state_reg[2]_i_1__5_n_6 ,\state_reg[2]_i_1__5_n_7 }),
        .S({1'b0,\state[2]_i_3__5_n_0 ,\state[2]_i_4__5_n_0 ,\state[2]_i_5__5_n_0 }));
  CARRY4 \state_reg[2]_i_2__5 
       (.CI(seconds_relay_6__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__5_n_0 ,\state_reg[2]_i_2__5_n_1 ,\state_reg[2]_i_2__5_n_2 ,\state_reg[2]_i_2__5_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__5_n_5 ,\state_reg[3]_i_2__5_n_6 ,\state_reg[3]_i_2__5_n_7 ,\state_reg[3]_i_6__5_n_4 }),
        .O({\state_reg[2]_i_2__5_n_4 ,\state_reg[2]_i_2__5_n_5 ,\state_reg[2]_i_2__5_n_6 ,\state_reg[2]_i_2__5_n_7 }),
        .S({\state[2]_i_6__5_n_0 ,\state[2]_i_7__5_n_0 ,\state[2]_i_8__5_n_0 ,\state[2]_i_9__5_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_6[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[3]_i_1__5 
       (.CI(\state_reg[3]_i_2__5_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__5_CO_UNCONNECTED [3],seconds_relay_6[3],\state_reg[3]_i_1__5_n_2 ,\state_reg[3]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_6[4],\state_reg[4]_i_1__5_n_7 ,\state_reg[4]_i_2__5_n_4 }),
        .O({\NLW_state_reg[3]_i_1__5_O_UNCONNECTED [3:2],\state_reg[3]_i_1__5_n_6 ,\state_reg[3]_i_1__5_n_7 }),
        .S({1'b0,\state[3]_i_3__5_n_0 ,\state[3]_i_4__5_n_0 ,\state[3]_i_5__5_n_0 }));
  CARRY4 \state_reg[3]_i_2__5 
       (.CI(\state_reg[3]_i_6__5_n_0 ),
        .CO({\state_reg[3]_i_2__5_n_0 ,\state_reg[3]_i_2__5_n_1 ,\state_reg[3]_i_2__5_n_2 ,\state_reg[3]_i_2__5_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__5_n_5 ,\state_reg[4]_i_2__5_n_6 ,\state_reg[4]_i_2__5_n_7 ,\state_reg[4]_i_8__5_n_4 }),
        .O({\state_reg[3]_i_2__5_n_4 ,\state_reg[3]_i_2__5_n_5 ,\state_reg[3]_i_2__5_n_6 ,\state_reg[3]_i_2__5_n_7 }),
        .S({\state[3]_i_7__5_n_0 ,\state[3]_i_8__5_n_0 ,\state[3]_i_9__5_n_0 ,\state[3]_i_10__5_n_0 }));
  CARRY4 \state_reg[3]_i_6__5 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__5_n_0 ,\state_reg[3]_i_6__5_n_1 ,\state_reg[3]_i_6__5_n_2 ,\state_reg[3]_i_6__5_n_3 }),
        .CYINIT(seconds_relay_6[4]),
        .DI({\state_reg[4]_i_8__5_n_5 ,\state_reg[4]_i_8__5_n_6 ,seconds_relay_6__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__5_n_4 ,\state_reg[3]_i_6__5_n_5 ,\state_reg[3]_i_6__5_n_6 ,\NLW_state_reg[3]_i_6__5_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__5_n_0 ,\state[3]_i_12__5_n_0 ,\state[3]_i_13__5_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[4]_1 [1]),
        .D(seconds_relay_6[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[4]_1 [0]));
  CARRY4 \state_reg[4]_i_14__5 
       (.CI(\state_reg[4]_i_15__5_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__5_CO_UNCONNECTED [3],\state_reg[4]_i_14__5_n_1 ,\state_reg[4]_i_14__5_n_2 ,\state_reg[4]_i_14__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__5_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__5_O_UNCONNECTED [3:2],\state_reg[4]_i_14__5_n_6 ,\state_reg[4]_i_14__5_n_7 }),
        .S({1'b0,\state[4]_i_30__5_n_0 ,\state[4]_i_31__5_n_0 ,\state[4]_i_32__5_n_0 }));
  CARRY4 \state_reg[4]_i_15__5 
       (.CI(\state_reg[4]_i_19__5_n_0 ),
        .CO({\state_reg[4]_i_15__5_n_0 ,\state_reg[4]_i_15__5_n_1 ,\state_reg[4]_i_15__5_n_2 ,\state_reg[4]_i_15__5_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__5_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__5_n_4 ,\state_reg[4]_i_15__5_n_5 ,\state_reg[4]_i_15__5_n_6 ,\state_reg[4]_i_15__5_n_7 }),
        .S({\state[4]_i_33__5_n_0 ,\state[4]_i_34__5_n_0 ,\state[4]_i_35__5_n_0 ,\state[4]_i_36__5_n_0 }));
  CARRY4 \state_reg[4]_i_19__5 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__5_n_0 ,\state_reg[4]_i_19__5_n_1 ,\state_reg[4]_i_19__5_n_2 ,\state_reg[4]_i_19__5_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_6__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__5_n_4 ,\state_reg[4]_i_19__5_n_5 ,\state_reg[4]_i_19__5_n_6 ,\NLW_state_reg[4]_i_19__5_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__5_n_0 ,\state[4]_i_38__5_n_0 ,\state[4]_i_39__5_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__5 
       (.CI(\state_reg[4]_i_2__5_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__5_CO_UNCONNECTED [3],seconds_relay_6[4],\state_reg[4]_i_1__5_n_2 ,\state_reg[4]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__5_n_1 ,\state_reg[4]_i_3__5_n_7 ,\state_reg[4]_i_4__5_n_4 }),
        .O({\NLW_state_reg[4]_i_1__5_O_UNCONNECTED [3:2],\state_reg[4]_i_1__5_n_6 ,\state_reg[4]_i_1__5_n_7 }),
        .S({1'b0,\state[4]_i_5__5_n_0 ,\state[4]_i_6__5_n_0 ,\state[4]_i_7__5_n_0 }));
  CARRY4 \state_reg[4]_i_2__5 
       (.CI(\state_reg[4]_i_8__5_n_0 ),
        .CO({\state_reg[4]_i_2__5_n_0 ,\state_reg[4]_i_2__5_n_1 ,\state_reg[4]_i_2__5_n_2 ,\state_reg[4]_i_2__5_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__5_n_5 ,\state_reg[4]_i_4__5_n_6 ,\state_reg[4]_i_4__5_n_7 ,\state_reg[4]_i_9__5_n_4 }),
        .O({\state_reg[4]_i_2__5_n_4 ,\state_reg[4]_i_2__5_n_5 ,\state_reg[4]_i_2__5_n_6 ,\state_reg[4]_i_2__5_n_7 }),
        .S({\state[4]_i_10__5_n_0 ,\state[4]_i_11__5_n_0 ,\state[4]_i_12__5_n_0 ,\state[4]_i_13__5_n_0 }));
  CARRY4 \state_reg[4]_i_3__5 
       (.CI(\state_reg[4]_i_4__5_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__5_CO_UNCONNECTED [3],\state_reg[4]_i_3__5_n_1 ,\state_reg[4]_i_3__5_n_2 ,\state_reg[4]_i_3__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__5_n_1 ,\state_reg[4]_i_14__5_n_7 ,\state_reg[4]_i_15__5_n_4 }),
        .O({\NLW_state_reg[4]_i_3__5_O_UNCONNECTED [3:2],\state_reg[4]_i_3__5_n_6 ,\state_reg[4]_i_3__5_n_7 }),
        .S({1'b0,\state[4]_i_16__5_n_0 ,\state[4]_i_17__5_n_0 ,\state[4]_i_18__5_n_0 }));
  CARRY4 \state_reg[4]_i_4__5 
       (.CI(\state_reg[4]_i_9__5_n_0 ),
        .CO({\state_reg[4]_i_4__5_n_0 ,\state_reg[4]_i_4__5_n_1 ,\state_reg[4]_i_4__5_n_2 ,\state_reg[4]_i_4__5_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__5_n_5 ,\state_reg[4]_i_15__5_n_6 ,\state_reg[4]_i_15__5_n_7 ,\state_reg[4]_i_19__5_n_4 }),
        .O({\state_reg[4]_i_4__5_n_4 ,\state_reg[4]_i_4__5_n_5 ,\state_reg[4]_i_4__5_n_6 ,\state_reg[4]_i_4__5_n_7 }),
        .S({\state[4]_i_20__5_n_0 ,\state[4]_i_21__5_n_0 ,\state[4]_i_22__5_n_0 ,\state[4]_i_23__5_n_0 }));
  CARRY4 \state_reg[4]_i_8__5 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__5_n_0 ,\state_reg[4]_i_8__5_n_1 ,\state_reg[4]_i_8__5_n_2 ,\state_reg[4]_i_8__5_n_3 }),
        .CYINIT(\state_reg[4]_i_3__5_n_1 ),
        .DI({\state_reg[4]_i_9__5_n_5 ,\state_reg[4]_i_9__5_n_6 ,seconds_relay_6__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__5_n_4 ,\state_reg[4]_i_8__5_n_5 ,\state_reg[4]_i_8__5_n_6 ,\NLW_state_reg[4]_i_8__5_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__5_n_0 ,\state[4]_i_25__5_n_0 ,\state[4]_i_26__5_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__5 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__5_n_0 ,\state_reg[4]_i_9__5_n_1 ,\state_reg[4]_i_9__5_n_2 ,\state_reg[4]_i_9__5_n_3 }),
        .CYINIT(\state_reg[4]_i_14__5_n_1 ),
        .DI({\state_reg[4]_i_19__5_n_5 ,\state_reg[4]_i_19__5_n_6 ,seconds_relay_6__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__5_n_4 ,\state_reg[4]_i_9__5_n_5 ,\state_reg[4]_i_9__5_n_6 ,\NLW_state_reg[4]_i_9__5_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__5_n_0 ,\state[4]_i_28__5_n_0 ,\state[4]_i_29__5_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "register" *) 
module design_1_liquid_0_1_register__parameterized0_6
   (\liquid_division_reg_reg[7] ,
    \liquid_division_reg_reg[3] ,
    DI,
    \state_reg[2]_0 ,
    \state_reg[4]_0 ,
    \liquid_division_reg_reg[8] ,
    \slv_reg9_reg[1] ,
    \slv_reg9_reg[1]_0 ,
    \liquid_division_reg_reg[8]_0 ,
    S,
    \state_reg[1]_i_1__6_0 ,
    Q,
    seconds_relay_7__8_carry__0_i_6,
    CO,
    O,
    \state_reg[4]_i_14__6_0 ,
    D,
    \state_reg[4]_i_14__6_1 ,
    \state_reg[0]_0 ,
    s00_axi_aclk);
  output \liquid_division_reg_reg[7] ;
  output \liquid_division_reg_reg[3] ;
  output [1:0]DI;
  output \state_reg[2]_0 ;
  output [4:0]\state_reg[4]_0 ;
  output [0:0]\liquid_division_reg_reg[8] ;
  output [2:0]\slv_reg9_reg[1] ;
  output [3:0]\slv_reg9_reg[1]_0 ;
  output [0:0]\liquid_division_reg_reg[8]_0 ;
  output [1:0]S;
  output [1:0]\state_reg[1]_i_1__6_0 ;
  input [8:0]Q;
  input [6:0]seconds_relay_7__8_carry__0_i_6;
  input [0:0]CO;
  input [3:0]O;
  input [3:0]\state_reg[4]_i_14__6_0 ;
  input [0:0]D;
  input [0:0]\state_reg[4]_i_14__6_1 ;
  input [1:0]\state_reg[0]_0 ;
  input s00_axi_aclk;

  wire [0:0]CO;
  wire [0:0]D;
  wire [1:0]DI;
  wire [3:0]O;
  wire [8:0]Q;
  wire [1:0]S;
  wire \liquid_division_reg_reg[3] ;
  wire \liquid_division_reg_reg[7] ;
  wire [0:0]\liquid_division_reg_reg[8] ;
  wire [0:0]\liquid_division_reg_reg[8]_0 ;
  wire s00_axi_aclk;
  wire [4:2]seconds_relay_7;
  wire seconds_relay_7__274_carry__0_i_1_n_0;
  wire seconds_relay_7__274_carry__0_i_1_n_1;
  wire seconds_relay_7__274_carry__0_i_1_n_2;
  wire seconds_relay_7__274_carry__0_i_1_n_3;
  wire seconds_relay_7__274_carry__0_i_6_n_0;
  wire seconds_relay_7__274_carry__0_i_7_n_0;
  wire seconds_relay_7__274_carry__0_i_8_n_0;
  wire seconds_relay_7__274_carry__0_i_9_n_0;
  wire seconds_relay_7__274_carry_i_10_n_0;
  wire seconds_relay_7__274_carry_i_11_n_0;
  wire seconds_relay_7__274_carry_i_12_n_0;
  wire seconds_relay_7__274_carry_i_1_n_0;
  wire seconds_relay_7__274_carry_i_1_n_1;
  wire seconds_relay_7__274_carry_i_1_n_2;
  wire seconds_relay_7__274_carry_i_1_n_3;
  wire seconds_relay_7__274_carry_i_6_n_0;
  wire seconds_relay_7__274_carry_i_6_n_1;
  wire seconds_relay_7__274_carry_i_6_n_2;
  wire seconds_relay_7__274_carry_i_6_n_3;
  wire seconds_relay_7__274_carry_i_6_n_4;
  wire seconds_relay_7__274_carry_i_6_n_5;
  wire seconds_relay_7__274_carry_i_6_n_6;
  wire seconds_relay_7__274_carry_i_7_n_0;
  wire seconds_relay_7__274_carry_i_8_n_0;
  wire seconds_relay_7__274_carry_i_9_n_0;
  wire [6:0]seconds_relay_7__8_carry__0_i_6;
  wire [2:0]\slv_reg9_reg[1] ;
  wire [3:0]\slv_reg9_reg[1]_0 ;
  wire \state[1]_i_2__6_n_0 ;
  wire \state[1]_i_3__6_n_0 ;
  wire \state[1]_i_4__6_n_0 ;
  wire \state[2]_i_3__6_n_0 ;
  wire \state[2]_i_4__6_n_0 ;
  wire \state[2]_i_5__6_n_0 ;
  wire \state[2]_i_6__6_n_0 ;
  wire \state[2]_i_7__6_n_0 ;
  wire \state[2]_i_8__6_n_0 ;
  wire \state[2]_i_9__6_n_0 ;
  wire \state[3]_i_10__6_n_0 ;
  wire \state[3]_i_11__6_n_0 ;
  wire \state[3]_i_12__6_n_0 ;
  wire \state[3]_i_13__6_n_0 ;
  wire \state[3]_i_3__6_n_0 ;
  wire \state[3]_i_4__6_n_0 ;
  wire \state[3]_i_5__6_n_0 ;
  wire \state[3]_i_7__6_n_0 ;
  wire \state[3]_i_8__6_n_0 ;
  wire \state[3]_i_9__6_n_0 ;
  wire \state[4]_i_10__6_n_0 ;
  wire \state[4]_i_11__6_n_0 ;
  wire \state[4]_i_12__6_n_0 ;
  wire \state[4]_i_13__6_n_0 ;
  wire \state[4]_i_16__6_n_0 ;
  wire \state[4]_i_17__6_n_0 ;
  wire \state[4]_i_18__6_n_0 ;
  wire \state[4]_i_20__6_n_0 ;
  wire \state[4]_i_21__6_n_0 ;
  wire \state[4]_i_22__6_n_0 ;
  wire \state[4]_i_23__6_n_0 ;
  wire \state[4]_i_24__6_n_0 ;
  wire \state[4]_i_25__6_n_0 ;
  wire \state[4]_i_26__6_n_0 ;
  wire \state[4]_i_27__6_n_0 ;
  wire \state[4]_i_28__6_n_0 ;
  wire \state[4]_i_29__6_n_0 ;
  wire \state[4]_i_30__6_n_0 ;
  wire \state[4]_i_31__6_n_0 ;
  wire \state[4]_i_32__6_n_0 ;
  wire \state[4]_i_33__6_n_0 ;
  wire \state[4]_i_34__6_n_0 ;
  wire \state[4]_i_35__6_n_0 ;
  wire \state[4]_i_36__6_n_0 ;
  wire \state[4]_i_37__6_n_0 ;
  wire \state[4]_i_38__6_n_0 ;
  wire \state[4]_i_39__6_n_0 ;
  wire \state[4]_i_5__6_n_0 ;
  wire \state[4]_i_6__6_n_0 ;
  wire \state[4]_i_7__6_n_0 ;
  wire [1:0]\state_reg[0]_0 ;
  wire [1:0]\state_reg[1]_i_1__6_0 ;
  wire \state_reg[1]_i_1__6_n_2 ;
  wire \state_reg[1]_i_1__6_n_3 ;
  wire \state_reg[1]_i_1__6_n_6 ;
  wire \state_reg[2]_0 ;
  wire \state_reg[2]_i_1__6_n_2 ;
  wire \state_reg[2]_i_1__6_n_3 ;
  wire \state_reg[2]_i_1__6_n_6 ;
  wire \state_reg[2]_i_1__6_n_7 ;
  wire \state_reg[2]_i_2__6_n_0 ;
  wire \state_reg[2]_i_2__6_n_1 ;
  wire \state_reg[2]_i_2__6_n_2 ;
  wire \state_reg[2]_i_2__6_n_3 ;
  wire \state_reg[2]_i_2__6_n_4 ;
  wire \state_reg[2]_i_2__6_n_5 ;
  wire \state_reg[2]_i_2__6_n_6 ;
  wire \state_reg[2]_i_2__6_n_7 ;
  wire \state_reg[3]_i_1__6_n_2 ;
  wire \state_reg[3]_i_1__6_n_3 ;
  wire \state_reg[3]_i_1__6_n_6 ;
  wire \state_reg[3]_i_1__6_n_7 ;
  wire \state_reg[3]_i_2__6_n_0 ;
  wire \state_reg[3]_i_2__6_n_1 ;
  wire \state_reg[3]_i_2__6_n_2 ;
  wire \state_reg[3]_i_2__6_n_3 ;
  wire \state_reg[3]_i_2__6_n_4 ;
  wire \state_reg[3]_i_2__6_n_5 ;
  wire \state_reg[3]_i_2__6_n_6 ;
  wire \state_reg[3]_i_2__6_n_7 ;
  wire \state_reg[3]_i_6__6_n_0 ;
  wire \state_reg[3]_i_6__6_n_1 ;
  wire \state_reg[3]_i_6__6_n_2 ;
  wire \state_reg[3]_i_6__6_n_3 ;
  wire \state_reg[3]_i_6__6_n_4 ;
  wire \state_reg[3]_i_6__6_n_5 ;
  wire \state_reg[3]_i_6__6_n_6 ;
  wire [4:0]\state_reg[4]_0 ;
  wire [3:0]\state_reg[4]_i_14__6_0 ;
  wire [0:0]\state_reg[4]_i_14__6_1 ;
  wire \state_reg[4]_i_14__6_n_1 ;
  wire \state_reg[4]_i_14__6_n_2 ;
  wire \state_reg[4]_i_14__6_n_3 ;
  wire \state_reg[4]_i_14__6_n_6 ;
  wire \state_reg[4]_i_14__6_n_7 ;
  wire \state_reg[4]_i_15__6_n_0 ;
  wire \state_reg[4]_i_15__6_n_1 ;
  wire \state_reg[4]_i_15__6_n_2 ;
  wire \state_reg[4]_i_15__6_n_3 ;
  wire \state_reg[4]_i_15__6_n_4 ;
  wire \state_reg[4]_i_15__6_n_5 ;
  wire \state_reg[4]_i_15__6_n_6 ;
  wire \state_reg[4]_i_15__6_n_7 ;
  wire \state_reg[4]_i_19__6_n_0 ;
  wire \state_reg[4]_i_19__6_n_1 ;
  wire \state_reg[4]_i_19__6_n_2 ;
  wire \state_reg[4]_i_19__6_n_3 ;
  wire \state_reg[4]_i_19__6_n_4 ;
  wire \state_reg[4]_i_19__6_n_5 ;
  wire \state_reg[4]_i_19__6_n_6 ;
  wire \state_reg[4]_i_1__6_n_2 ;
  wire \state_reg[4]_i_1__6_n_3 ;
  wire \state_reg[4]_i_1__6_n_6 ;
  wire \state_reg[4]_i_1__6_n_7 ;
  wire \state_reg[4]_i_2__6_n_0 ;
  wire \state_reg[4]_i_2__6_n_1 ;
  wire \state_reg[4]_i_2__6_n_2 ;
  wire \state_reg[4]_i_2__6_n_3 ;
  wire \state_reg[4]_i_2__6_n_4 ;
  wire \state_reg[4]_i_2__6_n_5 ;
  wire \state_reg[4]_i_2__6_n_6 ;
  wire \state_reg[4]_i_2__6_n_7 ;
  wire \state_reg[4]_i_3__6_n_1 ;
  wire \state_reg[4]_i_3__6_n_2 ;
  wire \state_reg[4]_i_3__6_n_3 ;
  wire \state_reg[4]_i_3__6_n_6 ;
  wire \state_reg[4]_i_3__6_n_7 ;
  wire \state_reg[4]_i_4__6_n_0 ;
  wire \state_reg[4]_i_4__6_n_1 ;
  wire \state_reg[4]_i_4__6_n_2 ;
  wire \state_reg[4]_i_4__6_n_3 ;
  wire \state_reg[4]_i_4__6_n_4 ;
  wire \state_reg[4]_i_4__6_n_5 ;
  wire \state_reg[4]_i_4__6_n_6 ;
  wire \state_reg[4]_i_4__6_n_7 ;
  wire \state_reg[4]_i_8__6_n_0 ;
  wire \state_reg[4]_i_8__6_n_1 ;
  wire \state_reg[4]_i_8__6_n_2 ;
  wire \state_reg[4]_i_8__6_n_3 ;
  wire \state_reg[4]_i_8__6_n_4 ;
  wire \state_reg[4]_i_8__6_n_5 ;
  wire \state_reg[4]_i_8__6_n_6 ;
  wire \state_reg[4]_i_9__6_n_0 ;
  wire \state_reg[4]_i_9__6_n_1 ;
  wire \state_reg[4]_i_9__6_n_2 ;
  wire \state_reg[4]_i_9__6_n_3 ;
  wire \state_reg[4]_i_9__6_n_4 ;
  wire \state_reg[4]_i_9__6_n_5 ;
  wire \state_reg[4]_i_9__6_n_6 ;
  wire [0:0]NLW_seconds_relay_7__274_carry_i_1_O_UNCONNECTED;
  wire [0:0]NLW_seconds_relay_7__274_carry_i_6_O_UNCONNECTED;
  wire [3:3]\NLW_state_reg[1]_i_1__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[1]_i_1__6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[2]_i_1__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[2]_i_1__6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[3]_i_1__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[3]_i_1__6_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[3]_i_6__6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_14__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_14__6_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_19__6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_1__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_1__6_O_UNCONNECTED ;
  wire [3:3]\NLW_state_reg[4]_i_3__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_state_reg[4]_i_3__6_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_8__6_O_UNCONNECTED ;
  wire [0:0]\NLW_state_reg[4]_i_9__6_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_2__6
       (.I0(\state_reg[4]_0 [2]),
        .I1(\state_reg[4]_0 [0]),
        .I2(\state_reg[4]_0 [1]),
        .I3(\state_reg[4]_0 [3]),
        .I4(\state_reg[4]_0 [4]),
        .O(\state_reg[2]_0 ));
  CARRY4 seconds_relay_7__274_carry__0_i_1
       (.CI(seconds_relay_7__274_carry_i_1_n_0),
        .CO({seconds_relay_7__274_carry__0_i_1_n_0,seconds_relay_7__274_carry__0_i_1_n_1,seconds_relay_7__274_carry__0_i_1_n_2,seconds_relay_7__274_carry__0_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({\state_reg[2]_i_2__6_n_5 ,\state_reg[2]_i_2__6_n_6 ,\state_reg[2]_i_2__6_n_7 ,seconds_relay_7__274_carry_i_6_n_4}),
        .O(\slv_reg9_reg[1]_0 ),
        .S({seconds_relay_7__274_carry__0_i_6_n_0,seconds_relay_7__274_carry__0_i_7_n_0,seconds_relay_7__274_carry__0_i_8_n_0,seconds_relay_7__274_carry__0_i_9_n_0}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_6
       (.I0(seconds_relay_7[2]),
        .I1(Q[6]),
        .I2(\state_reg[2]_i_2__6_n_5 ),
        .O(seconds_relay_7__274_carry__0_i_6_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_7
       (.I0(seconds_relay_7[2]),
        .I1(Q[5]),
        .I2(\state_reg[2]_i_2__6_n_6 ),
        .O(seconds_relay_7__274_carry__0_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_8
       (.I0(seconds_relay_7[2]),
        .I1(Q[4]),
        .I2(\state_reg[2]_i_2__6_n_7 ),
        .O(seconds_relay_7__274_carry__0_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__0_i_9
       (.I0(seconds_relay_7[2]),
        .I1(Q[3]),
        .I2(seconds_relay_7__274_carry_i_6_n_4),
        .O(seconds_relay_7__274_carry__0_i_9_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__274_carry__1_i_1
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(\state_reg[1]_i_1__6_n_6 ),
        .O(\state_reg[1]_i_1__6_0 [1]));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry__1_i_2
       (.I0(\liquid_division_reg_reg[8] ),
        .I1(Q[8]),
        .I2(\liquid_division_reg_reg[8]_0 ),
        .O(\state_reg[1]_i_1__6_0 [0]));
  CARRY4 seconds_relay_7__274_carry_i_1
       (.CI(1'b0),
        .CO({seconds_relay_7__274_carry_i_1_n_0,seconds_relay_7__274_carry_i_1_n_1,seconds_relay_7__274_carry_i_1_n_2,seconds_relay_7__274_carry_i_1_n_3}),
        .CYINIT(seconds_relay_7[2]),
        .DI({seconds_relay_7__274_carry_i_6_n_5,seconds_relay_7__274_carry_i_6_n_6,seconds_relay_7__8_carry__0_i_6[0],1'b0}),
        .O({\slv_reg9_reg[1] ,NLW_seconds_relay_7__274_carry_i_1_O_UNCONNECTED[0]}),
        .S({seconds_relay_7__274_carry_i_7_n_0,seconds_relay_7__274_carry_i_8_n_0,seconds_relay_7__274_carry_i_9_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_10
       (.I0(seconds_relay_7[3]),
        .I1(Q[2]),
        .I2(\state_reg[3]_i_6__6_n_5 ),
        .O(seconds_relay_7__274_carry_i_10_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_11
       (.I0(seconds_relay_7[3]),
        .I1(Q[1]),
        .I2(\state_reg[3]_i_6__6_n_6 ),
        .O(seconds_relay_7__274_carry_i_11_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_12
       (.I0(seconds_relay_7[3]),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[1]),
        .O(seconds_relay_7__274_carry_i_12_n_0));
  CARRY4 seconds_relay_7__274_carry_i_6
       (.CI(1'b0),
        .CO({seconds_relay_7__274_carry_i_6_n_0,seconds_relay_7__274_carry_i_6_n_1,seconds_relay_7__274_carry_i_6_n_2,seconds_relay_7__274_carry_i_6_n_3}),
        .CYINIT(seconds_relay_7[3]),
        .DI({\state_reg[3]_i_6__6_n_5 ,\state_reg[3]_i_6__6_n_6 ,seconds_relay_7__8_carry__0_i_6[1],1'b0}),
        .O({seconds_relay_7__274_carry_i_6_n_4,seconds_relay_7__274_carry_i_6_n_5,seconds_relay_7__274_carry_i_6_n_6,NLW_seconds_relay_7__274_carry_i_6_O_UNCONNECTED[0]}),
        .S({seconds_relay_7__274_carry_i_10_n_0,seconds_relay_7__274_carry_i_11_n_0,seconds_relay_7__274_carry_i_12_n_0,1'b1}));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_7
       (.I0(seconds_relay_7[2]),
        .I1(Q[2]),
        .I2(seconds_relay_7__274_carry_i_6_n_5),
        .O(seconds_relay_7__274_carry_i_7_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_8
       (.I0(seconds_relay_7[2]),
        .I1(Q[1]),
        .I2(seconds_relay_7__274_carry_i_6_n_6),
        .O(seconds_relay_7__274_carry_i_8_n_0));
  LUT3 #(
    .INIT(8'h96)) 
    seconds_relay_7__274_carry_i_9
       (.I0(seconds_relay_7[2]),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[0]),
        .O(seconds_relay_7__274_carry_i_9_n_0));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_7__8_carry__1_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(DI[1]));
  LUT2 #(
    .INIT(4'h6)) 
    seconds_relay_7__8_carry__1_i_2
       (.I0(Q[8]),
        .I1(\liquid_division_reg_reg[7] ),
        .O(DI[0]));
  LUT5 #(
    .INIT(32'h55555575)) 
    seconds_relay_7__8_carry__1_i_3
       (.I0(Q[8]),
        .I1(Q[6]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[5]),
        .I4(Q[7]),
        .O(S[1]));
  LUT5 #(
    .INIT(32'h99999799)) 
    seconds_relay_7__8_carry__1_i_4
       (.I0(Q[8]),
        .I1(Q[7]),
        .I2(Q[5]),
        .I3(\liquid_division_reg_reg[3] ),
        .I4(Q[6]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    seconds_relay_7__8_carry_i_1
       (.I0(Q[7]),
        .I1(Q[5]),
        .I2(\liquid_division_reg_reg[3] ),
        .I3(Q[6]),
        .I4(Q[8]),
        .O(\liquid_division_reg_reg[7] ));
  LUT6 #(
    .INIT(64'h0000000000001011)) 
    seconds_relay_7__8_carry_i_9
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(seconds_relay_7__8_carry__0_i_6[6]),
        .I3(Q[0]),
        .I4(Q[2]),
        .I5(Q[4]),
        .O(\liquid_division_reg_reg[3] ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[1]_i_2__6 
       (.I0(seconds_relay_7[2]),
        .I1(\state_reg[2]_i_1__6_n_6 ),
        .O(\state[1]_i_2__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_3__6 
       (.I0(seconds_relay_7[2]),
        .I1(Q[8]),
        .I2(\state_reg[2]_i_1__6_n_7 ),
        .O(\state[1]_i_3__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[1]_i_4__6 
       (.I0(seconds_relay_7[2]),
        .I1(Q[7]),
        .I2(\state_reg[2]_i_2__6_n_4 ),
        .O(\state[1]_i_4__6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[2]_i_3__6 
       (.I0(seconds_relay_7[3]),
        .I1(\state_reg[3]_i_1__6_n_6 ),
        .O(\state[2]_i_3__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_4__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[8]),
        .I2(\state_reg[3]_i_1__6_n_7 ),
        .O(\state[2]_i_4__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_5__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[7]),
        .I2(\state_reg[3]_i_2__6_n_4 ),
        .O(\state[2]_i_5__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_6__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[6]),
        .I2(\state_reg[3]_i_2__6_n_5 ),
        .O(\state[2]_i_6__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_7__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[5]),
        .I2(\state_reg[3]_i_2__6_n_6 ),
        .O(\state[2]_i_7__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_8__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[4]),
        .I2(\state_reg[3]_i_2__6_n_7 ),
        .O(\state[2]_i_8__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[2]_i_9__6 
       (.I0(seconds_relay_7[3]),
        .I1(Q[3]),
        .I2(\state_reg[3]_i_6__6_n_4 ),
        .O(\state[2]_i_9__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_10__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_8__6_n_4 ),
        .O(\state[3]_i_10__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_11__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_8__6_n_5 ),
        .O(\state[3]_i_11__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_12__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_8__6_n_6 ),
        .O(\state[3]_i_12__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_13__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[2]),
        .O(\state[3]_i_13__6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[3]_i_3__6 
       (.I0(seconds_relay_7[4]),
        .I1(\state_reg[4]_i_1__6_n_6 ),
        .O(\state[3]_i_3__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_4__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_1__6_n_7 ),
        .O(\state[3]_i_4__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_5__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_2__6_n_4 ),
        .O(\state[3]_i_5__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_7__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_2__6_n_5 ),
        .O(\state[3]_i_7__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_8__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_2__6_n_6 ),
        .O(\state[3]_i_8__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[3]_i_9__6 
       (.I0(seconds_relay_7[4]),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_2__6_n_7 ),
        .O(\state[3]_i_9__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_10__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_4__6_n_5 ),
        .O(\state[4]_i_10__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_11__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_4__6_n_6 ),
        .O(\state[4]_i_11__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_12__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_4__6_n_7 ),
        .O(\state[4]_i_12__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_13__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_9__6_n_4 ),
        .O(\state[4]_i_13__6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_16__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(\state_reg[4]_i_14__6_n_6 ),
        .O(\state[4]_i_16__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_17__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__6_n_7 ),
        .O(\state[4]_i_17__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_18__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_15__6_n_4 ),
        .O(\state[4]_i_18__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_20__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_15__6_n_5 ),
        .O(\state[4]_i_20__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_21__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_15__6_n_6 ),
        .O(\state[4]_i_21__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_22__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[4]),
        .I2(\state_reg[4]_i_15__6_n_7 ),
        .O(\state[4]_i_22__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_23__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[3]),
        .I2(\state_reg[4]_i_19__6_n_4 ),
        .O(\state[4]_i_23__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_24__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_9__6_n_5 ),
        .O(\state[4]_i_24__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_25__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_9__6_n_6 ),
        .O(\state[4]_i_25__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_26__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[3]),
        .O(\state[4]_i_26__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_27__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[2]),
        .I2(\state_reg[4]_i_19__6_n_5 ),
        .O(\state[4]_i_27__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_28__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[1]),
        .I2(\state_reg[4]_i_19__6_n_6 ),
        .O(\state[4]_i_28__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_29__6 
       (.I0(\state_reg[4]_i_14__6_n_1 ),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[4]),
        .O(\state[4]_i_29__6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_30__6 
       (.I0(CO),
        .I1(\state_reg[4]_i_14__6_1 ),
        .O(\state[4]_i_30__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_31__6 
       (.I0(CO),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_14__6_0 [3]),
        .O(\state[4]_i_31__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_32__6 
       (.I0(CO),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_14__6_0 [2]),
        .O(\state[4]_i_32__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_33__6 
       (.I0(CO),
        .I1(Q[6]),
        .I2(\state_reg[4]_i_14__6_0 [1]),
        .O(\state[4]_i_33__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_34__6 
       (.I0(CO),
        .I1(Q[5]),
        .I2(\state_reg[4]_i_14__6_0 [0]),
        .O(\state[4]_i_34__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_35__6 
       (.I0(CO),
        .I1(Q[4]),
        .I2(O[3]),
        .O(\state[4]_i_35__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_36__6 
       (.I0(CO),
        .I1(Q[3]),
        .I2(O[2]),
        .O(\state[4]_i_36__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_37__6 
       (.I0(CO),
        .I1(Q[2]),
        .I2(O[1]),
        .O(\state[4]_i_37__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_38__6 
       (.I0(CO),
        .I1(Q[1]),
        .I2(O[0]),
        .O(\state[4]_i_38__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_39__6 
       (.I0(CO),
        .I1(Q[0]),
        .I2(seconds_relay_7__8_carry__0_i_6[5]),
        .O(\state[4]_i_39__6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \state[4]_i_5__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(\state_reg[4]_i_3__6_n_6 ),
        .O(\state[4]_i_5__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_6__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[8]),
        .I2(\state_reg[4]_i_3__6_n_7 ),
        .O(\state[4]_i_6__6_n_0 ));
  LUT3 #(
    .INIT(8'h96)) 
    \state[4]_i_7__6 
       (.I0(\state_reg[4]_i_3__6_n_1 ),
        .I1(Q[7]),
        .I2(\state_reg[4]_i_4__6_n_4 ),
        .O(\state[4]_i_7__6_n_0 ));
  FDRE \state_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(D),
        .Q(\state_reg[4]_0 [0]),
        .R(\state_reg[0]_0 [0]));
  FDRE \state_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(\liquid_division_reg_reg[8] ),
        .Q(\state_reg[4]_0 [1]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[1]_i_1__6 
       (.CI(seconds_relay_7__274_carry__0_i_1_n_0),
        .CO({\NLW_state_reg[1]_i_1__6_CO_UNCONNECTED [3],\liquid_division_reg_reg[8] ,\state_reg[1]_i_1__6_n_2 ,\state_reg[1]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_7[2],\state_reg[2]_i_1__6_n_7 ,\state_reg[2]_i_2__6_n_4 }),
        .O({\NLW_state_reg[1]_i_1__6_O_UNCONNECTED [3:2],\state_reg[1]_i_1__6_n_6 ,\liquid_division_reg_reg[8]_0 }),
        .S({1'b0,\state[1]_i_2__6_n_0 ,\state[1]_i_3__6_n_0 ,\state[1]_i_4__6_n_0 }));
  FDRE \state_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_7[2]),
        .Q(\state_reg[4]_0 [2]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[2]_i_1__6 
       (.CI(\state_reg[2]_i_2__6_n_0 ),
        .CO({\NLW_state_reg[2]_i_1__6_CO_UNCONNECTED [3],seconds_relay_7[2],\state_reg[2]_i_1__6_n_2 ,\state_reg[2]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_7[3],\state_reg[3]_i_1__6_n_7 ,\state_reg[3]_i_2__6_n_4 }),
        .O({\NLW_state_reg[2]_i_1__6_O_UNCONNECTED [3:2],\state_reg[2]_i_1__6_n_6 ,\state_reg[2]_i_1__6_n_7 }),
        .S({1'b0,\state[2]_i_3__6_n_0 ,\state[2]_i_4__6_n_0 ,\state[2]_i_5__6_n_0 }));
  CARRY4 \state_reg[2]_i_2__6 
       (.CI(seconds_relay_7__274_carry_i_6_n_0),
        .CO({\state_reg[2]_i_2__6_n_0 ,\state_reg[2]_i_2__6_n_1 ,\state_reg[2]_i_2__6_n_2 ,\state_reg[2]_i_2__6_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[3]_i_2__6_n_5 ,\state_reg[3]_i_2__6_n_6 ,\state_reg[3]_i_2__6_n_7 ,\state_reg[3]_i_6__6_n_4 }),
        .O({\state_reg[2]_i_2__6_n_4 ,\state_reg[2]_i_2__6_n_5 ,\state_reg[2]_i_2__6_n_6 ,\state_reg[2]_i_2__6_n_7 }),
        .S({\state[2]_i_6__6_n_0 ,\state[2]_i_7__6_n_0 ,\state[2]_i_8__6_n_0 ,\state[2]_i_9__6_n_0 }));
  FDRE \state_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_7[3]),
        .Q(\state_reg[4]_0 [3]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[3]_i_1__6 
       (.CI(\state_reg[3]_i_2__6_n_0 ),
        .CO({\NLW_state_reg[3]_i_1__6_CO_UNCONNECTED [3],seconds_relay_7[3],\state_reg[3]_i_1__6_n_2 ,\state_reg[3]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,seconds_relay_7[4],\state_reg[4]_i_1__6_n_7 ,\state_reg[4]_i_2__6_n_4 }),
        .O({\NLW_state_reg[3]_i_1__6_O_UNCONNECTED [3:2],\state_reg[3]_i_1__6_n_6 ,\state_reg[3]_i_1__6_n_7 }),
        .S({1'b0,\state[3]_i_3__6_n_0 ,\state[3]_i_4__6_n_0 ,\state[3]_i_5__6_n_0 }));
  CARRY4 \state_reg[3]_i_2__6 
       (.CI(\state_reg[3]_i_6__6_n_0 ),
        .CO({\state_reg[3]_i_2__6_n_0 ,\state_reg[3]_i_2__6_n_1 ,\state_reg[3]_i_2__6_n_2 ,\state_reg[3]_i_2__6_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_2__6_n_5 ,\state_reg[4]_i_2__6_n_6 ,\state_reg[4]_i_2__6_n_7 ,\state_reg[4]_i_8__6_n_4 }),
        .O({\state_reg[3]_i_2__6_n_4 ,\state_reg[3]_i_2__6_n_5 ,\state_reg[3]_i_2__6_n_6 ,\state_reg[3]_i_2__6_n_7 }),
        .S({\state[3]_i_7__6_n_0 ,\state[3]_i_8__6_n_0 ,\state[3]_i_9__6_n_0 ,\state[3]_i_10__6_n_0 }));
  CARRY4 \state_reg[3]_i_6__6 
       (.CI(1'b0),
        .CO({\state_reg[3]_i_6__6_n_0 ,\state_reg[3]_i_6__6_n_1 ,\state_reg[3]_i_6__6_n_2 ,\state_reg[3]_i_6__6_n_3 }),
        .CYINIT(seconds_relay_7[4]),
        .DI({\state_reg[4]_i_8__6_n_5 ,\state_reg[4]_i_8__6_n_6 ,seconds_relay_7__8_carry__0_i_6[2],1'b0}),
        .O({\state_reg[3]_i_6__6_n_4 ,\state_reg[3]_i_6__6_n_5 ,\state_reg[3]_i_6__6_n_6 ,\NLW_state_reg[3]_i_6__6_O_UNCONNECTED [0]}),
        .S({\state[3]_i_11__6_n_0 ,\state[3]_i_12__6_n_0 ,\state[3]_i_13__6_n_0 ,1'b1}));
  FDRE \state_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\state_reg[0]_0 [1]),
        .D(seconds_relay_7[4]),
        .Q(\state_reg[4]_0 [4]),
        .R(\state_reg[0]_0 [0]));
  CARRY4 \state_reg[4]_i_14__6 
       (.CI(\state_reg[4]_i_15__6_n_0 ),
        .CO({\NLW_state_reg[4]_i_14__6_CO_UNCONNECTED [3],\state_reg[4]_i_14__6_n_1 ,\state_reg[4]_i_14__6_n_2 ,\state_reg[4]_i_14__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,CO,\state_reg[4]_i_14__6_0 [3:2]}),
        .O({\NLW_state_reg[4]_i_14__6_O_UNCONNECTED [3:2],\state_reg[4]_i_14__6_n_6 ,\state_reg[4]_i_14__6_n_7 }),
        .S({1'b0,\state[4]_i_30__6_n_0 ,\state[4]_i_31__6_n_0 ,\state[4]_i_32__6_n_0 }));
  CARRY4 \state_reg[4]_i_15__6 
       (.CI(\state_reg[4]_i_19__6_n_0 ),
        .CO({\state_reg[4]_i_15__6_n_0 ,\state_reg[4]_i_15__6_n_1 ,\state_reg[4]_i_15__6_n_2 ,\state_reg[4]_i_15__6_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_14__6_0 [1:0],O[3:2]}),
        .O({\state_reg[4]_i_15__6_n_4 ,\state_reg[4]_i_15__6_n_5 ,\state_reg[4]_i_15__6_n_6 ,\state_reg[4]_i_15__6_n_7 }),
        .S({\state[4]_i_33__6_n_0 ,\state[4]_i_34__6_n_0 ,\state[4]_i_35__6_n_0 ,\state[4]_i_36__6_n_0 }));
  CARRY4 \state_reg[4]_i_19__6 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_19__6_n_0 ,\state_reg[4]_i_19__6_n_1 ,\state_reg[4]_i_19__6_n_2 ,\state_reg[4]_i_19__6_n_3 }),
        .CYINIT(CO),
        .DI({O[1:0],seconds_relay_7__8_carry__0_i_6[5],1'b0}),
        .O({\state_reg[4]_i_19__6_n_4 ,\state_reg[4]_i_19__6_n_5 ,\state_reg[4]_i_19__6_n_6 ,\NLW_state_reg[4]_i_19__6_O_UNCONNECTED [0]}),
        .S({\state[4]_i_37__6_n_0 ,\state[4]_i_38__6_n_0 ,\state[4]_i_39__6_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_1__6 
       (.CI(\state_reg[4]_i_2__6_n_0 ),
        .CO({\NLW_state_reg[4]_i_1__6_CO_UNCONNECTED [3],seconds_relay_7[4],\state_reg[4]_i_1__6_n_2 ,\state_reg[4]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_3__6_n_1 ,\state_reg[4]_i_3__6_n_7 ,\state_reg[4]_i_4__6_n_4 }),
        .O({\NLW_state_reg[4]_i_1__6_O_UNCONNECTED [3:2],\state_reg[4]_i_1__6_n_6 ,\state_reg[4]_i_1__6_n_7 }),
        .S({1'b0,\state[4]_i_5__6_n_0 ,\state[4]_i_6__6_n_0 ,\state[4]_i_7__6_n_0 }));
  CARRY4 \state_reg[4]_i_2__6 
       (.CI(\state_reg[4]_i_8__6_n_0 ),
        .CO({\state_reg[4]_i_2__6_n_0 ,\state_reg[4]_i_2__6_n_1 ,\state_reg[4]_i_2__6_n_2 ,\state_reg[4]_i_2__6_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_4__6_n_5 ,\state_reg[4]_i_4__6_n_6 ,\state_reg[4]_i_4__6_n_7 ,\state_reg[4]_i_9__6_n_4 }),
        .O({\state_reg[4]_i_2__6_n_4 ,\state_reg[4]_i_2__6_n_5 ,\state_reg[4]_i_2__6_n_6 ,\state_reg[4]_i_2__6_n_7 }),
        .S({\state[4]_i_10__6_n_0 ,\state[4]_i_11__6_n_0 ,\state[4]_i_12__6_n_0 ,\state[4]_i_13__6_n_0 }));
  CARRY4 \state_reg[4]_i_3__6 
       (.CI(\state_reg[4]_i_4__6_n_0 ),
        .CO({\NLW_state_reg[4]_i_3__6_CO_UNCONNECTED [3],\state_reg[4]_i_3__6_n_1 ,\state_reg[4]_i_3__6_n_2 ,\state_reg[4]_i_3__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\state_reg[4]_i_14__6_n_1 ,\state_reg[4]_i_14__6_n_7 ,\state_reg[4]_i_15__6_n_4 }),
        .O({\NLW_state_reg[4]_i_3__6_O_UNCONNECTED [3:2],\state_reg[4]_i_3__6_n_6 ,\state_reg[4]_i_3__6_n_7 }),
        .S({1'b0,\state[4]_i_16__6_n_0 ,\state[4]_i_17__6_n_0 ,\state[4]_i_18__6_n_0 }));
  CARRY4 \state_reg[4]_i_4__6 
       (.CI(\state_reg[4]_i_9__6_n_0 ),
        .CO({\state_reg[4]_i_4__6_n_0 ,\state_reg[4]_i_4__6_n_1 ,\state_reg[4]_i_4__6_n_2 ,\state_reg[4]_i_4__6_n_3 }),
        .CYINIT(1'b0),
        .DI({\state_reg[4]_i_15__6_n_5 ,\state_reg[4]_i_15__6_n_6 ,\state_reg[4]_i_15__6_n_7 ,\state_reg[4]_i_19__6_n_4 }),
        .O({\state_reg[4]_i_4__6_n_4 ,\state_reg[4]_i_4__6_n_5 ,\state_reg[4]_i_4__6_n_6 ,\state_reg[4]_i_4__6_n_7 }),
        .S({\state[4]_i_20__6_n_0 ,\state[4]_i_21__6_n_0 ,\state[4]_i_22__6_n_0 ,\state[4]_i_23__6_n_0 }));
  CARRY4 \state_reg[4]_i_8__6 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_8__6_n_0 ,\state_reg[4]_i_8__6_n_1 ,\state_reg[4]_i_8__6_n_2 ,\state_reg[4]_i_8__6_n_3 }),
        .CYINIT(\state_reg[4]_i_3__6_n_1 ),
        .DI({\state_reg[4]_i_9__6_n_5 ,\state_reg[4]_i_9__6_n_6 ,seconds_relay_7__8_carry__0_i_6[3],1'b0}),
        .O({\state_reg[4]_i_8__6_n_4 ,\state_reg[4]_i_8__6_n_5 ,\state_reg[4]_i_8__6_n_6 ,\NLW_state_reg[4]_i_8__6_O_UNCONNECTED [0]}),
        .S({\state[4]_i_24__6_n_0 ,\state[4]_i_25__6_n_0 ,\state[4]_i_26__6_n_0 ,1'b1}));
  CARRY4 \state_reg[4]_i_9__6 
       (.CI(1'b0),
        .CO({\state_reg[4]_i_9__6_n_0 ,\state_reg[4]_i_9__6_n_1 ,\state_reg[4]_i_9__6_n_2 ,\state_reg[4]_i_9__6_n_3 }),
        .CYINIT(\state_reg[4]_i_14__6_n_1 ),
        .DI({\state_reg[4]_i_19__6_n_5 ,\state_reg[4]_i_19__6_n_6 ,seconds_relay_7__8_carry__0_i_6[4],1'b0}),
        .O({\state_reg[4]_i_9__6_n_4 ,\state_reg[4]_i_9__6_n_5 ,\state_reg[4]_i_9__6_n_6 ,\NLW_state_reg[4]_i_9__6_O_UNCONNECTED [0]}),
        .S({\state[4]_i_27__6_n_0 ,\state[4]_i_28__6_n_0 ,\state[4]_i_29__6_n_0 ,1'b1}));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer
   (D,
    started_reg_0,
    counter_out0_out,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1_n_0 ;
  wire \count_clk_cycles[0]_i_2_n_0 ;
  wire \count_clk_cycles[0]_i_4_n_0 ;
  wire \count_clk_cycles[0]_i_5_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out;
  wire counter_out_i_10_n_0;
  wire counter_out_i_5__6_n_0;
  wire counter_out_i_6_n_0;
  wire counter_out_i_7_n_0;
  wire counter_out_i_8_n_0;
  wire counter_out_i_9_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6_n_0),
        .I2(counter_out_i_7_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3_n_0 ,\count_clk_cycles_reg[0]_i_3_n_1 ,\count_clk_cycles_reg[0]_i_3_n_2 ,\count_clk_cycles_reg[0]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3_n_4 ,\count_clk_cycles_reg[0]_i_3_n_5 ,\count_clk_cycles_reg[0]_i_3_n_6 ,\count_clk_cycles_reg[0]_i_3_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1 
       (.CI(\count_clk_cycles_reg[8]_i_1_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1_n_0 ,\count_clk_cycles_reg[12]_i_1_n_1 ,\count_clk_cycles_reg[12]_i_1_n_2 ,\count_clk_cycles_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1_n_4 ,\count_clk_cycles_reg[12]_i_1_n_5 ,\count_clk_cycles_reg[12]_i_1_n_6 ,\count_clk_cycles_reg[12]_i_1_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1 
       (.CI(\count_clk_cycles_reg[12]_i_1_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1_n_0 ,\count_clk_cycles_reg[16]_i_1_n_1 ,\count_clk_cycles_reg[16]_i_1_n_2 ,\count_clk_cycles_reg[16]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1_n_4 ,\count_clk_cycles_reg[16]_i_1_n_5 ,\count_clk_cycles_reg[16]_i_1_n_6 ,\count_clk_cycles_reg[16]_i_1_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1 
       (.CI(\count_clk_cycles_reg[16]_i_1_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1_n_0 ,\count_clk_cycles_reg[20]_i_1_n_1 ,\count_clk_cycles_reg[20]_i_1_n_2 ,\count_clk_cycles_reg[20]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1_n_4 ,\count_clk_cycles_reg[20]_i_1_n_5 ,\count_clk_cycles_reg[20]_i_1_n_6 ,\count_clk_cycles_reg[20]_i_1_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1 
       (.CI(\count_clk_cycles_reg[20]_i_1_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1_n_6 ,\count_clk_cycles_reg[24]_i_1_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1 
       (.CI(\count_clk_cycles_reg[0]_i_3_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1_n_0 ,\count_clk_cycles_reg[4]_i_1_n_1 ,\count_clk_cycles_reg[4]_i_1_n_2 ,\count_clk_cycles_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1_n_4 ,\count_clk_cycles_reg[4]_i_1_n_5 ,\count_clk_cycles_reg[4]_i_1_n_6 ,\count_clk_cycles_reg[4]_i_1_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1 
       (.CI(\count_clk_cycles_reg[4]_i_1_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1_n_0 ,\count_clk_cycles_reg[8]_i_1_n_1 ,\count_clk_cycles_reg[8]_i_1_n_2 ,\count_clk_cycles_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1_n_4 ,\count_clk_cycles_reg[8]_i_1_n_5 ,\count_clk_cycles_reg[8]_i_1_n_6 ,\count_clk_cycles_reg[8]_i_1_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in[4]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__6_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6_n_0),
        .I4(counter_out_i_7_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__6
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__6_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8_n_0),
        .I2(counter_out_i_9_n_0),
        .I3(counter_out_i_10_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__6
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_10
   (D,
    started_reg_0,
    counter_out0_out_14,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_14;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__3_n_0 ;
  wire \count_clk_cycles[0]_i_2__3_n_0 ;
  wire \count_clk_cycles[0]_i_4__3_n_0 ;
  wire \count_clk_cycles[0]_i_5__3_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__3_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__3_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__3_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_14;
  wire counter_out_i_10__3_n_0;
  wire counter_out_i_5__2_n_0;
  wire counter_out_i_6__3_n_0;
  wire counter_out_i_7__3_n_0;
  wire counter_out_i_8__3_n_0;
  wire counter_out_i_9__3_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__3;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__3_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__3_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__3 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__3_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__3 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__3_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__3 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__3_n_0),
        .I2(counter_out_i_7__3_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__3 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__3_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__3_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__3 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__3_n_0 ,\count_clk_cycles_reg[0]_i_3__3_n_1 ,\count_clk_cycles_reg[0]_i_3__3_n_2 ,\count_clk_cycles_reg[0]_i_3__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__3_n_4 ,\count_clk_cycles_reg[0]_i_3__3_n_5 ,\count_clk_cycles_reg[0]_i_3__3_n_6 ,\count_clk_cycles_reg[0]_i_3__3_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__3_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__3_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__3_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__3 
       (.CI(\count_clk_cycles_reg[8]_i_1__3_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__3_n_0 ,\count_clk_cycles_reg[12]_i_1__3_n_1 ,\count_clk_cycles_reg[12]_i_1__3_n_2 ,\count_clk_cycles_reg[12]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__3_n_4 ,\count_clk_cycles_reg[12]_i_1__3_n_5 ,\count_clk_cycles_reg[12]_i_1__3_n_6 ,\count_clk_cycles_reg[12]_i_1__3_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__3_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__3_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__3 
       (.CI(\count_clk_cycles_reg[12]_i_1__3_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__3_n_0 ,\count_clk_cycles_reg[16]_i_1__3_n_1 ,\count_clk_cycles_reg[16]_i_1__3_n_2 ,\count_clk_cycles_reg[16]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__3_n_4 ,\count_clk_cycles_reg[16]_i_1__3_n_5 ,\count_clk_cycles_reg[16]_i_1__3_n_6 ,\count_clk_cycles_reg[16]_i_1__3_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__3_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__3_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__3_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__3 
       (.CI(\count_clk_cycles_reg[16]_i_1__3_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__3_n_0 ,\count_clk_cycles_reg[20]_i_1__3_n_1 ,\count_clk_cycles_reg[20]_i_1__3_n_2 ,\count_clk_cycles_reg[20]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__3_n_4 ,\count_clk_cycles_reg[20]_i_1__3_n_5 ,\count_clk_cycles_reg[20]_i_1__3_n_6 ,\count_clk_cycles_reg[20]_i_1__3_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__3_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__3_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__3 
       (.CI(\count_clk_cycles_reg[20]_i_1__3_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__3_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__3_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__3_n_6 ,\count_clk_cycles_reg[24]_i_1__3_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__3_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__3_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__3 
       (.CI(\count_clk_cycles_reg[0]_i_3__3_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__3_n_0 ,\count_clk_cycles_reg[4]_i_1__3_n_1 ,\count_clk_cycles_reg[4]_i_1__3_n_2 ,\count_clk_cycles_reg[4]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__3_n_4 ,\count_clk_cycles_reg[4]_i_1__3_n_5 ,\count_clk_cycles_reg[4]_i_1__3_n_6 ,\count_clk_cycles_reg[4]_i_1__3_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__3_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__3_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__3_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__3 
       (.CI(\count_clk_cycles_reg[4]_i_1__3_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__3_n_0 ,\count_clk_cycles_reg[8]_i_1__3_n_1 ,\count_clk_cycles_reg[8]_i_1__3_n_2 ,\count_clk_cycles_reg[8]_i_1__3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__3_n_4 ,\count_clk_cycles_reg[8]_i_1__3_n_5 ,\count_clk_cycles_reg[8]_i_1__3_n_6 ,\count_clk_cycles_reg[8]_i_1__3_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__3_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__3_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__3_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__3 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__3[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__3 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__3[1]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__3 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__3[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__3 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__3[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__3 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__3_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__3 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__3_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__3[4]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__3 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__3_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__3[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__3[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__3[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__3[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__3[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__3
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__3_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__3
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__2_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__3_n_0),
        .I4(counter_out_i_7__3_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_14));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__2
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__2_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__3
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__3_n_0),
        .I2(counter_out_i_9__3_n_0),
        .I3(counter_out_i_10__3_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__3_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__3
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__3_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__3
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__3_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__3
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__3_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__2
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_11
   (D,
    started_reg_0,
    counter_out0_out_16,
    counter_out_reg_0,
    Q,
    counter_out_reg_1,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 ,
    \FSM_onehot_current_state[1]_i_2 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_16;
  output counter_out_reg_0;
  input [1:0]Q;
  input counter_out_reg_1;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;
  input [2:0]\FSM_onehot_current_state[1]_i_2 ;

  wire [0:0]D;
  wire [2:0]\FSM_onehot_current_state[1]_i_2 ;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__4_n_0 ;
  wire \count_clk_cycles[0]_i_2__4_n_0 ;
  wire \count_clk_cycles[0]_i_4__4_n_0 ;
  wire \count_clk_cycles[0]_i_5__4_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__4_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__4_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__4_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_16;
  wire counter_out_i_10__4_n_0;
  wire counter_out_i_5__1_n_0;
  wire counter_out_i_6__4_n_0;
  wire counter_out_i_7__4_n_0;
  wire counter_out_i_8__4_n_0;
  wire counter_out_i_9__4_n_0;
  wire counter_out_reg_0;
  wire counter_out_reg_1;
  wire [4:0]p_0_in__4;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__4_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__4_O_UNCONNECTED ;

  LUT4 #(
    .INIT(16'hFFFE)) 
    \FSM_onehot_current_state[1]_i_3 
       (.I0(D),
        .I1(\FSM_onehot_current_state[1]_i_2 [0]),
        .I2(\FSM_onehot_current_state[1]_i_2 [2]),
        .I3(\FSM_onehot_current_state[1]_i_2 [1]),
        .O(counter_out_reg_0));
  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__4 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__4_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__4_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__4 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__4_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__4 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__4_n_0),
        .I2(counter_out_i_7__4_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__4 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__4_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__4_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__4 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__4_n_0 ,\count_clk_cycles_reg[0]_i_3__4_n_1 ,\count_clk_cycles_reg[0]_i_3__4_n_2 ,\count_clk_cycles_reg[0]_i_3__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__4_n_4 ,\count_clk_cycles_reg[0]_i_3__4_n_5 ,\count_clk_cycles_reg[0]_i_3__4_n_6 ,\count_clk_cycles_reg[0]_i_3__4_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__4_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__4_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__4_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__4 
       (.CI(\count_clk_cycles_reg[8]_i_1__4_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__4_n_0 ,\count_clk_cycles_reg[12]_i_1__4_n_1 ,\count_clk_cycles_reg[12]_i_1__4_n_2 ,\count_clk_cycles_reg[12]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__4_n_4 ,\count_clk_cycles_reg[12]_i_1__4_n_5 ,\count_clk_cycles_reg[12]_i_1__4_n_6 ,\count_clk_cycles_reg[12]_i_1__4_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__4_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__4_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__4 
       (.CI(\count_clk_cycles_reg[12]_i_1__4_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__4_n_0 ,\count_clk_cycles_reg[16]_i_1__4_n_1 ,\count_clk_cycles_reg[16]_i_1__4_n_2 ,\count_clk_cycles_reg[16]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__4_n_4 ,\count_clk_cycles_reg[16]_i_1__4_n_5 ,\count_clk_cycles_reg[16]_i_1__4_n_6 ,\count_clk_cycles_reg[16]_i_1__4_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__4_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__4_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__4_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__4 
       (.CI(\count_clk_cycles_reg[16]_i_1__4_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__4_n_0 ,\count_clk_cycles_reg[20]_i_1__4_n_1 ,\count_clk_cycles_reg[20]_i_1__4_n_2 ,\count_clk_cycles_reg[20]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__4_n_4 ,\count_clk_cycles_reg[20]_i_1__4_n_5 ,\count_clk_cycles_reg[20]_i_1__4_n_6 ,\count_clk_cycles_reg[20]_i_1__4_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__4_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__4_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__4 
       (.CI(\count_clk_cycles_reg[20]_i_1__4_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__4_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__4_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__4_n_6 ,\count_clk_cycles_reg[24]_i_1__4_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__4_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__4_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__4 
       (.CI(\count_clk_cycles_reg[0]_i_3__4_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__4_n_0 ,\count_clk_cycles_reg[4]_i_1__4_n_1 ,\count_clk_cycles_reg[4]_i_1__4_n_2 ,\count_clk_cycles_reg[4]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__4_n_4 ,\count_clk_cycles_reg[4]_i_1__4_n_5 ,\count_clk_cycles_reg[4]_i_1__4_n_6 ,\count_clk_cycles_reg[4]_i_1__4_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__4_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__4_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__4_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__4 
       (.CI(\count_clk_cycles_reg[4]_i_1__4_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__4_n_0 ,\count_clk_cycles_reg[8]_i_1__4_n_1 ,\count_clk_cycles_reg[8]_i_1__4_n_2 ,\count_clk_cycles_reg[8]_i_1__4_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__4_n_4 ,\count_clk_cycles_reg[8]_i_1__4_n_5 ,\count_clk_cycles_reg[8]_i_1__4_n_6 ,\count_clk_cycles_reg[8]_i_1__4_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__4_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__4_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__4_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__4 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__4[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__4 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__4[1]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__4 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__4[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__4 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__4[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__4 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__4_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__4 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__4_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__4[4]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__4 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__4_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__4[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__4[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__4[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__4[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__4[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__4
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__4_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__4
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__1_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__4_n_0),
        .I4(counter_out_i_7__4_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_16));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__1
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__1_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__4
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__4_n_0),
        .I2(counter_out_i_9__4_n_0),
        .I3(counter_out_i_10__4_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__4_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__4
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__4_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__4
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__4_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__4
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__4_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_1),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__1
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_12
   (D,
    started_reg_0,
    counter_out0_out_18,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_18;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__5_n_0 ;
  wire \count_clk_cycles[0]_i_2__5_n_0 ;
  wire \count_clk_cycles[0]_i_4__5_n_0 ;
  wire \count_clk_cycles[0]_i_5__5_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__5_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__5_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__5_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_18;
  wire counter_out_i_10__5_n_0;
  wire counter_out_i_5__0_n_0;
  wire counter_out_i_6__5_n_0;
  wire counter_out_i_7__5_n_0;
  wire counter_out_i_8__5_n_0;
  wire counter_out_i_9__5_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__5;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__5_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__5_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__5 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__5_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__5_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__5 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__5_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__5 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__5_n_0),
        .I2(counter_out_i_7__5_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__5 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__5_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__5_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__5 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__5_n_0 ,\count_clk_cycles_reg[0]_i_3__5_n_1 ,\count_clk_cycles_reg[0]_i_3__5_n_2 ,\count_clk_cycles_reg[0]_i_3__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__5_n_4 ,\count_clk_cycles_reg[0]_i_3__5_n_5 ,\count_clk_cycles_reg[0]_i_3__5_n_6 ,\count_clk_cycles_reg[0]_i_3__5_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__5_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__5_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__5_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__5 
       (.CI(\count_clk_cycles_reg[8]_i_1__5_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__5_n_0 ,\count_clk_cycles_reg[12]_i_1__5_n_1 ,\count_clk_cycles_reg[12]_i_1__5_n_2 ,\count_clk_cycles_reg[12]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__5_n_4 ,\count_clk_cycles_reg[12]_i_1__5_n_5 ,\count_clk_cycles_reg[12]_i_1__5_n_6 ,\count_clk_cycles_reg[12]_i_1__5_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__5_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__5_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__5 
       (.CI(\count_clk_cycles_reg[12]_i_1__5_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__5_n_0 ,\count_clk_cycles_reg[16]_i_1__5_n_1 ,\count_clk_cycles_reg[16]_i_1__5_n_2 ,\count_clk_cycles_reg[16]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__5_n_4 ,\count_clk_cycles_reg[16]_i_1__5_n_5 ,\count_clk_cycles_reg[16]_i_1__5_n_6 ,\count_clk_cycles_reg[16]_i_1__5_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__5_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__5_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__5_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__5 
       (.CI(\count_clk_cycles_reg[16]_i_1__5_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__5_n_0 ,\count_clk_cycles_reg[20]_i_1__5_n_1 ,\count_clk_cycles_reg[20]_i_1__5_n_2 ,\count_clk_cycles_reg[20]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__5_n_4 ,\count_clk_cycles_reg[20]_i_1__5_n_5 ,\count_clk_cycles_reg[20]_i_1__5_n_6 ,\count_clk_cycles_reg[20]_i_1__5_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__5_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__5_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__5 
       (.CI(\count_clk_cycles_reg[20]_i_1__5_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__5_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__5_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__5_n_6 ,\count_clk_cycles_reg[24]_i_1__5_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__5_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__5_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__5 
       (.CI(\count_clk_cycles_reg[0]_i_3__5_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__5_n_0 ,\count_clk_cycles_reg[4]_i_1__5_n_1 ,\count_clk_cycles_reg[4]_i_1__5_n_2 ,\count_clk_cycles_reg[4]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__5_n_4 ,\count_clk_cycles_reg[4]_i_1__5_n_5 ,\count_clk_cycles_reg[4]_i_1__5_n_6 ,\count_clk_cycles_reg[4]_i_1__5_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__5_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__5_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__5_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__5 
       (.CI(\count_clk_cycles_reg[4]_i_1__5_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__5_n_0 ,\count_clk_cycles_reg[8]_i_1__5_n_1 ,\count_clk_cycles_reg[8]_i_1__5_n_2 ,\count_clk_cycles_reg[8]_i_1__5_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__5_n_4 ,\count_clk_cycles_reg[8]_i_1__5_n_5 ,\count_clk_cycles_reg[8]_i_1__5_n_6 ,\count_clk_cycles_reg[8]_i_1__5_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__5_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__5_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__5_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__5 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__5[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__5 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__5[1]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__5 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__5[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__5 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__5[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__5 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__5_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__5 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__5_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__5[4]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__5 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__5_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__5[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__5[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__5[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__5[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__5[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__5
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__5_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__5
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__0_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__5_n_0),
        .I4(counter_out_i_7__5_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_18));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__0
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__0_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__5
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__5_n_0),
        .I2(counter_out_i_9__5_n_0),
        .I3(counter_out_i_10__5_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__5_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__5
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__5_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__5
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__5_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__5
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__5_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__0
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_13
   (D,
    started_reg_0,
    counter_out0_out_20,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_20;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__6_n_0 ;
  wire \count_clk_cycles[0]_i_2__6_n_0 ;
  wire \count_clk_cycles[0]_i_4__6_n_0 ;
  wire \count_clk_cycles[0]_i_5__6_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__6_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__6_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__6_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_20;
  wire counter_out_i_10__6_n_0;
  wire counter_out_i_5_n_0;
  wire counter_out_i_6__6_n_0;
  wire counter_out_i_7__6_n_0;
  wire counter_out_i_8__6_n_0;
  wire counter_out_i_9__6_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__6;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__6_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__6_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__6 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__6_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__6_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__6 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__6_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__6 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__6_n_0),
        .I2(counter_out_i_7__6_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__6_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__6 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__6_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__6_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__6 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__6_n_0 ,\count_clk_cycles_reg[0]_i_3__6_n_1 ,\count_clk_cycles_reg[0]_i_3__6_n_2 ,\count_clk_cycles_reg[0]_i_3__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__6_n_4 ,\count_clk_cycles_reg[0]_i_3__6_n_5 ,\count_clk_cycles_reg[0]_i_3__6_n_6 ,\count_clk_cycles_reg[0]_i_3__6_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__6_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__6_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__6_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__6 
       (.CI(\count_clk_cycles_reg[8]_i_1__6_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__6_n_0 ,\count_clk_cycles_reg[12]_i_1__6_n_1 ,\count_clk_cycles_reg[12]_i_1__6_n_2 ,\count_clk_cycles_reg[12]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__6_n_4 ,\count_clk_cycles_reg[12]_i_1__6_n_5 ,\count_clk_cycles_reg[12]_i_1__6_n_6 ,\count_clk_cycles_reg[12]_i_1__6_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__6_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__6_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__6 
       (.CI(\count_clk_cycles_reg[12]_i_1__6_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__6_n_0 ,\count_clk_cycles_reg[16]_i_1__6_n_1 ,\count_clk_cycles_reg[16]_i_1__6_n_2 ,\count_clk_cycles_reg[16]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__6_n_4 ,\count_clk_cycles_reg[16]_i_1__6_n_5 ,\count_clk_cycles_reg[16]_i_1__6_n_6 ,\count_clk_cycles_reg[16]_i_1__6_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__6_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__6_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__6_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__6 
       (.CI(\count_clk_cycles_reg[16]_i_1__6_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__6_n_0 ,\count_clk_cycles_reg[20]_i_1__6_n_1 ,\count_clk_cycles_reg[20]_i_1__6_n_2 ,\count_clk_cycles_reg[20]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__6_n_4 ,\count_clk_cycles_reg[20]_i_1__6_n_5 ,\count_clk_cycles_reg[20]_i_1__6_n_6 ,\count_clk_cycles_reg[20]_i_1__6_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__6_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__6_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__6 
       (.CI(\count_clk_cycles_reg[20]_i_1__6_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__6_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__6_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__6_n_6 ,\count_clk_cycles_reg[24]_i_1__6_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__6_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__6_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__6 
       (.CI(\count_clk_cycles_reg[0]_i_3__6_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__6_n_0 ,\count_clk_cycles_reg[4]_i_1__6_n_1 ,\count_clk_cycles_reg[4]_i_1__6_n_2 ,\count_clk_cycles_reg[4]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__6_n_4 ,\count_clk_cycles_reg[4]_i_1__6_n_5 ,\count_clk_cycles_reg[4]_i_1__6_n_6 ,\count_clk_cycles_reg[4]_i_1__6_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__6_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__6_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__6_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__6 
       (.CI(\count_clk_cycles_reg[4]_i_1__6_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__6_n_0 ,\count_clk_cycles_reg[8]_i_1__6_n_1 ,\count_clk_cycles_reg[8]_i_1__6_n_2 ,\count_clk_cycles_reg[8]_i_1__6_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__6_n_4 ,\count_clk_cycles_reg[8]_i_1__6_n_5 ,\count_clk_cycles_reg[8]_i_1__6_n_6 ,\count_clk_cycles_reg[8]_i_1__6_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__6_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__6_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__6_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__6 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__6[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__6 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__6[1]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__6 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__6[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__6 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__6[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__6 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__6_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__6 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__6_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__6[4]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__6 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__6_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__6[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__6[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__6[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__6[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__6[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__6
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__6_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__6
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__6_n_0),
        .I4(counter_out_i_7__6_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_20));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__6
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__6_n_0),
        .I2(counter_out_i_9__6_n_0),
        .I3(counter_out_i_10__6_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__6_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__6
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__6_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__6
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__6_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__6
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__6_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_7
   (D,
    started_reg_0,
    counter_out0_out_8,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_8;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__0_n_0 ;
  wire \count_clk_cycles[0]_i_2__0_n_0 ;
  wire \count_clk_cycles[0]_i_4__0_n_0 ;
  wire \count_clk_cycles[0]_i_5__0_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__0_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__0_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__0_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_8;
  wire counter_out_i_10__0_n_0;
  wire counter_out_i_5__5_n_0;
  wire counter_out_i_6__0_n_0;
  wire counter_out_i_7__0_n_0;
  wire counter_out_i_8__0_n_0;
  wire counter_out_i_9__0_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__0;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__0_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__0_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__0 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__0_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__0 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__0_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__0 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__0_n_0),
        .I2(counter_out_i_7__0_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__0_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__0 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__0_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__0_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__0 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__0_n_0 ,\count_clk_cycles_reg[0]_i_3__0_n_1 ,\count_clk_cycles_reg[0]_i_3__0_n_2 ,\count_clk_cycles_reg[0]_i_3__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__0_n_4 ,\count_clk_cycles_reg[0]_i_3__0_n_5 ,\count_clk_cycles_reg[0]_i_3__0_n_6 ,\count_clk_cycles_reg[0]_i_3__0_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__0_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__0_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__0_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__0 
       (.CI(\count_clk_cycles_reg[8]_i_1__0_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__0_n_0 ,\count_clk_cycles_reg[12]_i_1__0_n_1 ,\count_clk_cycles_reg[12]_i_1__0_n_2 ,\count_clk_cycles_reg[12]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__0_n_4 ,\count_clk_cycles_reg[12]_i_1__0_n_5 ,\count_clk_cycles_reg[12]_i_1__0_n_6 ,\count_clk_cycles_reg[12]_i_1__0_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__0_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__0_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__0 
       (.CI(\count_clk_cycles_reg[12]_i_1__0_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__0_n_0 ,\count_clk_cycles_reg[16]_i_1__0_n_1 ,\count_clk_cycles_reg[16]_i_1__0_n_2 ,\count_clk_cycles_reg[16]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__0_n_4 ,\count_clk_cycles_reg[16]_i_1__0_n_5 ,\count_clk_cycles_reg[16]_i_1__0_n_6 ,\count_clk_cycles_reg[16]_i_1__0_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__0_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__0_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__0_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__0 
       (.CI(\count_clk_cycles_reg[16]_i_1__0_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__0_n_0 ,\count_clk_cycles_reg[20]_i_1__0_n_1 ,\count_clk_cycles_reg[20]_i_1__0_n_2 ,\count_clk_cycles_reg[20]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__0_n_4 ,\count_clk_cycles_reg[20]_i_1__0_n_5 ,\count_clk_cycles_reg[20]_i_1__0_n_6 ,\count_clk_cycles_reg[20]_i_1__0_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__0_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__0_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__0 
       (.CI(\count_clk_cycles_reg[20]_i_1__0_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__0_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__0_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__0_n_6 ,\count_clk_cycles_reg[24]_i_1__0_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__0_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__0_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__0 
       (.CI(\count_clk_cycles_reg[0]_i_3__0_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__0_n_0 ,\count_clk_cycles_reg[4]_i_1__0_n_1 ,\count_clk_cycles_reg[4]_i_1__0_n_2 ,\count_clk_cycles_reg[4]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__0_n_4 ,\count_clk_cycles_reg[4]_i_1__0_n_5 ,\count_clk_cycles_reg[4]_i_1__0_n_6 ,\count_clk_cycles_reg[4]_i_1__0_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__0_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__0_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__0_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__0 
       (.CI(\count_clk_cycles_reg[4]_i_1__0_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__0_n_0 ,\count_clk_cycles_reg[8]_i_1__0_n_1 ,\count_clk_cycles_reg[8]_i_1__0_n_2 ,\count_clk_cycles_reg[8]_i_1__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__0_n_4 ,\count_clk_cycles_reg[8]_i_1__0_n_5 ,\count_clk_cycles_reg[8]_i_1__0_n_6 ,\count_clk_cycles_reg[8]_i_1__0_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__0_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__0_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__0_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__0 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__0[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__0 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__0 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__0[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__0 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__0[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__0 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__0_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__0 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__0_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__0[4]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__0 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__0_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__0[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__0[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__0[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__0[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__0[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__0
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__0_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__0
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__5_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__0_n_0),
        .I4(counter_out_i_7__0_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_8));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__5
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__5_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__0
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__0_n_0),
        .I2(counter_out_i_9__0_n_0),
        .I3(counter_out_i_10__0_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__0_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__0
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__0_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__0
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__0_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__0
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__0_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__5
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_8
   (D,
    started_reg_0,
    counter_out0_out_10,
    \FSM_onehot_current_state_reg[2] ,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 ,
    p_2_in,
    \FSM_onehot_current_state_reg[1] ,
    \FSM_onehot_current_state_reg[1]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_10;
  output [1:0]\FSM_onehot_current_state_reg[2] ;
  input [2:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;
  input [0:0]p_2_in;
  input [2:0]\FSM_onehot_current_state_reg[1] ;
  input \FSM_onehot_current_state_reg[1]_0 ;

  wire [0:0]D;
  wire [2:0]\FSM_onehot_current_state_reg[1] ;
  wire \FSM_onehot_current_state_reg[1]_0 ;
  wire [1:0]\FSM_onehot_current_state_reg[2] ;
  wire [2:0]Q;
  wire any_relays_enabled__6;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__1_n_0 ;
  wire \count_clk_cycles[0]_i_2__1_n_0 ;
  wire \count_clk_cycles[0]_i_4__1_n_0 ;
  wire \count_clk_cycles[0]_i_5__1_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__1_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__1_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__1_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_10;
  wire counter_out_i_10__1_n_0;
  wire counter_out_i_5__4_n_0;
  wire counter_out_i_6__1_n_0;
  wire counter_out_i_7__1_n_0;
  wire counter_out_i_8__1_n_0;
  wire counter_out_i_9__1_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__1;
  wire [0:0]p_2_in;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__1_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__1_O_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h4F44)) 
    \FSM_onehot_current_state[0]_i_1 
       (.I0(p_2_in),
        .I1(Q[0]),
        .I2(any_relays_enabled__6),
        .I3(Q[1]),
        .O(\FSM_onehot_current_state_reg[2] [0]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \FSM_onehot_current_state[1]_i_1 
       (.I0(Q[2]),
        .I1(any_relays_enabled__6),
        .I2(Q[1]),
        .O(\FSM_onehot_current_state_reg[2] [1]));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \FSM_onehot_current_state[1]_i_2 
       (.I0(D),
        .I1(\FSM_onehot_current_state_reg[1] [2]),
        .I2(\FSM_onehot_current_state_reg[1] [0]),
        .I3(\FSM_onehot_current_state_reg[1] [1]),
        .I4(\FSM_onehot_current_state_reg[1]_0 ),
        .O(any_relays_enabled__6));
  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__1 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__1_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__1 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__1_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__1 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__1_n_0),
        .I2(counter_out_i_7__1_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__1 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__1_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__1_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__1 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__1_n_0 ,\count_clk_cycles_reg[0]_i_3__1_n_1 ,\count_clk_cycles_reg[0]_i_3__1_n_2 ,\count_clk_cycles_reg[0]_i_3__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__1_n_4 ,\count_clk_cycles_reg[0]_i_3__1_n_5 ,\count_clk_cycles_reg[0]_i_3__1_n_6 ,\count_clk_cycles_reg[0]_i_3__1_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__1_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__1_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__1_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__1 
       (.CI(\count_clk_cycles_reg[8]_i_1__1_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__1_n_0 ,\count_clk_cycles_reg[12]_i_1__1_n_1 ,\count_clk_cycles_reg[12]_i_1__1_n_2 ,\count_clk_cycles_reg[12]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__1_n_4 ,\count_clk_cycles_reg[12]_i_1__1_n_5 ,\count_clk_cycles_reg[12]_i_1__1_n_6 ,\count_clk_cycles_reg[12]_i_1__1_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__1_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__1_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__1 
       (.CI(\count_clk_cycles_reg[12]_i_1__1_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__1_n_0 ,\count_clk_cycles_reg[16]_i_1__1_n_1 ,\count_clk_cycles_reg[16]_i_1__1_n_2 ,\count_clk_cycles_reg[16]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__1_n_4 ,\count_clk_cycles_reg[16]_i_1__1_n_5 ,\count_clk_cycles_reg[16]_i_1__1_n_6 ,\count_clk_cycles_reg[16]_i_1__1_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__1_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__1_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__1_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__1 
       (.CI(\count_clk_cycles_reg[16]_i_1__1_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__1_n_0 ,\count_clk_cycles_reg[20]_i_1__1_n_1 ,\count_clk_cycles_reg[20]_i_1__1_n_2 ,\count_clk_cycles_reg[20]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__1_n_4 ,\count_clk_cycles_reg[20]_i_1__1_n_5 ,\count_clk_cycles_reg[20]_i_1__1_n_6 ,\count_clk_cycles_reg[20]_i_1__1_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__1_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__1_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__1 
       (.CI(\count_clk_cycles_reg[20]_i_1__1_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__1_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__1_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__1_n_6 ,\count_clk_cycles_reg[24]_i_1__1_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__1_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__1_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__1 
       (.CI(\count_clk_cycles_reg[0]_i_3__1_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__1_n_0 ,\count_clk_cycles_reg[4]_i_1__1_n_1 ,\count_clk_cycles_reg[4]_i_1__1_n_2 ,\count_clk_cycles_reg[4]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__1_n_4 ,\count_clk_cycles_reg[4]_i_1__1_n_5 ,\count_clk_cycles_reg[4]_i_1__1_n_6 ,\count_clk_cycles_reg[4]_i_1__1_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__1_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__1_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__1_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__1 
       (.CI(\count_clk_cycles_reg[4]_i_1__1_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__1_n_0 ,\count_clk_cycles_reg[8]_i_1__1_n_1 ,\count_clk_cycles_reg[8]_i_1__1_n_2 ,\count_clk_cycles_reg[8]_i_1__1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__1_n_4 ,\count_clk_cycles_reg[8]_i_1__1_n_5 ,\count_clk_cycles_reg[8]_i_1__1_n_6 ,\count_clk_cycles_reg[8]_i_1__1_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__1_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__1_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__1_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__1 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[2]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__1[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__1 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__1[1]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__1 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__1[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__1 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__1[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__1 
       (.I0(started_reg_1),
        .I1(Q[2]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__1_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__1 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__1_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__1[4]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__1 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__1_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__1[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__1[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__1[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__1[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__1[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__1
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__1_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__1
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__4_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__1_n_0),
        .I4(counter_out_i_7__1_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_10));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__4
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__4_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__1
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__1_n_0),
        .I2(counter_out_i_9__1_n_0),
        .I3(counter_out_i_10__1_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__1_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__1
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__1_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__1
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__1_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__1
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__1_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[2]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__4
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule

(* ORIG_REF_NAME = "timer" *) 
module design_1_liquid_0_1_timer_9
   (D,
    started_reg_0,
    counter_out0_out_12,
    Q,
    counter_out_reg_0,
    s00_axi_aclk,
    \count_clk_cycles_reg[0]_0 ,
    started_reg_1,
    prev_was_load,
    \count_seconds_reg[4]_0 );
  output [0:0]D;
  output started_reg_0;
  output counter_out0_out_12;
  input [1:0]Q;
  input counter_out_reg_0;
  input s00_axi_aclk;
  input \count_clk_cycles_reg[0]_0 ;
  input [0:0]started_reg_1;
  input prev_was_load;
  input [4:0]\count_seconds_reg[4]_0 ;

  wire [0:0]D;
  wire [1:0]Q;
  wire count_clk_cycles0__2;
  wire \count_clk_cycles[0]_i_1__2_n_0 ;
  wire \count_clk_cycles[0]_i_2__2_n_0 ;
  wire \count_clk_cycles[0]_i_4__2_n_0 ;
  wire \count_clk_cycles[0]_i_5__2_n_0 ;
  wire [25:1]count_clk_cycles_reg;
  wire \count_clk_cycles_reg[0]_0 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_0 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_1 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_2 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_3 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_4 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_5 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_6 ;
  wire \count_clk_cycles_reg[0]_i_3__2_n_7 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_0 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_1 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_2 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_4 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_5 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[12]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_0 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_1 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_2 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_4 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_5 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[16]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_0 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_1 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_2 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_4 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_5 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[20]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg[24]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[24]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[24]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_0 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_1 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_2 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_4 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_5 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[4]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_0 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_1 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_2 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_3 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_4 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_5 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_6 ;
  wire \count_clk_cycles_reg[8]_i_1__2_n_7 ;
  wire \count_clk_cycles_reg_n_0_[0] ;
  wire count_seconds;
  wire \count_seconds[4]_i_3__2_n_0 ;
  wire [4:0]count_seconds_reg;
  wire [4:0]\count_seconds_reg[4]_0 ;
  wire counter_out0_out_12;
  wire counter_out_i_10__2_n_0;
  wire counter_out_i_5__3_n_0;
  wire counter_out_i_6__2_n_0;
  wire counter_out_i_7__2_n_0;
  wire counter_out_i_8__2_n_0;
  wire counter_out_i_9__2_n_0;
  wire counter_out_reg_0;
  wire [4:0]p_0_in__2;
  wire prev_was_load;
  wire s00_axi_aclk;
  wire started_i_1_n_0;
  wire started_reg_0;
  wire [0:0]started_reg_1;
  wire [3:1]\NLW_count_clk_cycles_reg[24]_i_1__2_CO_UNCONNECTED ;
  wire [3:2]\NLW_count_clk_cycles_reg[24]_i_1__2_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFFAEAA)) 
    \count_clk_cycles[0]_i_1__2 
       (.I0(Q[0]),
        .I1(started_reg_0),
        .I2(\count_clk_cycles[0]_i_4__2_n_0 ),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles_reg[0]_0 ),
        .O(\count_clk_cycles[0]_i_1__2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \count_clk_cycles[0]_i_2__2 
       (.I0(started_reg_0),
        .I1(count_seconds_reg[4]),
        .I2(count_seconds_reg[3]),
        .I3(count_seconds_reg[1]),
        .I4(count_seconds_reg[0]),
        .I5(count_seconds_reg[2]),
        .O(\count_clk_cycles[0]_i_2__2_n_0 ));
  LUT4 #(
    .INIT(16'h45FF)) 
    \count_clk_cycles[0]_i_4__2 
       (.I0(count_clk_cycles_reg[24]),
        .I1(counter_out_i_6__2_n_0),
        .I2(counter_out_i_7__2_n_0),
        .I3(count_clk_cycles_reg[25]),
        .O(\count_clk_cycles[0]_i_4__2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count_clk_cycles[0]_i_5__2 
       (.I0(\count_clk_cycles_reg_n_0_[0] ),
        .O(\count_clk_cycles[0]_i_5__2_n_0 ));
  FDRE \count_clk_cycles_reg[0] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__2_n_7 ),
        .Q(\count_clk_cycles_reg_n_0_[0] ),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[0]_i_3__2 
       (.CI(1'b0),
        .CO({\count_clk_cycles_reg[0]_i_3__2_n_0 ,\count_clk_cycles_reg[0]_i_3__2_n_1 ,\count_clk_cycles_reg[0]_i_3__2_n_2 ,\count_clk_cycles_reg[0]_i_3__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_clk_cycles_reg[0]_i_3__2_n_4 ,\count_clk_cycles_reg[0]_i_3__2_n_5 ,\count_clk_cycles_reg[0]_i_3__2_n_6 ,\count_clk_cycles_reg[0]_i_3__2_n_7 }),
        .S({count_clk_cycles_reg[3:1],\count_clk_cycles[0]_i_5__2_n_0 }));
  FDRE \count_clk_cycles_reg[10] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__2_n_5 ),
        .Q(count_clk_cycles_reg[10]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[11] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__2_n_4 ),
        .Q(count_clk_cycles_reg[11]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[12] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[12]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[12]_i_1__2 
       (.CI(\count_clk_cycles_reg[8]_i_1__2_n_0 ),
        .CO({\count_clk_cycles_reg[12]_i_1__2_n_0 ,\count_clk_cycles_reg[12]_i_1__2_n_1 ,\count_clk_cycles_reg[12]_i_1__2_n_2 ,\count_clk_cycles_reg[12]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[12]_i_1__2_n_4 ,\count_clk_cycles_reg[12]_i_1__2_n_5 ,\count_clk_cycles_reg[12]_i_1__2_n_6 ,\count_clk_cycles_reg[12]_i_1__2_n_7 }),
        .S(count_clk_cycles_reg[15:12]));
  FDRE \count_clk_cycles_reg[13] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[13]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[14] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__2_n_5 ),
        .Q(count_clk_cycles_reg[14]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[15] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[12]_i_1__2_n_4 ),
        .Q(count_clk_cycles_reg[15]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[16] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[16]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[16]_i_1__2 
       (.CI(\count_clk_cycles_reg[12]_i_1__2_n_0 ),
        .CO({\count_clk_cycles_reg[16]_i_1__2_n_0 ,\count_clk_cycles_reg[16]_i_1__2_n_1 ,\count_clk_cycles_reg[16]_i_1__2_n_2 ,\count_clk_cycles_reg[16]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[16]_i_1__2_n_4 ,\count_clk_cycles_reg[16]_i_1__2_n_5 ,\count_clk_cycles_reg[16]_i_1__2_n_6 ,\count_clk_cycles_reg[16]_i_1__2_n_7 }),
        .S(count_clk_cycles_reg[19:16]));
  FDRE \count_clk_cycles_reg[17] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[17]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[18] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__2_n_5 ),
        .Q(count_clk_cycles_reg[18]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[19] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[16]_i_1__2_n_4 ),
        .Q(count_clk_cycles_reg[19]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[1] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__2_n_6 ),
        .Q(count_clk_cycles_reg[1]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[20] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[20]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[20]_i_1__2 
       (.CI(\count_clk_cycles_reg[16]_i_1__2_n_0 ),
        .CO({\count_clk_cycles_reg[20]_i_1__2_n_0 ,\count_clk_cycles_reg[20]_i_1__2_n_1 ,\count_clk_cycles_reg[20]_i_1__2_n_2 ,\count_clk_cycles_reg[20]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[20]_i_1__2_n_4 ,\count_clk_cycles_reg[20]_i_1__2_n_5 ,\count_clk_cycles_reg[20]_i_1__2_n_6 ,\count_clk_cycles_reg[20]_i_1__2_n_7 }),
        .S(count_clk_cycles_reg[23:20]));
  FDRE \count_clk_cycles_reg[21] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[21]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[22] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__2_n_5 ),
        .Q(count_clk_cycles_reg[22]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[23] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[20]_i_1__2_n_4 ),
        .Q(count_clk_cycles_reg[23]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[24] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[24]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[24]_i_1__2 
       (.CI(\count_clk_cycles_reg[20]_i_1__2_n_0 ),
        .CO({\NLW_count_clk_cycles_reg[24]_i_1__2_CO_UNCONNECTED [3:1],\count_clk_cycles_reg[24]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_clk_cycles_reg[24]_i_1__2_O_UNCONNECTED [3:2],\count_clk_cycles_reg[24]_i_1__2_n_6 ,\count_clk_cycles_reg[24]_i_1__2_n_7 }),
        .S({1'b0,1'b0,count_clk_cycles_reg[25:24]}));
  FDRE \count_clk_cycles_reg[25] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[24]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[25]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[2] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__2_n_5 ),
        .Q(count_clk_cycles_reg[2]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[3] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[0]_i_3__2_n_4 ),
        .Q(count_clk_cycles_reg[3]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[4] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[4]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[4]_i_1__2 
       (.CI(\count_clk_cycles_reg[0]_i_3__2_n_0 ),
        .CO({\count_clk_cycles_reg[4]_i_1__2_n_0 ,\count_clk_cycles_reg[4]_i_1__2_n_1 ,\count_clk_cycles_reg[4]_i_1__2_n_2 ,\count_clk_cycles_reg[4]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[4]_i_1__2_n_4 ,\count_clk_cycles_reg[4]_i_1__2_n_5 ,\count_clk_cycles_reg[4]_i_1__2_n_6 ,\count_clk_cycles_reg[4]_i_1__2_n_7 }),
        .S(count_clk_cycles_reg[7:4]));
  FDRE \count_clk_cycles_reg[5] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[5]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[6] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__2_n_5 ),
        .Q(count_clk_cycles_reg[6]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[7] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[4]_i_1__2_n_4 ),
        .Q(count_clk_cycles_reg[7]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  FDRE \count_clk_cycles_reg[8] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__2_n_7 ),
        .Q(count_clk_cycles_reg[8]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_clk_cycles_reg[8]_i_1__2 
       (.CI(\count_clk_cycles_reg[4]_i_1__2_n_0 ),
        .CO({\count_clk_cycles_reg[8]_i_1__2_n_0 ,\count_clk_cycles_reg[8]_i_1__2_n_1 ,\count_clk_cycles_reg[8]_i_1__2_n_2 ,\count_clk_cycles_reg[8]_i_1__2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_clk_cycles_reg[8]_i_1__2_n_4 ,\count_clk_cycles_reg[8]_i_1__2_n_5 ,\count_clk_cycles_reg[8]_i_1__2_n_6 ,\count_clk_cycles_reg[8]_i_1__2_n_7 }),
        .S(count_clk_cycles_reg[11:8]));
  FDRE \count_clk_cycles_reg[9] 
       (.C(s00_axi_aclk),
        .CE(\count_clk_cycles[0]_i_2__2_n_0 ),
        .D(\count_clk_cycles_reg[8]_i_1__2_n_6 ),
        .Q(count_clk_cycles_reg[9]),
        .R(\count_clk_cycles[0]_i_1__2_n_0 ));
  LUT6 #(
    .INIT(64'h00008000FFFFBFFF)) 
    \count_seconds[0]_i_1__2 
       (.I0(\count_seconds_reg[4]_0 [0]),
        .I1(prev_was_load),
        .I2(Q[1]),
        .I3(started_reg_1),
        .I4(started_reg_0),
        .I5(count_seconds_reg[0]),
        .O(p_0_in__2[0]));
  LUT4 #(
    .INIT(16'hB88B)) 
    \count_seconds[1]_i_1__2 
       (.I0(\count_seconds_reg[4]_0 [1]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[0]),
        .I3(count_seconds_reg[1]),
        .O(p_0_in__2[1]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hBBB8888B)) 
    \count_seconds[2]_i_1__2 
       (.I0(\count_seconds_reg[4]_0 [2]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .O(p_0_in__2[2]));
  LUT6 #(
    .INIT(64'hBBBBBBB88888888B)) 
    \count_seconds[3]_i_1__2 
       (.I0(\count_seconds_reg[4]_0 [3]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[0]),
        .I4(count_seconds_reg[2]),
        .I5(count_seconds_reg[3]),
        .O(p_0_in__2[3]));
  LUT6 #(
    .INIT(64'h0000FF0080808080)) 
    \count_seconds[4]_i_1__2 
       (.I0(started_reg_1),
        .I1(Q[1]),
        .I2(prev_was_load),
        .I3(count_clk_cycles0__2),
        .I4(\count_clk_cycles[0]_i_4__2_n_0 ),
        .I5(started_reg_0),
        .O(count_seconds));
  LUT5 #(
    .INIT(32'hB8BB8B88)) 
    \count_seconds[4]_i_2__2 
       (.I0(\count_seconds_reg[4]_0 [4]),
        .I1(\count_clk_cycles_reg[0]_0 ),
        .I2(count_seconds_reg[3]),
        .I3(\count_seconds[4]_i_3__2_n_0 ),
        .I4(count_seconds_reg[4]),
        .O(p_0_in__2[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h01)) 
    \count_seconds[4]_i_3__2 
       (.I0(count_seconds_reg[1]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[2]),
        .O(\count_seconds[4]_i_3__2_n_0 ));
  FDRE \count_seconds_reg[0] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__2[0]),
        .Q(count_seconds_reg[0]),
        .R(Q[0]));
  FDRE \count_seconds_reg[1] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__2[1]),
        .Q(count_seconds_reg[1]),
        .R(Q[0]));
  FDRE \count_seconds_reg[2] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__2[2]),
        .Q(count_seconds_reg[2]),
        .R(Q[0]));
  FDRE \count_seconds_reg[3] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__2[3]),
        .Q(count_seconds_reg[3]),
        .R(Q[0]));
  FDRE \count_seconds_reg[4] 
       (.C(s00_axi_aclk),
        .CE(count_seconds),
        .D(p_0_in__2[4]),
        .Q(count_seconds_reg[4]),
        .R(Q[0]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    counter_out_i_10__2
       (.I0(count_clk_cycles_reg[2]),
        .I1(count_clk_cycles_reg[1]),
        .I2(count_clk_cycles_reg[5]),
        .I3(count_clk_cycles_reg[6]),
        .I4(count_clk_cycles_reg[3]),
        .I5(count_clk_cycles_reg[4]),
        .O(counter_out_i_10__2_n_0));
  LUT6 #(
    .INIT(64'h8A888A8AAAAAAAAA)) 
    counter_out_i_3__2
       (.I0(count_clk_cycles0__2),
        .I1(counter_out_i_5__3_n_0),
        .I2(count_clk_cycles_reg[24]),
        .I3(counter_out_i_6__2_n_0),
        .I4(counter_out_i_7__2_n_0),
        .I5(count_clk_cycles_reg[25]),
        .O(counter_out0_out_12));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFB)) 
    counter_out_i_5__3
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(counter_out_i_5__3_n_0));
  LUT6 #(
    .INIT(64'h000000005555777F)) 
    counter_out_i_6__2
       (.I0(count_clk_cycles_reg[17]),
        .I1(counter_out_i_8__2_n_0),
        .I2(counter_out_i_9__2_n_0),
        .I3(counter_out_i_10__2_n_0),
        .I4(count_clk_cycles_reg[16]),
        .I5(count_clk_cycles_reg[18]),
        .O(counter_out_i_6__2_n_0));
  LUT5 #(
    .INIT(32'h80000000)) 
    counter_out_i_7__2
       (.I0(count_clk_cycles_reg[19]),
        .I1(count_clk_cycles_reg[22]),
        .I2(count_clk_cycles_reg[23]),
        .I3(count_clk_cycles_reg[20]),
        .I4(count_clk_cycles_reg[21]),
        .O(counter_out_i_7__2_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    counter_out_i_8__2
       (.I0(count_clk_cycles_reg[13]),
        .I1(count_clk_cycles_reg[12]),
        .I2(count_clk_cycles_reg[15]),
        .I3(count_clk_cycles_reg[14]),
        .O(counter_out_i_8__2_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    counter_out_i_9__2
       (.I0(count_clk_cycles_reg[7]),
        .I1(count_clk_cycles_reg[10]),
        .I2(count_clk_cycles_reg[11]),
        .I3(count_clk_cycles_reg[8]),
        .I4(count_clk_cycles_reg[9]),
        .O(counter_out_i_9__2_n_0));
  FDRE counter_out_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(counter_out_reg_0),
        .Q(D),
        .R(Q[0]));
  LUT5 #(
    .INIT(32'hB8888888)) 
    started_i_1
       (.I0(count_clk_cycles0__2),
        .I1(started_reg_0),
        .I2(started_reg_1),
        .I3(Q[1]),
        .I4(prev_was_load),
        .O(started_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    started_i_2__3
       (.I0(count_seconds_reg[2]),
        .I1(count_seconds_reg[0]),
        .I2(count_seconds_reg[1]),
        .I3(count_seconds_reg[3]),
        .I4(count_seconds_reg[4]),
        .O(count_clk_cycles0__2));
  FDRE started_reg
       (.C(s00_axi_aclk),
        .CE(1'b1),
        .D(started_i_1_n_0),
        .Q(started_reg_0),
        .R(Q[0]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
